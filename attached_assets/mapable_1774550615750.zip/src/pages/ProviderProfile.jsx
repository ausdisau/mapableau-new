import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Star, MapPin, CheckCircle, Calendar, Clock, Shield, CreditCard, Image, Award, Quote } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TestimonialsSection from "../components/provider/TestimonialsSection";
import CertificationsDisplay from "../components/provider/CertificationsDisplay";
import PortfolioGallery from "../components/provider/PortfolioGallery";

// Placeholder for NDISClaimModal component (would typically be in its own file)
const NDISClaimModal = ({ isOpen, onClose, serviceRequest, onSuccess }) => {
  const [ndisNumber, setNdisNumber] = useState("");
  const [planManagerEmail, setPlanManagerEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNdisClaim = async () => {
    setIsSubmitting(true);
    try {
      // Simulate NDIS claim submission
      const claimDetails = {
        service_request_id: serviceRequest.id,
        ndis_number: ndisNumber,
        plan_manager_email: planManagerEmail,
        status: "submitted",
        amount: serviceRequest.total_cost,
        // Add other relevant details
      };
      // In a real app, you'd send this to your backend to handle NDIS integration
      console.log("Submitting NDIS claim:", claimDetails);

      // Simulate a slight delay for submission
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Create a payment record for NDIS claim (status pending/processing)
      const payment = await base44.entities.Payment.create({
        service_request_id: serviceRequest.id,
        amount: serviceRequest.total_cost,
        payment_method: "ndis_claim",
        status: "pending_ndis_approval", // Or 'processing'
      });

      // Update service request status
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: "pending_payment_confirmation",
        payment_status: "pending_ndis_approval",
      });

      onSuccess(payment);
    } catch (error) {
      console.error("Failed to submit NDIS claim:", error);
      // Handle error, show message to user
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Submit NDIS Claim</DialogTitle>
          <DialogDescription>
            Please provide your NDIS details to submit a claim for this service.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="ndisNumber">NDIS Number</Label>
            <Input
              id="ndisNumber"
              value={ndisNumber}
              onChange={(e) => setNdisNumber(e.target.value)}
              placeholder="e.g., 415309600"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="planManagerEmail">Plan Manager Email (Optional)</Label>
            <Input
              id="planManagerEmail"
              type="email"
              value={planManagerEmail}
              onChange={(e) => setPlanManagerEmail(e.target.value)}
              placeholder="planmanager@example.com"
            />
          </div>
          <Alert>
            <CheckCircle className="w-4 h-4" />
            <AlertDescription>
              A claim for ${serviceRequest?.total_cost.toFixed(2)} will be submitted to NDIS.
              You will be notified once the claim is approved.
            </AlertDescription>
          </Alert>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleNdisClaim} disabled={isSubmitting || !ndisNumber}>
            {isSubmitting ? "Submitting..." : "Submit Claim"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


export default function ProviderProfilePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const providerId = urlParams.get("id");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const [showBooking, setShowBooking] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [showNDISClaim, setShowNDISClaim] = useState(false);
  const [currentServiceRequest, setCurrentServiceRequest] = useState(null);
  const [bookingData, setBookingData] = useState({
    service_type: "personal_care",
    date: "",
    time: "",
    duration_hours: 2,
    location: "",
    notes: "",
  });

  const { data: provider, isLoading } = useQuery({
    queryKey: ["provider", providerId],
    queryFn: async () => {
      const providers = await base44.entities.ServiceProvider.list();
      return providers.find((p) => p.id === providerId);
    },
    enabled: !!providerId,
  });

  const isOwnProfile = currentUser?.email === provider?.email;

  const { data: reviews = [] } = useQuery({
    queryKey: ["providerReviews", providerId],
    queryFn: async () => {
      const allReviews = await base44.entities.Review.list("-created_date");
      return allReviews.filter((r) => r.location_id === providerId);
    },
    enabled: !!providerId,
  });

  const createBookingMutation = useMutation({
    mutationFn: (data) => base44.entities.ServiceRequest.create(data),
    onSuccess: (createdRequest) => {
      queryClient.invalidateQueries({ queryKey: ["myServiceRequests"] });
      setCurrentServiceRequest(createdRequest);
      setShowBooking(false);
      // Show payment options
      setShowPayment(true);
    },
  });

  const handleBooking = () => {
    createBookingMutation.mutate({
      ...bookingData,
      provider_id: providerId,
      status: "pending",
      payment_status: "pending", // Added payment_status
      total_cost: (provider?.hourly_rate || 0) * bookingData.duration_hours,
    });
  };

  const handlePaymentSuccess = (payment) => {
    setShowPayment(false);
    setShowNDISClaim(false);
    navigate(`${createPageUrl("PaymentSuccess")}?payment_id=${payment.id}`);
  };

  if (isLoading || !provider) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("FindCare"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Providers
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Provider Info */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4 mb-6">
                  {provider.photo_url ? (
                    <img
                      src={provider.photo_url}
                      alt={provider.name}
                      className="w-24 h-24 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-3xl">
                        {provider.name?.charAt(0)}
                      </span>
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h1 className="text-3xl font-bold text-primary">{provider.name}</h1>
                      {provider.verified && (
                        <CheckCircle className="w-6 h-6 text-secondary" />
                      )}
                    </div>
                    {provider.rating > 0 && (
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-5 h-5 ${
                                star <= provider.rating
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-600">
                          ({provider.review_count} reviews)
                        </span>
                      </div>
                    )}
                    <Badge className="bg-blue-100 text-blue-700">
                      {provider.type.replace(/_/g, " ")}
                    </Badge>
                  </div>
                </div>

                {provider.bio && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-2">About</h3>
                    <p className="text-gray-700 leading-relaxed">{provider.bio}</p>
                  </div>
                )}

                {provider.specialties && provider.specialties.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-3">Specialties</h3>
                    <div className="flex flex-wrap gap-2">
                      {provider.specialties.map((specialty, idx) => (
                        <Badge key={idx} variant="outline">
                          {specialty.replace(/_/g, " ")}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {provider.qualifications && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-2">Qualifications</h3>
                    <p className="text-gray-700">{provider.qualifications}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Booking Form */}
            {showBooking && (
              <Card>
                <CardHeader>
                  <CardTitle>Book a Service</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={bookingData.date}
                        onChange={(e) => setBookingData({ ...bookingData, date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Time</Label>
                      <Input
                        type="time"
                        value={bookingData.time}
                        onChange={(e) => setBookingData({ ...bookingData, time: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Duration (hours)</Label>
                    <Input
                      type="number"
                      min="1"
                      max="8"
                      value={bookingData.duration_hours}
                      onChange={(e) => setBookingData({ ...bookingData, duration_hours: parseInt(e.target.value) })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Location</Label>
                    <Input
                      placeholder="Where will the service be provided?"
                      value={bookingData.location}
                      onChange={(e) => setBookingData({ ...bookingData, location: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Additional Notes</Label>
                    <Textarea
                      placeholder="Any specific requirements or information..."
                      value={bookingData.notes}
                      onChange={(e) => setBookingData({ ...bookingData, notes: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <Alert>
                    <CheckCircle className="w-4 h-4" />
                    <AlertDescription>
                      Estimated cost: ${((provider.hourly_rate || 0) * bookingData.duration_hours).toFixed(2)}
                      {provider.ndis_registered && " (NDIS claimable)"}
                    </AlertDescription>
                  </Alert>

                  <div className="flex gap-3">
                    <Button
                      onClick={handleBooking}
                      className="flex-1 bg-secondary hover:bg-secondary/90"
                      disabled={!bookingData.date || !bookingData.time || createBookingMutation.isPending}
                    >
                      {createBookingMutation.isPending ? "Creating Booking..." : "Continue to Payment"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowBooking(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {!showBooking && !showPayment && !isOwnProfile && (
              <Button
                onClick={() => setShowBooking(true)}
                className="w-full bg-secondary hover:bg-secondary/90 h-12 text-base"
              >
                Book This Provider
              </Button>
            )}

            {/* Enhanced Profile Sections */}
            <Tabs defaultValue="testimonials" className="mt-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="testimonials" className="gap-2">
                  <Quote className="w-4 h-4" />
                  Testimonials
                </TabsTrigger>
                <TabsTrigger value="certifications" className="gap-2">
                  <Award className="w-4 h-4" />
                  Credentials
                </TabsTrigger>
                <TabsTrigger value="portfolio" className="gap-2">
                  <Image className="w-4 h-4" />
                  Portfolio
                </TabsTrigger>
              </TabsList>

              <TabsContent value="testimonials" className="mt-6">
                <TestimonialsSection providerId={providerId} isOwnProfile={isOwnProfile} />
              </TabsContent>

              <TabsContent value="certifications" className="mt-6">
                <CertificationsDisplay providerEmail={provider?.email} />
              </TabsContent>

              <TabsContent value="portfolio" className="mt-6">
                <PortfolioGallery 
                  providerId={providerId} 
                  providerEmail={provider?.email}
                  isOwnProfile={isOwnProfile}
                />
              </TabsContent>
            </Tabs>

            {/* Payment Options */}
            {showPayment && currentServiceRequest && (
              <Card>
                <CardHeader>
                  <CardTitle>Choose Payment Method</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={() => {
                      if (provider.ndis_registered) {
                        setShowNDISClaim(true);
                      } else {
                        // Optionally, show an alert if NDIS is not registered for this provider
                        alert("This provider is not NDIS registered.");
                      }
                    }}
                    className="w-full h-16 bg-green-600 hover:bg-green-700 text-white"
                    disabled={!provider.ndis_registered} // Disable if provider is not NDIS registered
                  >
                    <Shield className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div className="font-semibold">Pay with NDIS</div>
                      <div className="text-xs opacity-90">Submit claim to NDIS</div>
                    </div>
                  </Button>
                  <Button
                    onClick={() => {
                      setShowPayment(false);
                      // In real implementation, open Stripe modal or redirect to Stripe checkout
                      // For now, simulate immediate success
                      setTimeout(async () => {
                        const payment = await base44.entities.Payment.create({
                          service_request_id: currentServiceRequest.id,
                          amount: currentServiceRequest.total_cost,
                          payment_method: "stripe",
                          status: "succeeded",
                        });
                        // Update service request status
                        await base44.entities.ServiceRequest.update(currentServiceRequest.id, {
                          status: "confirmed",
                          payment_status: "paid",
                        });
                        handlePaymentSuccess(payment);
                      }, 100);
                    }}
                    variant="outline"
                    className="w-full h-16"
                  >
                    <CreditCard className="w-5 h-5 mr-2" />
                    <div className="text-left">
                      <div className="font-semibold">Pay with Card</div>
                      <div className="text-xs text-gray-600">Secure payment via Stripe</div>
                    </div>
                  </Button>
                  <Button variant="ghost" onClick={() => {
                    // Allow user to go back to booking details to modify
                    setShowPayment(false);
                    setShowBooking(true);
                  }}>
                    Back to Booking Details
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Info */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {provider.hourly_rate && (
                  <div>
                    <p className="text-sm text-gray-600">Hourly Rate</p>
                    <p className="text-2xl font-bold text-primary">${provider.hourly_rate}</p>
                  </div>
                )}
                
                {provider.experience_years && (
                  <div>
                    <p className="text-sm text-gray-600">Experience</p>
                    <p className="font-semibold">{provider.experience_years} years</p>
                  </div>
                )}

                {provider.location_suburb && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-secondary" />
                    <span>{provider.location_suburb}, {provider.location_state}</span>
                  </div>
                )}

                {provider.ndis_registered && (
                  <Badge className="bg-green-100 text-green-700 border-green-200 w-full justify-center">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    NDIS Registered Provider
                  </Badge>
                )}

                {provider.mobile_service && (
                  <Badge variant="outline" className="w-full justify-center">
                    Provides Home Visits
                  </Badge>
                )}
              </CardContent>
            </Card>

            {/* Languages */}
            {provider.languages && provider.languages.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Languages</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {provider.languages.map((lang, idx) => (
                      <Badge key={idx} variant="outline">{lang}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Availability */}
            {provider.availability && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Availability</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">{provider.availability}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* NDIS Claim Modal */}
      {currentServiceRequest && (
        <NDISClaimModal
          isOpen={showNDISClaim}
          onClose={() => setShowNDISClaim(false)}
          serviceRequest={currentServiceRequest}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
}