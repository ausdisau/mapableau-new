import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Star, 
  MapPin, 
  Calendar, 
  Award, 
  CheckCircle,
  Phone,
  Mail,
  Users,
  TrendingUp,
  ArrowLeft
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";
import RatingSummary from "../components/transport/RatingSummary";
import ReviewsList from "../components/transport/ReviewsList";

export default function DriverProfilePage() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const driverId = urlParams.get("id");

  const { data: driver, isLoading } = useQuery({
    queryKey: ["driver", driverId],
    queryFn: async () => {
      const drivers = await base44.entities.Driver.list();
      return drivers.find(d => d.id === driverId);
    },
    enabled: !!driverId,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["driverReviews", driverId],
    queryFn: async () => {
      const allReviews = await base44.entities.TransportReview.list("-created_date");
      return allReviews.filter(r => r.driver_id === driverId && r.reviewer_type === "participant");
    },
    enabled: !!driverId,
  });

  if (isLoading || !driver) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length
    : 0;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header Card */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-6">
                  <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="w-12 h-12 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-primary mb-2">{driver.full_name}</h1>
                    {averageRating > 0 && (
                      <div className="flex items-center gap-3 mb-3">
                        <div className="flex items-center gap-2">
                          <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                          <span className="text-xl font-semibold">{averageRating.toFixed(1)}</span>
                        </div>
                        <span className="text-gray-600">({reviews.length} reviews)</span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2">
                      {driver.active && (
                        <Badge className="bg-green-100 text-green-700">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active Driver
                        </Badge>
                      )}
                      <Badge variant="outline">
                        {driver.experience_years} years experience
                      </Badge>
                      <Badge variant="outline">
                        {driver.total_trips} trips completed
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* About */}
            <Card>
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">License Number</p>
                    <p className="font-medium">{driver.license_number}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">License Class</p>
                    <p className="font-medium">{driver.license_class}</p>
                  </div>
                  {driver.license_expiry && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">License Valid Until</p>
                      <p className="font-medium">{format(new Date(driver.license_expiry), "MMMM d, yyyy")}</p>
                    </div>
                  )}
                </div>

                {driver.specializations && driver.specializations.length > 0 && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Specializations</p>
                    <div className="flex flex-wrap gap-2">
                      {driver.specializations.map((spec, idx) => (
                        <Badge key={idx} variant="secondary">
                          {spec.replace(/_/g, " ")}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {driver.languages && driver.languages.length > 0 && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Languages</p>
                    <p className="font-medium">{driver.languages.join(", ")}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Certifications */}
            {driver.background_checks && (
              <Card>
                <CardHeader>
                  <CardTitle>Certifications & Background Checks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {driver.background_checks.ndis_worker_screening && (
                      <div className="flex items-center gap-2 text-green-700">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-medium">NDIS Worker Screening Check</span>
                      </div>
                    )}
                    {driver.background_checks.working_with_children_check && (
                      <div className="flex items-center gap-2 text-green-700">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-medium">Working with Children Check</span>
                      </div>
                    )}
                    {driver.background_checks.police_check_date && (
                      <div className="flex items-center gap-2 text-green-700">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-medium">
                          Police Check (Completed {format(new Date(driver.background_checks.police_check_date), "MMM yyyy")})
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Reviews Section */}
            <Card>
              <CardHeader>
                <CardTitle>Reviews from Participants</CardTitle>
              </CardHeader>
              <CardContent>
                <ReviewsList reviews={reviews} />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Rating Summary */}
            <RatingSummary reviews={reviews} />

            {/* Contact */}
            {(driver.phone || driver.email) && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {driver.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-gray-600" />
                      <span className="text-sm">{driver.phone}</span>
                    </div>
                  )}
                  {driver.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-600" />
                      <span className="text-sm">{driver.email}</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Total Trips</span>
                  <span className="font-bold text-primary">{driver.total_trips}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Experience</span>
                  <span className="font-bold text-primary">{driver.experience_years} years</span>
                </div>
                {averageRating > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Average Rating</span>
                    <span className="font-bold text-primary">{averageRating.toFixed(1)} ★</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}