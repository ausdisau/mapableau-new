import Layout from "./Layout.jsx";

import Map from "./Map";

import LocationDetails from "./LocationDetails";

import AddLocation from "./AddLocation";

import Dashboard from "./Dashboard";

import FindCare from "./FindCare";

import FindJobs from "./FindJobs";

import ProviderProfile from "./ProviderProfile";

import JobDetails from "./JobDetails";

import Offline from "./Offline";

import PaymentSuccess from "./PaymentSuccess";

import ProviderDashboard from "./ProviderDashboard";

import Messages from "./Messages";

import Support from "./Support";

import BudgetTracking from "./BudgetTracking";

import Onboarding from "./Onboarding";

import AccountSettings from "./AccountSettings";

import ServiceProviderProfile from "./ServiceProviderProfile";

import FindTransport from "./FindTransport";

import BookTransport from "./BookTransport";

import NDISBudget from "./NDISBudget";

import ProviderTransportDashboard from "./ProviderTransportDashboard";

import RouteOptimizer from "./RouteOptimizer";

import MyTransportBookings from "./MyTransportBookings";

import DriverProfile from "./DriverProfile";

import ScheduleManagement from "./ScheduleManagement";

import TrackRide from "./TrackRide";

import OAuthSettings from "./OAuthSettings";

import RoleManagement from "./RoleManagement";

import ProviderCredentials from "./ProviderCredentials";

import AdminCredentialReview from "./AdminCredentialReview";

import AdminDashboard from "./AdminDashboard";

import AuditLog from "./AuditLog";

import HelpCenter from "./HelpCenter";

import HelpArticle from "./HelpArticle";

import RBACSettings from "./RBACSettings";

import TwoFactorDemo from "./TwoFactorDemo";

import WorkflowManager from "./WorkflowManager";

import ApprovalRequests from "./ApprovalRequests";

import WorkflowAutomation from "./WorkflowAutomation";

import AIAssistantDemo from "./AIAssistantDemo";

import ProviderMatching from "./ProviderMatching";

import ComprehensiveAdminDashboard from "./ComprehensiveAdminDashboard";

import Home from "./Home";

import Forum from "./Forum";

import ForumThread from "./ForumThread";

import CreateForumPost from "./CreateForumPost";

import ProviderHub from "./ProviderHub";

import ParticipantProfile from "./ParticipantProfile";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Map: Map,
    
    LocationDetails: LocationDetails,
    
    AddLocation: AddLocation,
    
    Dashboard: Dashboard,
    
    FindCare: FindCare,
    
    FindJobs: FindJobs,
    
    ProviderProfile: ProviderProfile,
    
    JobDetails: JobDetails,
    
    Offline: Offline,
    
    PaymentSuccess: PaymentSuccess,
    
    ProviderDashboard: ProviderDashboard,
    
    Messages: Messages,
    
    Support: Support,
    
    BudgetTracking: BudgetTracking,
    
    Onboarding: Onboarding,
    
    AccountSettings: AccountSettings,
    
    ServiceProviderProfile: ServiceProviderProfile,
    
    FindTransport: FindTransport,
    
    BookTransport: BookTransport,
    
    NDISBudget: NDISBudget,
    
    ProviderTransportDashboard: ProviderTransportDashboard,
    
    RouteOptimizer: RouteOptimizer,
    
    MyTransportBookings: MyTransportBookings,
    
    DriverProfile: DriverProfile,
    
    ScheduleManagement: ScheduleManagement,
    
    TrackRide: TrackRide,
    
    OAuthSettings: OAuthSettings,
    
    RoleManagement: RoleManagement,
    
    ProviderCredentials: ProviderCredentials,
    
    AdminCredentialReview: AdminCredentialReview,
    
    AdminDashboard: AdminDashboard,
    
    AuditLog: AuditLog,
    
    HelpCenter: HelpCenter,
    
    HelpArticle: HelpArticle,
    
    RBACSettings: RBACSettings,
    
    TwoFactorDemo: TwoFactorDemo,
    
    WorkflowManager: WorkflowManager,
    
    ApprovalRequests: ApprovalRequests,
    
    WorkflowAutomation: WorkflowAutomation,
    
    AIAssistantDemo: AIAssistantDemo,
    
    ProviderMatching: ProviderMatching,
    
    ComprehensiveAdminDashboard: ComprehensiveAdminDashboard,
    
    Home: Home,
    
    Forum: Forum,
    
    ForumThread: ForumThread,
    
    CreateForumPost: CreateForumPost,
    
    ProviderHub: ProviderHub,
    
    ParticipantProfile: ParticipantProfile,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Map />} />
                
                
                <Route path="/Map" element={<Map />} />
                
                <Route path="/LocationDetails" element={<LocationDetails />} />
                
                <Route path="/AddLocation" element={<AddLocation />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/FindCare" element={<FindCare />} />
                
                <Route path="/FindJobs" element={<FindJobs />} />
                
                <Route path="/ProviderProfile" element={<ProviderProfile />} />
                
                <Route path="/JobDetails" element={<JobDetails />} />
                
                <Route path="/Offline" element={<Offline />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/ProviderDashboard" element={<ProviderDashboard />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/BudgetTracking" element={<BudgetTracking />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/AccountSettings" element={<AccountSettings />} />
                
                <Route path="/ServiceProviderProfile" element={<ServiceProviderProfile />} />
                
                <Route path="/FindTransport" element={<FindTransport />} />
                
                <Route path="/BookTransport" element={<BookTransport />} />
                
                <Route path="/NDISBudget" element={<NDISBudget />} />
                
                <Route path="/ProviderTransportDashboard" element={<ProviderTransportDashboard />} />
                
                <Route path="/RouteOptimizer" element={<RouteOptimizer />} />
                
                <Route path="/MyTransportBookings" element={<MyTransportBookings />} />
                
                <Route path="/DriverProfile" element={<DriverProfile />} />
                
                <Route path="/ScheduleManagement" element={<ScheduleManagement />} />
                
                <Route path="/TrackRide" element={<TrackRide />} />
                
                <Route path="/OAuthSettings" element={<OAuthSettings />} />
                
                <Route path="/RoleManagement" element={<RoleManagement />} />
                
                <Route path="/ProviderCredentials" element={<ProviderCredentials />} />
                
                <Route path="/AdminCredentialReview" element={<AdminCredentialReview />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AuditLog" element={<AuditLog />} />
                
                <Route path="/HelpCenter" element={<HelpCenter />} />
                
                <Route path="/HelpArticle" element={<HelpArticle />} />
                
                <Route path="/RBACSettings" element={<RBACSettings />} />
                
                <Route path="/TwoFactorDemo" element={<TwoFactorDemo />} />
                
                <Route path="/WorkflowManager" element={<WorkflowManager />} />
                
                <Route path="/ApprovalRequests" element={<ApprovalRequests />} />
                
                <Route path="/WorkflowAutomation" element={<WorkflowAutomation />} />
                
                <Route path="/AIAssistantDemo" element={<AIAssistantDemo />} />
                
                <Route path="/ProviderMatching" element={<ProviderMatching />} />
                
                <Route path="/ComprehensiveAdminDashboard" element={<ComprehensiveAdminDashboard />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Forum" element={<Forum />} />
                
                <Route path="/ForumThread" element={<ForumThread />} />
                
                <Route path="/CreateForumPost" element={<CreateForumPost />} />
                
                <Route path="/ProviderHub" element={<ProviderHub />} />
                
                <Route path="/ParticipantProfile" element={<ParticipantProfile />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}