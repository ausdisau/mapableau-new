
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Map, Briefcase, Users, Home, Menu, Settings, LogOut, ChevronDown, Plus, FileText, HelpCircle, Car, DollarSign, Shield, MessageSquare, Inbox, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

import OfflineDetector from "@/components/shared/OfflineDetector";
import GlobalSearchBar from "@/components/search/GlobalSearchBar";
import SearchResultsLightbox from "@/components/search/SearchResultsLightbox";
import NotificationBell from "@/components/shared/NotificationBell";
import AIFloatingButton from "@/components/ai/AIFloatingButton";
import TourOverlay from "@/components/onboarding/TourOverlay";
import TourLauncher from "@/components/onboarding/TourLauncher";
import { RoleBadge } from "@/components/shared/PermissionGuard";
import { hasAnyRole, hasPermission, PERMISSIONS } from "@/components/utils/permissions";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [searchResults, setSearchResults] = React.useState([]);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  // Don't show layout on home page
  const isHomePage = currentPageName === "Home";

  const navItems = [
    { name: "Home", path: createPageUrl("Home"), icon: Home, tour: "home" },
    { name: "Dashboard", path: createPageUrl("Dashboard"), icon: Home, tour: "dashboard" },
    { name: "My Profile", path: createPageUrl("ParticipantProfile"), icon: User, tour: "profile" },
    { name: "Community", path: createPageUrl("Forum"), icon: MessageSquare, tour: "forum" },
    { name: "Find Care", path: createPageUrl("FindCare"), icon: Users, tour: "find-care" },
    { name: "Find Transport", path: createPageUrl("FindTransport"), icon: Car, tour: "transport" },
    { name: "My Transport", path: createPageUrl("MyTransportBookings"), icon: Car },
    { name: "Find Jobs", path: createPageUrl("FindJobs"), icon: Briefcase, tour: "find-jobs" },
    { name: "Accessible Places", path: createPageUrl("Map"), icon: Map, tour: "accessible-places" },
    { name: "NDIS Budget", path: createPageUrl("NDISBudget"), icon: DollarSign, tour: "ndis-budget" },
  ];

  // Provider menu items (only show if user is a provider)
  const providerItems = [
    { name: "Provider Hub", path: createPageUrl("ProviderHub"), icon: Briefcase },
    { name: "My Services", path: createPageUrl("ProviderHub") + "?tab=services", icon: Users },
    { name: "Requests Inbox", path: createPageUrl("ProviderHub") + "?tab=requests", icon: Inbox },
  ];

  const isProvider = currentUser?.user_type === "service_provider" || 
                     currentUser?.user_type === "transport_provider";

  // Admin menu items
  const adminItems = [
    { name: "Admin Dashboard", path: createPageUrl("AdminDashboard"), icon: Shield, permission: PERMISSIONS.USERS_MANAGE_ROLES },
    { name: "Comprehensive Admin", path: createPageUrl("ComprehensiveAdminDashboard"), icon: Shield, permission: PERMISSIONS.USERS_MANAGE_ROLES },
    { name: "Audit Log", path: createPageUrl("AuditLog"), icon: FileText, permission: PERMISSIONS.USERS_MANAGE_ROLES },
    { name: "Role Management", path: createPageUrl("RoleManagement"), icon: Shield, permission: PERMISSIONS.USERS_MANAGE_ROLES },
    { name: "Credential Review", path: createPageUrl("AdminCredentialReview"), icon: Shield, permission: PERMISSIONS.USERS_MANAGE_ROLES },
    { name: "OAuth Settings", path: createPageUrl("OAuthSettings"), icon: Settings, permission: PERMISSIONS.SETTINGS_OAUTH },
    { name: "Provider Dashboard", path: createPageUrl("ProviderTransportDashboard"), icon: Car, roles: ['transport_provider', 'administrator'] },
    { name: "Route Optimizer", path: createPageUrl("RouteOptimizer"), icon: Map, roles: ['transport_provider', 'administrator'] },
  ];

  const handleSearchChange = (query) => {
    setSearchQuery(query);
  };

  const handleResultsOpen = (isOpen, query = "", results = []) => {
    setLightboxOpen(isOpen);
    if (isOpen) {
      setSearchResults(results);
    }
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  // If on home page, don't render layout wrapper
  if (isHomePage) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <OfflineDetector />
      
      <style>{`
        :root {
          --color-primary: #0F2947;
          --color-secondary: #5FA85C;
          --color-accent: #F8F3D4;
        }
        
        .text-primary { color: var(--color-primary); }
        .bg-primary { background-color: var(--color-primary); }
        .text-secondary { color: var(--color-secondary); }
        .bg-secondary { background-color: var(--color-secondary); }
        
        .hover-lift {
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .hover-lift:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .logo-glow {
          filter: drop-shadow(0 2px 8px rgba(95, 168, 92, 0.3));
          transition: filter 0.3s ease, transform 0.3s ease;
        }
        
        .logo-glow:hover {
          filter: drop-shadow(0 4px 12px rgba(95, 168, 92, 0.5));
          transform: translateY(-2px);
        }
      `}</style>

      {/* Header */}
      <header className="bg-primary border-b border-gray-200 sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center gap-4 h-16 sm:h-20">
            {/* Logo Section with Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 group flex-shrink-0 hover:opacity-90 transition-opacity" data-tour="main-nav">
                  <div className="relative">
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/05d1cd4bf_mapable-logo-original.png"
                      alt="MapAble"
                      className="h-10 sm:h-14 logo-glow"
                    />
                  </div>
                  <div className="hidden sm:flex flex-col">
                    <div className="flex items-center gap-1">
                      <span className="text-white font-bold text-xl tracking-tight">MapAble</span>
                      <ChevronDown className="w-4 h-4 text-white opacity-70" />
                    </div>
                    <span className="text-secondary text-xs font-medium">Empowering Independence</span>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel className="text-base">Quick Navigation</DropdownMenuLabel>
                <DropdownMenuSeparator />
                
                {navItems.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link to={item.path} className="cursor-pointer" data-tour={item.tour}>
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
                
                {/* Provider Section */}
                {isProvider && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel className="text-sm text-green-600">Provider Tools</DropdownMenuLabel>
                    {providerItems.map((item) => (
                      <DropdownMenuItem key={item.name} asChild>
                        <Link to={item.path} className="cursor-pointer">
                          <item.icon className="w-4 h-4 mr-3" />
                          {item.name}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </>
                )}
                
                {/* Admin Section */}
                {adminItems.some(item => 
                  (item.permission && hasPermission(currentUser, item.permission)) ||
                  (item.roles && hasAnyRole(currentUser, item.roles))
                ) && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel className="text-sm text-purple-600">Admin Tools</DropdownMenuLabel>
                    {adminItems.map((item) => {
                      const hasAccess = (item.permission && hasPermission(currentUser, item.permission)) ||
                                       (item.roles && hasAnyRole(currentUser, item.roles));
                      if (!hasAccess) return null;
                      
                      return (
                        <DropdownMenuItem key={item.name} asChild>
                          <Link to={item.path} className="cursor-pointer">
                            <item.icon className="w-4 h-4 mr-3" />
                            {item.name}
                          </Link>
                        </DropdownMenuItem>
                      );
                    })}
                  </>
                )}
                
                <DropdownMenuSeparator />
                <DropdownMenuLabel className="text-sm text-gray-500">Resources</DropdownMenuLabel>
                
                <DropdownMenuItem asChild>
                  <Link to={createPageUrl("AddLocation")} className="cursor-pointer">
                    <Plus className="w-4 h-4 mr-3" />
                    Add Location
                  </Link>
                </DropdownMenuItem>
                
                <DropdownMenuItem asChild>
                  <Link to={createPageUrl("Support")} className="cursor-pointer">
                    <HelpCircle className="w-4 h-4 mr-3" />
                    Help & Support
                  </Link>
                </DropdownMenuItem>
                
                <DropdownMenuSeparator />
                
                <DropdownMenuItem asChild>
                  <Link to={createPageUrl("AccountSettings")} className="cursor-pointer">
                    <Settings className="w-4 h-4 mr-3" />
                    Settings
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Global Search Bar */}
            <div className="hidden md:flex flex-1 max-w-2xl mx-4" data-tour="global-search">
              <GlobalSearchBar 
                onSearchChange={handleSearchChange}
                onResultsOpen={handleResultsOpen}
              />
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-2 flex-shrink-0">
              <div data-tour="notifications">
                <NotificationBell />
              </div>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2 text-white hover:bg-white/10">
                    {currentUser?.profile_photo_url ? (
                      <img
                        src={currentUser.profile_photo_url}
                        alt={currentUser.full_name}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center">
                        <span className="text-white text-sm font-semibold">
                          {currentUser?.full_name?.charAt(0) || "U"}
                        </span>
                      </div>
                    )}
                    <span className="hidden xl:inline">{currentUser?.full_name?.split(" ")[0] || "Account"}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-2">
                    <p className="text-sm font-semibold">{currentUser?.full_name}</p>
                    <p className="text-xs text-gray-500">{currentUser?.email}</p>
                    {currentUser?.role && (
                      <div className="mt-2">
                        <RoleBadge role={currentUser.role} />
                      </div>
                    )}
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to={createPageUrl("AccountSettings")} className="cursor-pointer">
                      <Settings className="w-4 h-4 mr-2" />
                      Account Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </nav>

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 bg-primary">
                {/* Mobile menu content */}
              </SheetContent>
            </Sheet>
          </div>

          {/* Mobile Search Bar */}
          <div className="md:hidden pb-4">
            <GlobalSearchBar 
              onSearchChange={handleSearchChange}
              onResultsOpen={handleResultsOpen}
            />
          </div>
        </div>
      </header>

      {/* Search Results Lightbox */}
      <SearchResultsLightbox
        isOpen={lightboxOpen}
        query={searchQuery}
        results={searchResults}
        onClose={() => setLightboxOpen(false)}
      />

      {/* AI Assistant Floating Button */}
      <div data-tour="ai-assistant">
        <AIFloatingButton />
      </div>

      {/* Onboarding Tour */}
      <TourOverlay currentPage={currentPageName} />
      <TourLauncher />

      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-primary text-white py-8 mt-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm">&copy; 2024 MapAble. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
