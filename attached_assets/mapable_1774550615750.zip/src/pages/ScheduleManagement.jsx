import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Calendar, 
  TrendingUp, 
  Users, 
  Car,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  ArrowLeft
} from "lucide-react";
import { format, isToday } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import AutoScheduleGenerator from "../components/schedule/AutoScheduleGenerator";
import ScheduleCalendar from "../components/schedule/ScheduleCalendar";
import ScheduleOverrideManager from "../components/schedule/ScheduleOverrideManager";

export default function ScheduleManagementPage() {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [showOverrideDialog, setShowOverrideDialog] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ["dailySchedules"],
    queryFn: () => base44.entities.DailySchedule.list("-schedule_date"),
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["allTransportBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-pickup_datetime"),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["allVehicles"],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: drivers = [] } = useQuery({
    queryKey: ["allDrivers"],
    queryFn: () => base44.entities.Driver.list(),
  });

  const selectedDateSchedules = schedules.filter(s =>
    format(new Date(s.schedule_date), "yyyy-MM-dd") === format(selectedDate, "yyyy-MM-dd")
  );

  const todaySchedules = schedules.filter(s => 
    isToday(new Date(s.schedule_date))
  );

  const draftSchedules = schedules.filter(s => s.status === "draft");
  const activeSchedules = schedules.filter(s => s.status === "active");
  const totalConflicts = schedules.reduce((sum, s) => sum + (s.conflicts?.length || 0), 0);
  const totalRevenue = schedules.reduce((sum, s) => sum + (s.total_revenue || 0), 0);

  const getDriver = (driverId) => drivers.find(d => d.id === driverId);
  const getVehicle = (vehicleId) => vehicles.find(v => v.id === vehicleId);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("ProviderTransportDashboard"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Schedule Management</h1>
          <p className="text-gray-600">Automated scheduling, conflict resolution, and manual overrides</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Today's Schedules</p>
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{todaySchedules.length}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Active Now</p>
                <Clock className="w-5 h-5 text-green-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{activeSchedules.length}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Needs Review</p>
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{draftSchedules.length}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Total Revenue</p>
                <DollarSign className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-3xl font-bold text-primary">${totalRevenue.toFixed(0)}</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="calendar" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="calendar">Calendar View</TabsTrigger>
            <TabsTrigger value="generator">Auto-Generate</TabsTrigger>
            <TabsTrigger value="today">Today's Schedule</TabsTrigger>
          </TabsList>

          {/* Calendar View */}
          <TabsContent value="calendar" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ScheduleCalendar
                  schedules={schedules}
                  selectedDate={selectedDate}
                  onDateSelect={setSelectedDate}
                />
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {format(selectedDate, "MMMM d, yyyy")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedDateSchedules.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">
                        No schedules for this date
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {selectedDateSchedules.map((schedule) => {
                          const driver = getDriver(schedule.driver_id);
                          const vehicle = getVehicle(schedule.vehicle_id);
                          
                          return (
                            <div
                              key={schedule.id}
                              className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                              onClick={() => {
                                setSelectedSchedule(schedule);
                                setShowOverrideDialog(true);
                              }}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <p className="font-semibold text-sm">{vehicle?.vehicle_name}</p>
                                <Badge className={
                                  schedule.status === "active" ? "bg-green-100 text-green-700" :
                                  schedule.status === "draft" ? "bg-yellow-100 text-yellow-700" :
                                  "bg-gray-100 text-gray-700"
                                }>
                                  {schedule.status}
                                </Badge>
                              </div>
                              <p className="text-xs text-gray-600 mb-2">
                                {driver?.full_name} • {schedule.shift_start_time} - {schedule.shift_end_time}
                              </p>
                              <div className="flex items-center gap-2 text-xs">
                                <Badge variant="outline">
                                  {schedule.assigned_bookings?.length || 0} trips
                                </Badge>
                                {schedule.conflicts && schedule.conflicts.length > 0 && (
                                  <Badge className="bg-red-100 text-red-700">
                                    {schedule.conflicts.length} conflicts
                                  </Badge>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Auto-Generator */}
          <TabsContent value="generator">
            <AutoScheduleGenerator
              targetDate={selectedDate}
              bookings={bookings}
              vehicles={vehicles}
              drivers={drivers}
              onScheduleGenerated={(generatedSchedules) => {
                console.log("Schedules generated:", generatedSchedules);
              }}
            />
          </TabsContent>

          {/* Today's Schedule */}
          <TabsContent value="today" className="space-y-4">
            {todaySchedules.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No schedules for today</h3>
                  <p className="text-gray-600 mb-4">Generate schedules to get started</p>
                  <Button onClick={() => navigate(`${createPageUrl("ScheduleManagement")}?tab=generator`)}>
                    Generate Schedule
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {todaySchedules.map((schedule) => {
                  const driver = getDriver(schedule.driver_id);
                  const vehicle = getVehicle(schedule.vehicle_id);
                  
                  return (
                    <Card key={schedule.id} className="hover-lift">
                      <CardContent className="pt-6">
                        <div className="space-y-4">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-bold text-lg">{vehicle?.vehicle_name}</h3>
                              <p className="text-sm text-gray-600">{driver?.full_name}</p>
                            </div>
                            <Badge className={
                              schedule.status === "active" ? "bg-green-100 text-green-700" :
                              schedule.status === "completed" ? "bg-gray-100 text-gray-700" :
                              "bg-yellow-100 text-yellow-700"
                            }>
                              {schedule.status}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-gray-400" />
                              <span>{schedule.shift_start_time} - {schedule.shift_end_time}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4 text-gray-400" />
                              <span>{schedule.assigned_bookings?.length || 0} trips</span>
                            </div>
                          </div>

                          {schedule.route_data && (
                            <div className="grid grid-cols-2 gap-4 text-sm p-3 bg-gray-50 rounded-lg">
                              <div>
                                <p className="text-xs text-gray-600">Distance</p>
                                <p className="font-semibold">{schedule.route_data.total_distance_km?.toFixed(1)} km</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-600">Duration</p>
                                <p className="font-semibold">{schedule.route_data.total_duration_minutes} min</p>
                              </div>
                            </div>
                          )}

                          {schedule.conflicts && schedule.conflicts.length > 0 && (
                            <Badge className="bg-red-100 text-red-700 w-full justify-center">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              {schedule.conflicts.length} conflict{schedule.conflicts.length !== 1 ? 's' : ''}
                            </Badge>
                          )}

                          <Button
                            variant="outline"
                            className="w-full"
                            onClick={() => {
                              setSelectedSchedule(schedule);
                              setShowOverrideDialog(true);
                            }}
                          >
                            Manage Schedule
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Override Dialog */}
      <Dialog open={showOverrideDialog} onOpenChange={setShowOverrideDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Schedule Details & Overrides</DialogTitle>
          </DialogHeader>
          {selectedSchedule && (
            <ScheduleOverrideManager
              schedule={selectedSchedule}
              drivers={drivers}
              vehicles={vehicles}
              onUpdate={() => {
                setShowOverrideDialog(false);
                setSelectedSchedule(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}