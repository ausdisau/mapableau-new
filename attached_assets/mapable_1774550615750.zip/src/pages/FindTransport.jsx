import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Search, MapPin, Star, CheckCircle, Car, Users, DollarSign, Sparkles, Filter } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function FindTransportPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState("all");
  const [stateFilter, setStateFilter] = useState("all");
  const [accessibilityFilters, setAccessibilityFilters] = useState([]);
  const [sortBy, setSortBy] = useState("rating");
  const [showFilters, setShowFilters] = useState(false);

  const { data: vehicles = [], isLoading } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.filter({ status: "available" }, "-rating"),
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const accessibilityOptions = [
    { value: "wheelchair_ramp", label: "Wheelchair Ramp", icon: "♿" },
    { value: "wheelchair_lift", label: "Wheelchair Lift", icon: "⬆️" },
    { value: "tie_down_system", label: "Tie-Down System", icon: "🔒" },
    { value: "swivel_seats", label: "Swivel Seats", icon: "💺" },
    { value: "lowered_floor", label: "Lowered Floor", icon: "📐" },
    { value: "wide_doors", label: "Wide Doors", icon: "🚪" },
    { value: "audio_announcements", label: "Audio Announcements", icon: "🔊" },
    { value: "visual_displays", label: "Visual Displays", icon: "📺" },
    { value: "service_animal_friendly", label: "Service Animal Friendly", icon: "🐕" },
  ];

  const toggleAccessibilityFilter = (value) => {
    setAccessibilityFilters(prev =>
      prev.includes(value) ? prev.filter(f => f !== value) : [...prev, value]
    );
  };

  const filteredVehicles = vehicles.filter((vehicle) => {
    const matchesSearch = vehicle.vehicle_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         vehicle.base_location?.suburb?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = vehicleTypeFilter === "all" || vehicle.vehicle_type === vehicleTypeFilter;
    const matchesState = stateFilter === "all" || vehicle.base_location?.state === stateFilter;
    
    // Check if vehicle has ALL selected accessibility features
    const matchesAccessibility = accessibilityFilters.length === 0 || 
      accessibilityFilters.every(filter => 
        vehicle.accessibility_features?.includes(filter)
      );
    
    return matchesSearch && matchesType && matchesState && matchesAccessibility;
  }).sort((a, b) => {
    if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0);
    if (sortBy === "price") return (a.hourly_rate || 0) - (b.hourly_rate || 0);
    if (sortBy === "trips") return (b.total_trips || 0) - (a.total_trips || 0);
    return 0;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Header */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-secondary" />
            <h1 className="text-4xl sm:text-5xl font-bold text-primary">
              Find Your Accessible Ride
            </h1>
          </div>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Browse NDIS-registered accessible vehicles across Australia. 
            Book wheelchair vans, accessible buses, and specialized transport with confidence.
          </p>
        </div>

        {/* Search and Quick Filters */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search by vehicle name or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 text-base"
                />
              </div>

              {/* Quick Filters Row */}
              <div className="grid sm:grid-cols-3 gap-3">
                <Select value={vehicleTypeFilter} onValueChange={setVehicleTypeFilter}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Vehicle Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Vehicle Types</SelectItem>
                    <SelectItem value="wheelchair_accessible_van">Wheelchair Van</SelectItem>
                    <SelectItem value="wheelchair_accessible_bus">Wheelchair Bus</SelectItem>
                    <SelectItem value="mobility_scooter_accessible">Scooter Accessible</SelectItem>
                    <SelectItem value="standard_accessible">Standard Accessible</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={stateFilter} onValueChange={setStateFilter}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="State/Territory" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All States</SelectItem>
                    <SelectItem value="NSW">New South Wales</SelectItem>
                    <SelectItem value="VIC">Victoria</SelectItem>
                    <SelectItem value="QLD">Queensland</SelectItem>
                    <SelectItem value="SA">South Australia</SelectItem>
                    <SelectItem value="WA">Western Australia</SelectItem>
                    <SelectItem value="TAS">Tasmania</SelectItem>
                    <SelectItem value="NT">Northern Territory</SelectItem>
                    <SelectItem value="ACT">Australian Capital Territory</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="price">Lowest Price</SelectItem>
                    <SelectItem value="trips">Most Experienced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Advanced Accessibility Filters Toggle */}
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="w-full sm:w-auto gap-2"
              >
                <Filter className="w-4 h-4" />
                {showFilters ? "Hide" : "Show"} Accessibility Features
                {accessibilityFilters.length > 0 && (
                  <Badge className="ml-2">{accessibilityFilters.length}</Badge>
                )}
              </Button>

              {/* Accessibility Features Filter */}
              {showFilters && (
                <div className="p-4 bg-blue-50 rounded-lg space-y-3">
                  <Label className="text-base font-semibold">Select Your Accessibility Needs</Label>
                  <p className="text-sm text-gray-600">
                    Vehicles must have ALL selected features to appear in results
                  </p>
                  <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {accessibilityOptions.map((option) => (
                      <div key={option.value} className="flex items-center space-x-2 p-2 bg-white rounded hover:bg-gray-50">
                        <Checkbox
                          id={option.value}
                          checked={accessibilityFilters.includes(option.value)}
                          onCheckedChange={() => toggleAccessibilityFilter(option.value)}
                        />
                        <label
                          htmlFor={option.value}
                          className="text-sm font-medium leading-none cursor-pointer flex items-center gap-2"
                        >
                          <span className="text-lg">{option.icon}</span>
                          {option.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Results Count and Clear */}
              <div className="flex items-center justify-between text-sm pt-2 border-t">
                <span className="text-gray-600">
                  <strong>{filteredVehicles.length}</strong> vehicle{filteredVehicles.length !== 1 ? 's' : ''} available
                </span>
                {(vehicleTypeFilter !== "all" || stateFilter !== "all" || searchQuery || accessibilityFilters.length > 0) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setVehicleTypeFilter("all");
                      setStateFilter("all");
                      setSearchQuery("");
                      setAccessibilityFilters([]);
                    }}
                    className="text-secondary"
                  >
                    Clear all filters
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Vehicles Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
          </div>
        ) : filteredVehicles.length === 0 ? (
          <Card className="shadow-lg">
            <CardContent className="py-12 text-center">
              <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No vehicles match your criteria</h3>
              <p className="text-gray-600 mb-4">Try adjusting your filters or search terms</p>
              <Button
                variant="outline"
                onClick={() => {
                  setVehicleTypeFilter("all");
                  setStateFilter("all");
                  setSearchQuery("");
                  setAccessibilityFilters([]);
                }}
              >
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVehicles.map((vehicle) => (
              <Card key={vehicle.id} className="hover-lift shadow-lg border-2 border-transparent hover:border-secondary transition-all">
                <CardContent className="pt-6">
                  {vehicle.photos && vehicle.photos[0] ? (
                    <img
                      src={vehicle.photos[0]}
                      alt={vehicle.vehicle_name}
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                  ) : (
                    <div className="w-full h-48 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg mb-4 flex items-center justify-center">
                      <Car className="w-16 h-16 text-blue-600" />
                    </div>
                  )}

                  <div className="space-y-3">
                    <div>
                      <h3 className="font-bold text-xl text-primary mb-1 truncate">
                        {vehicle.vehicle_name}
                      </h3>
                      {vehicle.rating > 0 && (
                        <div className="flex items-center gap-2 mb-2">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm font-medium">{vehicle.rating.toFixed(1)}</span>
                          </div>
                          <span className="text-xs text-gray-500">
                            ({vehicle.total_trips} trip{vehicle.total_trips !== 1 ? 's' : ''})
                          </span>
                        </div>
                      )}
                      <Badge variant="outline" className="text-xs capitalize">
                        {vehicle.vehicle_type?.replace(/_/g, " ")}
                      </Badge>
                    </div>

                    {/* Capacity */}
                    {vehicle.capacity && (
                      <div className="flex flex-wrap gap-2 text-xs">
                        {vehicle.capacity.wheelchair_spaces > 0 && (
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {vehicle.capacity.wheelchair_spaces} wheelchair
                          </Badge>
                        )}
                        {vehicle.capacity.standard_seats > 0 && (
                          <Badge variant="secondary">
                            {vehicle.capacity.standard_seats} seat{vehicle.capacity.standard_seats !== 1 ? 's' : ''}
                          </Badge>
                        )}
                        {vehicle.capacity.mobility_scooter_spaces > 0 && (
                          <Badge variant="secondary">
                            {vehicle.capacity.mobility_scooter_spaces} scooter
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Accessibility Features */}
                    {vehicle.accessibility_features && vehicle.accessibility_features.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {vehicle.accessibility_features.slice(0, 3).map((feature, idx) => {
                          const option = accessibilityOptions.find(o => o.value === feature);
                          return (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {option?.icon} {feature.replace(/_/g, " ")}
                            </Badge>
                          );
                        })}
                        {vehicle.accessibility_features.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{vehicle.accessibility_features.length - 3} more
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Location & Rate */}
                    <div className="space-y-2 pt-2 border-t">
                      {vehicle.base_location && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="w-4 h-4 text-secondary" />
                          <span>{vehicle.base_location.suburb}, {vehicle.base_location.state}</span>
                        </div>
                      )}
                      {vehicle.hourly_rate && (
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-green-600" />
                          <div className="text-sm">
                            <span className="font-semibold text-primary">${vehicle.hourly_rate}/hour</span>
                            {vehicle.per_km_rate && (
                              <span className="text-gray-600"> + ${vehicle.per_km_rate}/km</span>
                            )}
                          </div>
                        </div>
                      )}
                      {vehicle.ndis_registered && (
                        <Badge className="bg-green-100 text-green-700 text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          NDIS Registered
                        </Badge>
                      )}
                    </div>

                    <Link to={`${createPageUrl("BookTransport")}?vehicle_id=${vehicle.id}`}>
                      <Button className="w-full bg-secondary hover:bg-secondary/90 h-11 text-base font-semibold">
                        Book This Vehicle
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}