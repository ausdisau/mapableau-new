import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, MapPin, Upload, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AddLocationPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    category: "restaurant",
    address: "",
    suburb: "",
    state: "NSW",
    postcode: "",
    latitude: "",
    longitude: "",
    entrance_score: 5,
    interior_score: 5,
    bathroom_score: 5,
    parking_score: 5,
    staff_score: 5,
    description: "",
    accessibility_notes: "",
    phone: "",
    website: "",
    photo_url: "",
  });

  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const createLocationMutation = useMutation({
    mutationFn: (data) => base44.entities.Location.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["locations"] });
      setShowSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("Map"));
      }, 2000);
    },
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, photo_url: file_url });
    } catch (error) {
      console.error("Error uploading photo:", error);
    }
    setUploadingPhoto(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const overallScore = Math.round(
      (formData.entrance_score +
        formData.interior_score +
        formData.bathroom_score +
        formData.parking_score +
        formData.staff_score) *
        2
    );

    createLocationMutation.mutate({
      ...formData,
      overall_score: overallScore,
      latitude: formData.latitude ? parseFloat(formData.latitude) : null,
      longitude: formData.longitude ? parseFloat(formData.longitude) : null,
    });
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-primary mb-2">
              Location Added Successfully!
            </h2>
            <p className="text-gray-600">
              Thank you for contributing to MapAble. Redirecting to map...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Map"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Map
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Add New Location
          </h1>
          <p className="text-gray-600">
            Help others by sharing accessibility information about a place you know
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Location Name *</Label>
                <Input
                  id="name"
                  required
                  placeholder="e.g., The Accessible Cafe"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(v) => setFormData({ ...formData, category: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="restaurant">Restaurant</SelectItem>
                    <SelectItem value="cafe">Cafe</SelectItem>
                    <SelectItem value="performance_venue">Performance Venue</SelectItem>
                    <SelectItem value="disability_service">Disability Service</SelectItem>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="accommodation">Accommodation</SelectItem>
                    <SelectItem value="transport_hub">Transport Hub</SelectItem>
                    <SelectItem value="public_facility">Public Facility</SelectItem>
                    <SelectItem value="medical_center">Medical Center</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of the location..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="photo">Location Photo</Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    disabled={uploadingPhoto}
                  />
                  {uploadingPhoto && (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-secondary"></div>
                  )}
                </div>
                {formData.photo_url && (
                  <img
                    src={formData.photo_url}
                    alt="Preview"
                    className="mt-2 h-32 w-full object-cover rounded-lg"
                  />
                )}
              </div>
            </CardContent>
          </Card>

          {/* Address */}
          <Card>
            <CardHeader>
              <CardTitle>Address</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Street Address *</Label>
                <Input
                  id="address"
                  required
                  placeholder="123 Main Street"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </div>

              <div className="grid sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="suburb">Suburb</Label>
                  <Input
                    id="suburb"
                    placeholder="Sydney"
                    value={formData.suburb}
                    onChange={(e) => setFormData({ ...formData, suburb: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <Select
                    value={formData.state}
                    onValueChange={(v) => setFormData({ ...formData, state: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NSW">NSW</SelectItem>
                      <SelectItem value="VIC">VIC</SelectItem>
                      <SelectItem value="QLD">QLD</SelectItem>
                      <SelectItem value="SA">SA</SelectItem>
                      <SelectItem value="WA">WA</SelectItem>
                      <SelectItem value="TAS">TAS</SelectItem>
                      <SelectItem value="NT">NT</SelectItem>
                      <SelectItem value="ACT">ACT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="postcode">Postcode</Label>
                  <Input
                    id="postcode"
                    placeholder="2000"
                    value={formData.postcode}
                    onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="latitude">Latitude (optional)</Label>
                  <Input
                    id="latitude"
                    type="number"
                    step="any"
                    placeholder="-33.8688"
                    value={formData.latitude}
                    onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="longitude">Longitude (optional)</Label>
                  <Input
                    id="longitude"
                    type="number"
                    step="any"
                    placeholder="151.2093"
                    value={formData.longitude}
                    onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                  />
                </div>
              </div>

              <Alert>
                <MapPin className="w-4 h-4" />
                <AlertDescription className="text-sm">
                  GPS coordinates help us place the location accurately on the map. You can find these using Google Maps.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Accessibility Ratings */}
          <Card>
            <CardHeader>
              <CardTitle>Accessibility Ratings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {[
                { key: "entrance_score", label: "Entrance Accessibility", desc: "Ramps, automatic doors, step-free entry" },
                { key: "interior_score", label: "Interior Navigation", desc: "Wide pathways, turning space, no obstacles" },
                { key: "bathroom_score", label: "Bathroom Facilities", desc: "Accessible toilet, grab rails, adequate space" },
                { key: "parking_score", label: "Parking", desc: "Accessible parking bays, proximity to entrance" },
                { key: "staff_score", label: "Staff Awareness", desc: "Helpful, understanding of accessibility needs" },
              ].map((item) => (
                <div key={item.key} className="space-y-3">
                  <div>
                    <Label className="text-base font-semibold">{item.label}</Label>
                    <p className="text-sm text-gray-600 mt-1">{item.desc}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Slider
                      value={[formData[item.key]]}
                      onValueChange={(v) => setFormData({ ...formData, [item.key]: v[0] })}
                      min={0}
                      max={10}
                      step={1}
                      className="flex-1"
                    />
                    <div className="w-12 text-center">
                      <span className="text-2xl font-bold text-primary">{formData[item.key]}</span>
                      <span className="text-sm text-gray-500">/10</span>
                    </div>
                  </div>
                </div>
              ))}

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-lg">Overall Score</span>
                  <span className="text-3xl font-bold text-secondary">
                    {Math.round(
                      (formData.entrance_score +
                        formData.interior_score +
                        formData.bathroom_score +
                        formData.parking_score +
                        formData.staff_score) *
                        2
                    )}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Details */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="accessibility_notes">Detailed Accessibility Notes</Label>
                <Textarea
                  id="accessibility_notes"
                  placeholder="Provide detailed information about accessibility features, challenges, or special considerations..."
                  value={formData.accessibility_notes}
                  onChange={(e) =>
                    setFormData({ ...formData, accessibility_notes: e.target.value })
                  }
                  rows={5}
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="02 1234 5678"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    type="url"
                    placeholder="https://example.com"
                    value={formData.website}
                    onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex gap-4">
            <Button
              type="submit"
              className="flex-1 bg-secondary hover:bg-secondary/90 h-12 text-base"
              disabled={createLocationMutation.isPending}
            >
              {createLocationMutation.isPending ? "Adding Location..." : "Add Location"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(createPageUrl("Map"))}
              className="h-12"
            >
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}