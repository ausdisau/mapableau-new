import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Download, Home, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function PaymentSuccessPage() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const paymentId = urlParams.get("payment_id");

  const { data: payment } = useQuery({
    queryKey: ["payment", paymentId],
    queryFn: async () => {
      const payments = await base44.entities.Payment.list();
      return payments.find(p => p.id === paymentId);
    },
    enabled: !!paymentId,
  });

  const { data: serviceRequest } = useQuery({
    queryKey: ["serviceRequest", payment?.service_request_id],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.list();
      return requests.find(r => r.id === payment?.service_request_id);
    },
    enabled: !!payment?.service_request_id,
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl"
      >
        <Card className="shadow-2xl">
          <CardContent className="pt-12 pb-8">
            {/* Success Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle className="w-12 h-12 text-green-600" />
            </motion.div>

            {/* Success Message */}
            <h1 className="text-3xl font-bold text-center text-primary mb-4">
              {payment?.payment_method === "ndis_direct" ? "NDIS Claim Submitted!" : "Payment Successful!"}
            </h1>

            <p className="text-center text-gray-600 mb-8">
              {payment?.payment_method === "ndis_direct"
                ? "Your NDIS claim has been submitted for approval. You'll receive a confirmation once processed."
                : "Your booking has been confirmed. You'll receive a confirmation email shortly."}
            </p>

            {/* Payment Details */}
            {payment && (
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h2 className="font-semibold text-lg mb-4">Payment Details</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount Paid</span>
                    <span className="font-semibold">${payment.amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment Method</span>
                    <span className="font-semibold">
                      {payment.payment_method === "stripe" ? "Credit Card" : "NDIS Claim"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment Date</span>
                    <span className="font-semibold">
                      {new Date(payment.payment_date || payment.created_date).toLocaleDateString()}
                    </span>
                  </div>
                  {payment.ndis_claim_reference && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">NDIS Reference</span>
                      <span className="font-semibold font-mono text-sm">
                        {payment.ndis_claim_reference}
                      </span>
                    </div>
                  )}
                  {serviceRequest && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Service Type</span>
                        <span className="font-semibold">
                          {serviceRequest.service_type.replace(/_/g, " ")}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Service Date</span>
                        <span className="font-semibold">{serviceRequest.date}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={() => navigate(createPageUrl("Dashboard"))}
                className="flex-1 bg-secondary hover:bg-secondary/90 h-12"
              >
                <Home className="w-4 h-4 mr-2" />
                Go to Dashboard
              </Button>
              <Button
                variant="outline"
                className="flex-1 h-12"
                onClick={() => navigate(createPageUrl("Dashboard"))}
              >
                <Calendar className="w-4 h-4 mr-2" />
                View My Bookings
              </Button>
            </div>

            {/* Next Steps */}
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <h3 className="font-semibold text-primary mb-2">What's Next?</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold mt-1">•</span>
                  <span>You'll receive a confirmation email with your booking details</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold mt-1">•</span>
                  <span>Your service provider will contact you 24 hours before the appointment</span>
                </li>
                {payment?.payment_method === "ndis_direct" && (
                  <li className="flex items-start gap-2">
                    <span className="text-secondary font-bold mt-1">•</span>
                    <span>NDIS will process your claim within 2-5 business days</span>
                  </li>
                )}
                <li className="flex items-start gap-2">
                  <span className="text-secondary font-bold mt-1">•</span>
                  <span>You can manage your bookings from your dashboard</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}