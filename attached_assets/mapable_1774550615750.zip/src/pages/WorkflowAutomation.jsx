import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Workflow,
  Zap,
  Clock,
  CheckCircle,
  Settings,
  FileText,
  Info,
  Sparkles,
  Activity,
  GitBranch,
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import WorkflowExecutionLog from "../components/workflows/WorkflowExecutionLog";
import { toast } from "sonner";

// Workflow templates
const WORKFLOW_TEMPLATES = [
  {
    name: "Booking Confirmation",
    description: "Automatically send confirmation emails when bookings are created",
    category: "bookings",
    trigger: { type: "entity_created", entity: "TransportBooking" },
    actions: [
      {
        type: "send_email",
        config: {
          to: "{{booking.created_by}}",
          subject: "Booking Confirmed",
          body: "Your transport booking has been confirmed."
        }
      }
    ]
  },
  {
    name: "Credential Expiry Reminder",
    description: "Notify providers when credentials are about to expire",
    category: "credentials",
    trigger: { type: "scheduled", schedule: "daily" },
    actions: [
      {
        type: "send_notification",
        config: {
          message: "Your credential is expiring soon"
        }
      }
    ]
  },
  {
    name: "Driver Assignment Notification",
    description: "Notify participants when a driver is assigned",
    category: "bookings",
    trigger: { type: "entity_updated", entity: "TransportBooking" },
    actions: [
      {
        type: "send_notification",
        config: {
          message: "A driver has been assigned to your booking"
        }
      }
    ]
  }
];

// Simple workflow executor
const executeWorkflow = async (workflow, data) => {
  try {
    // Simulate workflow execution
    console.log("Executing workflow:", workflow.name, "with data:", data);
    
    // In a real implementation, this would execute each action
    for (const action of workflow.actions || []) {
      console.log("Executing action:", action.type, action.config);
      // Execute action based on type
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export default function WorkflowAutomationPage() {
  const [testingWorkflow, setTestingWorkflow] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: workflows = [] } = useQuery({
    queryKey: ["workflows"],
    queryFn: () => base44.entities.WorkflowDefinition.filter({ enabled: true }),
  });

  const { data: recentExecutions = [] } = useQuery({
    queryKey: ["recentExecutions"],
    queryFn: () => base44.entities.WorkflowExecution.list("-created_date", 20),
  });

  const testWorkflowMutation = useMutation({
    mutationFn: async (workflow) => {
      const testData = {
        user: currentUser,
        timestamp: new Date().toISOString(),
        test: true,
      };
      return await executeWorkflow(workflow, testData);
    },
    onSuccess: (result) => {
      if (result.success) {
        toast.success("Workflow executed successfully!");
      } else {
        toast.error(`Workflow failed: ${result.error}`);
      }
    },
  });

  const stats = {
    activeWorkflows: workflows.length,
    totalExecutions: recentExecutions.length,
    successRate: recentExecutions.length > 0
      ? Math.round((recentExecutions.filter(e => e.status === "completed").length / recentExecutions.length) * 100)
      : 0,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Workflow className="w-8 h-8 text-purple-600" />
                <h1 className="text-4xl font-bold text-primary">
                  Workflow Automation
                </h1>
              </div>
              <p className="text-gray-600 text-lg">
                Streamline operations with intelligent automation
              </p>
            </div>
            <Link to={createPageUrl("WorkflowManager")}>
              <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
                <Settings className="w-4 h-4" />
                Manage Workflows
              </Button>
            </Link>
          </div>
        </div>

        {/* Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Workflow className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-primary">{stats.activeWorkflows}</p>
                <p className="text-sm text-gray-600 mt-1">Active Workflows</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Zap className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-primary">{stats.totalExecutions}</p>
                <p className="text-sm text-gray-600 mt-1">Total Executions</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-primary">{stats.successRate}%</p>
                <p className="text-sm text-gray-600 mt-1">Success Rate</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="active" className="space-y-6">
          <TabsList>
            <TabsTrigger value="active">
              <Activity className="w-4 h-4 mr-2" />
              Active Workflows
            </TabsTrigger>
            <TabsTrigger value="templates">
              <Sparkles className="w-4 h-4 mr-2" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="executions">
              <FileText className="w-4 h-4 mr-2" />
              Recent Executions
            </TabsTrigger>
          </TabsList>

          {/* Active Workflows */}
          <TabsContent value="active">
            <div className="grid md:grid-cols-2 gap-6">
              {workflows.map((workflow) => (
                <Card key={workflow.id} className="hover-lift">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{workflow.name}</CardTitle>
                      <Badge className="bg-green-100 text-green-700">Active</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{workflow.description}</p>
                    
                    <div className="flex items-center justify-between text-sm mb-4">
                      <span className="text-gray-600">
                        Trigger: <span className="font-medium capitalize">{workflow.trigger?.type?.replace(/_/g, " ")}</span>
                      </span>
                      <span className="text-gray-600">
                        {workflow.actions?.length || 0} actions
                      </span>
                    </div>

                    {workflow.execution_count > 0 && (
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="p-2 bg-green-50 rounded text-center">
                          <p className="font-bold text-green-700">{workflow.success_count || 0}</p>
                          <p className="text-gray-600">Successful</p>
                        </div>
                        <div className="p-2 bg-red-50 rounded text-center">
                          <p className="font-bold text-red-700">{workflow.failure_count || 0}</p>
                          <p className="text-gray-600">Failed</p>
                        </div>
                      </div>
                    )}

                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full mt-4 gap-2"
                      onClick={() => {
                        setTestingWorkflow(workflow);
                        testWorkflowMutation.mutate(workflow);
                      }}
                      disabled={testWorkflowMutation.isPending && testingWorkflow?.id === workflow.id}
                    >
                      <Zap className="w-4 h-4" />
                      {testWorkflowMutation.isPending && testingWorkflow?.id === workflow.id
                        ? "Testing..."
                        : "Test Workflow"}
                    </Button>
                  </CardContent>
                </Card>
              ))}

              {workflows.length === 0 && (
                <Card className="md:col-span-2">
                  <CardContent className="py-12 text-center">
                    <Workflow className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      No active workflows
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Create workflows to automate your processes
                    </p>
                    <Link to={createPageUrl("WorkflowManager")}>
                      <Button className="bg-purple-600 hover:bg-purple-700">
                        Get Started
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Templates */}
          <TabsContent value="templates">
            <div className="grid md:grid-cols-2 gap-6">
              {WORKFLOW_TEMPLATES.map((template, idx) => (
                <Card key={idx} className="hover-lift">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{template.name}</CardTitle>
                      <Badge variant="outline" className="capitalize">
                        {template.category.replace(/_/g, " ")}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{template.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm">
                        <GitBranch className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-700">
                          Trigger: <span className="font-medium capitalize">
                            {template.trigger.type.replace(/_/g, " ")}
                          </span>
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Zap className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-700">
                          {template.actions.length} automated action{template.actions.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>

                    <Link to={createPageUrl("WorkflowManager")}>
                      <Button size="sm" variant="outline" className="w-full">
                        Use This Template
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Executions */}
          <TabsContent value="executions">
            <WorkflowExecutionLog limit={50} />
          </TabsContent>
        </Tabs>

        {/* Info Card */}
        <Card className="mt-8 border-2 border-blue-200">
          <CardContent className="pt-6">
            <Alert className="bg-blue-50 border-blue-200">
              <Info className="w-5 h-5 text-blue-600" />
              <AlertDescription className="text-blue-900">
                <p className="font-semibold mb-2">Automation Capabilities:</p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li><strong>User Management:</strong> Auto-assign roles based on registration data</li>
                  <li><strong>Credentials:</strong> Alert on expiring licenses, auto-mark expired</li>
                  <li><strong>Bookings:</strong> Send reminders, follow-ups, and confirmations</li>
                  <li><strong>Support:</strong> Alert staff about stale tickets, auto-assign</li>
                  <li><strong>Approvals:</strong> Route high-value actions for authorization</li>
                  <li><strong>Data Sync:</strong> Integrate with external systems via webhooks</li>
                </ul>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}