import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Shield, 
  Users, 
  Search,
  Edit,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Settings as SettingsIcon
} from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import AuditLogService from "../components/audit/AuditLogService";
import {
  hasPermission,
  getAllRoles,
  getRoleLabel,
  getRoleColor,
  getRoleDescription,
  getUserPermissions,
  MODULES,
  ACTIONS,
  createPermission,
  getModuleLabel,
  getModulePermissions,
} from "@/components/utils/permissions";

export default function RoleManagementPage() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editFormData, setEditFormData] = useState({
    role: "",
    custom_permissions: [],
    account_status: "active",
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const canManageRoles = hasPermission(currentUser, createPermission(MODULES.USERS, ACTIONS.MANAGE));

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list("-created_date"),
    enabled: canManageRoles,
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, data }) => {
      const oldUser = allUsers.find(u => u.id === userId);
      const updatedUser = await base44.entities.User.update(userId, data);
      
      // Log role change if role was changed
      if (oldUser && oldUser.role !== data.role) {
        await AuditLogService.logRoleChange(updatedUser, oldUser.role, data.role, data.custom_permissions || []);
      }
      
      // Log permission changes if custom permissions were modified
      if (oldUser && JSON.stringify(oldUser.custom_permissions) !== JSON.stringify(data.custom_permissions)) {
        const added = (data.custom_permissions || []).filter(p => !(oldUser.custom_permissions || []).includes(p));
        const removed = (oldUser.custom_permissions || []).filter(p => !(data.custom_permissions || []).includes(p));
        if (added.length > 0 || removed.length > 0) {
          await AuditLogService.logPermissionsModified(updatedUser, added, removed);
        }
      }
      
      return updatedUser;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allUsers"] });
      queryClient.invalidateQueries({ queryKey: ["auditLogs"] });
      setShowEditDialog(false);
      setSelectedUser(null);
      toast.success("User updated successfully!");
    },
  });

  // Filter users
  const filteredUsers = allUsers.filter(user => {
    const matchesSearch = !searchQuery || 
      user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  // Role statistics
  const roleStats = getAllRoles().map(role => ({
    ...role,
    count: allUsers.filter(u => u.role === role.value).length,
  }));

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setEditFormData({
      role: user.role || "user",
      custom_permissions: user.custom_permissions || [],
      account_status: user.account_status || "active",
    });
    setShowEditDialog(true);
  };

  const handleSaveUser = () => {
    if (!selectedUser) return;
    
    updateUserMutation.mutate({
      userId: selectedUser.id,
      data: editFormData,
    });
  };

  const togglePermission = (permission) => {
    const newPermissions = editFormData.custom_permissions.includes(permission)
      ? editFormData.custom_permissions.filter(p => p !== permission)
      : [...editFormData.custom_permissions, permission];
    
    setEditFormData({ ...editFormData, custom_permissions: newPermissions });
  };

  if (!canManageRoles) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200 border-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900 text-lg">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can manage user roles.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-8 h-8 text-purple-600" />
                <h1 className="text-4xl font-bold text-primary">User Role Management</h1>
              </div>
              <p className="text-gray-600 text-lg">
                Manage user roles and permissions across the platform
              </p>
            </div>
            <Link to={createPageUrl("RBACSettings")}>
              <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
                <SettingsIcon className="w-4 h-4" />
                RBAC Settings
              </Button>
            </Link>
          </div>
        </div>

        {/* Role Statistics */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {roleStats.slice(0, 4).map(role => (
            <Card key={role.value} className="hover-lift">
              <CardContent className="pt-6">
                <div className="text-center">
                  <Badge className={getRoleColor(role.value)}>
                    {role.name}
                  </Badge>
                  <p className="text-3xl font-bold text-primary mt-3">{role.count}</p>
                  <p className="text-sm text-gray-600 mt-1">users</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {getAllRoles().map(role => (
                    <SelectItem key={role.value} value={role.value}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Users ({filteredUsers.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredUsers.map(user => {
                const permissions = getUserPermissions(user);
                
                return (
                  <div 
                    key={user.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg">{user.full_name}</h3>
                        <Badge className={getRoleColor(user.role)}>
                          {getRoleLabel(user.role)}
                        </Badge>
                        {user.custom_permissions && user.custom_permissions.length > 0 && (
                          <Badge variant="outline" className="text-xs">
                            +{user.custom_permissions.length} custom
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{user.email}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <span>Created: {format(new Date(user.created_date), "MMM d, yyyy")}</span>
                        <span>•</span>
                        <span>{permissions.length} permissions</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditUser(user)}
                      className="gap-2"
                    >
                      <Edit className="w-4 h-4" />
                      Edit Role
                    </Button>
                  </div>
                );
              })}

              {filteredUsers.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">No users found matching your filters</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit User: {selectedUser?.full_name}</DialogTitle>
          </DialogHeader>
          
          {selectedUser && (
            <div className="space-y-6">
              {/* Role Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">User Role</label>
                <Select 
                  value={editFormData.role} 
                  onValueChange={(value) => setEditFormData({ ...editFormData, role: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {getAllRoles().map(role => (
                      <SelectItem key={role.value} value={role.value}>
                        <div className="flex items-center gap-2">
                          <span>{role.name}</span>
                          <span className="text-xs text-gray-500">({role.permissions.length} permissions)</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {getRoleDescription(editFormData.role) && (
                  <p className="text-sm text-gray-600">
                    {getRoleDescription(editFormData.role)}
                  </p>
                )}
              </div>

              {/* Custom Permissions */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Custom Permissions (Optional)</label>
                <p className="text-sm text-gray-600 mb-3">
                  Add additional permissions beyond those granted by the role
                </p>
                <div className="border rounded-lg p-4 max-h-96 overflow-y-auto">
                  {Object.values(MODULES).map(module => {
                    const permissions = getModulePermissions(module);
                    
                    return (
                      <div key={module} className="mb-4">
                        <h4 className="font-semibold mb-2">{getModuleLabel(module)}</h4>
                        <div className="space-y-2 pl-4">
                          {permissions.map(perm => (
                            <div key={perm.permission} className="flex items-center gap-2">
                              <Checkbox
                                id={`perm-${perm.permission}`}
                                checked={editFormData.custom_permissions.includes(perm.permission)}
                                onCheckedChange={() => togglePermission(perm.permission)}
                              />
                              <label 
                                htmlFor={`perm-${perm.permission}`}
                                className="text-sm cursor-pointer"
                              >
                                {perm.label}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowEditDialog(false);
                    setSelectedUser(null);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSaveUser}
                  disabled={updateUserMutation.isPending}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}