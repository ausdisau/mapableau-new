import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Sparkles,
  MapPin,
  TrendingUp,
  Save,
  Download,
  RefreshCw,
  ArrowLeft,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { toast } from "sonner";

import RouteOptimizerEngine from "../components/route/RouteOptimizerEngine";
import OptimizedRouteMap from "../components/route/OptimizedRouteMap";
import RouteManualAdjustment from "../components/route/RouteManualAdjustment";
import VehicleConstraintsForm from "../components/route/VehicleConstraintsForm";

export default function RouteOptimizerPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [optimizedRoutes, setOptimizedRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [vehicleConstraints, setVehicleConstraints] = useState({});

  const { data: bookings = [], isLoading: bookingsLoading } = useQuery({
    queryKey: ["transportBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-pickup_datetime"),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["allVehicles"],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: drivers = [] } = useQuery({
    queryKey: ["allDrivers"],
    queryFn: () => base44.entities.Driver.list(),
  });

  // Filter bookings for selected date
  const dateBookings = bookings.filter(b => {
    if (!b.pickup_datetime) return false;
    const bookingDate = format(new Date(b.pickup_datetime), "yyyy-MM-dd");
    return bookingDate === selectedDate && ["requested", "confirmed"].includes(b.status);
  });

  // Calculate stats
  const totalBookings = dateBookings.length;
  const totalDistance = optimizedRoutes.reduce((sum, r) => sum + (r.totalDistance || 0), 0);
  const totalDuration = optimizedRoutes.reduce((sum, r) => sum + (r.totalDuration || 0), 0);
  const efficiencyGain = optimizedRoutes.length > 0
    ? Math.round((1 - (totalDistance / (dateBookings.length * 20))) * 100)
    : 0;

  const handleOptimize = (routes) => {
    setOptimizedRoutes(routes);
    toast.success(`Generated ${routes.length} optimized routes`, {
      description: `Total distance: ${totalDistance.toFixed(1)}km, Duration: ${Math.round(totalDuration)}min`
    });
  };

  const handleRouteUpdate = (routeId, updatedRoute) => {
    setOptimizedRoutes(prev =>
      prev.map(r => r.id === routeId ? updatedRoute : r)
    );
  };

  const saveRoutesMutation = useMutation({
    mutationFn: async (routes) => {
      const saved = [];
      for (const route of routes) {
        // Create daily schedule for this route
        const scheduleData = {
          schedule_date: selectedDate,
          operator_id: route.vehicle?.operator_id || "default",
          vehicle_id: route.vehicleId,
          driver_id: route.driverId,
          shift_start_time: route.startTime,
          shift_end_time: route.endTime,
          assigned_bookings: route.bookings.map(b => b.id),
          route_data: {
            total_distance_km: route.totalDistance,
            total_duration_minutes: route.totalDuration,
            estimated_fuel_cost: route.totalDistance * 0.15,
            waypoints: route.waypoints
          },
          schedule_type: "auto_generated",
          status: "published",
          conflicts: [],
          exceptions: [],
          total_revenue: route.bookings.reduce((sum, b) => sum + (b.estimated_cost || 0), 0)
        };
        
        const schedule = await base44.entities.DailySchedule.create(scheduleData);
        saved.push(schedule);
      }
      return saved;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dailySchedules"] });
      toast.success("Routes saved successfully!", {
        description: "Schedules have been created and drivers will be notified"
      });
    }
  });

  const exportRoutes = () => {
    const data = JSON.stringify(optimizedRoutes, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `routes-${selectedDate}.json`;
    a.click();
    toast.success("Routes exported successfully");
  };

  if (bookingsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("ProviderTransportDashboard"))}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="w-8 h-8 text-purple-600" />
                <h1 className="text-4xl font-bold text-primary">Route Optimizer</h1>
              </div>
              <p className="text-gray-600 text-lg">
                AI-powered route optimization for maximum efficiency
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setOptimizedRoutes([]);
                }}
                className="px-4 py-2 border rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Bookings</p>
                <MapPin className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{totalBookings}</p>
              <p className="text-xs text-gray-500 mt-1">for {format(new Date(selectedDate), "MMM d")}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Total Distance</p>
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{totalDistance.toFixed(1)}</p>
              <p className="text-xs text-gray-500 mt-1">kilometers</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Duration</p>
                <RefreshCw className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{Math.round(totalDuration)}</p>
              <p className="text-xs text-gray-500 mt-1">minutes</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">Efficiency</p>
                <Sparkles className="w-5 h-5 text-yellow-600" />
              </div>
              <p className="text-3xl font-bold text-primary">{efficiencyGain}%</p>
              <p className="text-xs text-gray-500 mt-1">improvement</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        {dateBookings.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No bookings for this date</h3>
              <p className="text-gray-600">Select a different date or wait for new bookings</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="optimize" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="optimize">Optimize Routes</TabsTrigger>
              <TabsTrigger value="map" disabled={optimizedRoutes.length === 0}>
                Map View
              </TabsTrigger>
              <TabsTrigger value="adjust" disabled={optimizedRoutes.length === 0}>
                Manual Adjustments
              </TabsTrigger>
            </TabsList>

            {/* Optimize Tab */}
            <TabsContent value="optimize" className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <RouteOptimizerEngine
                    bookings={dateBookings}
                    vehicles={vehicles}
                    drivers={drivers}
                    selectedDate={selectedDate}
                    vehicleConstraints={vehicleConstraints}
                    onOptimized={handleOptimize}
                    isOptimizing={isOptimizing}
                    setIsOptimizing={setIsOptimizing}
                  />
                </div>

                <div className="space-y-6">
                  <VehicleConstraintsForm
                    vehicles={vehicles}
                    onConstraintsChange={setVehicleConstraints}
                  />

                  {optimizedRoutes.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Actions</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <Button
                          onClick={() => saveRoutesMutation.mutate(optimizedRoutes)}
                          disabled={saveRoutesMutation.isPending}
                          className="w-full bg-green-600 hover:bg-green-700 gap-2"
                        >
                          <Save className="w-4 h-4" />
                          {saveRoutesMutation.isPending ? "Saving..." : "Save Routes"}
                        </Button>
                        <Button
                          onClick={exportRoutes}
                          variant="outline"
                          className="w-full gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Export Routes
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Map View Tab */}
            <TabsContent value="map">
              <OptimizedRouteMap
                routes={optimizedRoutes}
                vehicles={vehicles}
                drivers={drivers}
                onRouteSelect={setSelectedRoute}
                selectedRoute={selectedRoute}
              />
            </TabsContent>

            {/* Manual Adjustments Tab */}
            <TabsContent value="adjust">
              <RouteManualAdjustment
                routes={optimizedRoutes}
                vehicles={vehicles}
                drivers={drivers}
                bookings={dateBookings}
                onRouteUpdate={handleRouteUpdate}
              />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}