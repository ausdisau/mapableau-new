import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  FileText,
  User,
  Calendar,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { hasPermission, hasAnyRole, MODULES, ACTIONS, createPermission } from "@/utils/permissions";

export default function ApprovalRequestsPage() {
  const queryClient = useQueryClient();
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showDecisionDialog, setShowDecisionDialog] = useState(false);
  const [decisionNotes, setDecisionNotes] = useState("");
  const [decisionType, setDecisionType] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const canApprove = hasPermission(currentUser, createPermission(MODULES.USERS, ACTIONS.MANAGE)) ||
                     hasAnyRole(currentUser, ["administrator", "moderator", "finance_manager"]);

  const { data: approvalRequests = [], isLoading } = useQuery({
    queryKey: ["approvalRequests"],
    queryFn: async () => {
      if (!canApprove) return [];
      
      // Get all pending requests or requests assigned to current user
      const all = await base44.entities.ApprovalRequest.list("-created_date");
      return all.filter(r => 
        r.status === "pending" && 
        (r.assigned_to === currentUser?.email || r.assigned_to === currentUser?.role)
      );
    },
    enabled: canApprove,
  });

  const { data: myRequests = [] } = useQuery({
    queryKey: ["myApprovalRequests"],
    queryFn: async () => {
      return await base44.entities.ApprovalRequest.filter({
        requested_by: currentUser?.email,
      }, "-created_date");
    },
    enabled: !!currentUser,
  });

  const processApprovalMutation = useMutation({
    mutationFn: async ({ requestId, approved, notes }) => {
      await base44.entities.ApprovalRequest.update(requestId, {
        status: approved ? "approved" : "rejected",
        approved_by: currentUser?.email,
        decision_date: new Date().toISOString(),
        decision_notes: notes,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["approvalRequests"] });
      queryClient.invalidateQueries({ queryKey: ["myApprovalRequests"] });
      setShowDecisionDialog(false);
      setSelectedRequest(null);
      setDecisionNotes("");
      toast.success(decisionType === "approve" ? "Request approved" : "Request rejected");
    },
  });

  const handleDecision = (request, approved) => {
    setSelectedRequest(request);
    setDecisionType(approved ? "approve" : "reject");
    setShowDecisionDialog(true);
  };

  const confirmDecision = () => {
    if (!selectedRequest) return;
    
    processApprovalMutation.mutate({
      requestId: selectedRequest.id,
      approved: decisionType === "approve",
      notes: decisionNotes,
    });
  };

  const getPriorityColor = (priority) => {
    const colors = {
      low: "bg-gray-100 text-gray-700",
      medium: "bg-blue-100 text-blue-700",
      high: "bg-orange-100 text-orange-700",
      urgent: "bg-red-100 text-red-700",
    };
    return colors[priority] || colors.medium;
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-700",
      approved: "bg-green-100 text-green-700",
      rejected: "bg-red-100 text-red-700",
      cancelled: "bg-gray-100 text-gray-700",
      expired: "bg-orange-100 text-orange-700",
    };
    return colors[status] || colors.pending;
  };

  if (!canApprove && myRequests.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert>
            <AlertTriangle className="w-5 h-5" />
            <AlertDescription>
              You don't have any approval requests or permissions to approve requests.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">Approval Requests</h1>
          <p className="text-gray-600 text-lg">
            Review and approve critical actions requiring authorization
          </p>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pending">
              Pending ({approvalRequests.filter(r => r.status === "pending").length})
            </TabsTrigger>
            <TabsTrigger value="my-requests">
              My Requests ({myRequests.length})
            </TabsTrigger>
            <TabsTrigger value="history">
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <div className="space-y-4">
              {approvalRequests.filter(r => r.status === "pending").map((request) => (
                <Card key={request.id} className="hover-lift">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{request.title}</h3>
                          <Badge className={getPriorityColor(request.priority)}>
                            {request.priority}
                          </Badge>
                          <Badge variant="outline" className="capitalize">
                            {request.request_type?.replace(/_/g, " ")}
                          </Badge>
                        </div>
                        
                        <p className="text-gray-600 text-sm mb-3">{request.description}</p>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {request.requested_by}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {formatDistanceToNow(new Date(request.created_date), { addSuffix: true })}
                          </span>
                          {request.expires_at && (
                            <span className="flex items-center gap-1 text-orange-600">
                              <Clock className="w-4 h-4" />
                              Expires {formatDistanceToNow(new Date(request.expires_at), { addSuffix: true })}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleDecision(request, true)}
                          className="bg-green-600 hover:bg-green-700 gap-2"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDecision(request, false)}
                          className="text-red-600 hover:bg-red-50 gap-2"
                        >
                          <XCircle className="w-4 h-4" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {approvalRequests.filter(r => r.status === "pending").length === 0 && (
                <Card>
                  <CardContent className="py-12 text-center">
                    <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      All caught up!
                    </h3>
                    <p className="text-gray-600">No pending approval requests</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="my-requests">
            <div className="space-y-4">
              {myRequests.map((request) => (
                <Card key={request.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{request.title}</h3>
                          <Badge className={getStatusColor(request.status)}>
                            {request.status}
                          </Badge>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">{request.description}</p>
                        
                        {request.decision_notes && (
                          <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                            <p className="text-sm font-medium text-gray-900">Decision Notes:</p>
                            <p className="text-sm text-gray-700">{request.decision_notes}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history">
            <div className="space-y-4">
              {approvalRequests.filter(r => r.status !== "pending").map((request) => (
                <Card key={request.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">{request.title}</h3>
                          <Badge className={getStatusColor(request.status)}>
                            {request.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p>Decided by {request.approved_by}</p>
                          {request.decision_date && (
                            <p>{format(new Date(request.decision_date), "PPp")}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Decision Dialog */}
      <Dialog open={showDecisionDialog} onOpenChange={setShowDecisionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {decisionType === "approve" ? "Approve Request" : "Reject Request"}
            </DialogTitle>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="space-y-4">
              <Alert className={decisionType === "approve" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
                <AlertDescription>
                  <p className="font-semibold mb-1">{selectedRequest.title}</p>
                  <p className="text-sm">{selectedRequest.description}</p>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Textarea
                  placeholder="Add any notes about your decision..."
                  value={decisionNotes}
                  onChange={(e) => setDecisionNotes(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDecisionDialog(false);
                    setDecisionNotes("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={confirmDecision}
                  disabled={processApprovalMutation.isPending}
                  className={decisionType === "approve" 
                    ? "bg-green-600 hover:bg-green-700" 
                    : "bg-red-600 hover:bg-red-700"
                  }
                >
                  {processApprovalMutation.isPending 
                    ? "Processing..." 
                    : decisionType === "approve" 
                      ? "Confirm Approval" 
                      : "Confirm Rejection"
                  }
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}