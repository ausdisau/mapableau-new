import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  ArrowLeft, 
  Send, 
  Sparkles,
  X,
  Info
} from "lucide-react";
import { toast } from "sonner";
import { hasPermission, PERMISSIONS } from "@/utils/permissions";
import AIContentGenerator from "../components/ai/AIContentGenerator";

const categories = [
  { value: "general", label: "General Discussion" },
  { value: "transport", label: "Transport & Travel" },
  { value: "care_services", label: "Care Services" },
  { value: "employment", label: "Employment" },
  { value: "accessibility", label: "Accessibility" },
  { value: "ndis_support", label: "NDIS Support" },
  { value: "technology", label: "Technology Help" },
  { value: "events", label: "Events" },
  { value: "feedback", label: "Platform Feedback" },
];

export default function CreateForumPostPage() {
  const navigate = useNavigate();
  const [showAI, setShowAI] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "general",
    tags: [],
    is_announcement: false,
  });
  
  const [tagInput, setTagInput] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.ForumPost.create(postData),
    onSuccess: (newPost) => {
      toast.success("Post created successfully!");
      navigate(`${createPageUrl("ForumThread")}?id=${newPost.id}`);
    },
    onError: () => {
      toast.error("Failed to create post");
    },
  });

  const isAdmin = hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES);

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()]
      });
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(tag => tag !== tagToRemove)
    });
  };

  const handleSubmit = () => {
    if (!formData.title.trim() || !formData.content.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    createPostMutation.mutate({
      ...formData,
      author_email: currentUser.email,
      author_name: currentUser.full_name,
      last_activity_date: new Date().toISOString(),
    });
  };

  const handleAIApply = (content) => {
    setFormData({ ...formData, content });
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-yellow-50 border-yellow-200">
            <Info className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-yellow-900">
              Please log in to create a forum post.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <Link to={createPageUrl("Forum")}>
            <Button variant="ghost" className="mb-4 gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Forum
            </Button>
          </Link>
          
          <h1 className="text-3xl font-bold text-primary mb-2">Create New Discussion</h1>
          <p className="text-gray-600">Share your thoughts, ask questions, or start a conversation</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Post Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                placeholder="What's on your mind?"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="text-lg"
              />
            </div>

            {/* Category */}
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Content */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="content">Content * (Markdown supported)</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAI(true)}
                  className="gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  AI Help
                </Button>
              </div>
              <Textarea
                id="content"
                placeholder="Share more details about your post..."
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                rows={12}
                className="font-mono text-sm"
              />
              <p className="text-xs text-gray-500">
                You can use **bold**, *italic*, and [links](url) in your post
              </p>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <Label htmlFor="tags">Tags (Optional)</Label>
              <div className="flex gap-2">
                <Input
                  id="tags"
                  placeholder="Add a tag (press Enter)"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
                />
                <Button onClick={handleAddTag} variant="outline">
                  Add
                </Button>
              </div>
              {formData.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.tags.map((tag, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-1">
                      {tag}
                      <X 
                        className="w-3 h-3 cursor-pointer hover:text-red-600" 
                        onClick={() => handleRemoveTag(tag)}
                      />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Admin Options */}
            {isAdmin && (
              <div className="border-t pt-6">
                <Label className="text-base font-semibold mb-3 block">Admin Options</Label>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="announcement"
                      checked={formData.is_announcement}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, is_announcement: checked })
                      }
                    />
                    <label htmlFor="announcement" className="text-sm cursor-pointer">
                      Mark as official announcement
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-6 border-t">
              <Link to={createPageUrl("Forum")}>
                <Button variant="outline">Cancel</Button>
              </Link>
              <Button
                onClick={handleSubmit}
                disabled={createPostMutation.isPending}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 gap-2"
              >
                <Send className="w-4 h-4" />
                {createPostMutation.isPending ? "Creating..." : "Create Post"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tips */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-2">Tips for a great post</h3>
                <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                  <li>Write a clear, descriptive title</li>
                  <li>Provide enough context so others can help</li>
                  <li>Choose the right category for better visibility</li>
                  <li>Use tags to make your post easier to find</li>
                  <li>Be respectful and follow community guidelines</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Content Generator */}
      <AIContentGenerator
        isOpen={showAI}
        onClose={() => setShowAI(false)}
        onApply={handleAIApply}
        contentType="general"
        context={{ category: formData.category, title: formData.title }}
        title="AI Content Helper"
      />
    </div>
  );
}