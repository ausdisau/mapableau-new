import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  ArrowLeft,
  Star,
  MapPin,
  CheckCircle,
  Award,
  Briefcase,
  Clock,
  DollarSign,
  Phone,
  Mail,
  Globe,
  Shield,
  TrendingUp,
  Users,
  Calendar,
  MessageSquare,
  ThumbsUp,
  AlertCircle,
  GraduationCap,
  Languages as LanguageIcon
} from "lucide-react";
import { format } from "date-fns";

import ProviderServicesSection from "../components/provider/ProviderServicesSection";
import ProviderCertificationsSection from "../components/provider/ProviderCertificationsSection";
import ProviderReviewsSection from "../components/provider/ProviderReviewsSection";
import ProviderBookingSection from "../components/provider/ProviderBookingSection";

export default function ServiceProviderProfilePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const providerId = urlParams.get("id");

  const { data: provider, isLoading } = useQuery({
    queryKey: ["provider", providerId],
    queryFn: async () => {
      const providers = await base44.entities.ServiceProvider.list();
      return providers.find((p) => p.id === providerId);
    },
    enabled: !!providerId,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["providerReviews", providerId],
    queryFn: async () => {
      const allReviews = await base44.entities.ProviderReview.list("-created_date");
      return allReviews.filter((r) => r.provider_id === providerId);
    },
    enabled: !!providerId,
  });

  const averageRatings = {
    overall: reviews.length > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length : 0,
    professionalism: reviews.length > 0 ? reviews.reduce((sum, r) => sum + (r.professionalism || 0), 0) / reviews.length : 0,
    communication: reviews.length > 0 ? reviews.reduce((sum, r) => sum + (r.communication || 0), 0) / reviews.length : 0,
    reliability: reviews.length > 0 ? reviews.reduce((sum, r) => sum + (r.reliability || 0), 0) / reviews.length : 0,
    quality: reviews.length > 0 ? reviews.reduce((sum, r) => sum + (r.quality_of_service || 0), 0) / reviews.length : 0,
  };

  if (isLoading || !provider) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("FindCare"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Providers
        </Button>

        {/* Header Section */}
        <Card className="mb-6 overflow-hidden">
          <div className="h-48 bg-gradient-to-r from-blue-500 via-blue-600 to-green-500 relative">
            <div className="absolute inset-0 bg-black/20"></div>
            {provider.verified && (
              <Badge className="absolute top-4 right-4 bg-white text-primary">
                <CheckCircle className="w-4 h-4 mr-1" />
                Verified Provider
              </Badge>
            )}
          </div>
          <CardContent className="relative pt-6">
            <div className="flex flex-col md:flex-row gap-6">
              {/* Profile Photo */}
              <div className="relative -mt-20 md:-mt-16">
                {provider.photo_url ? (
                  <img
                    src={provider.photo_url}
                    alt={provider.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
                  />
                ) : (
                  <div className="w-32 h-32 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center border-4 border-white shadow-xl">
                    <span className="text-white font-bold text-4xl">
                      {provider.name?.charAt(0)}
                    </span>
                  </div>
                )}
              </div>

              {/* Provider Info */}
              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div>
                    <h1 className="text-3xl font-bold text-primary mb-2">{provider.name}</h1>
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <Badge className="bg-blue-100 text-blue-700 text-sm">
                        {provider.type?.replace(/_/g, " ")}
                      </Badge>
                      {provider.ndis_registered && (
                        <Badge className="bg-green-100 text-green-700 text-sm">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          NDIS Registered
                        </Badge>
                      )}
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Clock className="w-4 h-4" />
                        {provider.experience_years || 0}+ years experience
                      </div>
                    </div>

                    {/* Rating Summary */}
                    {reviews.length > 0 && (
                      <div className="flex items-center gap-4 mb-3">
                        <div className="flex items-center gap-2">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-5 h-5 ${
                                  star <= averageRatings.overall
                                    ? "fill-yellow-400 text-yellow-400"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-xl font-bold text-primary">
                            {averageRatings.overall.toFixed(1)}
                          </span>
                          <span className="text-sm text-gray-600">
                            ({reviews.length} reviews)
                          </span>
                        </div>
                        {provider.completion_rate && (
                          <div className="flex items-center gap-2 text-sm">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                            <span>{provider.completion_rate}% completion rate</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Location */}
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      <MapPin className="w-4 h-4 text-secondary" />
                      <span>{provider.location_suburb}, {provider.location_state}</span>
                      {provider.service_radius && (
                        <span className="text-gray-400">• {provider.service_radius}km radius</span>
                      )}
                    </div>

                    {/* Contact Info */}
                    <div className="flex flex-wrap gap-3 mt-4">
                      {provider.phone && (
                        <a href={`tel:${provider.phone}`}>
                          <Button variant="outline" size="sm" className="gap-2">
                            <Phone className="w-4 h-4" />
                            Call
                          </Button>
                        </a>
                      )}
                      {provider.email && (
                        <a href={`mailto:${provider.email}`}>
                          <Button variant="outline" size="sm" className="gap-2">
                            <Mail className="w-4 h-4" />
                            Email
                          </Button>
                        </a>
                      )}
                      {provider.website && (
                        <a href={provider.website} target="_blank" rel="noopener noreferrer">
                          <Button variant="outline" size="sm" className="gap-2">
                            <Globe className="w-4 h-4" />
                            Website
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <Card className="md:w-64">
                    <CardContent className="pt-6">
                      <div className="space-y-3">
                        {provider.hourly_rate && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Hourly Rate</span>
                            <span className="text-xl font-bold text-primary">
                              ${provider.hourly_rate}
                            </span>
                          </div>
                        )}
                        {provider.response_time && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Response Time</span>
                            <span className="text-sm font-semibold">{provider.response_time}</span>
                          </div>
                        )}
                        {provider.mobile_service && (
                          <Badge variant="outline" className="w-full justify-center">
                            Home Visits Available
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Tabs */}
        <Tabs defaultValue="about" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto">
            <TabsTrigger value="about" className="gap-2">
              <Users className="w-4 h-4" />
              About
            </TabsTrigger>
            <TabsTrigger value="services" className="gap-2">
              <Briefcase className="w-4 h-4" />
              Services
            </TabsTrigger>
            <TabsTrigger value="credentials" className="gap-2">
              <Award className="w-4 h-4" />
              Credentials
            </TabsTrigger>
            <TabsTrigger value="reviews" className="gap-2">
              <Star className="w-4 h-4" />
              Reviews
            </TabsTrigger>
            <TabsTrigger value="booking" className="gap-2">
              <Calendar className="w-4 h-4" />
              Book Now
            </TabsTrigger>
          </TabsList>

          {/* About Tab */}
          <TabsContent value="about" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {/* Bio */}
                {provider.bio && (
                  <Card>
                    <CardHeader>
                      <CardTitle>About Me</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                        {provider.bio}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Specialties */}
                {provider.specialties && provider.specialties.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Briefcase className="w-5 h-5 text-secondary" />
                        Areas of Expertise
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {provider.specialties.map((specialty, idx) => (
                          <div key={idx} className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                            <CheckCircle className="w-4 h-4 text-blue-600" />
                            <span className="text-sm font-medium">
                              {specialty.replace(/_/g, " ")}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Education */}
                {provider.education && provider.education.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <GraduationCap className="w-5 h-5 text-secondary" />
                        Education
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {provider.education.map((edu, idx) => (
                          <div key={idx} className="flex gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <GraduationCap className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{edu.degree}</h4>
                              <p className="text-sm text-gray-600">{edu.institution}</p>
                              {edu.year && (
                                <p className="text-xs text-gray-500 mt-1">{edu.year}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Gallery */}
                {provider.gallery_urls && provider.gallery_urls.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Gallery</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {provider.gallery_urls.map((url, idx) => (
                          <img
                            key={idx}
                            src={url}
                            alt={`Gallery ${idx + 1}`}
                            className="w-full h-40 object-cover rounded-lg"
                          />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Insurance & Checks */}
                {provider.insurance_details && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Shield className="w-5 h-5 text-secondary" />
                        Safety & Compliance
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {provider.insurance_details.has_professional_indemnity && (
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Professional Indemnity Insurance</span>
                        </div>
                      )}
                      {provider.insurance_details.has_public_liability && (
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Public Liability Insurance</span>
                        </div>
                      )}
                      {provider.insurance_details.working_with_children_check && (
                        <div className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Working with Children Check</span>
                        </div>
                      )}
                      {provider.insurance_details.police_check_date && (
                        <div className="text-sm">
                          <span className="text-gray-600">Police Check: </span>
                          <span className="font-medium">
                            {format(new Date(provider.insurance_details.police_check_date), "MMM yyyy")}
                          </span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Languages */}
                {provider.languages && provider.languages.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <LanguageIcon className="w-5 h-5 text-secondary" />
                        Languages
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {provider.languages.map((lang, idx) => (
                          <Badge key={idx} variant="outline">{lang}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Availability */}
                {provider.availability && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Clock className="w-5 h-5 text-secondary" />
                        Availability
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-700">{provider.availability}</p>
                    </CardContent>
                  </Card>
                )}

                {/* NDIS Info */}
                {provider.ndis_registered && (
                  <Card className="bg-green-50 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-lg text-green-900">NDIS Registered</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {provider.ndis_registration_number && (
                        <p className="text-sm text-green-800">
                          <span className="font-medium">Registration: </span>
                          {provider.ndis_registration_number}
                        </p>
                      )}
                      <p className="text-sm text-green-800">
                        You can claim this provider's services through your NDIS plan.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services">
            <ProviderServicesSection provider={provider} />
          </TabsContent>

          {/* Credentials Tab */}
          <TabsContent value="credentials">
            <ProviderCertificationsSection provider={provider} />
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews">
            <ProviderReviewsSection 
              provider={provider} 
              reviews={reviews} 
              averageRatings={averageRatings}
            />
          </TabsContent>

          {/* Booking Tab */}
          <TabsContent value="booking">
            <ProviderBookingSection provider={provider} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}