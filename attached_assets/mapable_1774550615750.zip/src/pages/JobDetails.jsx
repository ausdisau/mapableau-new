import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, MapPin, Clock, DollarSign, CheckCircle, Building, Upload } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function JobDetailsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const jobId = urlParams.get("id");

  const [showApplication, setShowApplication] = useState(false);
  const [applicationData, setApplicationData] = useState({
    cover_letter: "",
    resume_url: "",
    accommodation_needs: "",
    support_required: [],
  });
  const [uploadingResume, setUploadingResume] = useState(false);

  const { data: job, isLoading } = useQuery({
    queryKey: ["job", jobId],
    queryFn: async () => {
      const jobs = await base44.entities.Job.list();
      return jobs.find((j) => j.id === jobId);
    },
    enabled: !!jobId,
  });

  const applyMutation = useMutation({
    mutationFn: (data) => base44.entities.JobApplication.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myApplications"] });
      navigate(createPageUrl("Dashboard"));
    },
  });

  const handleResumeUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingResume(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setApplicationData({ ...applicationData, resume_url: file_url });
    } catch (error) {
      console.error("Error uploading resume:", error);
    }
    setUploadingResume(false);
  };

  const handleApply = () => {
    applyMutation.mutate({
      ...applicationData,
      job_id: jobId,
    });
  };

  if (isLoading || !job) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("FindJobs"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Jobs
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center">
                    <Building className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-primary mb-2">{job.title}</h1>
                    <p className="text-xl text-gray-700 font-medium mb-3">{job.company}</p>
                    <div className="flex flex-wrap gap-3 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {job.location}, {job.state}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {job.employment_type.replace(/_/g, " ")}
                      </div>
                      {(job.salary_min || job.salary_max) && (
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          ${job.salary_min?.toLocaleString()} - ${job.salary_max?.toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {job.disability_confident && (
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Disability Confident Employer
                    </Badge>
                  )}
                  {job.remote_option && <Badge variant="outline">Remote Available</Badge>}
                  {job.flexible_hours && <Badge variant="outline">Flexible Hours</Badge>}
                  {job.wheelchair_accessible && <Badge variant="outline">Wheelchair Accessible</Badge>}
                </div>

                {/* Description */}
                <div className="mb-6">
                  <h3 className="font-semibold text-lg mb-3">Job Description</h3>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{job.description}</p>
                </div>

                {/* Supports Available */}
                {job.supports_available && job.supports_available.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-lg mb-3">Workplace Support Available</h3>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {job.supports_available.map((support, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>{support.replace(/_/g, " ")}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Required Skills */}
                {job.required_skills && job.required_skills.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Required Skills</h3>
                    <div className="flex flex-wrap gap-2">
                      {job.required_skills.map((skill, idx) => (
                        <Badge key={idx} variant="secondary">{skill}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Application Form */}
            {showApplication && (
              <Card>
                <CardHeader>
                  <CardTitle>Submit Your Application</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Resume / CV</Label>
                    <Input
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={handleResumeUpload}
                      disabled={uploadingResume}
                    />
                    {applicationData.resume_url && (
                      <p className="text-sm text-green-600 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        Resume uploaded successfully
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Cover Letter</Label>
                    <Textarea
                      placeholder="Tell us why you're interested in this role..."
                      value={applicationData.cover_letter}
                      onChange={(e) => setApplicationData({ ...applicationData, cover_letter: e.target.value })}
                      rows={6}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Workplace Accommodations (Optional)</Label>
                    <Textarea
                      placeholder="Any accommodations you may need to perform this role..."
                      value={applicationData.accommodation_needs}
                      onChange={(e) => setApplicationData({ ...applicationData, accommodation_needs: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <Alert>
                    <AlertDescription className="text-sm">
                      Your accommodation information is confidential and will only be shared with the employer if you choose to disclose it during the interview process.
                    </AlertDescription>
                  </Alert>

                  <div className="flex gap-3">
                    <Button
                      onClick={handleApply}
                      className="flex-1 bg-secondary hover:bg-secondary/90"
                      disabled={!applicationData.cover_letter || applyMutation.isPending}
                    >
                      {applyMutation.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowApplication(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {!showApplication && (
              <Button
                onClick={() => setShowApplication(true)}
                className="w-full bg-secondary hover:bg-secondary/90 h-12 text-base"
              >
                Apply for This Position
              </Button>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Company Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Company</p>
                  <p className="font-semibold">{job.company}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-semibold">{job.location}</p>
                </div>
                {job.posted_date && (
                  <div>
                    <p className="text-sm text-gray-600">Posted</p>
                    <p className="font-semibold">{new Date(job.posted_date).toLocaleDateString()}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* NDIS Support Info */}
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-lg">NDIS Employment Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-700 mb-3">
                  You may be able to use your NDIS funding for:
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Job coaching and interview preparation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Workplace modifications</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>On-the-job support</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Transport to work</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}