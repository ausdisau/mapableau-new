import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Sparkles,
  Search,
  Filter,
  Users,
  Loader2,
  Bell,
  CheckCircle,
  TrendingUp,
  Info,
  MessageSquare,
  Star
} from "lucide-react";
import { toast } from "sonner";
import ProviderMatchCard from "../components/matching/ProviderMatchCard";
import MatchFilters from "../components/matching/MatchFilters";
import MatchScore from "../components/matching/MatchScore";

// AI Provider Matching Functions
async function findMatchingProviders(userData, options = {}) {
  const { useAI = true, maxResults = 20, minScore = 40 } = options;

  try {
    const providers = await base44.entities.ServiceProvider.list();

    if (!useAI) {
      return {
        success: true,
        matches: providers.slice(0, maxResults).map(provider => ({
          provider,
          match_score: 50,
          match_reasons: ["Provider available in your area"]
        }))
      };
    }

    const prompt = `Analyze user needs and match with providers. Return providers with score >= ${minScore}.

User: Services: ${userData.preferred_services?.join(", ") || "Any"}, Location: ${userData.location || "Any"}

Providers:
${providers.slice(0, 30).map(p => `- ${p.name}: ${p.type}, ${p.specialties?.join(", ") || "General"}, ${p.location_suburb}, ${p.location_state}`).join('\n')}

Score each provider 0-100 based on service alignment, location, and ratings.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          matches: {
            type: "array",
            items: {
              type: "object",
              properties: {
                provider_id: { type: "string" },
                match_score: { type: "number" },
                match_reasons: { type: "array", items: { type: "string" } },
                why_good_fit: { type: "string" }
              }
            }
          }
        }
      }
    });

    const matches = result.matches
      .map(match => {
        const provider = providers.find(p => p.id === match.provider_id || p.name === match.provider_id);
        return provider ? { provider, match_score: match.match_score, match_reasons: match.match_reasons, why_good_fit: match.why_good_fit } : null;
      })
      .filter(m => m !== null)
      .sort((a, b) => b.match_score - a.match_score);

    return { success: true, matches };
  } catch (error) {
    return { success: false, matches: [], error: error.message };
  }
}

async function notifyTopMatches(matches, userData, topN = 5) {
  try {
    const topMatches = matches.slice(0, topN);
    let notificationsSent = 0;

    for (const match of topMatches) {
      try {
        await base44.entities.Notification.create({
          user_email: match.provider.email,
          title: "New Participant Match",
          message: `${userData.full_name} is looking for services that match your profile (${match.match_score}% match).`,
          type: "message",
          priority: match.match_score >= 80 ? "high" : "medium",
        });
        notificationsSent++;
      } catch (error) {
        console.error(`Failed to notify ${match.provider.email}:`, error);
      }
    }

    return { success: true, notifications_sent: notificationsSent };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export default function ProviderMatchingPage() {
  const queryClient = useQueryClient();
  const [searching, setSearching] = useState(false);
  const [matches, setMatches] = useState([]);
  const [filters, setFilters] = useState({
    min_score: 40,
    preferred_services: [],
  });
  const [notifyingProviders, setNotifyingProviders] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const handleSearch = async () => {
    if (!currentUser) {
      toast.error("Please log in to find matching providers");
      return;
    }

    setSearching(true);

    try {
      const userData = {
        ...filters,
        email: currentUser.email,
        full_name: currentUser.full_name,
      };

      const result = await findMatchingProviders(userData, {
        useAI: true,
        maxResults: 20,
        minScore: filters.min_score || 40,
      });

      if (result.success) {
        setMatches(result.matches);
        
        if (result.matches.length === 0) {
          toast.info("No matches found. Try adjusting your filters.");
        } else {
          toast.success(`Found ${result.matches.length} matching providers!`);
        }
      } else {
        toast.error("Failed to find matches. Please try again.");
      }
    } catch (error) {
      toast.error("An error occurred during matching");
    }

    setSearching(false);
  };

  const handleNotifyTopProviders = async () => {
    if (matches.length === 0) {
      toast.error("No matches to notify");
      return;
    }

    setNotifyingProviders(true);

    try {
      const userData = {
        ...filters,
        email: currentUser.email,
        full_name: currentUser.full_name,
      };

      const result = await notifyTopMatches(matches, userData, 5);

      if (result.success) {
        toast.success(`Notified ${result.notifications_sent} providers about your search!`);
      }
    } catch (error) {
      toast.error("Failed to notify providers");
    }

    setNotifyingProviders(false);
  };

  const handleContact = (provider) => {
    toast.success(`Contact initiated with ${provider.name}`);
  };

  const stats = {
    total: matches.length,
    excellent: matches.filter(m => m.match_score >= 80).length,
    good: matches.filter(m => m.match_score >= 60 && m.match_score < 80).length,
    average: matches.filter(m => m.match_score < 60).length,
    avgScore: matches.length > 0 
      ? Math.round(matches.reduce((sum, m) => sum + m.match_score, 0) / matches.length)
      : 0
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl font-bold text-primary">
              AI Provider Matching
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Find the perfect support providers tailored to your unique needs
          </p>
        </div>

        <Alert className="mb-8 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <AlertDescription>
            <p className="font-semibold text-lg mb-2">How AI Matching Works:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Our AI analyzes your needs, preferences, and location</li>
              <li>We match you with providers based on specializations, experience, and reviews</li>
              <li>Each match includes a compatibility score and personalized insights</li>
              <li>Top providers can be notified about your search automatically</li>
            </ul>
          </AlertDescription>
        </Alert>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              <MatchFilters filters={filters} onChange={setFilters} />

              <Button
                onClick={handleSearch}
                disabled={searching}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 gap-2 h-12"
                size="lg"
              >
                {searching ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Finding Matches...
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    Find Matching Providers
                  </>
                )}
              </Button>

              {matches.length > 0 && (
                <Button
                  onClick={handleNotifyTopProviders}
                  disabled={notifyingProviders}
                  variant="outline"
                  className="w-full gap-2"
                >
                  {notifyingProviders ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Notifying...
                    </>
                  ) : (
                    <>
                      <Bell className="w-4 h-4" />
                      Notify Top 5 Providers
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            {matches.length === 0 && !searching ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Ready to Find Your Perfect Match?
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Configure your preferences and click "Find Matching Providers" to get started
                  </p>
                  <div className="max-w-md mx-auto">
                    <Alert className="bg-blue-50 border-blue-200 text-left">
                      <Info className="w-4 h-4 text-blue-600" />
                      <AlertDescription className="text-sm text-blue-900">
                        <p className="font-semibold mb-1">Tips for better matches:</p>
                        <ul className="list-disc list-inside space-y-1 text-xs">
                          <li>Select the specific services you need</li>
                          <li>Specify your location for local providers</li>
                          <li>Set your minimum match score preference</li>
                          <li>Use additional filters to refine results</li>
                        </ul>
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            ) : matches.length > 0 ? (
              <>
                <div className="grid sm:grid-cols-4 gap-4 mb-6">
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-3xl font-bold text-primary">{stats.total}</div>
                      <div className="text-sm text-gray-600">Total Matches</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-3xl font-bold text-green-600">{stats.excellent}</div>
                      <div className="text-sm text-gray-600">Excellent (80+)</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-3xl font-bold text-blue-600">{stats.good}</div>
                      <div className="text-sm text-gray-600">Good (60-79)</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <MatchScore score={stats.avgScore} size="sm" showLabel={false} />
                        <div>
                          <div className="text-sm font-semibold text-gray-700">
                            {stats.avgScore}%
                          </div>
                          <div className="text-xs text-gray-600">Avg Score</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Tabs defaultValue="all" className="space-y-6">
                  <TabsList>
                    <TabsTrigger value="all">
                      All ({stats.total})
                    </TabsTrigger>
                    <TabsTrigger value="excellent">
                      Excellent ({stats.excellent})
                    </TabsTrigger>
                    <TabsTrigger value="good">
                      Good ({stats.good})
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-4">
                    {matches.map((match, idx) => (
                      <ProviderMatchCard
                        key={match.provider.id}
                        match={match}
                        onContact={handleContact}
                      />
                    ))}
                  </TabsContent>

                  <TabsContent value="excellent" className="space-y-4">
                    {matches
                      .filter(m => m.match_score >= 80)
                      .map((match) => (
                        <ProviderMatchCard
                          key={match.provider.id}
                          match={match}
                          onContact={handleContact}
                        />
                      ))}
                    {stats.excellent === 0 && (
                      <Card>
                        <CardContent className="py-12 text-center">
                          <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                          <p className="text-gray-600">
                            No excellent matches found. Try adjusting your filters.
                          </p>
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>

                  <TabsContent value="good" className="space-y-4">
                    {matches
                      .filter(m => m.match_score >= 60 && m.match_score < 80)
                      .map((match) => (
                        <ProviderMatchCard
                          key={match.provider.id}
                          match={match}
                          onContact={handleContact}
                        />
                      ))}
                    {stats.good === 0 && (
                      <Card>
                        <CardContent className="py-12 text-center">
                          <TrendingUp className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                          <p className="text-gray-600">
                            No good matches in this range.
                          </p>
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>
                </Tabs>
              </>
            ) : null}

            {searching && (
              <Card>
                <CardContent className="py-20 text-center">
                  <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Finding Your Perfect Matches...
                  </h3>
                  <p className="text-gray-600">
                    Our AI is analyzing providers based on your preferences
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}