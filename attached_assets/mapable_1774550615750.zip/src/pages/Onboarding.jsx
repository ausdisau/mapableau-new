
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, ArrowRight, ArrowLeft, Users, Briefcase, Map } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const [formData, setFormData] = useState({
    // Personal Information
    phone: "",
    suburb: "",
    state: "",
    
    // NDIS Information
    ndis_participant_number: "",
    ndis_plan_start_date: "",
    ndis_plan_end_date: "",
    support_coordinator_email: "",
    
    // Accessibility & Preferences
    user_type: "participant",
    disability_type: [],
    accessibility_needs: [],
    communication_preferences: ["email", "in_app"],
    
    // Goals
    employment_goals: "",
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      navigate(createPageUrl("Dashboard"));
    },
  });

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    updateUserMutation.mutate(formData);
  };

  const handleDisabilityTypeToggle = (type) => {
    const current = formData.disability_type || [];
    if (current.includes(type)) {
      setFormData({
        ...formData,
        disability_type: current.filter(t => t !== type)
      });
    } else {
      setFormData({
        ...formData,
        disability_type: [...current, type]
      });
    }
  };

  const handleAccessibilityNeedToggle = (need) => {
    const current = formData.accessibility_needs || [];
    if (current.includes(need)) {
      setFormData({
        ...formData,
        accessibility_needs: current.filter(n => n !== need)
      });
    } else {
      setFormData({
        ...formData,
        accessibility_needs: [...current, need]
      });
    }
  };

  const handleCommunicationToggle = (pref) => {
    const current = formData.communication_preferences || [];
    if (current.includes(pref)) {
      setFormData({
        ...formData,
        communication_preferences: current.filter(p => p !== pref)
      });
    } else {
      setFormData({
        ...formData,
        communication_preferences: [...current, pref]
      });
    }
  };

  const progress = (currentStep / totalSteps) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header with Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/05d1cd4bf_mapable-logo-original.png"
              alt="MapAble"
              className="h-16 sm:h-20"
            />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Welcome to MapAble!
          </h1>
          <p className="text-gray-600 text-lg">
            Let's personalize your experience in just a few steps
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Step {currentStep} of {totalSteps}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">
                  {currentStep === 1 && "Personal Information"}
                  {currentStep === 2 && "NDIS Details"}
                  {currentStep === 3 && "Accessibility & Preferences"}
                  {currentStep === 4 && "Your Goals"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Step 1: Personal Information */}
                {currentStep === 1 && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="0412 345 678"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="suburb">Suburb *</Label>
                        <Input
                          id="suburb"
                          placeholder="e.g., Sydney"
                          value={formData.suburb}
                          onChange={(e) => setFormData({ ...formData, suburb: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="state">State *</Label>
                        <Select
                          value={formData.state}
                          onValueChange={(value) => setFormData({ ...formData, state: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select state" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="NSW">NSW</SelectItem>
                            <SelectItem value="VIC">VIC</SelectItem>
                            <SelectItem value="QLD">QLD</SelectItem>
                            <SelectItem value="SA">SA</SelectItem>
                            <SelectItem value="WA">WA</SelectItem>
                            <SelectItem value="TAS">TAS</SelectItem>
                            <SelectItem value="NT">NT</SelectItem>
                            <SelectItem value="ACT">ACT</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="user_type">I am a... *</Label>
                      <Select
                        value={formData.user_type}
                        onValueChange={(value) => setFormData({ ...formData, user_type: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="participant">NDIS Participant</SelectItem>
                          <SelectItem value="service_provider">Service Provider</SelectItem>
                          <SelectItem value="employer">Employer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Step 2: NDIS Details */}
                {currentStep === 2 && (
                  <div className="space-y-4">
                    {formData.user_type === "participant" && (
                      <>
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                          <p className="text-sm text-blue-900">
                            <strong>Note:</strong> Your NDIS information helps us provide better service recommendations 
                            and ensures you can use your funding effectively. This information is private and secure.
                          </p>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="ndis_number">NDIS Participant Number *</Label>
                          <Input
                            id="ndis_number"
                            placeholder="e.g., 415309600"
                            value={formData.ndis_participant_number}
                            onChange={(e) => setFormData({ ...formData, ndis_participant_number: e.target.value })}
                          />
                        </div>

                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="plan_start">Plan Start Date *</Label>
                            <Input
                              id="plan_start"
                              type="date"
                              value={formData.ndis_plan_start_date}
                              onChange={(e) => setFormData({ ...formData, ndis_plan_start_date: e.target.value })}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="plan_end">Plan End Date *</Label>
                            <Input
                              id="plan_end"
                              type="date"
                              value={formData.ndis_plan_end_date}
                              onChange={(e) => setFormData({ ...formData, ndis_plan_end_date: e.target.value })}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="coordinator_email">Support Coordinator Email (Optional)</Label>
                          <Input
                            id="coordinator_email"
                            type="email"
                            placeholder="coordinator@example.com"
                            value={formData.support_coordinator_email}
                            onChange={(e) => setFormData({ ...formData, support_coordinator_email: e.target.value })}
                          />
                        </div>
                      </>
                    )}

                    {formData.user_type !== "participant" && (
                      <div className="text-center py-12">
                        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">
                          NDIS details not required
                        </h3>
                        <p className="text-gray-600">
                          As a {formData.user_type.replace("_", " ")}, you can skip this step.
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 3: Accessibility & Preferences */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    {formData.user_type === "participant" && (
                      <>
                        <div>
                          <Label className="text-base font-semibold mb-3 block">
                            Disability Type (Optional - helps us personalize your experience)
                          </Label>
                          <div className="grid sm:grid-cols-2 gap-3">
                            {[
                              { value: "physical", label: "Physical" },
                              { value: "sensory", label: "Sensory" },
                              { value: "intellectual", label: "Intellectual" },
                              { value: "psychosocial", label: "Psychosocial" },
                              { value: "neurological", label: "Neurological" },
                              { value: "multiple", label: "Multiple" },
                            ].map((type) => (
                              <div key={type.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                                <Checkbox
                                  id={type.value}
                                  checked={formData.disability_type?.includes(type.value)}
                                  onCheckedChange={() => handleDisabilityTypeToggle(type.value)}
                                />
                                <label
                                  htmlFor={type.value}
                                  className="text-sm font-medium cursor-pointer flex-1"
                                >
                                  {type.label}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <Label className="text-base font-semibold mb-3 block">
                            Accessibility Needs *
                          </Label>
                          <div className="grid sm:grid-cols-2 gap-3">
                            {[
                              "Wheelchair accessible venues",
                              "Step-free access",
                              "Accessible parking",
                              "Accessible bathrooms",
                              "Sign language interpreter",
                              "Audio descriptions",
                              "Large print materials",
                              "Screen reader compatible",
                              "Quiet spaces",
                              "Service animals welcome",
                            ].map((need) => (
                              <div key={need} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                                <Checkbox
                                  id={need}
                                  checked={formData.accessibility_needs?.includes(need)}
                                  onCheckedChange={() => handleAccessibilityNeedToggle(need)}
                                />
                                <label
                                  htmlFor={need}
                                  className="text-sm font-medium cursor-pointer flex-1"
                                >
                                  {need}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    <div>
                      <Label className="text-base font-semibold mb-3 block">
                        How would you like us to contact you? *
                      </Label>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {[
                          { value: "email", label: "Email" },
                          { value: "sms", label: "SMS" },
                          { value: "in_app", label: "In-App Notifications" },
                          { value: "phone_call", label: "Phone Call" },
                        ].map((pref) => (
                          <div key={pref.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                            <Checkbox
                              id={pref.value}
                              checked={formData.communication_preferences?.includes(pref.value)}
                              onCheckedChange={() => handleCommunicationToggle(pref.value)}
                            />
                            <label
                              htmlFor={pref.value}
                              className="text-sm font-medium cursor-pointer flex-1"
                            >
                              {pref.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 4: Goals & Interests */}
                {currentStep === 4 && (
                  <div className="space-y-6">
                    {formData.user_type === "participant" && (
                      <div className="space-y-2">
                        <Label htmlFor="employment_goals">Employment Goals (Optional)</Label>
                        <Textarea
                          id="employment_goals"
                          placeholder="Tell us about your employment aspirations, desired work schedule, industries of interest, etc."
                          value={formData.employment_goals}
                          onChange={(e) => setFormData({ ...formData, employment_goals: e.target.value })}
                          rows={5}
                        />
                        <p className="text-xs text-gray-500">
                          This helps us match you with suitable job opportunities and support services
                        </p>
                      </div>
                    )}

                    <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                      <h3 className="font-semibold text-lg text-green-900 mb-3 flex items-center gap-2">
                        <CheckCircle className="w-5 h-5" />
                        What's Next?
                      </h3>
                      <ul className="space-y-2 text-sm text-green-800">
                        <li className="flex items-start gap-2">
                          <Users className="w-4 h-4 mt-0.5 text-secondary" />
                          <span>Discover care services and support workers in your area</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Briefcase className="w-4 h-4 mt-0.5 text-secondary" />
                          <span>Browse inclusive employment opportunities</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Map className="w-4 h-4 mt-0.5 text-secondary" />
                          <span>Explore accessible places with community-verified ratings</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={handleBack}
                    disabled={currentStep === 1}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>

                  {currentStep < totalSteps ? (
                    <Button
                      onClick={handleNext}
                      className="bg-secondary hover:bg-secondary/90"
                    >
                      Next
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button
                      onClick={handleSubmit}
                      disabled={updateUserMutation.isPending}
                      className="bg-secondary hover:bg-secondary/90"
                    >
                      {updateUserMutation.isPending ? "Saving..." : "Complete Setup"}
                      <CheckCircle className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>

                {/* Skip Option */}
                <div className="text-center pt-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(createPageUrl("Dashboard"))}
                    className="text-gray-500"
                  >
                    Skip for now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
