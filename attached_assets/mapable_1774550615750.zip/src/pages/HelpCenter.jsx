import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Search,
  BookOpen,
  HelpCircle,
  MessageCircle,
  ThumbsUp,
  Eye,
  ChevronRight,
  FileText,
  Users,
  Car,
  Shield,
  DollarSign,
  MapPin,
  Star
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import HelpArticleCard from "../components/help/HelpArticleCard";
import PopularArticles from "../components/help/PopularArticles";
import QuickLinks from "../components/help/QuickLinks";

export default function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: articles = [], isLoading } = useQuery({
    queryKey: ["knowledgeBaseArticles"],
    queryFn: () => base44.entities.KnowledgeBaseArticle.filter({ published: true }, "-view_count"),
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  // Category configuration with icons and descriptions
  const categories = [
    {
      id: "getting_started",
      label: "Getting Started",
      icon: BookOpen,
      description: "Learn the basics of using MapAble",
      color: "blue"
    },
    {
      id: "ndis_funding",
      label: "NDIS Funding",
      icon: DollarSign,
      description: "Understanding NDIS plans and budgets",
      color: "green"
    },
    {
      id: "booking_services",
      label: "Booking Services",
      icon: Car,
      description: "How to book transport and care services",
      color: "purple"
    },
    {
      id: "finding_jobs",
      label: "Finding Jobs",
      icon: Users,
      description: "Employment opportunities and applications",
      color: "orange"
    },
    {
      id: "accessibility",
      label: "Accessibility",
      icon: MapPin,
      description: "Using accessibility features and ratings",
      color: "teal"
    },
    {
      id: "troubleshooting",
      label: "Troubleshooting",
      icon: HelpCircle,
      description: "Solutions to common issues",
      color: "red"
    },
    {
      id: "billing_payments",
      label: "Billing & Payments",
      icon: Shield,
      description: "Payment processing and invoices",
      color: "indigo"
    }
  ];

  // Filter articles based on search and category
  const filteredArticles = articles.filter(article => {
    const matchesSearch = !searchQuery || 
      article.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  // Get articles by category
  const getArticlesByCategory = (categoryId) => {
    return articles.filter(a => a.category === categoryId);
  };

  // Get popular articles (top 5 by view count)
  const popularArticles = [...articles]
    .sort((a, b) => (b.view_count || 0) - (a.view_count || 0))
    .slice(0, 5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <HelpCircle className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-primary mb-4">
            How can we help you?
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Find answers to your questions, learn how to use MapAble, and get the most out of our platform
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search for help articles, guides, and FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-6 text-lg border-2 border-gray-200 focus:border-blue-500 rounded-xl shadow-lg"
              />
            </div>
            {searchQuery && (
              <p className="text-sm text-gray-600 mt-2">
                Found {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} matching "{searchQuery}"
              </p>
            )}
          </div>
        </div>

        {/* Quick Links */}
        <QuickLinks />

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-8">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 gap-2 h-auto bg-transparent p-0">
            <TabsTrigger
              value="all"
              className="data-[state=active]:bg-white data-[state=active]:shadow-md border border-transparent data-[state=active]:border-blue-200"
            >
              All Topics
            </TabsTrigger>
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="data-[state=active]:bg-white data-[state=active]:shadow-md border border-transparent data-[state=active]:border-blue-200"
              >
                <category.icon className="w-4 h-4 mr-2" />
                <span className="hidden lg:inline">{category.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Search Results or Category View */}
            {searchQuery ? (
              <div>
                <h2 className="text-2xl font-bold text-primary mb-6">
                  Search Results
                </h2>
                {filteredArticles.length === 0 ? (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        No articles found
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Try different keywords or browse by category
                      </p>
                      <Button
                        onClick={() => setSearchQuery("")}
                        variant="outline"
                      >
                        Clear Search
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {filteredArticles.map(article => (
                      <HelpArticleCard key={article.id} article={article} />
                    ))}
                  </div>
                )}
              </div>
            ) : selectedCategory === "all" ? (
              // Show all categories
              categories.map(category => {
                const categoryArticles = getArticlesByCategory(category.id);
                if (categoryArticles.length === 0) return null;
                
                return (
                  <div key={category.id}>
                    <div className="flex items-center gap-3 mb-4">
                      <div className={`w-10 h-10 rounded-lg bg-${category.color}-100 flex items-center justify-center`}>
                        <category.icon className={`w-5 h-5 text-${category.color}-600`} />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-primary">{category.label}</h2>
                        <p className="text-sm text-gray-600">{category.description}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {categoryArticles.slice(0, 3).map(article => (
                        <HelpArticleCard key={article.id} article={article} compact />
                      ))}
                    </div>
                    {categoryArticles.length > 3 && (
                      <Button
                        variant="ghost"
                        onClick={() => setSelectedCategory(category.id)}
                        className="mt-3 gap-2"
                      >
                        View all {categoryArticles.length} articles
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                );
              })
            ) : (
              // Show selected category
              <div>
                {(() => {
                  const category = categories.find(c => c.id === selectedCategory);
                  const categoryArticles = getArticlesByCategory(selectedCategory);
                  
                  return (
                    <>
                      <div className="flex items-center gap-3 mb-6">
                        <div className={`w-12 h-12 rounded-xl bg-${category.color}-100 flex items-center justify-center`}>
                          <category.icon className={`w-6 h-6 text-${category.color}-600`} />
                        </div>
                        <div>
                          <h2 className="text-3xl font-bold text-primary">{category.label}</h2>
                          <p className="text-gray-600">{category.description}</p>
                        </div>
                      </div>
                      
                      {categoryArticles.length === 0 ? (
                        <Card>
                          <CardContent className="py-12 text-center">
                            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-gray-900 mb-2">
                              No articles yet
                            </h3>
                            <p className="text-gray-600">
                              Articles for this category are coming soon
                            </p>
                          </CardContent>
                        </Card>
                      ) : (
                        <div className="space-y-4">
                          {categoryArticles.map(article => (
                            <HelpArticleCard key={article.id} article={article} />
                          ))}
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Popular Articles */}
            <PopularArticles articles={popularArticles} />

            {/* Contact Support */}
            <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-purple-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-blue-600" />
                  Still Need Help?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-gray-700">
                  Can't find what you're looking for? Our support team is here to help!
                </p>
                <Link to={createPageUrl("Support")}>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Contact Support
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Helpful Resources */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Helpful Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link
                  to={createPageUrl("Dashboard")}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                >
                  <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Video Tutorials</p>
                    <p className="text-xs text-gray-600">Step-by-step guides</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </Link>

                <Link
                  to={createPageUrl("Dashboard")}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                >
                  <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <Users className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">Community Forum</p>
                    <p className="text-xs text-gray-600">Connect with others</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </Link>

                <a
                  href="https://www.ndis.gov.au"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                >
                  <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <Shield className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">NDIS Resources</p>
                    <p className="text-xs text-gray-600">Official NDIS info</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </a>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="bg-gradient-to-br from-gray-50 to-gray-100">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div>
                    <p className="text-3xl font-bold text-primary">{articles.length}</p>
                    <p className="text-sm text-gray-600">Help Articles</p>
                  </div>
                  <div className="pt-4 border-t">
                    <p className="text-2xl font-bold text-blue-600">
                      {articles.reduce((sum, a) => sum + (a.view_count || 0), 0)}
                    </p>
                    <p className="text-sm text-gray-600">Total Views</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}