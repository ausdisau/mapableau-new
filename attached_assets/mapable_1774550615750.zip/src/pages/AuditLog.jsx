import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Shield,
  Search,
  Download,
  AlertTriangle,
  Activity,
  User,
  Calendar,
  Filter,
  FileText,
  ChevronRight
} from "lucide-react";
import { format } from "date-fns";
import { hasPermission, PERMISSIONS } from "@/components/utils/permissions";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function AuditLogPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [actionTypeFilter, setActionTypeFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [selectedLog, setSelectedLog] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: auditLogs = [], isLoading } = useQuery({
    queryKey: ["auditLogs"],
    queryFn: () => base44.entities.AuditLog.list("-created_date", 500),
    enabled: hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
    enabled: hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)
  });

  if (!hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can view audit logs.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const getUserByEmail = (email) => allUsers.find(u => u.email === email);

  // Filter logs
  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.actor_email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.target_email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesAction = actionTypeFilter === "all" || log.action_type === actionTypeFilter;
    const matchesSeverity = severityFilter === "all" || log.severity === severityFilter;
    
    let matchesDate = true;
    if (dateFilter !== "all" && log.created_date) {
      const logDate = new Date(log.created_date);
      const now = new Date();
      const daysDiff = Math.floor((now - logDate) / (1000 * 60 * 60 * 24));
      
      if (dateFilter === "today") matchesDate = daysDiff === 0;
      else if (dateFilter === "week") matchesDate = daysDiff <= 7;
      else if (dateFilter === "month") matchesDate = daysDiff <= 30;
    }
    
    return matchesSearch && matchesAction && matchesSeverity && matchesDate;
  });

  // Statistics
  const stats = {
    total: auditLogs.length,
    today: auditLogs.filter(l => {
      if (!l.created_date) return false;
      const today = new Date().toDateString();
      return new Date(l.created_date).toDateString() === today;
    }).length,
    critical: auditLogs.filter(l => l.severity === "critical").length,
    failed: auditLogs.filter(l => l.status === "failed").length
  };

  const getSeverityColor = (severity) => {
    const colors = {
      low: "bg-blue-100 text-blue-700",
      medium: "bg-yellow-100 text-yellow-700",
      high: "bg-orange-100 text-orange-700",
      critical: "bg-red-100 text-red-700"
    };
    return colors[severity] || "bg-gray-100 text-gray-700";
  };

  const getActionIcon = (actionType) => {
    if (actionType.includes("user")) return User;
    if (actionType.includes("credential")) return Shield;
    if (actionType.includes("booking")) return Calendar;
    if (actionType.includes("schedule")) return Calendar;
    if (actionType.includes("payment")) return FileText;
    return Activity;
  };

  const handleExport = () => {
    const csv = [
      ["Date", "Action", "Actor", "Target", "Severity", "Status", "Description"].join(","),
      ...filteredLogs.map(log => [
        log.created_date ? format(new Date(log.created_date), "yyyy-MM-dd HH:mm:ss") : "",
        log.action_type,
        log.actor_email,
        log.target_email || "",
        log.severity,
        log.status,
        `"${log.description?.replace(/"/g, '""') || ""}"`
      ].join(","))
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-log-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl font-bold text-primary">Audit Log</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Track and monitor all significant actions across the platform
          </p>
        </div>

        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Events</p>
                  <p className="text-3xl font-bold text-primary">{stats.total}</p>
                </div>
                <Activity className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Today</p>
                  <p className="text-3xl font-bold text-green-600">{stats.today}</p>
                </div>
                <Calendar className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Critical Events</p>
                  <p className="text-3xl font-bold text-red-600">{stats.critical}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Failed Actions</p>
                  <p className="text-3xl font-bold text-orange-600">{stats.failed}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="lg:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by description, actor, or target..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Action Type */}
              <Select value={actionTypeFilter} onValueChange={setActionTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Actions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Actions</SelectItem>
                  <SelectItem value="user_role_changed">Role Changes</SelectItem>
                  <SelectItem value="credential_approved">Credentials Approved</SelectItem>
                  <SelectItem value="credential_rejected">Credentials Rejected</SelectItem>
                  <SelectItem value="booking_cancelled">Bookings Cancelled</SelectItem>
                  <SelectItem value="schedule_published">Schedules Published</SelectItem>
                  <SelectItem value="payment_processed">Payments Processed</SelectItem>
                  <SelectItem value="settings_changed">Settings Changed</SelectItem>
                </SelectContent>
              </Select>

              {/* Severity */}
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Severities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>

              {/* Date Range */}
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between mt-4 pt-4 border-t">
              <p className="text-sm text-gray-600">
                Showing {filteredLogs.length} of {auditLogs.length} events
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                className="gap-2"
                disabled={filteredLogs.length === 0}
              >
                <Download className="w-4 h-4" />
                Export CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Audit Log Entries */}
        <Card>
          <CardHeader>
            <CardTitle>Audit Trail</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredLogs.length === 0 ? (
              <div className="py-12 text-center">
                <Activity className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No audit logs found</h3>
                <p className="text-gray-600">Try adjusting your filters</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredLogs.map((log) => {
                  const actor = getUserByEmail(log.actor_email);
                  const target = log.target_email ? getUserByEmail(log.target_email) : null;
                  const Icon = getActionIcon(log.action_type);

                  return (
                    <div
                      key={log.id}
                      onClick={() => setSelectedLog(log)}
                      className="p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <div className={`w-10 h-10 rounded-lg ${getSeverityColor(log.severity)} bg-opacity-20 flex items-center justify-center flex-shrink-0`}>
                            <Icon className="w-5 h-5" />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <h3 className="font-semibold text-gray-900">{log.description}</h3>
                              <Badge className={getSeverityColor(log.severity)}>
                                {log.severity}
                              </Badge>
                              {log.status === "failed" && (
                                <Badge className="bg-red-100 text-red-700">Failed</Badge>
                              )}
                            </div>

                            <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                <span className="font-medium">
                                  {actor?.full_name || log.actor_email}
                                </span>
                                {log.actor_role && (
                                  <span className="text-xs text-gray-500">({log.actor_role})</span>
                                )}
                              </div>

                              {target && (
                                <>
                                  <ChevronRight className="w-3 h-3 text-gray-400" />
                                  <span>{target.full_name}</span>
                                </>
                              )}

                              <span className="text-gray-400">•</span>
                              
                              {log.created_date && (
                                <div className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {format(new Date(log.created_date), "MMM d, yyyy 'at' h:mm a")}
                                </div>
                              )}
                            </div>

                            {log.changes?.fields_changed && (
                              <div className="mt-2">
                                <span className="text-xs text-gray-500">
                                  Changed: {log.changes.fields_changed.join(", ")}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>

                        <Badge variant="outline" className="text-xs capitalize flex-shrink-0">
                          {log.action_type?.replace(/_/g, " ")}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Details Dialog */}
      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Audit Log Details</DialogTitle>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label>Action Type</Label>
                  <p className="font-medium capitalize">{selectedLog.action_type?.replace(/_/g, " ")}</p>
                </div>
                <div>
                  <Label>Severity</Label>
                  <Badge className={getSeverityColor(selectedLog.severity)}>
                    {selectedLog.severity}
                  </Badge>
                </div>
                <div>
                  <Label>Status</Label>
                  <Badge variant={selectedLog.status === "success" ? "default" : "destructive"}>
                    {selectedLog.status}
                  </Badge>
                </div>
                <div>
                  <Label>Timestamp</Label>
                  <p className="text-sm">
                    {selectedLog.created_date && format(new Date(selectedLog.created_date), "PPpp")}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Actor</Label>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-medium">{getUserByEmail(selectedLog.actor_email)?.full_name || selectedLog.actor_email}</p>
                  <p className="text-sm text-gray-600">{selectedLog.actor_email}</p>
                  {selectedLog.actor_role && (
                    <Badge variant="outline" className="mt-1 text-xs capitalize">
                      {selectedLog.actor_role}
                    </Badge>
                  )}
                </div>
              </div>

              {selectedLog.target_email && (
                <div className="space-y-2">
                  <Label>Target</Label>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="font-medium">
                      {getUserByEmail(selectedLog.target_email)?.full_name || selectedLog.target_email}
                    </p>
                    <p className="text-sm text-gray-600">{selectedLog.target_email}</p>
                    {selectedLog.target_entity_type && (
                      <p className="text-xs text-gray-500 mt-1">
                        Entity: {selectedLog.target_entity_type} ({selectedLog.target_entity_id})
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Description</Label>
                <p className="text-sm text-gray-700 p-3 bg-gray-50 rounded-lg">
                  {selectedLog.description}
                </p>
              </div>

              {selectedLog.changes && (
                <div className="space-y-2">
                  <Label>Changes</Label>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap overflow-x-auto">
                      {JSON.stringify(selectedLog.changes, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {selectedLog.metadata && Object.keys(selectedLog.metadata).length > 0 && (
                <div className="space-y-2">
                  <Label>Metadata</Label>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap overflow-x-auto">
                      {JSON.stringify(selectedLog.metadata, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {selectedLog.user_agent && (
                <div className="space-y-2">
                  <Label>User Agent</Label>
                  <p className="text-xs text-gray-600 p-3 bg-gray-50 rounded-lg break-all">
                    {selectedLog.user_agent}
                  </p>
                </div>
              )}

              {selectedLog.error_message && (
                <Alert className="bg-red-50 border-red-200">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    <span className="font-semibold">Error: </span>
                    {selectedLog.error_message}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Label({ children, className = "" }) {
  return <label className={`text-sm font-medium text-gray-700 ${className}`}>{children}</label>;
}