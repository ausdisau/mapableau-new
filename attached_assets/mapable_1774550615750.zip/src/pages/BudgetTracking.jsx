import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, Calendar, ArrowLeft, Download } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInDays } from "date-fns";

export default function BudgetTrackingPage() {
  const navigate = useNavigate();

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["myServiceRequests"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.ServiceRequest.filter({ created_by: user.email }, "-created_date");
    },
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["myPayments"],
    queryFn: async () => {
      const allPayments = await base44.entities.Payment.list("-created_date");
      const myRequestIds = serviceRequests.map(r => r.id);
      return allPayments.filter(p => myRequestIds.includes(p.service_request_id));
    },
    enabled: serviceRequests.length > 0,
  });

  const totalSpent = payments
    .filter(p => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  const pendingPayments = payments.filter(p => 
    ["pending", "processing", "ndis_submitted"].includes(p.status)
  ).reduce((sum, p) => sum + p.amount, 0);

  const ndisPayments = payments.filter(p => p.payment_method === "ndis_direct");
  const stripePayments = payments.filter(p => p.payment_method === "stripe");

  const categoryBreakdown = serviceRequests.reduce((acc, req) => {
    const category = req.service_type;
    if (!acc[category]) {
      acc[category] = { count: 0, total: 0 };
    }
    acc[category].count++;
    acc[category].total += req.total_cost || 0;
    return acc;
  }, {});

  const planDaysRemaining = currentUser?.ndis_plan_end_date
    ? differenceInDays(new Date(currentUser.ndis_plan_end_date), new Date())
    : null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Dashboard"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Budget & Spending Tracker
          </h1>
          <p className="text-gray-600 text-lg">
            Monitor your NDIS plan utilization and service spending
          </p>
        </div>

        {/* NDIS Plan Overview */}
        {currentUser?.ndis_participant_number && (
          <Card className="mb-8 bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
            <CardHeader>
              <CardTitle>NDIS Plan Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Participant Number</p>
                  <p className="font-mono text-lg font-semibold">{currentUser.ndis_participant_number}</p>
                </div>
                {currentUser.ndis_plan_start_date && (
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Plan Start Date</p>
                    <p className="font-semibold">{format(new Date(currentUser.ndis_plan_start_date), "MMM d, yyyy")}</p>
                  </div>
                )}
                {currentUser.ndis_plan_end_date && (
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Plan End Date</p>
                    <p className="font-semibold">{format(new Date(currentUser.ndis_plan_end_date), "MMM d, yyyy")}</p>
                    {planDaysRemaining !== null && (
                      <p className="text-sm text-blue-700 mt-1">
                        {planDaysRemaining > 0 ? `${planDaysRemaining} days remaining` : "Plan expired"}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Spending Summary */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-1">Total Spent</p>
              <p className="text-3xl font-bold text-primary mb-2">${totalSpent.toFixed(2)}</p>
              <p className="text-xs text-gray-500">{payments.filter(p => p.status === "succeeded").length} completed payments</p>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-1">Pending Payments</p>
              <p className="text-3xl font-bold text-primary mb-2">${pendingPayments.toFixed(2)}</p>
              <p className="text-xs text-gray-500">{payments.filter(p => ["pending", "processing", "ndis_submitted"].includes(p.status)).length} awaiting processing</p>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-1">Services Booked</p>
              <p className="text-3xl font-bold text-primary mb-2">{serviceRequests.length}</p>
              <p className="text-xs text-gray-500">Across all categories</p>
            </CardContent>
          </Card>
        </div>

        {/* Service Category Breakdown */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Spending by Service Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(categoryBreakdown).map(([category, data]) => {
                const percentage = totalSpent > 0 ? (data.total / totalSpent) * 100 : 0;
                return (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{category.replace(/_/g, " ")}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-gray-600">{data.count} services</span>
                        <span className="font-semibold text-primary">${data.total.toFixed(2)}</span>
                      </div>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Payment History */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Payment History</CardTitle>
              <Button variant="outline" size="sm" className="gap-2">
                <Download className="w-4 h-4" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {payments.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <DollarSign className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No payment history yet</p>
                </div>
              ) : (
                payments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <p className="font-semibold">${payment.amount.toFixed(2)}</p>
                        <Badge variant="outline" className="text-xs">
                          {payment.payment_method === "stripe" ? "Card" : "NDIS"}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {format(new Date(payment.payment_date || payment.created_date), "MMMM d, yyyy 'at' h:mm a")}
                      </p>
                      {payment.ndis_claim_reference && (
                        <p className="text-xs text-gray-500 mt-1 font-mono">
                          Ref: {payment.ndis_claim_reference}
                        </p>
                      )}
                    </div>
                    <Badge className={
                      payment.status === "succeeded" ? "bg-green-100 text-green-700" :
                      payment.status === "ndis_submitted" || payment.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                      payment.status === "failed" ? "bg-red-100 text-red-700" :
                      "bg-gray-100 text-gray-700"
                    }>
                      {payment.status.replace(/_/g, " ")}
                    </Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}