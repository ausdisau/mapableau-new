import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Sparkles,
  FileText,
  MessageSquare,
  Lightbulb,
  BarChart3,
  Briefcase,
  MapPin,
  User,
} from "lucide-react";
import AIContentGenerator from "../components/ai/AIContentGenerator";
import AISummarizer from "../components/ai/AISummarizer";
import AISuggestions from "../components/ai/AISuggestions";

export default function AIAssistantDemoPage() {
  const [showGenerator, setShowGenerator] = useState(false);
  const [generatorType, setGeneratorType] = useState("general");
  const [generatorContext, setGeneratorContext] = useState({});
  const [generatorTitle, setGeneratorTitle] = useState("");

  // Demo data
  const [jobTitle, setJobTitle] = useState("Customer Support Specialist");
  const [company, setCompany] = useState("MapAble");
  const [location, setLocation] = useState("Sydney, NSW");

  const [locationName, setLocationName] = useState("The Accessible Café");
  const [locationCategory, setLocationCategory] = useState("café");

  const [providerName, setProviderName] = useState("Sarah Johnson");
  const [providerType, setProviderType] = useState("Support Worker");
  const [providerExp, setProviderExp] = useState("8");

  const [textToSummarize, setTextToSummarize] = useState(
    "MapAble is an innovative NDIS-registered platform designed to empower people with disabilities across Australia and New Zealand. Our comprehensive ecosystem includes accessible location mapping, transport coordination, employment opportunities, and care service connections. We believe in creating an inclusive digital environment where everyone can access the services they need with dignity and independence. Our platform features real-time tracking, intelligent route optimization, credential verification systems, and seamless NDIS integration. With over 1,000 verified providers and 5,000 accessible locations mapped, we're building the future of disability services together."
  );

  const [contentToAnalyze, setContentToAnalyze] = useState(
    "Looking for a support worker who can help with daily activities and community access in the Western Sydney area."
  );

  const handleOpenGenerator = (type, title, context) => {
    setGeneratorType(type);
    setGeneratorTitle(title);
    setGeneratorContext(context);
    setShowGenerator(true);
  };

  const handleApplyGenerated = (content) => {
    console.log("Generated content:", content);
  };

  const handleApplySuggestion = (suggestion) => {
    console.log("Applied suggestion:", suggestion);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl font-bold text-primary">AI Assistant Demo</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Explore AI-powered features that enhance productivity across MapAble
          </p>
        </div>

        {/* Overview */}
        <Alert className="mb-8 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <AlertDescription>
            <p className="font-semibold text-lg mb-2">AI Capabilities:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li><strong>Content Generation:</strong> Create job descriptions, location notes, provider bios</li>
              <li><strong>Text Summarization:</strong> Condense lengthy content into key points</li>
              <li><strong>Smart Suggestions:</strong> Get relevant categories, tags, and improvements</li>
              <li><strong>Message Drafting:</strong> Generate professional responses and communications</li>
            </ul>
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="generation" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="generation">
              <FileText className="w-4 h-4 mr-2" />
              Content Generation
            </TabsTrigger>
            <TabsTrigger value="summarization">
              <BarChart3 className="w-4 h-4 mr-2" />
              Summarization
            </TabsTrigger>
            <TabsTrigger value="suggestions">
              <Lightbulb className="w-4 h-4 mr-2" />
              Smart Suggestions
            </TabsTrigger>
            <TabsTrigger value="messaging">
              <MessageSquare className="w-4 h-4 mr-2" />
              Message Drafting
            </TabsTrigger>
          </TabsList>

          {/* Content Generation Tab */}
          <TabsContent value="generation">
            <div className="grid md:grid-cols-3 gap-6">
              {/* Job Description Generator */}
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Briefcase className="w-5 h-5 text-purple-600" />
                    Job Description
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs">Job Title</Label>
                    <Input
                      placeholder="e.g., Support Worker"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Company</Label>
                    <Input
                      placeholder="e.g., MapAble"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Location</Label>
                    <Input
                      placeholder="e.g., Sydney, NSW"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <Button
                    onClick={() =>
                      handleOpenGenerator(
                        "job_description",
                        "Generate Job Description",
                        {
                          title: jobTitle,
                          company: company,
                          location: location,
                          employment_type: "full_time",
                        }
                      )
                    }
                    className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    Generate
                  </Button>
                </CardContent>
              </Card>

              {/* Location Notes Generator */}
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <MapPin className="w-5 h-5 text-green-600" />
                    Accessibility Notes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs">Location Name</Label>
                    <Input
                      placeholder="e.g., The Accessible Café"
                      value={locationName}
                      onChange={(e) => setLocationName(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Category</Label>
                    <Input
                      placeholder="e.g., Café, Restaurant"
                      value={locationCategory}
                      onChange={(e) => setLocationCategory(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="h-[52px]"></div>
                  <Button
                    onClick={() =>
                      handleOpenGenerator(
                        "location_notes",
                        "Generate Accessibility Notes",
                        {
                          name: locationName,
                          category: locationCategory,
                          features: "Wheelchair ramp, accessible bathroom",
                        }
                      )
                    }
                    className="w-full bg-green-600 hover:bg-green-700 gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    Generate
                  </Button>
                </CardContent>
              </Card>

              {/* Provider Bio Generator */}
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <User className="w-5 h-5 text-blue-600" />
                    Provider Bio
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs">Provider Name</Label>
                    <Input
                      placeholder="e.g., Sarah Johnson"
                      value={providerName}
                      onChange={(e) => setProviderName(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Type</Label>
                    <Input
                      placeholder="e.g., Support Worker"
                      value={providerType}
                      onChange={(e) => setProviderType(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Experience (years)</Label>
                    <Input
                      type="number"
                      placeholder="e.g., 5"
                      value={providerExp}
                      onChange={(e) => setProviderExp(e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <Button
                    onClick={() =>
                      handleOpenGenerator(
                        "provider_bio",
                        "Generate Provider Bio",
                        {
                          name: providerName,
                          type: providerType,
                          experience_years: providerExp,
                          specialties: ["Personal care", "Community access"],
                        }
                      )
                    }
                    className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    Generate
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Summarization Tab */}
          <TabsContent value="summarization">
            <Card>
              <CardHeader>
                <CardTitle>Text Summarization</CardTitle>
                <p className="text-sm text-gray-600">
                  Condense lengthy text into concise summaries
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Text to Summarize</Label>
                  <Textarea
                    placeholder="Enter text to summarize..."
                    value={textToSummarize}
                    onChange={(e) => setTextToSummarize(e.target.value)}
                    rows={8}
                  />
                </div>

                <AISummarizer text={textToSummarize} />

                <Alert className="bg-blue-50 border-blue-200">
                  <BarChart3 className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-sm text-blue-900">
                    <p className="font-semibold mb-1">Use cases:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Summarize audit logs for quick review</li>
                      <li>Condense user feedback and reviews</li>
                      <li>Create executive summaries of reports</li>
                      <li>Quick overviews of long documents</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Smart Suggestions Tab */}
          <TabsContent value="suggestions">
            <Card>
              <CardHeader>
                <CardTitle>Smart Suggestions</CardTitle>
                <p className="text-sm text-gray-600">
                  Get AI-powered suggestions for categories, tags, and improvements
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Content to Analyze</Label>
                  <Textarea
                    placeholder="Enter content to get suggestions..."
                    value={contentToAnalyze}
                    onChange={(e) => setContentToAnalyze(e.target.value)}
                    rows={6}
                  />
                </div>

                <AISuggestions
                  content={contentToAnalyze}
                  type="service_request"
                  onApplySuggestion={handleApplySuggestion}
                />

                <Alert className="bg-green-50 border-green-200">
                  <Lightbulb className="w-4 h-4 text-green-600" />
                  <AlertDescription className="text-sm text-green-900">
                    <p className="font-semibold mb-1">Intelligent assistance:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Suggest relevant categories for listings</li>
                      <li>Recommend tags for better discoverability</li>
                      <li>Improve text clarity and engagement</li>
                      <li>Optimize content for search</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Message Drafting Tab */}
          <TabsContent value="messaging">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Message Reply Generator</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() =>
                      handleOpenGenerator(
                        "message_reply",
                        "Draft Message Reply",
                        {
                          thread: [
                            {
                              from: "John",
                              content: "Hi, I'm looking for transport services for medical appointments.",
                            },
                          ],
                        }
                      )
                    }
                    className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Generate Reply
                  </Button>
                  <p className="text-xs text-gray-600 mt-3">
                    AI will draft a professional, helpful response to messages
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Support Ticket Response</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() =>
                      handleOpenGenerator(
                        "ticket_response",
                        "Draft Ticket Response",
                        {
                          subject: "Cannot find accessible locations",
                          description: "I'm trying to search for wheelchair-accessible cafés but the filters aren't working.",
                          category: "technical",
                          priority: "medium",
                        }
                      )
                    }
                    className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    Generate Response
                  </Button>
                  <p className="text-xs text-gray-600 mt-3">
                    AI will create empathetic, solution-focused support responses
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Integration Info */}
        <Card className="mt-8 border-2 border-purple-200">
          <CardHeader>
            <CardTitle>AI Integration Across MapAble</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-purple-50 rounded-lg">
                <Briefcase className="w-6 h-6 text-purple-600 mb-2" />
                <h4 className="font-semibold mb-1">Job Postings</h4>
                <p className="text-xs text-gray-600">
                  Generate engaging, inclusive job descriptions
                </p>
              </div>

              <div className="p-4 bg-green-50 rounded-lg">
                <MapPin className="w-6 h-6 text-green-600 mb-2" />
                <h4 className="font-semibold mb-1">Locations</h4>
                <p className="text-xs text-gray-600">
                  Create detailed accessibility notes
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <User className="w-6 h-6 text-blue-600 mb-2" />
                <h4 className="font-semibold mb-1">Providers</h4>
                <p className="text-xs text-gray-600">
                  Write compelling provider profiles
                </p>
              </div>

              <div className="p-4 bg-orange-50 rounded-lg">
                <MessageSquare className="w-6 h-6 text-orange-600 mb-2" />
                <h4 className="font-semibold mb-1">Support</h4>
                <p className="text-xs text-gray-600">
                  Draft professional responses
                </p>
              </div>
            </div>

            <div className="mt-6 p-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg">
              <p className="text-sm font-semibold mb-2">✨ Floating AI Assistant</p>
              <p className="text-xs text-gray-700">
                Click the purple AI button in the bottom-right corner to access the AI assistant from anywhere in the app. 
                It can help with content generation, text improvement, suggestions, and more!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Generator Dialog */}
      <AIContentGenerator
        isOpen={showGenerator}
        onClose={() => setShowGenerator(false)}
        onApply={handleApplyGenerated}
        contentType={generatorType}
        context={generatorContext}
        title={generatorTitle}
      />
    </div>
  );
}