import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, DollarSign, Star, TrendingUp, Users, Clock, MessageSquare } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function ProviderDashboardPage() {
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["providerBookings"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const allRequests = await base44.entities.ServiceRequest.list("-created_date");
      // Find provider record for this user
      const providers = await base44.entities.ServiceProvider.filter({ created_by: user.email });
      if (providers.length === 0) return [];
      const providerId = providers[0].id;
      return allRequests.filter(r => r.provider_id === providerId);
    },
    enabled: !!currentUser,
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["providerPayments"],
    queryFn: async () => {
      const allPayments = await base44.entities.Payment.list("-created_date");
      const myRequestIds = serviceRequests.map(r => r.id);
      return allPayments.filter(p => myRequestIds.includes(p.service_request_id));
    },
    enabled: serviceRequests.length > 0,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["providerReviews"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const providers = await base44.entities.ServiceProvider.filter({ created_by: user.email });
      if (providers.length === 0) return [];
      const providerId = providers[0].id;
      const allReviews = await base44.entities.Review.list("-created_date");
      return allReviews.filter(r => r.location_id === providerId);
    },
    enabled: !!currentUser,
  });

  const upcomingBookings = serviceRequests.filter(
    r => r.status === "confirmed" && new Date(r.date) >= new Date()
  );

  const totalEarnings = payments
    .filter(p => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Provider Dashboard
          </h1>
          <p className="text-gray-600 text-lg">
            Welcome back, {currentUser?.full_name}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-lift bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600 mb-1">Upcoming Bookings</p>
                  <p className="text-3xl font-bold text-primary">{upcomingBookings.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600 mb-1">Total Earnings</p>
                  <p className="text-3xl font-bold text-primary">${totalEarnings.toFixed(0)}</p>
                </div>
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-yellow-600 mb-1">Average Rating</p>
                  <div className="flex items-center gap-2">
                    <p className="text-3xl font-bold text-primary">
                      {averageRating > 0 ? averageRating.toFixed(1) : "N/A"}
                    </p>
                    {averageRating > 0 && <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />}
                  </div>
                </div>
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600 mb-1">Total Services</p>
                  <p className="text-3xl font-bold text-primary">{serviceRequests.length}</p>
                </div>
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Bookings */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-secondary" />
                Upcoming Services
              </CardTitle>
            </CardHeader>
            <CardContent>
              {upcomingBookings.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No upcoming bookings</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingBookings.slice(0, 5).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex-1">
                        <p className="font-medium">{booking.service_type.replace(/_/g, " ")}</p>
                        <p className="text-sm text-gray-600">{booking.date} at {booking.time}</p>
                        <p className="text-xs text-gray-500">{booking.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-secondary">{booking.duration_hours}h</p>
                        <p className="text-xs text-gray-500">${booking.total_cost}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Reviews */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Recent Reviews
              </CardTitle>
            </CardHeader>
            <CardContent>
              {reviews.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No reviews yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {reviews.slice(0, 5).map((review) => (
                    <div key={review.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${
                                star <= review.rating
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-xs text-gray-500">
                          {format(new Date(review.created_date), "MMM d")}
                        </p>
                      </div>
                      {review.title && (
                        <p className="font-medium text-sm mb-1">{review.title}</p>
                      )}
                      <p className="text-sm text-gray-600 line-clamp-2">{review.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Payments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              Recent Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {payments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <DollarSign className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p>No payments yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {payments.slice(0, 10).map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">${payment.amount.toFixed(2)}</p>
                      <p className="text-sm text-gray-600">
                        {payment.payment_method === "stripe" ? "Credit Card" : "NDIS Claim"}
                      </p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(payment.payment_date || payment.created_date), "MMM d, yyyy")}
                      </p>
                    </div>
                    <Badge
                      className={
                        payment.status === "succeeded"
                          ? "bg-green-100 text-green-700"
                          : payment.status === "pending"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-gray-100 text-gray-700"
                      }
                    >
                      {payment.status}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}