import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Users, 
  Activity, 
  BarChart3,
  AlertTriangle,
  RefreshCw,
  Sparkles
} from "lucide-react";
import { toast } from "sonner";
import { hasPermission, PERMISSIONS } from "@/components/utils/permissions";

import DashboardWidget, { WidgetSkeleton } from "../components/admin/DashboardWidget";
import WidgetCustomizer from "../components/admin/WidgetCustomizer";
import VerificationStatusWidget from "../components/admin/widgets/VerificationStatusWidget";
import NewUsersWidget from "../components/admin/widgets/NewUsersWidget";
import ServiceRequestsWidget from "../components/admin/widgets/ServiceRequestsWidget";
import PlatformStatsWidget from "../components/admin/widgets/PlatformStatsWidget";

// Define available widgets
const AVAILABLE_WIDGETS = [
  {
    id: 'verification',
    title: 'Provider Verification',
    description: 'Track credential verification status and pending reviews',
    icon: Shield,
    component: VerificationStatusWidget,
  },
  {
    id: 'newUsers',
    title: 'New User Sign-ups',
    description: 'Monitor recent user registrations and growth trends',
    icon: Users,
    component: NewUsersWidget,
  },
  {
    id: 'serviceRequests',
    title: 'Service Requests',
    description: 'View active bookings and completion rates',
    icon: Activity,
    component: ServiceRequestsWidget,
  },
  {
    id: 'platformStats',
    title: 'Platform Statistics',
    description: 'Overview of all platform metrics and activity',
    icon: BarChart3,
    component: PlatformStatsWidget,
  },
];

const DEFAULT_WIDGET_ORDER = AVAILABLE_WIDGETS.map(w => w.id);

export default function AdminDashboardPage() {
  const queryClient = useQueryClient();
  const [widgetOrder, setWidgetOrder] = useState(DEFAULT_WIDGET_ORDER);
  const [visibleWidgets, setVisibleWidgets] = useState(DEFAULT_WIDGET_ORDER);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // Load saved preferences
  useEffect(() => {
    if (currentUser?.dashboard_preferences) {
      try {
        const prefs = currentUser.dashboard_preferences;
        if (prefs.widgetOrder) {
          setWidgetOrder(prefs.widgetOrder);
        }
        if (prefs.visibleWidgets) {
          setVisibleWidgets(prefs.visibleWidgets);
        }
      } catch (error) {
        console.error("Failed to load dashboard preferences:", error);
      }
    }
  }, [currentUser]);

  const savePreferencesMutation = useMutation({
    mutationFn: async (preferences) => {
      return await base44.auth.updateMe({
        dashboard_preferences: preferences,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });
      setHasUnsavedChanges(false);
      toast.success("Dashboard preferences saved!");
    },
    onError: () => {
      toast.error("Failed to save preferences");
    },
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(widgetOrder);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setWidgetOrder(items);
    setHasUnsavedChanges(true);
  };

  const handleUpdateVisibility = (newVisibleWidgets) => {
    setVisibleWidgets(newVisibleWidgets);
    setHasUnsavedChanges(true);
  };

  const handleRemoveWidget = (widgetId) => {
    const newVisibleWidgets = visibleWidgets.filter(id => id !== widgetId);
    setVisibleWidgets(newVisibleWidgets);
    setHasUnsavedChanges(true);
    toast.success("Widget hidden. Use 'Customize Dashboard' to show it again.");
  };

  const handleSavePreferences = () => {
    savePreferencesMutation.mutate({
      widgetOrder,
      visibleWidgets,
    });
  };

  const handleResetToDefaults = () => {
    setWidgetOrder(DEFAULT_WIDGET_ORDER);
    setVisibleWidgets(DEFAULT_WIDGET_ORDER);
    setHasUnsavedChanges(true);
    toast.success("Dashboard reset to default layout");
  };

  // Check admin access
  if (!hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can access the admin dashboard.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const visibleWidgetConfigs = widgetOrder
    .filter(id => visibleWidgets.includes(id))
    .map(id => AVAILABLE_WIDGETS.find(w => w.id === id))
    .filter(Boolean);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-primary">Admin Dashboard</h1>
                <p className="text-gray-600 text-lg">Monitor platform performance and metrics</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  queryClient.invalidateQueries();
                  toast.success("Dashboard refreshed");
                }}
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
              
              <WidgetCustomizer
                availableWidgets={AVAILABLE_WIDGETS}
                visibleWidgets={visibleWidgets}
                onUpdateVisibility={handleUpdateVisibility}
              />
            </div>
          </div>

          {hasUnsavedChanges && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="flex items-center justify-between">
                <span className="text-yellow-900">
                  You have unsaved changes to your dashboard layout
                </span>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleResetToDefaults}
                  >
                    Reset
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleSavePreferences}
                    disabled={savePreferencesMutation.isPending}
                    className="bg-yellow-600 hover:bg-yellow-700"
                  >
                    {savePreferencesMutation.isPending ? "Saving..." : "Save Layout"}
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Widgets Grid with Drag & Drop */}
        {visibleWidgetConfigs.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Widgets Visible</h3>
            <p className="text-gray-600 mb-4">
              Add widgets to your dashboard to start monitoring platform metrics
            </p>
            <WidgetCustomizer
              availableWidgets={AVAILABLE_WIDGETS}
              visibleWidgets={visibleWidgets}
              onUpdateVisibility={handleUpdateVisibility}
            />
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="widgets">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="grid md:grid-cols-2 gap-6"
                >
                  {visibleWidgetConfigs.map((widget, index) => {
                    const WidgetComponent = widget.component;
                    
                    return (
                      <Draggable 
                        key={widget.id} 
                        draggableId={widget.id} 
                        index={index}
                      >
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                          >
                            <DashboardWidget
                              id={widget.id}
                              title={widget.title}
                              icon={widget.icon}
                              onRemove={() => handleRemoveWidget(widget.id)}
                              isDragging={snapshot.isDragging}
                              dragHandleProps={provided.dragHandleProps}
                            >
                              <WidgetComponent />
                            </DashboardWidget>
                          </div>
                        )}
                      </Draggable>
                    );
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}

        {/* Help Text */}
        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-900">
            <strong>💡 Tip:</strong> Drag widgets by the grip icon to reorder them. 
            Click the X to hide widgets, or use "Customize Dashboard" to manage visibility.
            Your layout preferences are saved automatically.
          </p>
        </div>
      </div>
    </div>
  );
}