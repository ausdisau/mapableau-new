import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User,
  Calendar,
  Briefcase,
  Car,
  Heart,
  Settings,
  MapPin,
  Phone,
  Mail,
  CheckCircle,
  Clock,
  XCircle,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Star
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function ParticipantProfilePage() {
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get("id");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: viewingUser } = useQuery({
    queryKey: ["viewingUser", userId],
    queryFn: async () => {
      if (userId) {
        const users = await base44.entities.User.filter({ id: userId });
        return users[0];
      }
      return currentUser;
    },
    enabled: !!currentUser,
  });

  const user = viewingUser || currentUser;
  const isOwnProfile = !userId || currentUser?.id === userId;

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["userServiceRequests", user?.email],
    queryFn: () => base44.entities.ServiceRequest.filter({ created_by: user?.email }),
    enabled: !!user?.email && isOwnProfile,
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["userTransportBookings", user?.email],
    queryFn: () => base44.entities.TransportBooking.filter({ created_by: user?.email }),
    enabled: !!user?.email && isOwnProfile,
  });

  const { data: jobApplications = [] } = useQuery({
    queryKey: ["userJobApplications", user?.email],
    queryFn: () => base44.entities.JobApplication.filter({ created_by: user?.email }),
    enabled: !!user?.email && isOwnProfile,
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["userPayments", user?.email],
    queryFn: () => base44.entities.Payment.filter({ created_by: user?.email }),
    enabled: !!user?.email && isOwnProfile,
  });

  const { data: ndisPlans = [] } = useQuery({
    queryKey: ["userNDISPlans", user?.ndis_participant_number],
    queryFn: () => base44.entities.NDISPlanBudget.filter({ 
      participant_number: user?.ndis_participant_number 
    }),
    enabled: !!user?.ndis_participant_number && isOwnProfile,
  });

  // Calculate stats
  const upcomingServices = serviceRequests.filter(r => 
    r.status === "confirmed" && new Date(r.date) >= new Date()
  ).length;

  const upcomingTransport = transportBookings.filter(b => 
    ["confirmed", "driver_assigned"].includes(b.status) && 
    new Date(b.pickup_datetime) >= new Date()
  ).length;

  const activeApplications = jobApplications.filter(a => 
    ["submitted", "under_review", "interview_scheduled"].includes(a.status)
  ).length;

  const totalSpent = payments
    .filter(p => p.status === "succeeded")
    .reduce((sum, p) => sum + (p.amount || 0), 0);

  const currentPlan = ndisPlans[0];
  const planUtilization = currentPlan 
    ? ((currentPlan.total_spent || 0) / currentPlan.total_plan_budget * 100).toFixed(1)
    : 0;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <Card className="mb-8 overflow-hidden">
          {/* Cover Photo */}
          <div className="h-48 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 relative">
            {user.cover_photo_url && (
              <img
                src={user.cover_photo_url}
                alt="Cover"
                className="w-full h-full object-cover"
              />
            )}
          </div>

          <CardContent className="pt-0">
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6 -mt-16 sm:-mt-20">
              {/* Profile Photo */}
              <div className="relative">
                {user.profile_photo_url ? (
                  <img
                    src={user.profile_photo_url}
                    alt={user.full_name}
                    className="w-32 h-32 sm:w-40 sm:h-40 rounded-2xl object-cover border-4 border-white shadow-xl"
                  />
                ) : (
                  <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center border-4 border-white shadow-xl">
                    <span className="text-white font-bold text-5xl">
                      {user.full_name?.charAt(0) || "U"}
                    </span>
                  </div>
                )}
              </div>

              {/* User Info */}
              <div className="flex-1 sm:mt-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900">{user.full_name}</h1>
                    <p className="text-gray-600 capitalize">
                      {user.user_type?.replace(/_/g, " ") || "Participant"}
                    </p>
                  </div>
                  {isOwnProfile && (
                    <Link to={createPageUrl("AccountSettings")}>
                      <Button variant="outline" className="gap-2">
                        <Settings className="w-4 h-4" />
                        Edit Profile
                      </Button>
                    </Link>
                  )}
                </div>

                {user.bio && (
                  <p className="text-gray-700 mt-3 max-w-2xl">{user.bio}</p>
                )}

                <div className="flex flex-wrap gap-4 mt-4">
                  {user.suburb && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>{user.suburb}, {user.state}</span>
                    </div>
                  )}
                  {user.phone && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{user.phone}</span>
                    </div>
                  )}
                  {user.email && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{user.email}</span>
                    </div>
                  )}
                </div>

                {/* Social Links */}
                {user.social_media && Object.values(user.social_media).some(v => v) && (
                  <div className="flex gap-3 mt-4">
                    {user.social_media.facebook && (
                      <a href={user.social_media.facebook} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm">Facebook</Button>
                      </a>
                    )}
                    {user.social_media.twitter && (
                      <a href={user.social_media.twitter} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm">Twitter</Button>
                      </a>
                    )}
                    {user.social_media.linkedin && (
                      <a href={user.social_media.linkedin} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm">LinkedIn</Button>
                      </a>
                    )}
                    {user.social_media.website && (
                      <a href={user.social_media.website} target="_blank" rel="noopener noreferrer">
                        <Button variant="outline" size="sm">Website</Button>
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {isOwnProfile && (
          <>
            {/* Quick Stats */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="border-2 border-green-100 hover-lift">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 font-medium">Upcoming Services</p>
                      <p className="text-3xl font-bold text-green-600">{upcomingServices}</p>
                    </div>
                    <Heart className="w-10 h-10 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-blue-100 hover-lift">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 font-medium">Transport Bookings</p>
                      <p className="text-3xl font-bold text-blue-600">{upcomingTransport}</p>
                    </div>
                    <Car className="w-10 h-10 text-blue-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-orange-100 hover-lift">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 font-medium">Active Applications</p>
                      <p className="text-3xl font-bold text-orange-600">{activeApplications}</p>
                    </div>
                    <Briefcase className="w-10 h-10 text-orange-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-100 hover-lift">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 font-medium">Total Spent</p>
                      <p className="text-3xl font-bold text-purple-600">${totalSpent.toLocaleString()}</p>
                    </div>
                    <DollarSign className="w-10 h-10 text-purple-400" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* NDIS Plan Alert */}
            {currentPlan && (
              <Alert className={`mb-6 ${
                planUtilization > 90 ? "bg-red-50 border-red-200" :
                planUtilization > 75 ? "bg-yellow-50 border-yellow-200" :
                "bg-blue-50 border-blue-200"
              }`}>
                <TrendingUp className={`w-4 h-4 ${
                  planUtilization > 90 ? "text-red-600" :
                  planUtilization > 75 ? "text-yellow-600" :
                  "text-blue-600"
                }`} />
                <AlertDescription>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">
                      NDIS Plan: {planUtilization}% utilized
                    </span>
                    <Link to={createPageUrl("NDISBudget")}>
                      <Button size="sm" variant="outline">View Budget</Button>
                    </Link>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Main Content Tabs */}
            <Tabs defaultValue="bookings" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 bg-white shadow-md rounded-xl p-1">
                <TabsTrigger value="bookings" className="gap-2">
                  <Heart className="w-4 h-4" />
                  Care Services
                </TabsTrigger>
                <TabsTrigger value="transport" className="gap-2">
                  <Car className="w-4 h-4" />
                  Transport
                </TabsTrigger>
                <TabsTrigger value="jobs" className="gap-2">
                  <Briefcase className="w-4 h-4" />
                  Job Applications
                </TabsTrigger>
                <TabsTrigger value="about" className="gap-2">
                  <User className="w-4 h-4" />
                  About
                </TabsTrigger>
              </TabsList>

              {/* Care Services Tab */}
              <TabsContent value="bookings">
                <Card>
                  <CardHeader>
                    <CardTitle>My Care Services</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {serviceRequests.length === 0 ? (
                      <div className="text-center py-12">
                        <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-600">No service bookings yet</p>
                        <Link to={createPageUrl("FindCare")}>
                          <Button className="mt-4 bg-green-600 hover:bg-green-700">
                            Find Care Services
                          </Button>
                        </Link>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {serviceRequests.map(request => (
                          <Card key={request.id} className="border-2">
                            <CardContent className="pt-6">
                              <div className="flex items-start justify-between mb-3">
                                <div>
                                  <h3 className="font-semibold text-lg capitalize">
                                    {request.service_type?.replace(/_/g, " ")}
                                  </h3>
                                  <p className="text-sm text-gray-600">
                                    {format(new Date(request.date), "MMMM d, yyyy")} at {request.time}
                                  </p>
                                </div>
                                <Badge className={
                                  request.status === "confirmed" ? "bg-green-100 text-green-700" :
                                  request.status === "completed" ? "bg-blue-100 text-blue-700" :
                                  request.status === "cancelled" ? "bg-red-100 text-red-700" :
                                  "bg-yellow-100 text-yellow-700"
                                }>
                                  {request.status}
                                </Badge>
                              </div>
                              {request.notes && (
                                <p className="text-sm text-gray-700 mb-3">{request.notes}</p>
                              )}
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">
                                  {request.duration_hours} hours
                                </span>
                                <span className="font-semibold text-green-600">
                                  ${request.total_cost}
                                </span>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Transport Tab */}
              <TabsContent value="transport">
                <Card>
                  <CardHeader>
                    <CardTitle>My Transport Bookings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {transportBookings.length === 0 ? (
                      <div className="text-center py-12">
                        <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-600">No transport bookings yet</p>
                        <Link to={createPageUrl("FindTransport")}>
                          <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                            Book Transport
                          </Button>
                        </Link>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {transportBookings.slice(0, 10).map(booking => (
                          <Card key={booking.id} className="border-2">
                            <CardContent className="pt-6">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <h3 className="font-semibold text-lg capitalize">
                                      {booking.booking_type?.replace(/_/g, " ")} Trip
                                    </h3>
                                    <Badge className={
                                      booking.status === "completed" ? "bg-green-100 text-green-700" :
                                      ["confirmed", "driver_assigned", "en_route_to_pickup"].includes(booking.status) 
                                        ? "bg-blue-100 text-blue-700" :
                                      booking.status === "cancelled" ? "bg-red-100 text-red-700" :
                                      "bg-yellow-100 text-yellow-700"
                                    }>
                                      {booking.status?.replace(/_/g, " ")}
                                    </Badge>
                                  </div>
                                  <p className="text-sm text-gray-600 mb-2">
                                    {format(new Date(booking.pickup_datetime), "MMMM d, yyyy 'at' h:mm a")}
                                  </p>
                                  <div className="space-y-1 text-sm">
                                    <p className="text-gray-700">
                                      <span className="font-medium">From:</span> {booking.pickup_location?.address}
                                    </p>
                                    <p className="text-gray-700">
                                      <span className="font-medium">To:</span> {booking.dropoff_location?.address}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              {booking.estimated_cost && (
                                <div className="flex items-center justify-between text-sm pt-3 border-t">
                                  <span className="text-gray-600">Estimated Cost</span>
                                  <span className="font-semibold text-blue-600">
                                    ${booking.estimated_cost}
                                  </span>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Job Applications Tab */}
              <TabsContent value="jobs">
                <Card>
                  <CardHeader>
                    <CardTitle>My Job Applications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {jobApplications.length === 0 ? (
                      <div className="text-center py-12">
                        <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <p className="text-gray-600">No job applications yet</p>
                        <Link to={createPageUrl("FindJobs")}>
                          <Button className="mt-4 bg-orange-600 hover:bg-orange-700">
                            Find Jobs
                          </Button>
                        </Link>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {jobApplications.map(application => (
                          <Card key={application.id} className="border-2">
                            <CardContent className="pt-6">
                              <div className="flex items-start justify-between mb-3">
                                <div>
                                  <h3 className="font-semibold text-lg">Job Application</h3>
                                  <p className="text-sm text-gray-600">
                                    Applied {format(new Date(application.created_date), "MMM d, yyyy")}
                                  </p>
                                </div>
                                <Badge className={
                                  application.status === "offered" || application.status === "accepted" 
                                    ? "bg-green-100 text-green-700" :
                                  application.status === "interview_scheduled" ? "bg-blue-100 text-blue-700" :
                                  application.status === "rejected" || application.status === "withdrawn"
                                    ? "bg-red-100 text-red-700" :
                                  "bg-yellow-100 text-yellow-700"
                                }>
                                  {application.status?.replace(/_/g, " ")}
                                </Badge>
                              </div>
                              {application.cover_letter && (
                                <p className="text-sm text-gray-700 line-clamp-3 mb-3">
                                  {application.cover_letter}
                                </p>
                              )}
                              {application.accommodation_needs && (
                                <div className="bg-blue-50 p-3 rounded text-sm">
                                  <p className="font-medium text-blue-900 mb-1">Accommodation Needs:</p>
                                  <p className="text-blue-700">{application.accommodation_needs}</p>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* About Tab */}
              <TabsContent value="about">
                <div className="grid lg:grid-cols-2 gap-6">
                  {/* Personal Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Personal Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {user.disability_type && user.disability_type.length > 0 && (
                        <div>
                          <Label className="text-sm font-semibold text-gray-700">Disability Type</Label>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {user.disability_type.map((type, idx) => (
                              <Badge key={idx} variant="outline" className="capitalize">
                                {type}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {user.accessibility_needs && user.accessibility_needs.length > 0 && (
                        <div>
                          <Label className="text-sm font-semibold text-gray-700">Accessibility Needs</Label>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {user.accessibility_needs.map((need, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {need}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {user.communication_preferences && user.communication_preferences.length > 0 && (
                        <div>
                          <Label className="text-sm font-semibold text-gray-700">Communication Preferences</Label>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {user.communication_preferences.map((pref, idx) => (
                              <Badge key={idx} variant="outline" className="capitalize">
                                {pref.replace(/_/g, " ")}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* NDIS Information */}
                  {user.ndis_participant_number && (
                    <Card>
                      <CardHeader>
                        <CardTitle>NDIS Information</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <Label className="text-sm text-gray-600">Participant Number</Label>
                          <p className="font-semibold">
                            {user.ndis_participant_number}
                          </p>
                        </div>
                        {user.ndis_plan_start_date && user.ndis_plan_end_date && (
                          <div>
                            <Label className="text-sm text-gray-600">Current Plan Period</Label>
                            <p className="font-semibold">
                              {format(new Date(user.ndis_plan_start_date), "MMM d, yyyy")} - {format(new Date(user.ndis_plan_end_date), "MMM d, yyyy")}
                            </p>
                          </div>
                        )}
                        {user.support_coordinator_email && (
                          <div>
                            <Label className="text-sm text-gray-600">Support Coordinator</Label>
                            <p className="font-semibold">{user.support_coordinator_email}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Employment Goals */}
                  {user.employment_goals && (
                    <Card className="lg:col-span-2">
                      <CardHeader>
                        <CardTitle>Employment Goals</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700">{user.employment_goals}</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}

        {/* Public View (when viewing someone else's profile) */}
        {!isOwnProfile && (
          <Card>
            <CardContent className="py-12 text-center">
              <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">Profile details are private</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function Label({ children, className = "" }) {
  return <label className={`block text-sm font-medium ${className}`}>{children}</label>;
}