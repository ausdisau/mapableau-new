import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Phone, 
  User,
  Car,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Loader2
} from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LiveTrackingMap from "../components/tracking/LiveTrackingMap";
import DriverInfoCard from "../components/tracking/DriverInfoCard";
import TripProgressTimeline from "../components/tracking/TripProgressTimeline";

export default function TrackRidePage() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const bookingId = urlParams.get("booking_id");
  const [eta, setEta] = useState(null);

  const { data: booking, isLoading: bookingLoading } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const bookings = await base44.entities.TransportBooking.list();
      return bookings.find(b => b.id === bookingId);
    },
    enabled: !!bookingId,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: driver } = useQuery({
    queryKey: ["driver", booking?.driver_id],
    queryFn: async () => {
      const drivers = await base44.entities.Driver.list();
      return drivers.find(d => d.id === booking.driver_id);
    },
    enabled: !!booking?.driver_id,
    refetchInterval: 3000, // Update driver location every 3 seconds
  });

  const { data: vehicle } = useQuery({
    queryKey: ["vehicle", booking?.vehicle_id],
    queryFn: async () => {
      const vehicles = await base44.entities.Vehicle.list();
      return vehicles.find(v => v.id === booking.vehicle_id);
    },
    enabled: !!booking?.vehicle_id,
  });

  // Calculate ETA based on driver location and destination
  useEffect(() => {
    if (driver?.current_location && booking?.pickup_location) {
      const calculateETA = () => {
        // Simple ETA calculation (in real app, use Google Maps Distance Matrix API)
        const lat1 = driver.current_location.latitude;
        const lon1 = driver.current_location.longitude;
        const lat2 = booking.pickup_location.latitude || -33.8688;
        const lon2 = booking.pickup_location.longitude || 151.2093;

        const R = 6371; // Earth's radius in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c; // Distance in km

        // Assume average speed of 40 km/h in city traffic
        const timeInHours = distance / 40;
        const timeInMinutes = Math.ceil(timeInHours * 60);

        setEta({
          distance: distance.toFixed(1),
          time: timeInMinutes
        });
      };

      calculateETA();
    }
  }, [driver?.current_location, booking?.pickup_location]);

  if (bookingLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-secondary" />
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertCircle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Booking not found</span>
              <p className="text-sm text-red-700 mt-1">
                The booking you're trying to track doesn't exist or has been cancelled.
              </p>
            </AlertDescription>
          </Alert>
          <Button onClick={() => navigate(createPageUrl("MyTransportBookings"))} className="mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Bookings
          </Button>
        </div>
      </div>
    );
  }

  const isActive = ["driver_assigned", "en_route_to_pickup", "passenger_on_board", "in_transit"].includes(booking.status);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary text-white py-4 shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => navigate(createPageUrl("MyTransportBookings"))}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="text-center">
              <h1 className="text-xl font-bold">Track Your Ride</h1>
              <p className="text-sm text-gray-200">
                {format(new Date(booking.pickup_datetime), "MMM d, h:mm a")}
              </p>
            </div>
            <div className="w-20" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Status Alert */}
        {!isActive && (
          <Alert className="mb-6">
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>
              This booking is {booking.status?.replace(/_/g, " ")}. 
              Live tracking is only available when a driver is assigned and en route.
            </AlertDescription>
          </Alert>
        )}

        {/* ETA Banner */}
        {isActive && eta && (
          <Card className="mb-6 bg-gradient-to-r from-secondary to-blue-600 text-white border-0">
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Navigation className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm opacity-90">Estimated Arrival</p>
                    <p className="text-2xl font-bold">{eta.time} min</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm opacity-90">Distance</p>
                  <p className="text-lg font-semibold">{eta.distance} km</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Map View */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="overflow-hidden">
              <LiveTrackingMap
                booking={booking}
                driver={driver}
                vehicle={vehicle}
                isActive={isActive}
              />
            </Card>

            {/* Trip Progress Timeline */}
            <TripProgressTimeline booking={booking} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Driver Info */}
            {driver && vehicle && (
              <DriverInfoCard
                driver={driver}
                vehicle={vehicle}
                booking={booking}
              />
            )}

            {/* Trip Details */}
            <Card>
              <CardContent className="pt-6 space-y-4">
                <h3 className="font-semibold text-lg mb-4">Trip Details</h3>
                
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-gray-500 mb-1">Pickup</p>
                      <p className="text-sm font-medium">
                        {booking.pickup_location.address || booking.pickup_location.suburb}
                      </p>
                      {booking.pickup_location.notes && (
                        <p className="text-xs text-gray-600 mt-1">
                          {booking.pickup_location.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="ml-4 border-l-2 border-gray-200 h-6" />

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-4 h-4 text-red-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-gray-500 mb-1">Drop-off</p>
                      <p className="text-sm font-medium">
                        {booking.dropoff_location.address || booking.dropoff_location.suburb}
                      </p>
                      {booking.dropoff_location.notes && (
                        <p className="text-xs text-gray-600 mt-1">
                          {booking.dropoff_location.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Status</span>
                    <Badge className={
                      booking.status === "completed" ? "bg-green-100 text-green-700" :
                      isActive ? "bg-blue-100 text-blue-700" :
                      "bg-gray-100 text-gray-700"
                    }>
                      {booking.status?.replace(/_/g, " ")}
                    </Badge>
                  </div>
                  {booking.passenger_count > 1 && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Passengers</span>
                      <span className="font-medium">{booking.passenger_count}</span>
                    </div>
                  )}
                  {booking.accessibility_requirements?.length > 0 && (
                    <div className="text-sm">
                      <p className="text-gray-600 mb-1">Accessibility</p>
                      <div className="flex flex-wrap gap-1">
                        {booking.accessibility_requirements.map((req, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {req.replace(/_/g, " ")}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contact */}
            <Card className="bg-red-50 border-red-200">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-red-900 mb-2">Need Help?</h4>
                    <p className="text-sm text-red-700 mb-3">
                      Contact support if you need immediate assistance
                    </p>
                    <Button size="sm" variant="outline" className="border-red-300 text-red-700 hover:bg-red-100">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Support
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}