import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calendar,
  AlertCircle,
  CheckCircle,
  Download,
  RefreshCw,
  PieChart
} from "lucide-react";
import { format, differenceInDays } from "date-fns";

export default function NDISBudgetPage() {
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: planBudgets = [] } = useQuery({
    queryKey: ["ndisPlanBudgets"],
    queryFn: async () => {
      if (!currentUser?.ndis_participant_number) return [];
      return await base44.entities.NDISPlanBudget.filter({
        created_by: currentUser.email
      }, "-plan_start_date", 1);
    },
    enabled: !!currentUser,
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["myServiceRequests"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.ServiceRequest.filter({ created_by: user.email }, "-created_date");
    },
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["myTransportBookings"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.TransportBooking.filter({ created_by: user.email }, "-created_date");
    },
  });

  const currentPlan = planBudgets[0];

  // Calculate spending from bookings
  const totalCareSpent = serviceRequests
    .filter(r => r.payment_status === "paid")
    .reduce((sum, r) => sum + (r.total_cost || 0), 0);

  const totalTransportSpent = transportBookings
    .filter(b => b.payment_status === "paid")
    .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0);

  const pendingCareAmount = serviceRequests
    .filter(r => r.payment_status === "pending")
    .reduce((sum, r) => sum + (r.total_cost || 0), 0);

  const pendingTransportAmount = transportBookings
    .filter(b => b.payment_status === "pending")
    .reduce((sum, b) => sum + (b.estimated_cost || 0), 0);

  const daysRemaining = currentUser?.ndis_plan_end_date
    ? differenceInDays(new Date(currentUser.ndis_plan_end_date), new Date())
    : 0;

  const planProgress = currentUser?.ndis_plan_start_date && currentUser?.ndis_plan_end_date
    ? ((new Date().getTime() - new Date(currentUser.ndis_plan_start_date).getTime()) /
       (new Date(currentUser.ndis_plan_end_date).getTime() - new Date(currentUser.ndis_plan_start_date).getTime())) * 100
    : 0;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-primary mb-2">NDIS Plan Budget</h1>
            <p className="text-gray-600">Track your NDIS funding and spending</p>
          </div>
          <Button variant="outline" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Sync with NDIS
          </Button>
        </div>

        {!currentUser?.ndis_participant_number ? (
          <Alert>
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>
              <p className="font-medium">NDIS Participant Number Required</p>
              <p className="text-sm mt-1">
                Please add your NDIS participant number in Account Settings to view your budget.
              </p>
            </AlertDescription>
          </Alert>
        ) : (
          <>
            {/* Plan Overview */}
            <Card className="mb-6 bg-gradient-to-r from-blue-50 to-green-50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Current Plan Overview</CardTitle>
                  {currentUser.ndis_plan_end_date && daysRemaining <= 60 && daysRemaining > 0 && (
                    <Badge className="bg-yellow-100 text-yellow-700">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Plan ending in {daysRemaining} days
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6 mb-6">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Participant Number</p>
                    <p className="text-xl font-bold text-primary">
                      {currentUser.ndis_participant_number || "Not set"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Plan Dates</p>
                    <p className="text-sm font-semibold">
                      {currentUser.ndis_plan_start_date 
                        ? format(new Date(currentUser.ndis_plan_start_date), "d MMM yyyy")
                        : "Not set"} - {" "}
                      {currentUser.ndis_plan_end_date
                        ? format(new Date(currentUser.ndis_plan_end_date), "d MMM yyyy")
                        : "Not set"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Days Remaining</p>
                    <p className="text-xl font-bold text-primary">{daysRemaining > 0 ? daysRemaining : 0}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Plan Progress</span>
                    <span>{Math.min(planProgress, 100).toFixed(0)}% of plan period used</span>
                  </div>
                  <Progress value={Math.min(planProgress, 100)} className="h-3" />
                </div>
              </CardContent>
            </Card>

            {/* Budget Summary */}
            <div className="grid md:grid-cols-4 gap-6 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Total Spent</p>
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                  </div>
                  <p className="text-3xl font-bold text-primary">
                    ${(totalCareSpent + totalTransportSpent).toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Care + Transport</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Pending</p>
                    <DollarSign className="w-5 h-5 text-yellow-600" />
                  </div>
                  <p className="text-3xl font-bold text-yellow-700">
                    ${(pendingCareAmount + pendingTransportAmount).toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Awaiting payment</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Care Services</p>
                    <PieChart className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-3xl font-bold text-green-700">
                    ${totalCareSpent.toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{serviceRequests.length} bookings</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Transport</p>
                    <TrendingDown className="w-5 h-5 text-purple-600" />
                  </div>
                  <p className="text-3xl font-bold text-purple-700">
                    ${totalTransportSpent.toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{transportBookings.length} trips</p>
                </CardContent>
              </Card>
            </div>

            {/* Spending Breakdown */}
            <div className="grid lg:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Care Services Spending</CardTitle>
                </CardHeader>
                <CardContent>
                  {serviceRequests.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No care service bookings yet</p>
                  ) : (
                    <div className="space-y-3">
                      {serviceRequests.slice(0, 5).map((request) => (
                        <div key={request.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium text-sm capitalize">
                              {request.service_type?.replace(/_/g, " ")}
                            </p>
                            <p className="text-xs text-gray-600">
                              {format(new Date(request.created_date), "d MMM yyyy")}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-primary">${request.total_cost?.toFixed(2)}</p>
                            <Badge 
                              variant={request.payment_status === "paid" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {request.payment_status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Transport Spending</CardTitle>
                </CardHeader>
                <CardContent>
                  {transportBookings.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No transport bookings yet</p>
                  ) : (
                    <div className="space-y-3">
                      {transportBookings.slice(0, 5).map((booking) => (
                        <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium text-sm capitalize">
                              {booking.purpose?.replace(/_/g, " ")}
                            </p>
                            <p className="text-xs text-gray-600">
                              {booking.pickup_datetime 
                                ? format(new Date(booking.pickup_datetime), "d MMM yyyy")
                                : "Not scheduled"}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-primary">
                              ${(booking.actual_cost || booking.estimated_cost || 0).toFixed(2)}
                            </p>
                            <Badge 
                              variant={booking.payment_status === "paid" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {booking.payment_status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Budget Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export Spending Report
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Calendar className="w-4 h-4" />
                    View Plan History
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Budget Alerts
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}