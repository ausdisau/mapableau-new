import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Shield,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  Plus,
  Info,
  Award,
  FileText
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import CredentialUploadForm from "../components/credentials/CredentialUploadForm";
import CredentialsList from "../components/credentials/CredentialsList";
import CredentialExpiryChecker from "../components/verification/CredentialExpiryChecker";
import { differenceInDays } from "date-fns";

export default function ProviderCredentialsPage() {
  const [showUploadDialog, setShowUploadDialog] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: credentials = [], isLoading } = useQuery({
    queryKey: ["myCredentials"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.ProviderCredential.filter(
        { provider_email: user.email },
        "-created_date"
      );
    },
  });

  // Calculate verification progress
  const verifiedCount = credentials.filter(c => c.verification_status === "verified").length;
  const totalCount = credentials.length;
  const verificationProgress = totalCount > 0 ? (verifiedCount / totalCount) * 100 : 0;

  // Group credentials by status
  const pendingCredentials = credentials.filter(c => 
    ["pending_submission", "submitted", "under_review"].includes(c.verification_status)
  );
  const verifiedCredentials = credentials.filter(c => c.verification_status === "verified");
  const rejectedCredentials = credentials.filter(c => c.verification_status === "rejected");
  const expiringSoon = verifiedCredentials.filter(c => {
    if (!c.expiry_date) return false;
    const days = differenceInDays(new Date(c.expiry_date), new Date());
    return days <= 30 && days > 0;
  });
  const expiredCredentials = credentials.filter(c => c.verification_status === "expired");

  // Required credentials checklist
  const requiredCredentials = [
    { type: "police_check", name: "Police Check", priority: "high" },
    { type: "working_with_children_check", name: "Working with Children Check", priority: "high" },
    { type: "ndis_worker_screening", name: "NDIS Worker Screening", priority: "high" },
    { type: "insurance_public_liability", name: "Public Liability Insurance", priority: "high" },
    { type: "first_aid_certificate", name: "First Aid Certificate", priority: "medium" },
  ];

  const missingRequired = requiredCredentials.filter(req => 
    !credentials.some(c => c.credential_type === req.type && c.verification_status === "verified")
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-8 h-8 text-blue-600" />
                <h1 className="text-4xl font-bold text-primary">Provider Credentials</h1>
              </div>
              <p className="text-gray-600 text-lg">
                Manage and verify your professional credentials, licenses, and certifications
              </p>
            </div>
            <Button
              onClick={() => setShowUploadDialog(true)}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Credential
            </Button>
          </div>
        </div>

        {/* Important Alerts */}
        {missingRequired.length > 0 && (
          <Alert className="mb-8 bg-orange-50 border-orange-200 border-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            <AlertDescription>
              <div>
                <span className="font-semibold text-orange-900 text-lg">
                  Action Required: Missing Essential Credentials
                </span>
                <p className="text-sm text-orange-800 mt-2 mb-3">
                  You're missing {missingRequired.length} required credential{missingRequired.length !== 1 ? 's' : ''} 
                  needed to provide services as an NDIS provider.
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm text-orange-800 mb-3">
                  {missingRequired.map(req => (
                    <li key={req.type}>{req.name}</li>
                  ))}
                </ul>
                <Button
                  onClick={() => setShowUploadDialog(true)}
                  className="bg-orange-600 hover:bg-orange-700"
                  size="sm"
                >
                  Upload Missing Credentials
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Expiry Checker */}
        <div className="mb-8">
          <CredentialExpiryChecker userEmail={currentUser?.email} />
        </div>

        {/* Verification Progress */}
        <Card className="mb-8 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Award className="w-5 h-5 text-blue-600" />
                Verification Progress
              </span>
              <div className="text-3xl font-bold text-blue-600">
                {Math.round(verificationProgress)}%
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={verificationProgress} className="h-3 mb-4" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-green-600">{verifiedCount}</p>
                <p className="text-xs text-gray-600">Verified</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{pendingCredentials.length}</p>
                <p className="text-xs text-gray-600">Under Review</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-600">{expiringSoon.length}</p>
                <p className="text-xs text-gray-600">Expiring Soon</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-red-600">{expiredCredentials.length}</p>
                <p className="text-xs text-gray-600">Expired</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mb-8 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="space-y-2 text-sm text-blue-900">
                <p className="font-semibold">Credential Verification Process:</p>
                <ul className="list-disc list-inside space-y-1 text-blue-800">
                  <li>Upload your credential documents (PDF, JPG, or PNG format)</li>
                  <li>Our admin team reviews within 2-3 business days</li>
                  <li>You'll receive notifications about status updates</li>
                  <li>We'll send reminders 30 and 7 days before expiry</li>
                  <li>Keep your credentials current to maintain verified status</li>
                </ul>
                <div className="pt-2">
                  <Link to={createPageUrl("HelpCenter")}>
                    <Button variant="link" className="text-blue-600 p-0 h-auto">
                      Learn more about credential requirements →
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Credentials Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">
              All ({credentials.length})
            </TabsTrigger>
            <TabsTrigger value="verified">
              <CheckCircle className="w-4 h-4 mr-1" />
              Verified ({verifiedCount})
            </TabsTrigger>
            <TabsTrigger value="pending">
              <Clock className="w-4 h-4 mr-1" />
              Pending ({pendingCredentials.length})
            </TabsTrigger>
            <TabsTrigger value="expiring">
              <AlertTriangle className="w-4 h-4 mr-1" />
              Expiring ({expiringSoon.length})
            </TabsTrigger>
            <TabsTrigger value="rejected">
              <XCircle className="w-4 h-4 mr-1" />
              Rejected ({rejectedCredentials.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <CredentialsList credentials={credentials} />
          </TabsContent>

          <TabsContent value="verified">
            <CredentialsList credentials={verifiedCredentials} />
          </TabsContent>

          <TabsContent value="pending">
            {pendingCredentials.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    No Pending Credentials
                  </h3>
                  <p className="text-gray-600">
                    All your credentials have been reviewed
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                <Alert className="bg-blue-50 border-blue-200">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-blue-900">
                    These credentials are currently under review. You'll receive a notification once they're verified.
                  </AlertDescription>
                </Alert>
                <CredentialsList credentials={pendingCredentials} />
              </div>
            )}
          </TabsContent>

          <TabsContent value="expiring">
            {expiringSoon.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    All Credentials Valid
                  </h3>
                  <p className="text-gray-600">
                    No credentials expiring in the next 30 days
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-900">
                    These credentials are expiring soon. Please renew them to maintain your verified status.
                  </AlertDescription>
                </Alert>
                <CredentialsList credentials={expiringSoon} />
              </div>
            )}
          </TabsContent>

          <TabsContent value="rejected">
            {rejectedCredentials.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    No Rejected Credentials
                  </h3>
                  <p className="text-gray-600">
                    All your submitted credentials have been approved
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                <Alert className="bg-red-50 border-red-200">
                  <XCircle className="w-4 h-4 text-red-600" />
                  <AlertDescription className="text-red-900">
                    These credentials were rejected. Please review the rejection reason and upload corrected documents.
                  </AlertDescription>
                </Alert>
                <CredentialsList credentials={rejectedCredentials} />
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Help Section */}
        <Card className="mt-8 border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <FileText className="w-8 h-8 text-purple-600 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-lg mb-2">Need Help with Credentials?</h3>
                <p className="text-gray-700 mb-4">
                  Visit our Help Center for detailed guides on credential requirements, document formats, 
                  and the verification process.
                </p>
                <div className="flex gap-3">
                  <Link to={createPageUrl("HelpCenter")}>
                    <Button variant="outline">
                      Browse Help Articles
                    </Button>
                  </Link>
                  <Link to={createPageUrl("Support")}>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Contact Support
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Upload New Credential</DialogTitle>
          </DialogHeader>
          <CredentialUploadForm
            onSuccess={() => setShowUploadDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}