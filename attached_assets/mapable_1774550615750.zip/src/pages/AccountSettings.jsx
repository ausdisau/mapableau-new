
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Shield, Bell, CreditCard, LogOut, Save, Upload, Camera, Link as LinkIcon, Facebook, Twitter, Instagram, Linkedin, Globe } from "lucide-react";
import { toast } from "sonner";
import NotificationPreferences from "../components/notifications/NotificationPreferences";
import PushNotificationSetup from "../components/notifications/PushNotificationSetup";
import TwoFactorSettings from "../components/auth/TwoFactorSettings";

export default function AccountSettingsPage() {
  const queryClient = useQueryClient();
  
  // Get tab from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const initialTab = urlParams.get('tab') || 'profile';

  const { data: currentUser, isLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const [formData, setFormData] = useState({});
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);

  React.useEffect(() => {
    if (currentUser) {
      setFormData({
        ...currentUser,
        social_media: currentUser.social_media || {
          facebook: '',
          twitter: '',
          instagram: '',
          linkedin: '',
          website: ''
        }
      });
    }
  }, [currentUser]);

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });
      toast.success("Profile updated successfully!");
    },
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, profile_photo_url: file_url });
      toast.success("Photo uploaded! Click Save to update your profile.");
    } catch (error) {
      toast.error("Failed to upload photo");
    }
    setUploadingPhoto(false);
  };

  const handleCoverUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingCover(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_photo_url: file_url });
      toast.success("Cover photo uploaded! Click Save to update your profile.");
    } catch (error) {
      toast.error("Failed to upload cover photo");
    }
    setUploadingCover(false);
  };

  const handleSave = () => {
    updateProfileMutation.mutate(formData);
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const handleDisabilityTypeToggle = (type) => {
    const current = formData.disability_type || [];
    if (current.includes(type)) {
      setFormData({
        ...formData,
        disability_type: current.filter(t => t !== type)
      });
    } else {
      setFormData({
        ...formData,
        disability_type: [...current, type]
      });
    }
  };

  const handleAccessibilityNeedToggle = (need) => {
    const current = formData.accessibility_needs || [];
    if (current.includes(need)) {
      setFormData({
        ...formData,
        accessibility_needs: current.filter(n => n !== need)
      });
    } else {
      setFormData({
        ...formData,
        accessibility_needs: [...current, need]
      });
    }
  };

  const handleCommunicationToggle = (pref) => {
    const current = formData.communication_preferences || [];
    if (current.includes(pref)) {
      setFormData({
        ...formData,
        communication_preferences: current.filter(p => p !== pref)
      });
    } else {
      setFormData({
        ...formData,
        communication_preferences: [...current, pref]
      });
    }
  };

  const updateSocialMedia = (platform, value) => {
    setFormData({
      ...formData,
      social_media: {
        ...formData.social_media,
        [platform]: value
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Account Settings
          </h1>
          <p className="text-gray-600 text-lg">
            Manage your profile, security, preferences, and NDIS information
          </p>
        </div>

        <Tabs defaultValue={initialTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile" className="gap-2">
              <User className="w-4 h-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="security" className="gap-2">
              <Shield className="w-4 h-4" />
              Security
            </TabsTrigger>
            <TabsTrigger value="ndis" className="gap-2">
              <CreditCard className="w-4 h-4" />
              NDIS
            </TabsTrigger>
            <TabsTrigger value="preferences" className="gap-2">
              <Bell className="w-4 h-4" />
              Preferences
            </TabsTrigger>
            <TabsTrigger value="account" className="gap-2">
              <LogOut className="w-4 h-4" />
              Account
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Cover Photo */}
                <div className="space-y-2">
                  <Label>Cover Photo</Label>
                  <div className="relative w-full h-48 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg overflow-hidden">
                    {formData.cover_photo_url ? (
                      <img
                        src={formData.cover_photo_url}
                        alt="Cover"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <Camera className="w-12 h-12 text-white opacity-50" />
                      </div>
                    )}
                    <Label htmlFor="cover-upload" className="absolute bottom-4 right-4 cursor-pointer">
                      <Button variant="secondary" disabled={uploadingCover} asChild>
                        <span>
                          <Upload className="w-4 h-4 mr-2" />
                          {uploadingCover ? "Uploading..." : "Change Cover"}
                        </span>
                      </Button>
                    </Label>
                    <Input
                      id="cover-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleCoverUpload}
                      className="hidden"
                    />
                  </div>
                  <p className="text-xs text-gray-500">Recommended: 1200x300px. JPG, PNG or GIF. Max 5MB.</p>
                </div>

                <Separator />

                {/* Profile Photo */}
                <div className="flex items-center gap-6">
                  <div className="relative">
                    {formData.profile_photo_url ? (
                      <img
                        src={formData.profile_photo_url}
                        alt="Profile"
                        className="w-24 h-24 rounded-full object-cover border-4 border-secondary"
                      />
                    ) : (
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center border-4 border-secondary">
                        <span className="text-white font-bold text-3xl">
                          {currentUser?.full_name?.charAt(0) || "U"}
                        </span>
                      </div>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="photo-upload" className="cursor-pointer">
                      <Button variant="outline" disabled={uploadingPhoto} asChild>
                        <span>
                          <Upload className="w-4 h-4 mr-2" />
                          {uploadingPhoto ? "Uploading..." : "Change Photo"}
                        </span>
                      </Button>
                    </Label>
                    <Input
                      id="photo-upload"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    <p className="text-xs text-gray-500 mt-2">JPG, PNG or GIF. Max 5MB.</p>
                  </div>
                </div>

                <Separator />

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input value={currentUser?.full_name || ""} disabled />
                    <p className="text-xs text-gray-500">Contact support to change your name</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input value={currentUser?.email || ""} disabled />
                    <p className="text-xs text-gray-500">Contact support to change your email</p>
                  </div>
                </div>

                {/* Bio */}
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    placeholder="Tell us about yourself..."
                    value={formData.bio || ""}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    rows={4}
                  />
                  <p className="text-xs text-gray-500">Brief description for your profile</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="0412 345 678"
                    value={formData.phone || ""}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="suburb">Suburb</Label>
                    <Input
                      id="suburb"
                      placeholder="e.g., Sydney"
                      value={formData.suburb || ""}
                      onChange={(e) => setFormData({ ...formData, suburb: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="state">State</Label>
                    <Select
                      value={formData.state || ""}
                      onValueChange={(value) => setFormData({ ...formData, state: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NSW">NSW</SelectItem>
                        <SelectItem value="VIC">VIC</SelectItem>
                        <SelectItem value="QLD">QLD</SelectItem>
                        <SelectItem value="SA">SA</SelectItem>
                        <SelectItem value="WA">WA</SelectItem>
                        <SelectItem value="TAS">TAS</SelectItem>
                        <SelectItem value="NT">NT</SelectItem>
                        <SelectItem value="ACT">ACT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                {/* Social Media Links */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <LinkIcon className="w-5 h-5 text-gray-500" />
                    <Label className="text-base font-semibold">Social Media Links</Label>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Facebook className="w-5 h-5 text-blue-600" />
                      <Input
                        placeholder="https://facebook.com/yourprofile"
                        value={formData.social_media?.facebook || ""}
                        onChange={(e) => updateSocialMedia('facebook', e.target.value)}
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Twitter className="w-5 h-5 text-sky-500" />
                      <Input
                        placeholder="https://twitter.com/yourhandle"
                        value={formData.social_media?.twitter || ""}
                        onChange={(e) => updateSocialMedia('twitter', e.target.value)}
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Instagram className="w-5 h-5 text-pink-600" />
                      <Input
                        placeholder="https://instagram.com/yourprofile"
                        value={formData.social_media?.instagram || ""}
                        onChange={(e) => updateSocialMedia('instagram', e.target.value)}
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Linkedin className="w-5 h-5 text-blue-700" />
                      <Input
                        placeholder="https://linkedin.com/in/yourprofile"
                        value={formData.social_media?.linkedin || ""}
                        onChange={(e) => updateSocialMedia('linkedin', e.target.value)}
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Globe className="w-5 h-5 text-gray-600" />
                      <Input
                        placeholder="https://yourwebsite.com"
                        value={formData.social_media?.website || ""}
                        onChange={(e) => updateSocialMedia('website', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab - NEW */}
          <TabsContent value="security">
            <TwoFactorSettings userEmail={currentUser?.email} />
          </TabsContent>

          {/* NDIS Details Tab */}
          <TabsContent value="ndis">
            <Card>
              <CardHeader>
                <CardTitle>NDIS Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {formData.user_type === "participant" ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="ndis_number">NDIS Participant Number</Label>
                      <Input
                        id="ndis_number"
                        placeholder="e.g., 415309600"
                        value={formData.ndis_participant_number || ""}
                        onChange={(e) => setFormData({ ...formData, ndis_participant_number: e.target.value })}
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="plan_start">Plan Start Date</Label>
                        <Input
                          id="plan_start"
                          type="date"
                          value={formData.ndis_plan_start_date || ""}
                          onChange={(e) => setFormData({ ...formData, ndis_plan_start_date: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="plan_end">Plan End Date</Label>
                        <Input
                          id="plan_end"
                          type="date"
                          value={formData.ndis_plan_end_date || ""}
                          onChange={(e) => setFormData({ ...formData, ndis_plan_end_date: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="coordinator_email">Support Coordinator Email</Label>
                      <Input
                        id="coordinator_email"
                        type="email"
                        placeholder="coordinator@example.com"
                        value={formData.support_coordinator_email || ""}
                        onChange={(e) => setFormData({ ...formData, support_coordinator_email: e.target.value })}
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-sm text-blue-900">
                        <strong>Privacy Notice:</strong> Your NDIS information is securely stored and only used
                        to provide you with relevant services and support.
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12">
                    <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      NDIS Details Not Required
                    </h3>
                    <p className="text-gray-600">
                      As a {formData.user_type?.replace("_", " ")}, NDIS information is not needed.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Accessibility & Communication</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {formData.user_type === "participant" && (
                  <>
                    <div>
                      <Label className="text-base font-semibold mb-3 block">
                        Disability Type
                      </Label>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {[
                          { value: "physical", label: "Physical" },
                          { value: "sensory", label: "Sensory" },
                          { value: "intellectual", label: "Intellectual" },
                          { value: "psychosocial", label: "Psychosocial" },
                          { value: "neurological", label: "Neurological" },
                          { value: "multiple", label: "Multiple" },
                        ].map((type) => (
                          <div key={type.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                            <Checkbox
                              id={`dt-${type.value}`}
                              checked={formData.disability_type?.includes(type.value) || false}
                              onCheckedChange={() => handleDisabilityTypeToggle(type.value)}
                            />
                            <label
                              htmlFor={`dt-${type.value}`}
                              className="text-sm font-medium cursor-pointer flex-1"
                            >
                              {type.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <Label className="text-base font-semibold mb-3 block">
                        Accessibility Needs
                      </Label>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {[
                          "Wheelchair accessible venues",
                          "Step-free access",
                          "Accessible parking",
                          "Accessible bathrooms",
                          "Sign language interpreter",
                          "Audio descriptions",
                        ].map((need) => (
                          <div key={need} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                            <Checkbox
                              id={`need-${need}`}
                              checked={formData.accessibility_needs?.includes(need) || false}
                              onCheckedChange={() => handleAccessibilityNeedToggle(need)}
                            />
                            <label
                              htmlFor={`need-${need}`}
                              className="text-sm font-medium cursor-pointer flex-1"
                            >
                              {need}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />
                  </>
                )}

                <div>
                  <Label className="text-base font-semibold mb-3 block">
                    Communication Preferences
                  </Label>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {[
                      { value: "email", label: "Email" },
                      { value: "sms", label: "SMS" },
                      { value: "in_app", label: "In-App Notifications" },
                      { value: "phone_call", label: "Phone Call" },
                    ].map((pref) => (
                      <div key={pref.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <Checkbox
                          id={`pref-${pref.value}`}
                          checked={formData.communication_preferences?.includes(pref.value) || false}
                          onCheckedChange={() => handleCommunicationToggle(pref.value)}
                        />
                        <label
                          htmlFor={`pref-${pref.value}`}
                          className="text-sm font-medium cursor-pointer flex-1"
                        >
                          {pref.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {formData.user_type === "participant" && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <Label htmlFor="employment_goals">Employment Goals</Label>
                      <Textarea
                        id="employment_goals"
                        placeholder="Tell us about your employment aspirations..."
                        value={formData.employment_goals || ""}
                        onChange={(e) => setFormData({ ...formData, employment_goals: e.target.value })}
                        rows={5}
                      />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
            <PushNotificationSetup />
            <NotificationPreferences />
          </TabsContent>

          {/* Account Tab */}
          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-base font-semibold mb-2 block">Account Type</Label>
                  <p className="text-gray-700 capitalize">{formData.user_type?.replace("_", " ") || "Participant"}</p>
                </div>

                <div>
                  <Label className="text-base font-semibold mb-2 block">Email</Label>
                  <p className="text-gray-700">{currentUser?.email}</p>
                  <p className="text-xs text-gray-500 mt-1">This is your login email</p>
                </div>

                <Separator />

                <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                  <h3 className="font-semibold text-red-900 mb-3 flex items-center gap-2">
                    <LogOut className="w-5 h-5" />
                    Sign Out
                  </h3>
                  <p className="text-sm text-red-800 mb-4">
                    You'll be logged out of your account and redirected to the login page.
                  </p>
                  <Button
                    variant="destructive"
                    onClick={handleLogout}
                    className="gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end mt-6">
          <Button
            onClick={handleSave}
            disabled={updateProfileMutation.isPending}
            className="bg-secondary hover:bg-secondary/90 gap-2"
            size="lg"
          >
            <Save className="w-4 h-4" />
            {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}
