import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Users, 
  Activity, 
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Settings,
  FileText,
  MessageSquare,
  TrendingUp
} from "lucide-react";
import { hasPermission, PERMISSIONS } from "@/utils/permissions";

import UserManagementTab from "../components/admin/comprehensive/UserManagementTab";
import ProviderVerificationTab from "../components/admin/comprehensive/ProviderVerificationTab";
import ContentModerationTab from "../components/admin/comprehensive/ContentModerationTab";
import SystemAnalyticsTab from "../components/admin/comprehensive/SystemAnalyticsTab";
import SystemSettingsTab from "../components/admin/comprehensive/SystemSettingsTab";
import BookingManagementTab from "../components/admin/comprehensive/BookingManagementTab";
import AuditActivityTab from "../components/admin/comprehensive/AuditActivityTab";

export default function ComprehensiveAdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: users = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
    enabled: hasPermission(currentUser, PERMISSIONS.USERS_VIEW_ALL),
  });

  const { data: providers = [] } = useQuery({
    queryKey: ["allProviders"],
    queryFn: () => base44.entities.ServiceProvider.list(),
    enabled: hasPermission(currentUser, PERMISSIONS.PROVIDERS_VIEW_ALL),
  });

  const { data: credentials = [] } = useQuery({
    queryKey: ["allCredentials"],
    queryFn: () => base44.entities.ProviderCredential.list(),
    enabled: hasPermission(currentUser, PERMISSIONS.CREDENTIALS_VIEW_ALL),
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["allBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-created_date", 100),
    enabled: hasPermission(currentUser, PERMISSIONS.BOOKINGS_VIEW_ALL),
  });

  // Check admin access
  if (!hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can access the admin dashboard.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  // Calculate overview stats
  const pendingCredentials = credentials.filter(c => c.verification_status === "submitted").length;
  const activeUsers = users.filter(u => u.account_status === "active").length;
  const pendingProviders = providers.filter(p => !p.verified).length;
  const activeBookings = bookings.filter(b => 
    ["requested", "confirmed", "driver_assigned"].includes(b.status)
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Admin Control Center</h1>
              <p className="text-gray-600 text-lg">Comprehensive platform management and analytics</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid md:grid-cols-4 gap-4 mt-6">
            <div className="bg-white rounded-xl p-4 border-2 border-blue-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">Active Users</p>
                  <p className="text-3xl font-bold text-blue-600">{activeUsers}</p>
                </div>
                <Users className="w-10 h-10 text-blue-400" />
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 border-2 border-amber-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">Pending Verification</p>
                  <p className="text-3xl font-bold text-amber-600">{pendingCredentials + pendingProviders}</p>
                </div>
                <AlertTriangle className="w-10 h-10 text-amber-400" />
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 border-2 border-green-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">Active Bookings</p>
                  <p className="text-3xl font-bold text-green-600">{activeBookings}</p>
                </div>
                <Activity className="w-10 h-10 text-green-400" />
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">Total Providers</p>
                  <p className="text-3xl font-bold text-purple-600">{providers.length}</p>
                </div>
                <TrendingUp className="w-10 h-10 text-purple-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 bg-white shadow-lg rounded-xl p-1">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Users</span>
            </TabsTrigger>
            <TabsTrigger value="providers" className="gap-2">
              <CheckCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Providers</span>
            </TabsTrigger>
            <TabsTrigger value="bookings" className="gap-2">
              <Activity className="w-4 h-4" />
              <span className="hidden sm:inline">Bookings</span>
            </TabsTrigger>
            <TabsTrigger value="moderation" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">Moderation</span>
            </TabsTrigger>
            <TabsTrigger value="audit" className="gap-2">
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">Audit</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <SystemAnalyticsTab />
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users">
            <UserManagementTab />
          </TabsContent>

          {/* Provider Verification Tab */}
          <TabsContent value="providers">
            <ProviderVerificationTab />
          </TabsContent>

          {/* Booking Management Tab */}
          <TabsContent value="bookings">
            <BookingManagementTab />
          </TabsContent>

          {/* Content Moderation Tab */}
          <TabsContent value="moderation">
            <ContentModerationTab />
          </TabsContent>

          {/* Audit Activity Tab */}
          <TabsContent value="audit">
            <AuditActivityTab />
          </TabsContent>

          {/* System Settings Tab */}
          <TabsContent value="settings">
            <SystemSettingsTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}