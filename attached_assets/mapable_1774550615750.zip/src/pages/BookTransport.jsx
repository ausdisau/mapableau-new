
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Calendar, Clock, MapPin, DollarSign, CheckCircle, AlertCircle, Car } from "lucide-react";
import { addDays, addWeeks, addMonths, differenceInDays } from "date-fns";
import RecurringBookingForm from "../components/transport/RecurringBookingForm";
import { toast } from "sonner";
import NotificationService from "../components/notifications/NotificationService";

export default function BookTransportPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const vehicleId = urlParams.get("vehicle_id");
  const linkedServiceId = urlParams.get("linked_service_id");

  const [isRecurring, setIsRecurring] = useState(false);
  const [recurrencePattern, setRecurrencePattern] = useState({
    frequency: "",
    days_of_week: [],
    end_date: "",
    occurrences: undefined
  });

  const [bookingData, setBookingData] = useState({
    booking_type: "one_way",
    pickup_location: {
      address: "",
      suburb: "",
      state: "NSW",
      postcode: "",
      notes: ""
    },
    dropoff_location: {
      address: "",
      suburb: "",
      state: "NSW",
      postcode: "",
      notes: ""
    },
    pickup_datetime: "",
    passenger_name: "",
    passenger_phone: "",
    accessibility_requirements: [],
    purpose: "medical_appointment",
    passenger_count: 1,
    companion_count: 0,
    special_instructions: "",
    ndis_funded: true,
  });

  const { data: vehicle, isLoading: vehicleLoading } = useQuery({
    queryKey: ["vehicle", vehicleId],
    queryFn: async () => {
      const vehicles = await base44.entities.Vehicle.list();
      return vehicles.find((v) => v.id === vehicleId);
    },
    enabled: !!vehicleId,
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data) => {
      // Create bookings
      let createdBookings;
      if (data.isRecurring) {
        const bookings = data.bookingsArray;
        const seriesId = `series_${Date.now()}`;
        
        createdBookings = [];
        for (let i = 0; i < bookings.length; i++) {
          const booking = await base44.entities.TransportBooking.create({
            ...bookings[i],
            series_id: seriesId,
            occurrence_number: i + 1,
            parent_booking_id: i === 0 ? null : createdBookings[0].id
          });
          createdBookings.push(booking);
        }
      } else {
        const booking = await base44.entities.TransportBooking.create(data.bookingData);
        createdBookings = [booking];
      }
      
      // Send notification for first booking to the user
      if (currentUser && createdBookings.length > 0) {
        await NotificationService.notifyBookingConfirmed(createdBookings[0], currentUser.email);
      }
      
      // Notify provider
      if (vehicle && vehicle.operator_id) {
        // In real app, would look up operator's email from operator_id and send notification.
        // await NotificationService.notifyProviderOfNewBooking(createdBookBooks[0], operatorEmail);
      }
      
      return createdBookings;
    },
    onSuccess: (bookings) => {
      queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] });
      toast.success(
        bookings.length > 1 
          ? `${bookings.length} recurring bookings created successfully!`
          : "Booking created successfully!",
        {
          description: "You'll receive a notification when a driver is assigned.",
        }
      );
      navigate(`${createPageUrl("MyTransportBookings")}?booking_success=true`);
    },
    onError: (error) => {
      toast.error("Failed to create booking", {
        description: error.message
      });
    }
  });

  const generateRecurringBookings = (baseBooking, pattern) => {
    const bookings = [];
    if (!baseBooking.pickup_datetime) return []; // Cannot generate without a start date

    let currentDate = new Date(baseBooking.pickup_datetime);
    const firstPickupTime = currentDate.toTimeString().slice(0, 5); // Keep the time part consistent

    const maxOccurrences = pattern.occurrences || Infinity; // Use Infinity if occurrences is not set for end_date logic
    
    let endDateLimit = null;
    if (pattern.end_date) {
      endDateLimit = new Date(pattern.end_date);
      // Set end time to end of day to include bookings on the end date
      endDateLimit.setHours(23, 59, 59, 999);
    }

    let count = 0;
    while (count < maxOccurrences) {
      // Create a date for the current iteration, ensuring it matches the time of the first pickup
      const bookingDate = new Date(currentDate);
      // Re-apply the time from the original pickup_datetime to ensure consistent time of day
      const [hours, minutes] = firstPickupTime.split(':').map(Number);
      bookingDate.setHours(hours, minutes, 0, 0);

      if (endDateLimit && bookingDate > endDateLimit) {
        break; // Stop if beyond the end date
      }

      bookings.push({
        ...baseBooking,
        pickup_datetime: bookingDate.toISOString().slice(0, 16), // Format to YYYY-MM-DDTHH:MM
        is_recurring: true, // Mark this individual booking as part of a recurring series
        recurrence_pattern: pattern // Store the pattern for reference
      });

      count++;

      // Increment date based on frequency
      if (pattern.frequency === "daily") {
        currentDate = addDays(currentDate, 1);
      } else if (pattern.frequency === "weekly") {
        currentDate = addWeeks(currentDate, 1);
      } else if (pattern.frequency === "biweekly") {
        currentDate = addWeeks(currentDate, 2);
      } else if (pattern.frequency === "monthly") {
        currentDate = addMonths(currentDate, 1);
      } else {
        // If no frequency, stop after the first booking (or it's an invalid pattern)
        break;
      }
    }

    return bookings;
  };

  const handleBooking = () => {
    const estimatedDistance = 15;
    const estimatedDuration = 30;
    const estimatedCost = vehicle.hourly_rate 
      ? (vehicle.hourly_rate * (estimatedDuration / 60)) + (vehicle.per_km_rate || 0) * estimatedDistance
      : 0;

    const baseBookingData = {
      ...bookingData,
      vehicle_id: vehicleId,
      linked_service_request_id: linkedServiceId || null,
      estimated_distance_km: estimatedDistance,
      estimated_duration_minutes: estimatedDuration,
      estimated_cost: estimatedCost,
      status: "requested",
      payment_status: "pending",
    };

    if (isRecurring && recurrencePattern.frequency && bookingData.pickup_datetime) {
      // Check if end_date or occurrences is provided
      if (!recurrencePattern.end_date && recurrencePattern.occurrences === undefined) {
        console.error("Recurring booking requires either an end date or number of occurrences.");
        // Potentially show an error to the user via a toast or alert
        toast.error("Recurring booking requires either an end date or number of occurrences.");
        return;
      }
      const bookingsArray = generateRecurringBookings(baseBookingData, recurrencePattern);
      if (bookingsArray.length > 0) {
        createBookingMutation.mutate({ isRecurring: true, bookingsArray });
      } else {
        // Handle case where no bookings were generated (e.g., end date before start date)
        console.error("No recurring bookings could be generated with the given pattern.");
        toast.error("No recurring bookings could be generated with the given pattern. Please check dates.");
      }
    } else {
      createBookingMutation.mutate({ isRecurring: false, bookingData: baseBookingData });
    }
  };

  const accessibilityOptions = [
    { value: "wheelchair", label: "Wheelchair" },
    { value: "mobility_scooter", label: "Mobility Scooter" },
    { value: "walker", label: "Walker" },
    { value: "service_animal", label: "Service Animal" },
    { value: "oxygen_tank", label: "Oxygen Tank" },
    { value: "assistance_required", label: "Physical Assistance Required" },
    { value: "communication_support", label: "Communication Support" },
  ];

  const toggleAccessibility = (value) => {
    setBookingData(prev => ({
      ...prev,
      accessibility_requirements: prev.accessibility_requirements.includes(value)
        ? prev.accessibility_requirements.filter(r => r !== value)
        : [...prev.accessibility_requirements, value]
    }));
  };

  if (vehicleLoading || !vehicle) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  const estimatedCost = vehicle.hourly_rate 
    ? (vehicle.hourly_rate * 0.5) + (vehicle.per_km_rate || 0) * 15
    : 0;

  const totalBookings = isRecurring && recurrencePattern.frequency && bookingData.pickup_datetime
    ? generateRecurringBookings({ pickup_datetime: bookingData.pickup_datetime }, recurrencePattern).length
    : 1;


  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("FindTransport"))}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Transport
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Book Accessible Transport</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Booking Type */}
                <div className="space-y-2">
                  <Label>Trip Type</Label>
                  <Select
                    value={bookingData.booking_type}
                    onValueChange={(v) => setBookingData({ ...bookingData, booking_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="one_way">One Way</SelectItem>
                      <SelectItem value="return">Return Trip</SelectItem>
                      <SelectItem value="multi_stop">Multiple Stops</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Pickup Details */}
                <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-secondary" />
                    Pickup Location
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <Label>Address</Label>
                      <Input
                        placeholder="123 Main Street"
                        value={bookingData.pickup_location.address}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          pickup_location: { ...bookingData.pickup_location, address: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Suburb</Label>
                      <Input
                        value={bookingData.pickup_location.suburb}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          pickup_location: { ...bookingData.pickup_location, suburb: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Postcode</Label>
                      <Input
                        value={bookingData.pickup_location.postcode}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          pickup_location: { ...bookingData.pickup_location, postcode: e.target.value }
                        })}
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <Label>Pickup Notes (optional)</Label>
                      <Input
                        placeholder="E.g., Meet at main entrance"
                        value={bookingData.pickup_location.notes}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          pickup_location: { ...bookingData.pickup_location, notes: e.target.value }
                        })}
                      />
                    </div>
                  </div>
                </div>

                {/* Drop-off Details */}
                <div className="space-y-4 p-4 bg-green-50 rounded-lg">
                  <h3 className="font-semibold flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-green-600" />
                    Drop-off Location
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <Label>Address</Label>
                      <Input
                        placeholder="456 Hospital Road"
                        value={bookingData.dropoff_location.address}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          dropoff_location: { ...bookingData.dropoff_location, address: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Suburb</Label>
                      <Input
                        value={bookingData.dropoff_location.suburb}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          dropoff_location: { ...bookingData.dropoff_location, suburb: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Postcode</Label>
                      <Input
                        value={bookingData.dropoff_location.postcode}
                        onChange={(e) => setBookingData({
                          ...bookingData,
                          dropoff_location: { ...bookingData.dropoff_location, postcode: e.target.value }
                        })}
                      />
                    </div>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>First Pickup Date & Time</Label>
                    <Input
                      type="datetime-local"
                      value={bookingData.pickup_datetime}
                      onChange={(e) => setBookingData({ ...bookingData, pickup_datetime: e.target.value })}
                      min={new Date().toISOString().slice(0, 16)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Purpose</Label>
                    <Select
                      value={bookingData.purpose}
                      onValueChange={(v) => setBookingData({ ...bookingData, purpose: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="medical_appointment">Medical Appointment</SelectItem>
                        <SelectItem value="therapy_session">Therapy Session</SelectItem>
                        <SelectItem value="community_access">Community Access</SelectItem>
                        <SelectItem value="employment">Employment</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="social_participation">Social Participation</SelectItem>
                        <SelectItem value="shopping">Shopping</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Passenger Details */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Passenger Name</Label>
                    <Input
                      value={bookingData.passenger_name}
                      onChange={(e) => setBookingData({ ...bookingData, passenger_name: e.target.value })}
                      placeholder={currentUser?.full_name || ""}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Contact Phone</Label>
                    <Input
                      type="tel"
                      value={bookingData.passenger_phone}
                      onChange={(e) => setBookingData({ ...bookingData, passenger_phone: e.target.value })}
                      placeholder={currentUser?.phone || ""}
                    />
                  </div>
                </div>

                {/* Accessibility Requirements */}
                <div className="space-y-3">
                  <Label>Accessibility Requirements</Label>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {accessibilityOptions.map((option) => (
                      <div key={option.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={option.value}
                          checked={bookingData.accessibility_requirements.includes(option.value)}
                          onCheckedChange={() => toggleAccessibility(option.value)}
                        />
                        <label
                          htmlFor={option.value}
                          className="text-sm font-medium leading-none cursor-pointer"
                        >
                          {option.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Special Instructions */}
                <div className="space-y-2">
                  <Label>Special Instructions (optional)</Label>
                  <Textarea
                    placeholder="Any specific requirements or information for the driver..."
                    value={bookingData.special_instructions}
                    onChange={(e) => setBookingData({ ...bookingData, special_instructions: e.target.value })}
                    rows={3}
                  />
                </div>

                {/* NDIS Funding */}
                <Alert>
                  <CheckCircle className="w-4 h-4" />
                  <AlertDescription>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="ndis_funded"
                          checked={bookingData.ndis_funded}
                          onCheckedChange={(checked) => setBookingData({ ...bookingData, ndis_funded: checked })}
                        />
                        <label htmlFor="ndis_funded" className="text-sm font-medium cursor-pointer">
                          Claim through NDIS
                        </label>
                      </div>
                      <span className="text-lg font-bold text-primary">${estimatedCost.toFixed(2)}</span>
                    </div>
                    <p className="text-xs mt-2 text-gray-600">
                      Estimated cost per trip (~15km, 30min)
                    </p>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            {/* Recurring Booking Form */}
            <RecurringBookingForm
              isRecurring={isRecurring}
              setIsRecurring={setIsRecurring}
              recurrencePattern={recurrencePattern}
              setRecurrencePattern={setRecurrencePattern}
              firstPickupDate={bookingData.pickup_datetime?.split('T')[0]}
            />

            {/* Submit Button */}
            <Button
              onClick={handleBooking}
              className="w-full bg-secondary hover:bg-secondary/90 h-12 text-base"
              disabled={
                !bookingData.pickup_location.address ||
                !bookingData.dropoff_location.address ||
                !bookingData.pickup_datetime ||
                !bookingData.passenger_name ||
                (isRecurring && (!recurrencePattern.frequency || (recurrencePattern.end_date === "" && recurrencePattern.occurrences === undefined))) ||
                createBookingMutation.isPending
              }
            >
              {createBookingMutation.isPending 
                ? "Processing..." 
                : isRecurring 
                  ? `Book ${totalBookings} Recurring Trips`
                  : "Confirm Booking"
              }
            </Button>
          </div>

          {/* Vehicle Summary Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Vehicle Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {vehicle.photos && vehicle.photos[0] ? (
                  <img
                    src={vehicle.photos[0]}
                    alt={vehicle.vehicle_name}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-full h-32 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg flex items-center justify-center">
                    <Car className="w-12 h-12 text-blue-600" />
                  </div>
                )}

                <div>
                  <h3 className="font-bold text-primary">{vehicle.vehicle_name}</h3>
                  <p className="text-sm text-gray-600">{vehicle.vehicle_type?.replace(/_/g, " ")}</p>
                </div>

                {vehicle.capacity && (
                  <div className="text-sm space-y-1">
                    {vehicle.capacity.wheelchair_spaces > 0 && (
                      <p>• {vehicle.capacity.wheelchair_spaces} wheelchair space(s)</p>
                    )}
                    {vehicle.capacity.standard_seats > 0 && (
                      <p>• {vehicle.capacity.standard_seats} standard seat(s)</p>
                    )}
                  </div>
                )}

                <div className="pt-3 border-t">
                  {vehicle.hourly_rate && (
                    <div className="text-sm">
                      <span className="font-semibold">${vehicle.hourly_rate}/hour</span>
                      {vehicle.per_km_rate && (
                        <span className="text-gray-600"> + ${vehicle.per_km_rate}/km</span>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {isRecurring && totalBookings > 1 && (
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-6">
                  <div className="text-center space-y-2">
                    <p className="text-sm text-gray-600">Total Estimated Cost</p>
                    <p className="text-3xl font-bold text-primary">
                      ${(estimatedCost * totalBookings).toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-600">
                      {totalBookings} trips × ${estimatedCost.toFixed(2)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {linkedServiceId && (
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-blue-900 text-sm">Linked to Service</p>
                      <p className="text-xs text-blue-700 mt-1">
                        This transport will be coordinated with your care service booking
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
