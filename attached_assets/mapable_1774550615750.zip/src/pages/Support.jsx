import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, HelpCircle, Book, MessageCircle, Plus, Clock } from "lucide-react";
import { format } from "date-fns";

export default function SupportPage() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [ticketData, setTicketData] = useState({
    subject: "",
    description: "",
    category: "technical",
    priority: "medium",
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: tickets = [] } = useQuery({
    queryKey: ["myTickets"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.SupportTicket.filter({ created_by: user.email }, "-created_date");
    },
    enabled: !!currentUser,
  });

  const { data: articles = [] } = useQuery({
    queryKey: ["knowledgeBase"],
    queryFn: () => base44.entities.KnowledgeBaseArticle.filter({ published: true }, "-view_count"),
  });

  const createTicketMutation = useMutation({
    mutationFn: (data) => base44.entities.SupportTicket.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myTickets"] });
      setShowNewTicket(false);
      setTicketData({
        subject: "",
        description: "",
        category: "technical",
        priority: "medium",
      });
    },
  });

  const filteredArticles = articles.filter(
    a =>
      a.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSubmitTicket = () => {
    createTicketMutation.mutate(ticketData);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "resolved":
      case "closed":
        return "bg-green-100 text-green-700";
      case "in_progress":
        return "bg-blue-100 text-blue-700";
      case "awaiting_response":
        return "bg-yellow-100 text-yellow-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Support Centre
          </h1>
          <p className="text-gray-600 text-lg">
            Get help with your MapAble account and services
          </p>
        </div>

        <Tabs defaultValue="knowledge" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="knowledge" className="gap-2">
              <Book className="w-4 h-4" />
              Knowledge Base
            </TabsTrigger>
            <TabsTrigger value="tickets" className="gap-2">
              <MessageCircle className="w-4 h-4" />
              My Tickets ({tickets.length})
            </TabsTrigger>
          </TabsList>

          {/* Knowledge Base */}
          <TabsContent value="knowledge" className="space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search articles, guides, FAQs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardContent>
            </Card>

            {filteredArticles.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Book className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No articles found</h3>
                  <p className="text-gray-600">Try a different search term or browse by category</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredArticles.map((article) => (
                  <Card key={article.id} className="hover-lift cursor-pointer">
                    <CardHeader>
                      <Badge variant="outline" className="w-fit mb-2">
                        {article.category.replace(/_/g, " ")}
                      </Badge>
                      <CardTitle className="text-lg">{article.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 line-clamp-3 mb-4">
                        {article.content.substring(0, 150)}...
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{article.view_count} views</span>
                        <span>{article.helpful_count} found helpful</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Support Tickets */}
          <TabsContent value="tickets" className="space-y-6">
            <div className="flex justify-between items-center">
              <p className="text-gray-600">{tickets.length} total tickets</p>
              <Button
                onClick={() => setShowNewTicket(!showNewTicket)}
                className="bg-secondary hover:bg-secondary/90"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Ticket
              </Button>
            </div>

            {/* New Ticket Form */}
            {showNewTicket && (
              <Card>
                <CardHeader>
                  <CardTitle>Submit a Support Request</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Input
                      placeholder="Brief description of your issue"
                      value={ticketData.subject}
                      onChange={(e) => setTicketData({ ...ticketData, subject: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select
                        value={ticketData.category}
                        onValueChange={(v) => setTicketData({ ...ticketData, category: v })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="technical">Technical Issue</SelectItem>
                          <SelectItem value="billing">Billing & Payments</SelectItem>
                          <SelectItem value="service_quality">Service Quality</SelectItem>
                          <SelectItem value="accessibility">Accessibility</SelectItem>
                          <SelectItem value="account">Account Management</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select
                        value={ticketData.priority}
                        onValueChange={(v) => setTicketData({ ...ticketData, priority: v })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      placeholder="Please provide details about your issue..."
                      value={ticketData.description}
                      onChange={(e) => setTicketData({ ...ticketData, description: e.target.value })}
                      rows={6}
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={handleSubmitTicket}
                      className="bg-secondary hover:bg-secondary/90"
                      disabled={!ticketData.subject || !ticketData.description || createTicketMutation.isPending}
                    >
                      {createTicketMutation.isPending ? "Submitting..." : "Submit Ticket"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowNewTicket(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Tickets List */}
            {tickets.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No support tickets</h3>
                  <p className="text-gray-600 mb-4">You haven't submitted any support requests yet</p>
                  <Button onClick={() => setShowNewTicket(true)} className="bg-secondary hover:bg-secondary/90">
                    Create Your First Ticket
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {tickets.map((ticket) => (
                  <Card key={ticket.id} className="hover-lift">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-lg">{ticket.subject}</h3>
                            <Badge className={getStatusColor(ticket.status)}>
                              {ticket.status.replace(/_/g, " ")}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {ticket.category.replace(/_/g, " ")}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                            {ticket.description}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {format(new Date(ticket.created_date), "MMM d, yyyy")}
                            </div>
                            <span>Priority: {ticket.priority}</span>
                          </div>
                        </div>
                      </div>
                      {ticket.resolution_notes && (
                        <div className="mt-4 p-3 bg-green-50 rounded-lg">
                          <p className="text-sm font-medium text-green-900 mb-1">Resolution:</p>
                          <p className="text-sm text-green-700">{ticket.resolution_notes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}