import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Globe, RefreshCw } from "lucide-react";

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full">
        <CardContent className="pt-12 pb-8 text-center">
          <div className="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Globe className="w-16 h-16 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-primary mb-4">
            You're Offline
          </h1>
          
          <p className="text-lg text-gray-600 mb-6 leading-relaxed">
            MapAble works best with an internet connection. Some features may be limited while offline.
          </p>
          
          <Button
            onClick={() => window.location.reload()}
            className="bg-secondary hover:bg-secondary/90 gap-2 text-lg px-8 py-6"
          >
            <RefreshCw className="w-5 h-5" />
            Try Again
          </Button>

          <div className="mt-12 p-6 bg-blue-50 rounded-lg text-left">
            <h2 className="font-semibold text-lg mb-3 text-primary">
              While You're Offline
            </h2>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-secondary font-bold">•</span>
                <span>Recently viewed locations may be available in your browser cache</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary font-bold">•</span>
                <span>Your saved searches and preferences are stored locally</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary font-bold">•</span>
                <span>Any bookings or requests will be synced when you reconnect</span>
              </li>
            </ul>
          </div>

          <p className="mt-6 text-sm text-gray-500">
            We'll automatically reconnect when your internet is restored
          </p>
        </CardContent>
      </Card>
    </div>
  );
}