import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft,
  ThumbsUp,
  ThumbsDown,
  Eye,
  Clock,
  Share2,
  Bookmark,
  HelpCircle
} from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";

export default function HelpArticlePage() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const articleId = urlParams.get("id");

  const { data: article, isLoading } = useQuery({
    queryKey: ["knowledgeBaseArticle", articleId],
    queryFn: async () => {
      const articles = await base44.entities.KnowledgeBaseArticle.filter({ id: articleId });
      return articles[0] || null;
    },
    enabled: !!articleId,
  });

  const { data: relatedArticles = [] } = useQuery({
    queryKey: ["relatedArticles", article?.category],
    queryFn: async () => {
      if (!article?.category) return [];
      const articles = await base44.entities.KnowledgeBaseArticle.filter({
        category: article.category,
        published: true
      }, "-view_count", 4);
      return articles.filter(a => a.id !== articleId);
    },
    enabled: !!article?.category,
  });

  const incrementViewMutation = useMutation({
    mutationFn: (id) =>
      base44.entities.KnowledgeBaseArticle.update(id, {
        view_count: (article?.view_count || 0) + 1
      }),
  });

  const markHelpfulMutation = useMutation({
    mutationFn: (id) =>
      base44.entities.KnowledgeBaseArticle.update(id, {
        helpful_count: (article?.helpful_count || 0) + 1
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["knowledgeBaseArticle", articleId] });
      toast.success("Thank you for your feedback!");
    },
  });

  // Increment view count on mount
  useEffect(() => {
    if (article?.id) {
      incrementViewMutation.mutate(article.id);
    }
  }, [article?.id]);

  const getCategoryColor = (category) => {
    const colors = {
      getting_started: "bg-blue-100 text-blue-700",
      ndis_funding: "bg-green-100 text-green-700",
      booking_services: "bg-purple-100 text-purple-700",
      finding_jobs: "bg-orange-100 text-orange-700",
      accessibility: "bg-teal-100 text-teal-700",
      troubleshooting: "bg-red-100 text-red-700",
      billing_payments: "bg-indigo-100 text-indigo-700"
    };
    return colors[category] || "bg-gray-100 text-gray-700";
  };

  const getCategoryLabel = (category) => {
    const labels = {
      getting_started: "Getting Started",
      ndis_funding: "NDIS Funding",
      booking_services: "Booking Services",
      finding_jobs: "Finding Jobs",
      accessibility: "Accessibility",
      troubleshooting: "Troubleshooting",
      billing_payments: "Billing & Payments"
    };
    return labels[category] || category;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Article Not Found
              </h3>
              <p className="text-gray-600 mb-4">
                The help article you're looking for doesn't exist or has been removed.
              </p>
              <Link to={createPageUrl("HelpCenter")}>
                <Button className="bg-secondary hover:bg-secondary/90">
                  Back to Help Center
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to={createPageUrl("HelpCenter")}>
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Help Center
          </Button>
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="pt-6">
                {/* Article Header */}
                <div className="mb-6">
                  <Badge className={getCategoryColor(article.category)} variant="secondary">
                    {getCategoryLabel(article.category)}
                  </Badge>
                  <h1 className="text-4xl font-bold text-primary mt-4 mb-4">
                    {article.title}
                  </h1>
                  
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                    {article.view_count > 0 && (
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {article.view_count} views
                      </span>
                    )}
                    {article.helpful_count > 0 && (
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-4 h-4" />
                        {article.helpful_count} found helpful
                      </span>
                    )}
                    {article.updated_date && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        Updated {format(new Date(article.updated_date), "MMM d, yyyy")}
                      </span>
                    )}
                  </div>

                  {/* Tags */}
                  {article.tags && article.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {article.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-xs px-3 py-1 bg-gray-100 text-gray-700 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <Separator className="my-6" />

                {/* Article Content */}
                <div className="prose prose-lg max-w-none">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => (
                        <h1 className="text-3xl font-bold text-primary mt-8 mb-4">{children}</h1>
                      ),
                      h2: ({ children }) => (
                        <h2 className="text-2xl font-bold text-primary mt-6 mb-3">{children}</h2>
                      ),
                      h3: ({ children }) => (
                        <h3 className="text-xl font-semibold text-primary mt-4 mb-2">{children}</h3>
                      ),
                      p: ({ children }) => (
                        <p className="text-gray-700 leading-relaxed mb-4">{children}</p>
                      ),
                      ul: ({ children }) => (
                        <ul className="list-disc list-inside space-y-2 mb-4 text-gray-700">{children}</ul>
                      ),
                      ol: ({ children }) => (
                        <ol className="list-decimal list-inside space-y-2 mb-4 text-gray-700">{children}</ol>
                      ),
                      li: ({ children }) => (
                        <li className="ml-4">{children}</li>
                      ),
                      code: ({ inline, children }) =>
                        inline ? (
                          <code className="px-1.5 py-0.5 bg-gray-100 text-gray-800 rounded text-sm font-mono">
                            {children}
                          </code>
                        ) : (
                          <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto mb-4">
                            <code className="text-sm font-mono text-gray-800">{children}</code>
                          </pre>
                        ),
                      blockquote: ({ children }) => (
                        <blockquote className="border-l-4 border-blue-500 pl-4 my-4 italic text-gray-700">
                          {children}
                        </blockquote>
                      ),
                      a: ({ children, href }) => (
                        <a
                          href={href}
                          className="text-blue-600 hover:text-blue-700 underline"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {children}
                        </a>
                      ),
                    }}
                  >
                    {article.content}
                  </ReactMarkdown>
                </div>

                <Separator className="my-8" />

                {/* Feedback Section */}
                <div className="bg-gray-50 rounded-lg p-6 text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Was this article helpful?
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Let us know if you found this information useful
                  </p>
                  <div className="flex justify-center gap-3">
                    <Button
                      onClick={() => markHelpfulMutation.mutate(article.id)}
                      disabled={markHelpfulMutation.isPending}
                      className="gap-2"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      Yes, this helped
                    </Button>
                    <Button variant="outline" className="gap-2">
                      <ThumbsDown className="w-4 h-4" />
                      No, I need more help
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardContent className="pt-6 space-y-3">
                <Button
                  variant="outline"
                  className="w-full gap-2"
                  onClick={handleShare}
                >
                  <Share2 className="w-4 h-4" />
                  Share Article
                </Button>
                <Button variant="outline" className="w-full gap-2">
                  <Bookmark className="w-4 h-4" />
                  Bookmark
                </Button>
              </CardContent>
            </Card>

            {/* Related Articles */}
            {relatedArticles.length > 0 && (
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold text-lg mb-4">Related Articles</h3>
                  <div className="space-y-3">
                    {relatedArticles.map((related) => (
                      <Link
                        key={related.id}
                        to={`${createPageUrl("HelpArticle")}?id=${related.id}`}
                        className="block p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                      >
                        <p className="font-medium text-sm text-gray-900 line-clamp-2 group-hover:text-blue-700">
                          {related.title}
                        </p>
                        <span className="text-xs text-gray-600 mt-1 flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {related.view_count || 0} views
                        </span>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Contact Support */}
            <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-purple-50">
              <CardContent className="pt-6">
                <h3 className="font-semibold text-lg mb-2">Still Need Help?</h3>
                <p className="text-sm text-gray-700 mb-4">
                  Contact our support team for personalized assistance
                </p>
                <Link to={createPageUrl("Support")}>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Contact Support
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}