import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Briefcase, 
  Car, 
  MapPin, 
  UtensilsCrossed, 
  ParkingSquare,
  ArrowRight,
  Star,
  Users,
  CheckCircle,
  Sparkles,
  TrendingUp,
  Shield
} from "lucide-react";
import { motion } from "framer-motion";

const services = [
  {
    id: "care",
    name: "MapAble for Care",
    tagline: "Find trusted support and care services",
    description: "Connect with verified NDIS support workers, therapists, and care providers across Australia",
    icon: Heart,
    color: "from-green-500 to-green-600",
    accentColor: "green",
    linkTo: "FindCare",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/7276e895a_mapable_care_3d.png",
    stats: { label: "Care Providers", value: "500+" }
  },
  {
    id: "jobs",
    name: "MapAble for Jobs",
    tagline: "Discover inclusive employment opportunities",
    description: "Browse disability-confident employers and access employment support services",
    icon: Briefcase,
    color: "from-orange-500 to-orange-600",
    accentColor: "orange",
    linkTo: "FindJobs",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/aed9e52b7_mapable_jobs_3d.png",
    stats: { label: "Active Jobs", value: "200+" }
  },
  {
    id: "transport",
    name: "MapAble for Transport",
    tagline: "Book accessible transport with ease",
    description: "NDIS-registered wheelchair accessible vehicles and professional drivers",
    icon: Car,
    color: "from-blue-500 to-blue-600",
    accentColor: "blue",
    linkTo: "FindTransport",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/5bd15e6ae_mapable_transport_3d.png",
    stats: { label: "Trips Completed", value: "5,000+" }
  },
  {
    id: "places",
    name: "MapAble Places",
    tagline: "Explore accessible venues near you",
    description: "Discover restaurants, cafes, and entertainment with verified accessibility ratings",
    icon: MapPin,
    color: "from-purple-500 to-purple-600",
    accentColor: "purple",
    linkTo: "Map",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/2f91a347f_mapable_main_organic.png",
    stats: { label: "Locations Rated", value: "1,000+" }
  },
  {
    id: "foods",
    name: "MapAble Foods",
    tagline: "Find accessible dining experiences",
    description: "Restaurant ratings, menus, and accessibility features at your fingertips",
    icon: UtensilsCrossed,
    color: "from-green-600 to-lime-600",
    accentColor: "lime",
    linkTo: "Map",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/8ed08f742_mapable_foods_organic.png",
    stats: { label: "Restaurants", value: "300+" }
  },
  {
    id: "moves",
    name: "MapAble Moves",
    tagline: "Discover accessible parks and recreation",
    description: "Find parks, playgrounds, and outdoor spaces with accessibility information",
    icon: ParkingSquare,
    color: "from-teal-500 to-teal-600",
    accentColor: "teal",
    linkTo: "Map",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/ca5a7aea2_mapable_moves_3d.png",
    stats: { label: "Parks & Spaces", value: "150+" }
  },
];

const features = [
  {
    icon: Shield,
    title: "NDIS Registered",
    description: "All providers are verified and NDIS registered"
  },
  {
    icon: Star,
    title: "Evidence-Based Ratings",
    description: "Real accessibility scores from the community"
  },
  {
    icon: CheckCircle,
    title: "Trusted Platform",
    description: "Used by thousands across Australia"
  },
  {
    icon: Sparkles,
    title: "AI-Powered Matching",
    description: "Smart recommendations for your needs"
  },
];

export default function HomePage() {
  const [hoveredService, setHoveredService] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0F2947] via-[#1a4d6f] to-[#5FA85C] opacity-95"></div>
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex justify-center mb-8">
              <motion.img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/05d1cd4bf_mapable-logo-original.png"
                alt="MapAble"
                className="h-28 sm:h-36 drop-shadow-2xl"
                initial={{ scale: 0.8, rotate: -5 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ duration: 0.8, type: "spring" }}
              />
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight">
              Welcome to <span className="text-[#5FA85C]">MapAble</span>
            </h1>
            
            <p className="text-xl sm:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
              Your all-in-one platform for accessible living in Australia
            </p>

            <p className="text-lg text-blue-200 mb-12 max-w-2xl mx-auto">
              Find care, employment, transport, and accessible places - all in one place
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Link to={createPageUrl("Dashboard")}>
                <Button size="lg" className="bg-[#5FA85C] hover:bg-[#4d8a4a] text-white px-8 py-6 text-lg rounded-full shadow-2xl hover:shadow-green-500/50 transition-all">
                  Get Started
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("Map")}>
                <Button size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-8 py-6 text-lg rounded-full">
                  Explore Map
                  <MapPin className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
            <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="rgb(248 250 252)"/>
          </svg>
        </div>
      </section>

      {/* Services Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="bg-[#5FA85C] text-white mb-4 px-4 py-2">Our Services</Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-[#0F2947] mb-4">
            Everything You Need
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive accessibility services designed for the disability community
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                onHoverStart={() => setHoveredService(service.id)}
                onHoverEnd={() => setHoveredService(null)}
              >
                <Link to={createPageUrl(service.linkTo)}>
                  <Card className="h-full group cursor-pointer overflow-hidden border-2 border-transparent hover:border-[#5FA85C] transition-all duration-300 hover:shadow-2xl hover:-translate-y-2">
                    <CardContent className="p-0">
                      {/* Image Section */}
                      <div className="relative h-48 overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200">
                        <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-10 group-hover:opacity-20 transition-opacity`}></div>
                        <img
                          src={service.image}
                          alt={service.name}
                          className="w-full h-full object-contain p-6 group-hover:scale-110 transition-transform duration-500"
                        />
                        <Badge className={`absolute top-4 right-4 bg-white/90 backdrop-blur-sm text-${service.accentColor}-700 border-${service.accentColor}-200`}>
                          {service.stats.value}
                        </Badge>
                      </div>

                      {/* Content Section */}
                      <div className="p-6">
                        <div className="flex items-center gap-3 mb-3">
                          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow`}>
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-[#0F2947] group-hover:text-[#5FA85C] transition-colors">
                              {service.name}
                            </h3>
                          </div>
                        </div>

                        <p className={`text-sm font-semibold text-${service.accentColor}-600 mb-2`}>
                          {service.tagline}
                        </p>

                        <p className="text-gray-600 mb-4 line-clamp-2">
                          {service.description}
                        </p>

                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">{service.stats.label}</span>
                          <div className="flex items-center gap-2 text-[#5FA85C] font-semibold group-hover:gap-4 transition-all">
                            Explore
                            <ArrowRight className="w-5 h-5" />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gradient-to-br from-[#0F2947] to-[#1a4d6f] py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-4">
              Why Choose MapAble?
            </h2>
            <p className="text-xl text-blue-200 max-w-2xl mx-auto">
              Trusted by the disability community across Australia
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all h-full">
                    <CardContent className="p-6 text-center">
                      <div className="w-16 h-16 rounded-full bg-[#5FA85C]/20 flex items-center justify-center mx-auto mb-4">
                        <Icon className="w-8 h-8 text-[#5FA85C]" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-blue-200">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Users, value: "10,000+", label: "Active Users" },
              { icon: CheckCircle, value: "5,000+", label: "Verified Providers" },
              { icon: MapPin, value: "1,000+", label: "Accessible Venues" },
              { icon: TrendingUp, value: "98%", label: "Satisfaction Rate" },
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <Icon className="w-12 h-12 text-[#5FA85C] mx-auto mb-4" />
                  <div className="text-4xl font-bold text-[#0F2947] mb-2">
                    {stat.value}
                  </div>
                  <div className="text-gray-600 font-medium">
                    {stat.label}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-br from-[#5FA85C] to-[#4d8a4a] py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
              Join thousands of Australians making accessibility easier every day
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              {currentUser ? (
                <Link to={createPageUrl("Dashboard")}>
                  <Button size="lg" className="bg-white text-[#5FA85C] hover:bg-gray-100 px-8 py-6 text-lg rounded-full shadow-2xl">
                    Go to Dashboard
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
              ) : (
                <>
                  <Button 
                    size="lg" 
                    onClick={() => base44.auth.redirectToLogin()}
                    className="bg-white text-[#5FA85C] hover:bg-gray-100 px-8 py-6 text-lg rounded-full shadow-2xl"
                  >
                    Sign Up Free
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                  <Link to={createPageUrl("Map")}>
                    <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg rounded-full">
                      Browse as Guest
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}