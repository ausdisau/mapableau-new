import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Key, 
  CheckCircle, 
  AlertTriangle,
  Save,
  Eye,
  EyeOff,
  Copy,
  ExternalLink,
  Shield
} from "lucide-react";
import { toast } from "sonner";

export default function OAuthSettingsPage() {
  const queryClient = useQueryClient();
  const [showSecrets, setShowSecrets] = useState({
    google: false,
    facebook: false,
    microsoft: false
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // OAuth Configuration State
  const [googleConfig, setGoogleConfig] = useState({
    enabled: false,
    clientId: "",
    clientSecret: "",
    redirectUri: `${window.location.origin}/auth/google/callback`
  });

  const [facebookConfig, setFacebookConfig] = useState({
    enabled: false,
    appId: "",
    appSecret: "",
    redirectUri: `${window.location.origin}/auth/facebook/callback`
  });

  const [microsoftConfig, setMicrosoftConfig] = useState({
    enabled: false,
    clientId: "",
    clientSecret: "",
    tenantId: "common",
    redirectUri: `${window.location.origin}/auth/microsoft/callback`
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (config) => {
      // Store OAuth config securely (in production, use backend)
      localStorage.setItem('oauth_config', JSON.stringify(config));
      return config;
    },
    onSuccess: () => {
      toast.success("OAuth settings saved successfully!", {
        description: "Social login providers have been configured"
      });
    }
  });

  const handleSaveGoogle = () => {
    saveConfigMutation.mutate({ provider: 'google', ...googleConfig });
  };

  const handleSaveFacebook = () => {
    saveConfigMutation.mutate({ provider: 'facebook', ...facebookConfig });
  };

  const handleSaveMicrosoft = () => {
    saveConfigMutation.mutate({ provider: 'microsoft', ...microsoftConfig });
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const toggleSecret = (provider) => {
    setShowSecrets(prev => ({
      ...prev,
      [provider]: !prev[provider]
    }));
  };

  // Check if user is admin
  if (currentUser?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can manage OAuth settings.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-primary">OAuth Configuration</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Configure social login providers for Google, Facebook, and Microsoft
          </p>
        </div>

        {/* Info Alert */}
        <Alert className="mb-6">
          <Key className="w-4 h-4" />
          <AlertDescription>
            <span className="font-semibold">Secure Configuration</span>
            <p className="text-sm mt-1">
              OAuth credentials are sensitive. Store them securely and never share them publicly.
              In production, these should be managed server-side with environment variables.
            </p>
          </AlertDescription>
        </Alert>

        {/* Tabs for Each Provider */}
        <Tabs defaultValue="google" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="google" className="gap-2">
              <img src="https://www.google.com/favicon.ico" alt="Google" className="w-4 h-4" />
              Google
            </TabsTrigger>
            <TabsTrigger value="facebook" className="gap-2">
              <img src="https://www.facebook.com/favicon.ico" alt="Facebook" className="w-4 h-4" />
              Facebook
            </TabsTrigger>
            <TabsTrigger value="microsoft" className="gap-2">
              <img src="https://www.microsoft.com/favicon.ico" alt="Microsoft" className="w-4 h-4" />
              Microsoft
            </TabsTrigger>
          </TabsList>

          {/* Google OAuth */}
          <TabsContent value="google">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                      Google OAuth 2.0
                    </CardTitle>
                    <Badge variant={googleConfig.enabled ? "default" : "secondary"}>
                      {googleConfig.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <Label className="font-semibold">Enable Google Login</Label>
                      <p className="text-xs text-gray-600 mt-1">Allow users to sign in with Google</p>
                    </div>
                    <Switch
                      checked={googleConfig.enabled}
                      onCheckedChange={(checked) => 
                        setGoogleConfig({ ...googleConfig, enabled: checked })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Client ID</Label>
                    <Input
                      placeholder="xxxxx.apps.googleusercontent.com"
                      value={googleConfig.clientId}
                      onChange={(e) => 
                        setGoogleConfig({ ...googleConfig, clientId: e.target.value })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Client Secret</Label>
                    <div className="relative">
                      <Input
                        type={showSecrets.google ? "text" : "password"}
                        placeholder="GOCSPX-xxxxxxxxxxxxx"
                        value={googleConfig.clientSecret}
                        onChange={(e) => 
                          setGoogleConfig({ ...googleConfig, clientSecret: e.target.value })
                        }
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSecret('google')}
                        className="absolute right-0 top-0 h-full px-3"
                      >
                        {showSecrets.google ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Redirect URI</Label>
                    <div className="flex gap-2">
                      <Input
                        value={googleConfig.redirectUri}
                        readOnly
                        className="bg-gray-50"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(googleConfig.redirectUri)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-600">
                      Add this URL to your Google Cloud Console authorized redirect URIs
                    </p>
                  </div>

                  <Button
                    onClick={handleSaveGoogle}
                    disabled={!googleConfig.clientId || !googleConfig.clientSecret || saveConfigMutation.isPending}
                    className="w-full gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Google Configuration
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Setup Instructions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        1
                      </div>
                      <div>
                        <p className="font-semibold">Create a Google Cloud Project</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Google Cloud Console and create a new project
                        </p>
                        <a 
                          href="https://console.cloud.google.com" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 text-xs flex items-center gap-1 mt-2 hover:underline"
                        >
                          Open Google Cloud Console
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        2
                      </div>
                      <div>
                        <p className="font-semibold">Enable Google+ API</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Navigate to "APIs & Services" and enable the Google+ API
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        3
                      </div>
                      <div>
                        <p className="font-semibold">Create OAuth 2.0 Credentials</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Credentials → Create Credentials → OAuth 2.0 Client ID
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        4
                      </div>
                      <div>
                        <p className="font-semibold">Configure OAuth Consent Screen</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Set application name, logo, and authorized domains
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        5
                      </div>
                      <div>
                        <p className="font-semibold">Add Redirect URI</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Copy the redirect URI from the left and add it to authorized URIs
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        6
                      </div>
                      <div>
                        <p className="font-semibold">Copy Credentials</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Copy the Client ID and Client Secret and paste them in the form
                        </p>
                      </div>
                    </div>
                  </div>

                  <Alert className="bg-blue-50 border-blue-200">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-sm">
                      <span className="font-semibold text-blue-900">Scopes Required</span>
                      <ul className="text-xs text-blue-700 mt-2 space-y-1">
                        <li>• email</li>
                        <li>• profile</li>
                        <li>• openid</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Facebook OAuth */}
          <TabsContent value="facebook">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <img src="https://www.facebook.com/favicon.ico" alt="Facebook" className="w-5 h-5" />
                      Facebook Login
                    </CardTitle>
                    <Badge variant={facebookConfig.enabled ? "default" : "secondary"}>
                      {facebookConfig.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <Label className="font-semibold">Enable Facebook Login</Label>
                      <p className="text-xs text-gray-600 mt-1">Allow users to sign in with Facebook</p>
                    </div>
                    <Switch
                      checked={facebookConfig.enabled}
                      onCheckedChange={(checked) => 
                        setFacebookConfig({ ...facebookConfig, enabled: checked })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>App ID</Label>
                    <Input
                      placeholder="1234567890123456"
                      value={facebookConfig.appId}
                      onChange={(e) => 
                        setFacebookConfig({ ...facebookConfig, appId: e.target.value })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>App Secret</Label>
                    <div className="relative">
                      <Input
                        type={showSecrets.facebook ? "text" : "password"}
                        placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                        value={facebookConfig.appSecret}
                        onChange={(e) => 
                          setFacebookConfig({ ...facebookConfig, appSecret: e.target.value })
                        }
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSecret('facebook')}
                        className="absolute right-0 top-0 h-full px-3"
                      >
                        {showSecrets.facebook ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Redirect URI</Label>
                    <div className="flex gap-2">
                      <Input
                        value={facebookConfig.redirectUri}
                        readOnly
                        className="bg-gray-50"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(facebookConfig.redirectUri)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-600">
                      Add this URL to your Facebook App's Valid OAuth Redirect URIs
                    </p>
                  </div>

                  <Button
                    onClick={handleSaveFacebook}
                    disabled={!facebookConfig.appId || !facebookConfig.appSecret || saveConfigMutation.isPending}
                    className="w-full gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Facebook Configuration
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Setup Instructions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        1
                      </div>
                      <div>
                        <p className="font-semibold">Create Facebook App</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Facebook Developers and create a new app
                        </p>
                        <a 
                          href="https://developers.facebook.com" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 text-xs flex items-center gap-1 mt-2 hover:underline"
                        >
                          Open Facebook Developers
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        2
                      </div>
                      <div>
                        <p className="font-semibold">Add Facebook Login Product</p>
                        <p className="text-gray-600 text-xs mt-1">
                          In your app dashboard, add the "Facebook Login" product
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        3
                      </div>
                      <div>
                        <p className="font-semibold">Configure OAuth Settings</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Facebook Login → Settings and configure OAuth settings
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        4
                      </div>
                      <div>
                        <p className="font-semibold">Add Valid OAuth Redirect URIs</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Copy the redirect URI and add it to Valid OAuth Redirect URIs
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        5
                      </div>
                      <div>
                        <p className="font-semibold">Get App Credentials</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Settings → Basic to find your App ID and App Secret
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        6
                      </div>
                      <div>
                        <p className="font-semibold">Make App Public</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Switch your app from Development to Live mode in App Review
                        </p>
                      </div>
                    </div>
                  </div>

                  <Alert className="bg-blue-50 border-blue-200">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-sm">
                      <span className="font-semibold text-blue-900">Permissions Required</span>
                      <ul className="text-xs text-blue-700 mt-2 space-y-1">
                        <li>• email</li>
                        <li>• public_profile</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Microsoft OAuth */}
          <TabsContent value="microsoft">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <img src="https://www.microsoft.com/favicon.ico" alt="Microsoft" className="w-5 h-5" />
                      Microsoft Identity Platform
                    </CardTitle>
                    <Badge variant={microsoftConfig.enabled ? "default" : "secondary"}>
                      {microsoftConfig.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <Label className="font-semibold">Enable Microsoft Login</Label>
                      <p className="text-xs text-gray-600 mt-1">Allow users to sign in with Microsoft</p>
                    </div>
                    <Switch
                      checked={microsoftConfig.enabled}
                      onCheckedChange={(checked) => 
                        setMicrosoftConfig({ ...microsoftConfig, enabled: checked })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Application (client) ID</Label>
                    <Input
                      placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                      value={microsoftConfig.clientId}
                      onChange={(e) => 
                        setMicrosoftConfig({ ...microsoftConfig, clientId: e.target.value })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Client Secret Value</Label>
                    <div className="relative">
                      <Input
                        type={showSecrets.microsoft ? "text" : "password"}
                        placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxx"
                        value={microsoftConfig.clientSecret}
                        onChange={(e) => 
                          setMicrosoftConfig({ ...microsoftConfig, clientSecret: e.target.value })
                        }
                        className="pr-10"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSecret('microsoft')}
                        className="absolute right-0 top-0 h-full px-3"
                      >
                        {showSecrets.microsoft ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Directory (tenant) ID</Label>
                    <Input
                      placeholder="common (or your tenant ID)"
                      value={microsoftConfig.tenantId}
                      onChange={(e) => 
                        setMicrosoftConfig({ ...microsoftConfig, tenantId: e.target.value })
                      }
                    />
                    <p className="text-xs text-gray-600">
                      Use "common" for multi-tenant apps or specify your tenant ID
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label>Redirect URI</Label>
                    <div className="flex gap-2">
                      <Input
                        value={microsoftConfig.redirectUri}
                        readOnly
                        className="bg-gray-50"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(microsoftConfig.redirectUri)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-600">
                      Add this URL to your Azure AD app's redirect URIs
                    </p>
                  </div>

                  <Button
                    onClick={handleSaveMicrosoft}
                    disabled={!microsoftConfig.clientId || !microsoftConfig.clientSecret || saveConfigMutation.isPending}
                    className="w-full gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Microsoft Configuration
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Setup Instructions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        1
                      </div>
                      <div>
                        <p className="font-semibold">Register Application in Azure</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Go to Azure Portal and register a new application
                        </p>
                        <a 
                          href="https://portal.azure.com" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 text-xs flex items-center gap-1 mt-2 hover:underline"
                        >
                          Open Azure Portal
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        2
                      </div>
                      <div>
                        <p className="font-semibold">Navigate to App Registrations</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Azure Active Directory → App registrations → New registration
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        3
                      </div>
                      <div>
                        <p className="font-semibold">Configure Platform</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Authentication → Add a platform → Web
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        4
                      </div>
                      <div>
                        <p className="font-semibold">Add Redirect URI</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Copy the redirect URI and add it to your app's web platform
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        5
                      </div>
                      <div>
                        <p className="font-semibold">Create Client Secret</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Certificates & secrets → New client secret → Copy the value
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-semibold text-xs">
                        6
                      </div>
                      <div>
                        <p className="font-semibold">Copy Application IDs</p>
                        <p className="text-gray-600 text-xs mt-1">
                          Copy Application (client) ID and Directory (tenant) ID from Overview
                        </p>
                      </div>
                    </div>
                  </div>

                  <Alert className="bg-blue-50 border-blue-200">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-sm">
                      <span className="font-semibold text-blue-900">API Permissions Required</span>
                      <ul className="text-xs text-blue-700 mt-2 space-y-1">
                        <li>• User.Read</li>
                        <li>• email</li>
                        <li>• openid</li>
                        <li>• profile</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Test OAuth Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Test OAuth Integration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Button
                disabled={!googleConfig.enabled || !googleConfig.clientId}
                className="gap-2"
              >
                <img src="https://www.google.com/favicon.ico" alt="Google" className="w-4 h-4" />
                Test Google Login
              </Button>
              <Button
                disabled={!facebookConfig.enabled || !facebookConfig.appId}
                className="gap-2"
              >
                <img src="https://www.facebook.com/favicon.ico" alt="Facebook" className="w-4 h-4" />
                Test Facebook Login
              </Button>
              <Button
                disabled={!microsoftConfig.enabled || !microsoftConfig.clientId}
                className="gap-2"
              >
                <img src="https://www.microsoft.com/favicon.ico" alt="Microsoft" className="w-4 h-4" />
                Test Microsoft Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}