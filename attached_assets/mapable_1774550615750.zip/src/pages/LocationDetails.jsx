
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  MapPin,
  Phone,
  Globe,
  Star,
  ThumbsUp,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Accessibility, // Changed from Wheelchair to Accessibility
  User
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";

import AccessibilityScore from "../components/shared/AccessibilityScore";
import AccessibilityBreakdown from "../components/location/AccessibilityBreakdown";
import ReviewCard from "../components/location/ReviewCard";

export default function LocationDetailsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const locationId = urlParams.get("id");

  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewData, setReviewData] = useState({
    rating: 5,
    title: "",
    content: "",
    visit_date: "",
    mobility_aid: "manual_wheelchair",
    would_recommend: true,
  });

  const { data: location, isLoading } = useQuery({
    queryKey: ["location", locationId],
    queryFn: async () => {
      const locations = await base44.entities.Location.list();
      return locations.find((l) => l.id === locationId);
    },
    enabled: !!locationId,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews", locationId],
    queryFn: async () => {
      const allReviews = await base44.entities.Review.list("-created_date");
      return allReviews.filter((r) => r.location_id === locationId);
    },
    enabled: !!locationId,
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.Review.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reviews", locationId] });
      setShowReviewForm(false);
      setReviewData({
        rating: 5,
        title: "",
        content: "",
        visit_date: "",
        mobility_aid: "manual_wheelchair",
        would_recommend: true,
      });
    },
  });

  const handleSubmitReview = () => {
    createReviewMutation.mutate({
      ...reviewData,
      location_id: locationId,
    });
  };

  const averageRating =
    reviews.length > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
      : 0;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-secondary"></div>
      </div>
    );
  }

  if (!location) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen px-4">
        <AlertCircle className="w-16 h-16 text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Location Not Found</h2>
        <p className="text-gray-600 mb-6">The location you're looking for doesn't exist.</p>
        <Button onClick={() => navigate(createPageUrl("Map"))}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Map
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Map"))}
          className="mb-6 hover:bg-gray-100"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Map
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header Card */}
            <Card className="overflow-hidden hover-lift">
              {location.photo_url && (
                <div className="h-64 bg-gray-200">
                  <img
                    src={location.photo_url}
                    alt={location.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <CardContent className="p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <h1 className="text-3xl font-bold text-primary">{location.name}</h1>
                      {location.verified && (
                        <Badge className="bg-secondary text-white">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Verified
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">
                        {location.address}, {location.suburb} {location.state} {location.postcode}
                      </span>
                    </div>
                    <Badge variant="outline" className="text-sm">
                      {location.category?.replace(/_/g, " ")}
                    </Badge>
                  </div>
                  <AccessibilityScore score={location.overall_score || 0} size="lg" />
                </div>

                {location.description && (
                  <p className="text-gray-700 leading-relaxed mb-4">{location.description}</p>
                )}

                {/* Contact Info */}
                <div className="flex flex-wrap gap-3">
                  {location.phone && (
                    <a href={`tel:${location.phone}`}>
                      <Button variant="outline" size="sm" className="gap-2">
                        <Phone className="w-4 h-4" />
                        {location.phone}
                      </Button>
                    </a>
                  )}
                  {location.website && (
                    <a href={location.website} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm" className="gap-2">
                        <Globe className="w-4 h-4" />
                        Visit Website
                      </Button>
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Accessibility Breakdown */}
            <AccessibilityBreakdown location={location} />

            {/* Accessibility Notes */}
            {location.accessibility_notes && (
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Accessibility className="w-5 h-5 text-secondary" /> {/* Changed to Accessibility */}
                    Detailed Accessibility Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {location.accessibility_notes}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Reviews Section */}
            <Card className="hover-lift">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-500" />
                    Community Reviews ({reviews.length})
                  </CardTitle>
                  {!showReviewForm && (
                    <Button
                      onClick={() => setShowReviewForm(true)}
                      className="bg-secondary hover:bg-secondary/90"
                      size="sm"
                    >
                      Write Review
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {showReviewForm && (
                  <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
                    <h3 className="font-semibold text-lg">Share Your Experience</h3>
                    
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Overall Rating</Label>
                        <Select
                          value={reviewData.rating.toString()}
                          onValueChange={(v) => setReviewData({ ...reviewData, rating: parseInt(v) })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">5 Stars - Excellent</SelectItem>
                            <SelectItem value="4">4 Stars - Good</SelectItem>
                            <SelectItem value="3">3 Stars - Average</SelectItem>
                            <SelectItem value="2">2 Stars - Poor</SelectItem>
                            <SelectItem value="1">1 Star - Very Poor</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Visit Date</Label>
                        <Input
                          type="date"
                          value={reviewData.visit_date}
                          onChange={(e) =>
                            setReviewData({ ...reviewData, visit_date: e.target.value })
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Mobility Aid Used</Label>
                      <Select
                        value={reviewData.mobility_aid}
                        onValueChange={(v) => setReviewData({ ...reviewData, mobility_aid: v })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="manual_wheelchair">Manual Wheelchair</SelectItem>
                          <SelectItem value="power_wheelchair">Power Wheelchair</SelectItem>
                          <SelectItem value="mobility_scooter">Mobility Scooter</SelectItem>
                          <SelectItem value="walker">Walker</SelectItem>
                          <SelectItem value="crutches">Crutches</SelectItem>
                          <SelectItem value="cane">Cane</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                          <SelectItem value="none">None</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Review Title</Label>
                      <Input
                        placeholder="Brief summary of your experience"
                        value={reviewData.title}
                        onChange={(e) => setReviewData({ ...reviewData, title: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Your Review</Label>
                      <Textarea
                        placeholder="Share your detailed experience about accessibility..."
                        value={reviewData.content}
                        onChange={(e) => setReviewData({ ...reviewData, content: e.target.value })}
                        className="h-32"
                      />
                    </div>

                    <div className="flex gap-3">
                      <Button
                        onClick={handleSubmitReview}
                        className="bg-secondary hover:bg-secondary/90"
                        disabled={!reviewData.content || createReviewMutation.isPending}
                      >
                        Submit Review
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowReviewForm(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}

                {reviews.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    No reviews yet. Be the first to share your experience!
                  </p>
                ) : (
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <ReviewCard key={review.id} review={review} />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Rating Summary */}
            <Card className="hover-lift">
              <CardHeader>
                <CardTitle className="text-lg">Rating Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-4">
                  <div className="text-5xl font-bold text-primary mb-2">
                    {averageRating.toFixed(1)}
                  </div>
                  <div className="flex justify-center gap-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${
                          star <= averageRating
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">{reviews.length} reviews</p>
                </div>
                <Separator className="my-4" />
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map((rating) => {
                    const count = reviews.filter((r) => r.rating === rating).length;
                    const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                    return (
                      <div key={rating} className="flex items-center gap-2">
                        <span className="text-sm font-medium w-8">{rating}★</span>
                        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-yellow-400"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-sm text-gray-600 w-8">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Quick Facts */}
            <Card className="hover-lift">
              <CardHeader>
                <CardTitle className="text-lg">Quick Facts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-secondary" />
                  <span className="text-gray-600">{location.state}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-secondary" />
                  <span className="text-gray-600">
                    Added {format(new Date(location.created_date), "MMM d, yyyy")}
                  </span>
                </div>
                {reviews.length > 0 && (
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-secondary" />
                    <span className="text-gray-600">{reviews.length} community reviews</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
