
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Car,
  Users,
  Plus,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Calendar,
  BarChart3,
  Settings,
  Download
} from "lucide-react";
import { format, isBefore, differenceInDays } from "date-fns";

import VehicleManagementTab from "../components/transport/VehicleManagementTab";
import DriverManagementTab from "../components/transport/DriverManagementTab";
import AssignmentTab from "../components/transport/AssignmentTab";
import MaintenanceTab from "../components/transport/MaintenanceTab";
import ReportsTab from "../components/transport/ReportsTab";
import RouteOptimizationTab from "../components/transport/RouteOptimizationTab";
import SchedulingTab from "../components/transport/SchedulingTab";

export default function ProviderTransportDashboardPage() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: vehicles = [], isLoading: vehiclesLoading } = useQuery({
    queryKey: ["myVehicles"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.Vehicle.filter({ created_by: user.email }, "-created_date");
    },
  });

  const { data: drivers = [], isLoading: driversLoading } = useQuery({
    queryKey: ["myDrivers"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.Driver.filter({ created_by: user.email }, "-created_date");
    },
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["providerBookings"],
    queryFn: async () => {
      const allBookings = await base44.entities.TransportBooking.list("-pickup_datetime", 100);
      return allBookings.filter((b) => 
        vehicles.some(v => v.id === b.vehicle_id)
      );
    },
    enabled: vehicles.length > 0,
  });

  // Calculate metrics
  const activeVehicles = vehicles.filter(v => v.status === "available").length;
  const availableDrivers = drivers.filter(d => d.status === "available" && d.active).length;
  const activeBookings = bookings.filter(b => 
    ["confirmed", "driver_assigned", "en_route_to_pickup", "passenger_on_board", "in_transit"].includes(b.status)
  ).length;
  
  const completedTrips = bookings.filter(b => b.status === "completed").length;
  const totalRevenue = bookings
    .filter(b => b.payment_status === "paid")
    .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0);

  // Maintenance alerts
  const maintenanceAlerts = vehicles.filter(v => {
    const insuranceExpiring = v.insurance_expiry && 
      differenceInDays(new Date(v.insurance_expiry), new Date()) <= 30;
    const registrationExpiring = v.registration_expiry && 
      differenceInDays(new Date(v.registration_expiry), new Date()) <= 30;
    const maintenanceDue = v.last_maintenance && 
      differenceInDays(new Date(), new Date(v.last_maintenance)) >= 90;
    return insuranceExpiring || registrationExpiring || maintenanceDue;
  });

  const isLoading = vehiclesLoading || driversLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">
            Transport Fleet Management
          </h1>
          <p className="text-gray-600">
            Manage your vehicles, drivers, and bookings
          </p>
        </div>

        {/* Alerts */}
        {maintenanceAlerts.length > 0 && (
          <Alert className="mb-6 border-yellow-200 bg-yellow-50">
            <AlertCircle className="w-4 h-4 text-yellow-600" />
            <AlertDescription>
              <span className="font-semibold text-yellow-900">
                {maintenanceAlerts.length} vehicle(s) require attention
              </span>
              <p className="text-sm text-yellow-800 mt-1">
                Check Maintenance tab for expiring insurance, registration, or overdue services.
              </p>
            </AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
            <TabsTrigger value="drivers">Drivers</TabsTrigger>
            <TabsTrigger value="assignments">Assignments</TabsTrigger>
            <TabsTrigger value="scheduling">Scheduling</TabsTrigger>
            <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
            <TabsTrigger value="routes">Routes</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Active Vehicles</p>
                    <Car className="w-5 h-5 text-blue-600" />
                  </div>
                  <p className="text-3xl font-bold text-primary">{activeVehicles}</p>
                  <p className="text-xs text-gray-500 mt-1">of {vehicles.length} total</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Available Drivers</p>
                    <Users className="w-5 h-5 text-green-600" />
                  </div>
                  <p className="text-3xl font-bold text-primary">{availableDrivers}</p>
                  <p className="text-xs text-gray-500 mt-1">of {drivers.length} total</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Active Bookings</p>
                    <TrendingUp className="w-5 h-5 text-yellow-600" />
                  </div>
                  <p className="text-3xl font-bold text-primary">{activeBookings}</p>
                  <p className="text-xs text-gray-500 mt-1">in progress</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-600">Total Revenue</p>
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                  </div>
                  <p className="text-3xl font-bold text-primary">${totalRevenue.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">{completedTrips} completed trips</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  <Button onClick={() => setActiveTab("vehicles")} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Vehicle
                  </Button>
                  <Button onClick={() => setActiveTab("drivers")} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Driver
                  </Button>
                  <Button onClick={() => setActiveTab("assignments")} variant="outline" className="gap-2">
                    <Settings className="w-4 h-4" />
                    Manage Assignments
                  </Button>
                  <Button onClick={() => setActiveTab("reports")} variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export Reports
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Bookings</CardTitle>
                </CardHeader>
                <CardContent>
                  {bookings.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No bookings yet</p>
                  ) : (
                    <div className="space-y-3">
                      {bookings.slice(0, 5).map((booking) => {
                        const vehicle = vehicles.find(v => v.id === booking.vehicle_id);
                        return (
                          <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex-1">
                              <p className="font-medium text-sm">{vehicle?.vehicle_name || "Unknown Vehicle"}</p>
                              <p className="text-xs text-gray-600">
                                {booking.pickup_datetime 
                                  ? format(new Date(booking.pickup_datetime), "MMM d, h:mm a")
                                  : "Not scheduled"}
                              </p>
                            </div>
                            <Badge variant={
                              booking.status === "completed" ? "default" : 
                              booking.status === "cancelled" ? "destructive" : 
                              "secondary"
                            }>
                              {booking.status?.replace(/_/g, " ")}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Driver Status</CardTitle>
                </CardHeader>
                <CardContent>
                  {drivers.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No drivers registered</p>
                  ) : (
                    <div className="space-y-3">
                      {drivers.slice(0, 5).map((driver) => (
                        <div key={driver.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <Users className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium text-sm">{driver.full_name}</p>
                              <p className="text-xs text-gray-600">{driver.total_trips} trips</p>
                            </div>
                          </div>
                          <Badge variant={
                            driver.status === "available" ? "default" : 
                            driver.status === "on_trip" ? "secondary" : 
                            "outline"
                          }>
                            {driver.status?.replace(/_/g, " ")}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Other Tabs */}
          <TabsContent value="vehicles">
            <VehicleManagementTab vehicles={vehicles} />
          </TabsContent>

          <TabsContent value="drivers">
            <DriverManagementTab drivers={drivers} />
          </TabsContent>

          <TabsContent value="assignments">
            <AssignmentTab vehicles={vehicles} drivers={drivers} />
          </TabsContent>

          {/* Scheduling Tab */}
          <TabsContent value="scheduling">
            <SchedulingTab />
          </TabsContent>

          <TabsContent value="maintenance">
            <MaintenanceTab vehicles={vehicles} />
          </TabsContent>

          <TabsContent value="routes">
            <RouteOptimizationTab bookings={bookings} vehicles={vehicles} />
          </TabsContent>

          <TabsContent value="reports">
            <ReportsTab vehicles={vehicles} drivers={drivers} bookings={bookings} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
