
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Shield,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  FileText,
  Search,
  Eye,
  User,
  Calendar,
  Download
} from "lucide-react";
import { toast } from "sonner";
import { format, differenceInDays } from "date-fns";
import { hasPermission, PERMISSIONS } from "@/utils/permissions";
import AuditLogService from "../components/audit/AuditLogService";

export default function AdminCredentialReviewPage() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCredential, setSelectedCredential] = useState(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [reviewNotes, setReviewNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: allCredentials = [], isLoading } = useQuery({
    queryKey: ["allCredentials"],
    queryFn: () => base44.entities.ProviderCredential.list("-created_date"),
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
  });

  const approveCredentialMutation = useMutation({
    mutationFn: ({ id, notes }) =>
      base44.entities.ProviderCredential.update(id, {
        verification_status: "verified",
        reviewed_by: currentUser?.email,
        reviewed_date: new Date().toISOString(),
        admin_notes: notes,
      }),
    onSuccess: async (updatedCredential, { notes }) => {
      // Log the audit event
      await AuditLogService.logCredentialApproval(
        updatedCredential,
        updatedCredential.provider_email
      );
      
      queryClient.invalidateQueries({ queryKey: ["allCredentials"] });
      queryClient.invalidateQueries({ queryKey: ["auditLogs"] });
      setShowReviewDialog(false);
      setSelectedCredential(null);
      setReviewNotes("");
      toast.success("Credential approved!");
    },
  });

  const rejectCredentialMutation = useMutation({
    mutationFn: ({ id, reason, notes }) =>
      base44.entities.ProviderCredential.update(id, {
        verification_status: "rejected",
        reviewed_by: currentUser?.email,
        reviewed_date: new Date().toISOString(),
        rejection_reason: reason,
        admin_notes: notes,
      }),
    onSuccess: async (updatedCredential, { reason }) => {
      // Log the audit event
      await AuditLogService.logCredentialRejection(
        updatedCredential,
        updatedCredential.provider_email,
        reason
      );
      
      queryClient.invalidateQueries({ queryKey: ["allCredentials"] });
      queryClient.invalidateQueries({ queryKey: ["auditLogs"] });
      setShowReviewDialog(false);
      setSelectedCredential(null);
      setReviewNotes("");
      setRejectionReason("");
      toast.success("Credential rejected");
    },
  });

  const markUnderReviewMutation = useMutation({
    mutationFn: (id) =>
      base44.entities.ProviderCredential.update(id, {
        verification_status: "under_review",
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allCredentials"] });
      toast.success("Marked as under review");
    },
  });

  if (!hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES)) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Access Denied</span>
              <p className="text-sm text-red-700 mt-1">
                Only administrators can review provider credentials.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const getUserByEmail = (email) => allUsers.find(u => u.email === email);

  const filteredCredentials = allCredentials.filter((credential) => {
    const user = getUserByEmail(credential.provider_email);
    const matchesSearch = 
      credential.credential_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      credential.provider_email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user?.full_name?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const pendingReview = filteredCredentials.filter(c => 
    c.verification_status === "submitted" || c.verification_status === "under_review"
  );
  const verified = filteredCredentials.filter(c => c.verification_status === "verified");
  const rejected = filteredCredentials.filter(c => c.verification_status === "rejected");
  const expiringSoon = verified.filter(c => {
    if (!c.expiry_date) return false;
    const days = differenceInDays(new Date(c.expiry_date), new Date());
    return days <= 30 && days > 0;
  });

  const getStatusColor = (status) => {
    const colors = {
      submitted: "bg-blue-100 text-blue-700",
      under_review: "bg-yellow-100 text-yellow-700",
      verified: "bg-green-100 text-green-700",
      rejected: "bg-red-100 text-red-700",
      expired: "bg-orange-100 text-orange-700"
    };
    return colors[status] || "bg-gray-100 text-gray-700";
  };

  const handleApprove = () => {
    if (!selectedCredential) return;
    approveCredentialMutation.mutate({
      id: selectedCredential.id,
      notes: reviewNotes,
    });
  };

  const handleReject = () => {
    if (!selectedCredential || !rejectionReason) {
      toast.error("Please provide a rejection reason");
      return;
    }
    rejectCredentialMutation.mutate({
      id: selectedCredential.id,
      reason: rejectionReason,
      notes: reviewNotes,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-purple-600" />
            <h1 className="text-4xl font-bold text-primary">Credential Review Dashboard</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Review and approve provider credentials and certifications
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Pending Review</p>
                  <p className="text-3xl font-bold text-yellow-600">{pendingReview.length}</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Verified</p>
                  <p className="text-3xl font-bold text-green-600">{verified.length}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Expiring Soon</p>
                  <p className="text-3xl font-bold text-orange-600">{expiringSoon.length}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Rejected</p>
                  <p className="text-3xl font-bold text-red-600">{rejected.length}</p>
                </div>
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by provider name, email, or credential..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">Pending ({pendingReview.length})</TabsTrigger>
            <TabsTrigger value="verified">Verified ({verified.length})</TabsTrigger>
            <TabsTrigger value="expiring">Expiring ({expiringSoon.length})</TabsTrigger>
            <TabsTrigger value="rejected">Rejected ({rejected.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            {pendingReview.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">All caught up!</h3>
                  <p className="text-gray-600">No credentials pending review</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {pendingReview.map((credential) => {
                  const user = getUserByEmail(credential.provider_email);
                  return (
                    <Card key={credential.id} className="hover-lift border-2 border-yellow-200">
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                              <User className="w-6 h-6 text-blue-600" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg">{credential.credential_name}</h3>
                              <p className="text-sm text-gray-600 capitalize mb-2">
                                {credential.credential_type.replace(/_/g, " ")}
                              </p>
                              <div className="flex flex-wrap items-center gap-3 text-sm">
                                <span className="text-gray-600">
                                  Provider: <span className="font-medium">{user?.full_name || credential.provider_email}</span>
                                </span>
                                {credential.issuing_organization && (
                                  <span className="text-gray-600">
                                    Issued by: <span className="font-medium">{credential.issuing_organization}</span>
                                  </span>
                                )}
                                {credential.submitted_date && (
                                  <span className="text-gray-600">
                                    Submitted: {format(new Date(credential.submitted_date), "MMM d, yyyy")}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <Badge className={getStatusColor(credential.verification_status)}>
                            {credential.verification_status.replace(/_/g, " ")}
                          </Badge>
                        </div>

                        <div className="flex gap-2">
                          {credential.document_url && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(credential.document_url, "_blank")}
                              className="gap-2"
                            >
                              <Eye className="w-4 h-4" />
                              View Document
                            </Button>
                          )}
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedCredential(credential);
                              setShowReviewDialog(true);
                            }}
                            className="bg-purple-600 hover:bg-purple-700 gap-2"
                          >
                            <FileText className="w-4 h-4" />
                            Review
                          </Button>
                          {credential.verification_status === "submitted" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => markUnderReviewMutation.mutate(credential.id)}
                              className="gap-2"
                            >
                              <Clock className="w-4 h-4" />
                              Mark Under Review
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="verified">
            <div className="space-y-4">
              {verified.map((credential) => {
                const user = getUserByEmail(credential.provider_email);
                const daysUntilExpiry = credential.expiry_date 
                  ? differenceInDays(new Date(credential.expiry_date), new Date())
                  : null;
                return (
                  <Card key={credential.id} className="border-2 border-green-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-6 h-6 text-green-600" />
                          <div>
                            <h3 className="font-semibold">{credential.credential_name}</h3>
                            <p className="text-sm text-gray-600">{user?.full_name || credential.provider_email}</p>
                            {credential.expiry_date && (
                              <p className="text-sm text-gray-600">
                                Expires: {format(new Date(credential.expiry_date), "MMM d, yyyy")}
                                {daysUntilExpiry !== null && daysUntilExpiry <= 30 && (
                                  <span className="text-yellow-600 font-semibold ml-2">
                                    ({daysUntilExpiry} days)
                                  </span>
                                )}
                              </p>
                            )}
                          </div>
                        </div>
                        {credential.document_url && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(credential.document_url, "_blank")}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="expiring">
            <div className="space-y-4">
              {expiringSoon.map((credential) => {
                const user = getUserByEmail(credential.provider_email);
                const days = differenceInDays(new Date(credential.expiry_date), new Date());
                return (
                  <Card key={credential.id} className="border-2 border-orange-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="w-6 h-6 text-orange-600" />
                        <div className="flex-1">
                          <h3 className="font-semibold">{credential.credential_name}</h3>
                          <p className="text-sm text-gray-600">{user?.full_name || credential.provider_email}</p>
                          <p className="text-sm font-semibold text-orange-600">
                            Expires in {days} days - {format(new Date(credential.expiry_date), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="rejected">
            <div className="space-y-4">
              {rejected.map((credential) => {
                const user = getUserByEmail(credential.provider_email);
                return (
                  <Card key={credential.id} className="border-2 border-red-200">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-3">
                        <XCircle className="w-6 h-6 text-red-600" />
                        <div className="flex-1">
                          <h3 className="font-semibold">{credential.credential_name}</h3>
                          <p className="text-sm text-gray-600 mb-2">{user?.full_name || credential.provider_email}</p>
                          {credential.rejection_reason && (
                            <Alert className="bg-red-50 border-red-200">
                              <AlertDescription className="text-sm text-red-800">
                                <span className="font-semibold">Reason: </span>
                                {credential.rejection_reason}
                              </AlertDescription>
                            </Alert>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Credential</DialogTitle>
          </DialogHeader>
          
          {selectedCredential && (
            <div className="space-y-6">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-lg mb-2">{selectedCredential.credential_name}</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-600">Provider:</span>
                    <p className="font-medium">
                      {getUserByEmail(selectedCredential.provider_email)?.full_name || selectedCredential.provider_email}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600">Type:</span>
                    <p className="font-medium capitalize">{selectedCredential.credential_type.replace(/_/g, " ")}</p>
                  </div>
                  {selectedCredential.issuing_organization && (
                    <div>
                      <span className="text-gray-600">Issuing Organization:</span>
                      <p className="font-medium">{selectedCredential.issuing_organization}</p>
                    </div>
                  )}
                  {selectedCredential.credential_number && (
                    <div>
                      <span className="text-gray-600">Number:</span>
                      <p className="font-mono font-medium">{selectedCredential.credential_number}</p>
                    </div>
                  )}
                  {selectedCredential.issue_date && (
                    <div>
                      <span className="text-gray-600">Issued:</span>
                      <p className="font-medium">{format(new Date(selectedCredential.issue_date), "MMM d, yyyy")}</p>
                    </div>
                  )}
                  {selectedCredential.expiry_date && (
                    <div>
                      <span className="text-gray-600">Expires:</span>
                      <p className="font-medium">{format(new Date(selectedCredential.expiry_date), "MMM d, yyyy")}</p>
                    </div>
                  )}
                </div>
              </div>

              {selectedCredential.document_url && (
                <div>
                  <Label className="mb-2 block">Document</Label>
                  <Button
                    variant="outline"
                    onClick={() => window.open(selectedCredential.document_url, "_blank")}
                    className="w-full gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    View Document in New Tab
                  </Button>
                </div>
              )}

              <div className="space-y-2">
                <Label>Admin Notes (Internal)</Label>
                <Textarea
                  placeholder="Add internal notes about this credential..."
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Rejection Reason (Visible to Provider)</Label>
                <Textarea
                  placeholder="Explain why this credential is being rejected..."
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowReviewDialog(false);
                    setSelectedCredential(null);
                    setReviewNotes("");
                    setRejectionReason("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleReject}
                  disabled={rejectCredentialMutation.isPending || !rejectionReason}
                  className="gap-2"
                >
                  <XCircle className="w-4 h-4" />
                  Reject
                </Button>
                <Button
                  onClick={handleApprove}
                  disabled={approveCredentialMutation.isPending}
                  className="bg-green-600 hover:bg-green-700 gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Approve
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
