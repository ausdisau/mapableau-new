import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Loader2 } from "lucide-react";

// Import role-specific dashboards
import ParticipantDashboard from "../components/dashboards/ParticipantDashboard";
import ProviderDashboard from "../components/dashboards/ProviderDashboard";
import NomineeDashboard from "../components/dashboards/NomineeDashboard";
import IntermediaryDashboard from "../components/dashboards/IntermediaryDashboard";

export default function DashboardPage() {
  const navigate = useNavigate();

  const { data: currentUser, isLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // Route based on user type/role
  const getUserDashboard = () => {
    if (!currentUser) return null;

    // Check role first
    const role = currentUser.role;
    const userType = currentUser.user_type;

    // Admin gets comprehensive admin dashboard
    if (role === 'administrator') {
      return null; // Will redirect
    }

    // Provider roles
    if (role === 'transport_provider' || userType === 'transport_provider') {
      return <ProviderDashboard user={currentUser} providerType="transport" />;
    }

    if (role === 'service_provider' || userType === 'service_provider') {
      return <ProviderDashboard user={currentUser} providerType="service" />;
    }

    if (role === 'driver') {
      return <ProviderDashboard user={currentUser} providerType="driver" />;
    }

    // Intermediary roles (Plan Managers, Support Coordinators)
    if (role === 'plan_manager' || role === 'support_coordinator') {
      return <IntermediaryDashboard user={currentUser} role={role} />;
    }

    // Nominee (guardian/family member)
    if (userType === 'nominee' || userType === 'guardian') {
      return <NomineeDashboard user={currentUser} />;
    }

    // Default: Participant dashboard
    return <ParticipantDashboard user={currentUser} />;
  };

  useEffect(() => {
    // Redirect administrators to admin dashboard
    if (currentUser?.role === 'administrator') {
      navigate(createPageUrl('ComprehensiveAdminDashboard'));
    }
  }, [currentUser, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-secondary animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (currentUser?.role === 'administrator') {
    return null; // Will redirect
  }

  return getUserDashboard();
}