
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { Search, MapPin, ChevronLeft, ChevronRight, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils/urlHelpers";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";

import LocationCard from "../components/map/LocationCard";
import AccessibilityScore from "../components/shared/AccessibilityScore";

// Fix Leaflet default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

// Australian bounds for map
const AUSTRALIA_BOUNDS = [
  [-44, 113], // Southwest coordinates
  [-10, 154]  // Northeast coordinates
];

// Major Australian cities for tile preloading
const AUSTRALIA_REGIONS = [
  { name: "Sydney", coords: [-33.8688, 151.2093], zoom: 12 },
  { name: "Melbourne", coords: [-37.8136, 144.9631], zoom: 12 },
  { name: "Brisbane", coords: [-27.4698, 153.0251], zoom: 12 },
  { name: "Perth", coords: [-31.9505, 115.8605], zoom: 12 },
  { name: "Adelaide", coords: [-34.9285, 138.6007], zoom: 12 },
  { name: "Canberra", coords: [-35.2809, 149.1300], zoom: 12 },
  { name: "Australia Overview", coords: [-25.2744, 133.7751], zoom: 5 }
];

// Create custom icon for accessible locations
const createAccessibleIcon = (score) => {
  const color = score >= 80 ? "#10B981" : score >= 60 ? "#F59E0B" : "#EF4444";
  return L.divIcon({
    html: `<div style="background-color: ${color}; width: 32px; height: 32px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; font-size: 14px;">${Math.round(score)}</div>`,
    className: "",
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

function MapUpdater({ center, zoom }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  
  return null;
}

function TilePreloader({ onComplete }) {
  const map = useMap();
  const [preloadProgress, setPreloadProgress] = useState(0);

  useEffect(() => {
    let isMounted = true;
    const preloadTiles = async () => {
      try {
        const tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
        let loaded = 0;
        const totalRegions = AUSTRALIA_REGIONS.length;

        // Preload tiles for each major region
        for (const region of AUSTRALIA_REGIONS) {
          if (!isMounted) break;
          
          const bounds = map.getBounds();
          const zoom = region.zoom;
          const center = L.latLng(region.coords);
          
          // Calculate tile coordinates for the region
          const tileSize = 256;
          const numTiles = 9; // 3x3 grid around center
          
          // Preload a few tiles around each region center
          const centerTile = {
            x: Math.floor((center.lng + 180) / 360 * Math.pow(2, zoom)),
            y: Math.floor((1 - Math.log(Math.tan(center.lat * Math.PI / 180) + 1 / Math.cos(center.lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom))
          };

          // Load center tiles
          for (let dx = -1; dx <= 1; dx++) {
            for (let dy = -1; dy <= 1; dy++) {
              const img = new Image();
              const s = ['a', 'b', 'c'][Math.floor(Math.random() * 3)];
              img.src = `https://${s}.tile.openstreetmap.org/${zoom}/${centerTile.x + dx}/${centerTile.y + dy}.png`;
              // Don't wait for image to load, just trigger the request
            }
          }

          loaded++;
          if (isMounted) {
            setPreloadProgress((loaded / totalRegions) * 100);
          }
        }

        // Wait a bit for tiles to cache
        await new Promise(resolve => setTimeout(resolve, 500));
        
        if (isMounted && onComplete) {
          onComplete();
        }
      } catch (error) {
        console.log('Tile preloading completed with errors:', error);
        if (isMounted && onComplete) {
          onComplete();
        }
      }
    };

    const timer = setTimeout(preloadTiles, 100);
    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [map, onComplete]);

  return (
    <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-[1000] bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg border border-gray-200">
      <div className="flex items-center gap-3">
        <Loader2 className="w-4 h-4 text-secondary animate-spin" />
        <div className="text-xs font-medium text-gray-700">
          Optimizing map tiles... {Math.round(preloadProgress)}%
        </div>
      </div>
    </div>
  );
}

function MapLoadingIndicator() {
  const [isLoading, setIsLoading] = useState(true);
  const map = useMap();

  useEffect(() => {
    const handleLoad = () => setIsLoading(false);
    map.whenReady(handleLoad);
    
    // Fallback timeout
    const timeout = setTimeout(() => setIsLoading(false), 3000);
    
    return () => clearTimeout(timeout);
  }, [map]);

  if (!isLoading) return null;

  return (
    <div className="absolute inset-0 bg-white/90 backdrop-blur-sm z-[1000] flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="w-12 h-12 text-secondary animate-spin mx-auto mb-4" />
        <p className="text-lg font-semibold text-primary">Loading Map...</p>
        <p className="text-sm text-gray-600">Finding accessible places near you</p>
      </div>
    </div>
  );
}

function SearchResultsLightbox({ isOpen, query, onQueryChange, results, onClose, onSelectLocation, getAverageRating, getLocationReviews, isLoading }) {
  const showResults = query && results.length > 0 && !isLoading;
  const showNoResults = query && results.length === 0 && !isLoading;
  const showInitialPrompt = !query && !isLoading;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] h-[80vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-2 border-b">
          <DialogTitle className="text-2xl font-bold">Search Accessible Places</DialogTitle>
          <DialogDescription>Find locations across Australia by name, suburb, or address.</DialogDescription>
          <div className="relative mt-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search locations, suburbs, addresses..."
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              className="pl-10 h-12 text-base w-full"
              autoFocus
            />
            {query && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onQueryChange("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:bg-gray-100"
              >
                <X className="w-5 h-5" />
              </Button>
            )}
          </div>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto p-6 pt-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <Loader2 className="w-12 h-12 text-secondary animate-spin mx-auto mb-3" />
                <p className="text-gray-600">Searching...</p>
              </div>
            </div>
          ) : showResults ? (
            <div className="space-y-4">
              {results.map((location) => (
                <LocationCard
                  key={location.id}
                  location={location}
                  averageRating={getAverageRating(location.id)}
                  reviewCount={getLocationReviews(location.id).length}
                  onClick={() => {
                    onSelectLocation(location);
                    onClose();
                  }}
                />
              ))}
            </div>
          ) : showNoResults ? (
            <div className="flex flex-col items-center justify-center h-full text-center px-6">
              <MapPin className="w-16 h-16 text-gray-300 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No locations found for "{query}"</h3>
              <p className="text-gray-600 text-sm">
                Try a different search term or check for typos.
              </p>
            </div>
          ) : showInitialPrompt && (
            <div className="flex flex-col items-center justify-center h-full text-center px-6">
              <Search className="w-16 h-16 text-gray-300 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Start typing to find places</h3>
              <p className="text-gray-600 text-sm">
                Search by location name, suburb, or address.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Loading skeleton for location cards
function LocationCardSkeleton() {
  return (
    <div className="p-4 border rounded-lg bg-white">
      <div className="flex gap-3">
        <Skeleton className="w-20 h-20 rounded-lg" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-4 w-full" />
        </div>
      </div>
    </div>
  );
}

export default function MapPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [stateFilter, setStateFilter] = useState("all");
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState([-25.2744, 133.7751]);
  const [mapZoom, setMapZoom] = useState(5);
  const [isPanelOpen, setIsPanelOpen] = useState(true);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [tilesPreloaded, setTilesPreloaded] = useState(false);

  const { data: locations = [], isLoading: locationsLoading } = useQuery({
    queryKey: ["locations"],
    queryFn: () => base44.entities.Location.list("-overall_score"),
  });

  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["reviews"],
    queryFn: () => base44.entities.Review.list("-created_date"),
  });

  const isLoading = locationsLoading || reviewsLoading;

  // Memoize functions
  const getLocationReviews = useCallback((locationId) => {
    return reviews.filter(r => r.location_id === locationId);
  }, [reviews]);

  const getAverageRating = useCallback((locationId) => {
    const locationReviews = getLocationReviews(locationId);
    if (locationReviews.length === 0) return 0;
    return locationReviews.reduce((sum, r) => sum + r.rating, 0) / locationReviews.length;
  }, [getLocationReviews]);

  const filteredLocations = useMemo(() => {
    return locations.filter((location) => {
      const matchesSearch = location.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           location.suburb?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           location.address?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = categoryFilter === "all" || location.category === categoryFilter;
      const matchesState = stateFilter === "all" || location.state === stateFilter;
      return matchesSearch && matchesCategory && matchesState;
    });
  }, [locations, searchQuery, categoryFilter, stateFilter]);

  const handleLocationClick = useCallback((location) => {
    setSelectedLocation(location);
    if (location.latitude && location.longitude) {
      setMapCenter([location.latitude, location.longitude]);
      setMapZoom(15);
    }
  }, []);

  // Try to get user's location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLat = position.coords.latitude;
          const userLng = position.coords.longitude;
          
          // Check if user is in Australia (rough bounds check)
          if (userLat >= -44 && userLat <= -10 && userLng >= 113 && userLng <= 154) {
            setMapCenter([userLat, userLng]);
            setMapZoom(12);
          } else {
            // Default to Australia center if outside Australia
            setMapCenter([-25.2744, 133.7751]);
            setMapZoom(5);
          }
        },
        () => {
          // Default to Australia center if geolocation fails
          setMapCenter([-25.2744, 133.7751]);
          setMapZoom(5);
        },
        { timeout: 5000, maximumAge: 300000 } // 5s timeout, 5min cache
      );
    }
  }, []);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)] relative">
      {/* Sidebar Toggle Button (Desktop) */}
      <Button
        variant="secondary"
        size="icon"
        onClick={() => setIsPanelOpen(!isPanelOpen)}
        className="hidden lg:flex absolute top-4 z-[100] shadow-lg hover:scale-110 transition-transform"
        style={{ left: isPanelOpen ? "calc(min(33.333vw, 450px) - 20px)" : "1rem" }}
      >
        {isPanelOpen ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
      </Button>

      {/* Sidebar */}
      <div
        className={`lg:transition-all lg:duration-300 bg-white border-r border-gray-200 flex flex-col overflow-hidden ${
          isPanelOpen ? "lg:w-1/3 xl:w-2/5 min-w-[300px] max-w-[450px]" : "lg:w-0"
        }`}
      >
        <div className={`${isPanelOpen ? "" : "lg:hidden"}`}>
          {/* Search and Filters */}
          <div className="p-4 sm:p-6 border-b border-gray-200 space-y-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-2">
                Discover Accessible Places
              </h2>
              <p className="text-sm text-gray-600">
                Evidence-based ratings across Australia
              </p>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-2 gap-3">
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="restaurant">Restaurants</SelectItem>
                  <SelectItem value="cafe">Cafes</SelectItem>
                  <SelectItem value="performance_venue">Venues</SelectItem>
                  <SelectItem value="disability_service">Disability Services</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="accommodation">Accommodation</SelectItem>
                  <SelectItem value="public_facility">Public Facilities</SelectItem>
                  <SelectItem value="medical_center">Medical Centers</SelectItem>
                </SelectContent>
              </Select>

              <Select value={stateFilter} onValueChange={setStateFilter}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="State" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All States</SelectItem>
                  <SelectItem value="NSW">NSW</SelectItem>
                  <SelectItem value="VIC">VIC</SelectItem>
                  <SelectItem value="QLD">QLD</SelectItem>
                  <SelectItem value="SA">SA</SelectItem>
                  <SelectItem value="WA">WA</SelectItem>
                  <SelectItem value="TAS">TAS</SelectItem>
                  <SelectItem value="NT">NT</SelectItem>
                  <SelectItem value="ACT">ACT</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Loading locations...
                  </span>
                ) : (
                  `${filteredLocations.length} location${filteredLocations.length !== 1 ? 's' : ''} found`
                )}
              </span>
              {(categoryFilter !== "all" || stateFilter !== "all" || searchQuery) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setCategoryFilter("all");
                    setStateFilter("all");
                    setSearchQuery("");
                  }}
                  className="text-secondary hover:text-secondary/80"
                >
                  Clear filters
                </Button>
              )}
            </div>
          </div>

          {/* Location List */}
          <div className="flex-1 overflow-y-auto">
            {isLoading ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <LocationCardSkeleton key={i} />
                ))}
              </div>
            ) : filteredLocations.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-center px-6">
                <MapPin className="w-16 h-16 text-gray-300 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No locations found</h3>
                <p className="text-gray-600 text-sm">
                  Try adjusting your filters or use the search button to open the global search
                </p>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {filteredLocations.map((location) => (
                  <LocationCard
                    key={location.id}
                    location={location}
                    averageRating={getAverageRating(location.id)}
                    reviewCount={getLocationReviews(location.id).length}
                    onClick={() => handleLocationClick(location)}
                    isSelected={selectedLocation?.id === location.id}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative bg-gray-100">
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setLightboxOpen(true)}
          className="absolute top-4 right-4 z-[100] shadow-lg hover:scale-110 transition-transform"
        >
          <Search className="w-5 h-5" />
        </Button>

        {!mapReady && (
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50 z-[100] flex items-center justify-center">
            <div className="text-center">
              <Loader2 className="w-16 h-16 text-secondary animate-spin mx-auto mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Loading Map</h3>
              <p className="text-gray-600">Preparing your accessible places map...</p>
              <p className="text-sm text-gray-500 mt-2">Optimizing tiles for Australia</p>
            </div>
          </div>
        )}

        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: "100%", width: "100%" }}
          className="z-0"
          whenReady={() => setMapReady(true)}
          maxBounds={AUSTRALIA_BOUNDS}
          maxBoundsViscosity={0.5}
          minZoom={4}
        >
          <MapUpdater center={mapCenter} zoom={mapZoom} />
          <MapLoadingIndicator />
          {mapReady && !tilesPreloaded && (
            <TilePreloader onComplete={() => setTilesPreloaded(true)} />
          )}
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxZoom={19}
            keepBuffer={8}
            updateWhenIdle={false}
            updateWhenZooming={false}
          />
          {!isLoading && filteredLocations.map((location) => {
            if (!location.latitude || !location.longitude) return null;
            return (
              <Marker
                key={location.id}
                position={[location.latitude, location.longitude]}
                icon={createAccessibleIcon(location.overall_score || 50)}
                eventHandlers={{
                  click: () => handleLocationClick(location),
                }}
              >
                <Popup>
                  <div className="p-2 min-w-[200px]">
                    <h3 className="font-bold text-base mb-2">{location.name}</h3>
                    <AccessibilityScore score={location.overall_score || 0} size="sm" />
                    <p className="text-sm text-gray-600 mt-2">{location.address}</p>
                    <Link to={`${createPageUrl("LocationDetails")}?id=${location.id}`}>
                      <Button size="sm" className="w-full mt-3 bg-secondary hover:bg-secondary/90">
                        View Details
                      </Button>
                    </Link>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>

        {/* Selected Location Overlay (Mobile) */}
        {selectedLocation && (
          <div className="absolute bottom-0 left-0 right-0 lg:hidden bg-white border-t border-gray-200 shadow-2xl p-4 z-10">
            <div className="flex items-start gap-3">
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-1">{selectedLocation.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{selectedLocation.suburb}, {selectedLocation.state}</p>
                <AccessibilityScore score={selectedLocation.overall_score || 0} size="sm" />
              </div>
              <Link to={`${createPageUrl("LocationDetails")}?id=${selectedLocation.id}`}>
                <Button size="sm" className="bg-secondary hover:bg-secondary/90">
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Search Results Lightbox */}
      <SearchResultsLightbox
        isOpen={lightboxOpen}
        query={searchQuery}
        onQueryChange={setSearchQuery}
        results={filteredLocations}
        onClose={() => setLightboxOpen(false)}
        onSelectLocation={handleLocationClick}
        getAverageRating={getAverageRating}
        getLocationReviews={getLocationReviews}
        isLoading={isLoading}
      />
    </div>
  );
}
