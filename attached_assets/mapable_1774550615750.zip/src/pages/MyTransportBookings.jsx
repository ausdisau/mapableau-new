
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  Calendar,
  MapPin,
  Car,
  Clock,
  DollarSign,
  CheckCircle,
  XCircle,
  AlertCircle,
  Navigation,
  User,
  Phone,
  Star,
  Repeat
} from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ParticipantRatingForm from "../components/transport/ParticipantRatingForm";
import RecurringSeriesManager from "../components/transport/RecurringSeriesManager"; // New import
import { toast } from "sonner";
import NotificationService from "../components/notifications/NotificationService";
import AuditLogService from "../components/audit/AuditLogService";

export default function MyTransportBookingsPage() {
  const queryClient = useQueryClient();
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [ratingBooking, setRatingBooking] = useState(null);
  const [showSeriesDialog, setShowSeriesDialog] = useState(false); // New state
  const [selectedSeriesId, setSelectedSeriesId] = useState(null); // New state

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: allBookings = [], isLoading } = useQuery({ // Renamed 'bookings' to 'allBookings' for clarity
    queryKey: ["myTransportBookings"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.TransportBooking.filter(
        { created_by: user.email },
        "-pickup_datetime"
      );
    },
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["allVehicles"],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: drivers = [] } = useQuery({
    queryKey: ["allDrivers"],
    queryFn: () => base44.entities.Driver.list(),
  });

  const { data: myReviews = [] } = useQuery({
    queryKey: ["myTransportReviews"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.TransportReview.filter({ created_by: user.email });
    },
  });

  const cancelBookingMutation = useMutation({
    mutationFn: async (bookingId) => {
      const booking = await base44.entities.TransportBooking.update(bookingId, { status: "cancelled" });
      
      // Send notification
      const user = await base44.auth.me();
      await NotificationService.notifyBookingCancelled(booking, user.email);
      
      // Log the audit event
      await AuditLogService.logBookingCancellation(booking, "Cancelled by participant");
      
      return booking;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] });
      queryClient.invalidateQueries({ queryKey: ["auditLogs"] });
      setShowCancelDialog(false);
      setSelectedBooking(null);
      toast.success("Booking cancelled successfully");
    },
  });

  // Group bookings by series
  const recurringSeriesMap = {};
  allBookings.forEach(booking => {
    if (booking.series_id) {
      if (!recurringSeriesMap[booking.series_id]) {
        recurringSeriesMap[booking.series_id] = [];
      }
      recurringSeriesMap[booking.series_id].push(booking);
    }
  });

  // Get non-recurring bookings
  const nonRecurringBookings = allBookings.filter(b => !b.series_id);

  // Filter for upcoming bookings (combining non-recurring and one representative from each upcoming series)
  const upcomingBookingsFinal = [];

  // Add non-recurring upcoming bookings
  nonRecurringBookings.forEach(booking => {
    if (
      booking.pickup_datetime &&
      new Date(booking.pickup_datetime) > new Date() &&
      !["cancelled", "completed", "no_show"].includes(booking.status)
    ) {
      upcomingBookingsFinal.push({ ...booking, isSeriesRepresentative: false });
    }
  });

  // Add series representatives for upcoming series
  Object.values(recurringSeriesMap).forEach(series => {
    // Sort series bookings by pickup_datetime to find the earliest upcoming
    const sortedSeries = [...series].sort((a, b) => new Date(a.pickup_datetime).getTime() - new Date(b.pickup_datetime).getTime());
    const firstUpcomingInSeries = sortedSeries.find(b =>
      b.pickup_datetime &&
      new Date(b.pickup_datetime) > new Date() &&
      !["cancelled", "completed", "no_show"].includes(b.status)
    );
    if (firstUpcomingInSeries) {
      upcomingBookingsFinal.push({ ...firstUpcomingInSeries, isSeriesRepresentative: true });
    }
  });

  // Sort the final upcoming list by date
  upcomingBookingsFinal.sort((a, b) => new Date(a.pickup_datetime).getTime() - new Date(b.pickup_datetime).getTime());

  const pastBookings = allBookings.filter(b =>
    b.pickup_datetime &&
    (new Date(b.pickup_datetime) < new Date() || ["completed", "no_show"].includes(b.status))
  );

  const cancelledBookings = allBookings.filter(b => b.status === "cancelled");

  const getVehicle = (vehicleId) => vehicles.find(v => v.id === vehicleId);
  const getDriver = (driverId) => drivers.find(d => d.id === driverId);

  const hasReview = (bookingId) => myReviews.some(r => r.booking_id === bookingId);

  const getStatusColor = (status) => {
    const colors = {
      requested: "bg-yellow-100 text-yellow-700",
      confirmed: "bg-blue-100 text-blue-700",
      driver_assigned: "bg-indigo-100 text-indigo-700",
      en_route_to_pickup: "bg-purple-100 text-purple-700",
      passenger_on_board: "bg-green-100 text-green-700",
      in_transit: "bg-green-100 text-green-700",
      completed: "bg-gray-100 text-gray-700",
      cancelled: "bg-red-100 text-red-700",
      no_show: "bg-orange-100 text-orange-700"
    };
    return colors[status] || "bg-gray-100 text-gray-700";
  };

  const renderBookingCard = (booking) => {
    const vehicle = getVehicle(booking.vehicle_id);
    const driver = booking.driver_id ? getDriver(booking.driver_id) : null;
    const reviewed = hasReview(booking.id);
    const isSeriesRepresentative = booking.isSeriesRepresentative; // Use the new flag
    const seriesBookings = booking.series_id ? recurringSeriesMap[booking.series_id] : null;
    
    // Check if booking is trackable
    const isTrackable = ["driver_assigned", "en_route_to_pickup", "passenger_on_board", "in_transit"].includes(booking.status);

    return (
      <Card key={booking.id} className={`hover-lift ${isSeriesRepresentative ? 'border-2 border-blue-200' : ''}`}>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {/* Status and Date */}
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status?.replace(/_/g, " ")}
                  </Badge>
                  {isSeriesRepresentative && seriesBookings && (
                    <Badge className="bg-blue-100 text-blue-700 gap-1">
                      <Repeat className="w-3 h-3" />
                      Recurring ({seriesBookings.length} trips)
                    </Badge>
                  )}
                </div>
                {booking.pickup_datetime && (
                  <p className="text-sm text-gray-600">
                    <Calendar className="w-4 h-4 inline mr-1" />
                    {format(new Date(booking.pickup_datetime), "EEEE, MMMM d, yyyy 'at' h:mm a")}
                  </p>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedBooking(booking)}
              >
                View Details
              </Button>
            </div>

            {/* Vehicle Info */}
            {vehicle && (
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                <Car className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-semibold text-primary">{vehicle.vehicle_name}</p>
                  <p className="text-sm text-gray-600">{vehicle.vehicle_type?.replace(/_/g, " ")}</p>
                </div>
              </div>
            )}

            {/* Driver Info */}
            {driver && (
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <User className="w-8 h-8 text-green-600" />
                <div className="flex-1">
                  <p className="font-semibold text-primary">{driver.full_name}</p>
                  <div className="flex items-center gap-2">
                    {driver.rating > 0 && (
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{driver.rating.toFixed(1)}</span>
                      </div>
                    )}
                    {driver.phone && (
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Phone className="w-3 h-3" />
                        {driver.phone}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Locations */}
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Pickup</p>
                  <p className="text-sm text-gray-600">
                    {booking.pickup_location.address || booking.pickup_location.suburb}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Drop-off</p>
                  <p className="text-sm text-gray-600">
                    {booking.dropoff_location.address || booking.dropoff_location.suburb}
                  </p>
                </div>
              </div>
            </div>

            {/* Cost */}
            {(booking.estimated_cost || booking.actual_cost) && (
              <div className="flex items-center justify-between pt-3 border-t">
                <span className="text-sm text-gray-600">Total Cost</span>
                <span className="text-lg font-bold text-primary">
                  ${(booking.actual_cost || booking.estimated_cost).toFixed(2)}
                </span>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col gap-2">
              {/* Track Ride Button - NEW */}
              {isTrackable && (
                <Link to={`${createPageUrl("TrackRide")}?booking_id=${booking.id}`}>
                  <Button
                    size="sm"
                    className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
                  >
                    <Navigation className="w-4 h-4" />
                    Track Ride Live
                  </Button>
                </Link>
              )}

              {isSeriesRepresentative && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedSeriesId(booking.series_id);
                    setShowSeriesDialog(true);
                  }}
                  className="w-full gap-2"
                >
                  <Repeat className="w-4 h-4" />
                  Manage Recurring Series
                </Button>
              )}

              {booking.status === "requested" && !isSeriesRepresentative && ( // Only show cancel for non-series or individual series bookings not marked as representative
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => {
                    setSelectedBooking(booking);
                    setShowCancelDialog(true);
                  }}
                  className="w-full"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Cancel Booking
                </Button>
              )}

              {booking.status === "completed" && !reviewed && (
                <Button
                  size="sm"
                  onClick={() => {
                    setRatingBooking(booking);
                    setShowRatingDialog(true);
                  }}
                  className="w-full bg-yellow-500 hover:bg-yellow-600 gap-2"
                >
                  <Star className="w-4 h-4" />
                  Rate This Trip
                </Button>
              )}

              {booking.status === "completed" && reviewed && (
                <div className="flex items-center gap-2 text-sm text-green-700 bg-green-50 p-2 rounded">
                  <CheckCircle className="w-4 h-4" />
                  <span>Review submitted</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-secondary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">My Transport Bookings</h1>
          <p className="text-gray-600">View and manage your accessible transport bookings</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Upcoming Trips</p>
                  <p className="text-3xl font-bold text-primary">{upcomingBookingsFinal.length}</p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Completed Trips</p>
                  <p className="text-3xl font-bold text-primary">
                    {allBookings.filter(b => b.status === "completed").length}
                  </p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Spent</p>
                  <p className="text-3xl font-bold text-primary">
                    ${allBookings
                      .filter(b => b.payment_status === "paid")
                      .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0)
                      .toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bookings Tabs */}
        <Tabs defaultValue="upcoming" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upcoming">
              Upcoming ({upcomingBookingsFinal.length})
            </TabsTrigger>
            <TabsTrigger value="past">
              Past ({pastBookings.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelled ({cancelledBookings.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="space-y-4">
            {upcomingBookingsFinal.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No upcoming bookings</h3>
                  <p className="text-gray-600 mb-4">Ready to book your next accessible ride?</p>
                  <Link to={createPageUrl("FindTransport")}>
                    <Button className="bg-secondary hover:bg-secondary/90">
                      Browse Vehicles
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {upcomingBookingsFinal.map(renderBookingCard)}
              </div>
            )}
          </TabsContent>

          <TabsContent value="past" className="space-y-4">
            {pastBookings.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No past bookings</h3>
                  <p className="text-gray-600">Your completed trips will appear here</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {pastBookings.map(renderBookingCard)}
              </div>
            )}
          </TabsContent>

          <TabsContent value="cancelled" className="space-y-4">
            {cancelledBookings.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <XCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No cancelled bookings</h3>
                  <p className="text-gray-600">Cancelled trips will appear here</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {cancelledBookings.map(renderBookingCard)}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Booking Details Dialog */}
      <Dialog open={!!selectedBooking && !showCancelDialog} onOpenChange={() => setSelectedBooking(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
          </DialogHeader>
          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-gray-600">Status</Label>
                  <Badge className={`${getStatusColor(selectedBooking.status)} mt-1`}>
                    {selectedBooking.status?.replace(/_/g, " ")}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm text-gray-600">Booking Type</Label>
                  <p className="font-medium capitalize">{selectedBooking.booking_type?.replace(/_/g, " ")}</p>
                </div>
              </div>

              {/* Full details would go here */}
              <Alert>
                <Navigation className="w-4 h-4" />
                <AlertDescription>
                  Track your ride in real-time when the driver is en route
                </AlertDescription>
              </Alert>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Cancel Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this booking? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
              Keep Booking
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedBooking && cancelBookingMutation.mutate(selectedBooking.id)}
              disabled={cancelBookingMutation.isPending}
            >
              {cancelBookingMutation.isPending ? "Cancelling..." : "Yes, Cancel"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Recurring Series Dialog */}
      <Dialog open={showSeriesDialog} onOpenChange={setShowSeriesDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Recurring Series</DialogTitle>
          </DialogHeader>
          {selectedSeriesId && recurringSeriesMap[selectedSeriesId] && (
            <RecurringSeriesManager
              seriesBookings={recurringSeriesMap[selectedSeriesId]}
              onClose={() => {
                setShowSeriesDialog(false);
                setSelectedSeriesId(null);
                queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] }); // Invalidate to refresh bookings list
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Rating Dialog */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Rate Your Transport Experience</DialogTitle>
            <DialogDescription>
              Your feedback helps us maintain quality and assists other participants
            </DialogDescription>
          </DialogHeader>
          {ratingBooking && (
            <ParticipantRatingForm
              booking={ratingBooking}
              vehicle={getVehicle(ratingBooking.vehicle_id)}
              driver={ratingBooking.driver_id ? getDriver(ratingBooking.driver_id) : null}
              onSuccess={() => {
                setShowRatingDialog(false);
                setRatingBooking(null);
                queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] }); // Invalidate to refresh card state
                queryClient.invalidateQueries({ queryKey: ["myTransportReviews"] }); // Invalidate reviews to update hasReview
              }}
              onCancel={() => {
                setShowRatingDialog(false);
                setRatingBooking(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Label({ children, className = "" }) {
  return <label className={`text-sm font-medium ${className}`}>{children}</label>;
}
