import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Shield, 
  Plus, 
  Edit,
  Trash2,
  Users,
  AlertTriangle,
  Key,
  Grid3x3
} from "lucide-react";
import { toast } from "sonner";
import CustomRoleEditor from "../components/rbac/CustomRoleEditor";
import PermissionMatrix from "../components/rbac/PermissionMatrix";
import { getAllRoles, isSystemRole, hasPermission, MODULES, createPermission, ACTIONS } from "@/components/utils/permissions";

export default function RBACSettingsPage() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedRole, setSelectedRole] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // Check admin permission
  const isAdmin = hasPermission(currentUser, createPermission(MODULES.USERS, ACTIONS.MANAGE));

  const { data: allUsers = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
    enabled: isAdmin,
  });

  // Get all roles with user counts
  const rolesWithCounts = getAllRoles().map(role => ({
    ...role,
    userCount: allUsers.filter(u => u.role === role.value).length,
  }));

  const handleCreateRole = (roleData) => {
    // In a real implementation, you would save custom roles to a database
    // For now, we'll just show a toast
    toast.success(`Role "${roleData.name}" created successfully!`);
    console.log("New role:", roleData);
    setShowCreateDialog(false);
  };

  const handleEditRole = (roleData) => {
    toast.success(`Role "${roleData.name}" updated successfully!`);
    console.log("Updated role:", roleData);
    setShowEditDialog(false);
    setSelectedRole(null);
  };

  const handleDeleteRole = () => {
    if (!selectedRole) return;
    
    toast.success(`Role "${selectedRole.name}" deleted successfully!`);
    console.log("Deleted role:", selectedRole.value);
    setShowDeleteDialog(false);
    setSelectedRole(null);
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200 border-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <AlertDescription>
              <div>
                <span className="font-semibold text-red-900 text-lg">Access Denied</span>
                <p className="text-sm text-red-700 mt-1">
                  Only administrators can manage roles and permissions.
                </p>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-8 h-8 text-purple-600" />
                <h1 className="text-4xl font-bold text-primary">
                  Role-Based Access Control
                </h1>
              </div>
              <p className="text-gray-600 text-lg">
                Manage roles, permissions, and access control for your platform
              </p>
            </div>
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="bg-purple-600 hover:bg-purple-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Custom Role
            </Button>
          </div>
        </div>

        {/* Important Info */}
        <Alert className="mb-8 bg-blue-50 border-blue-200 border-2">
          <Key className="w-5 h-5 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <p className="font-semibold mb-2">About Role-Based Access Control:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>System roles (marked with a shield) cannot be modified or deleted</li>
              <li>Custom roles allow you to create specific permission sets for your needs</li>
              <li>Users can have custom permissions that override their role defaults</li>
              <li>Changes to roles affect all users with that role immediately</li>
            </ul>
          </AlertDescription>
        </Alert>

        {/* Tabs */}
        <Tabs defaultValue="roles" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="roles">
              <Users className="w-4 h-4 mr-2" />
              Roles ({rolesWithCounts.length})
            </TabsTrigger>
            <TabsTrigger value="matrix">
              <Grid3x3 className="w-4 h-4 mr-2" />
              Permission Matrix
            </TabsTrigger>
            <TabsTrigger value="modules">
              <Key className="w-4 h-4 mr-2" />
              Modules & Permissions
            </TabsTrigger>
          </TabsList>

          {/* Roles Tab */}
          <TabsContent value="roles">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rolesWithCounts.map((role) => (
                <Card 
                  key={role.value} 
                  className={`hover-lift ${
                    role.isSystem ? 'border-2 border-purple-200' : 'border-2 border-gray-200'
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <CardTitle className="text-lg">{role.name}</CardTitle>
                          {role.isSystem && (
                            <Shield className="w-4 h-4 text-purple-600" title="System Role" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {role.description}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {/* Stats */}
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Users with this role:</span>
                        <span className="font-semibold text-primary">{role.userCount}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Permissions:</span>
                        <span className="font-semibold text-purple-600">
                          {role.permissions.length}
                        </span>
                      </div>

                      {/* Color Badge */}
                      <div className="pt-3 border-t">
                        <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold bg-${role.color}-100 text-${role.color}-700 border border-${role.color}-200`}>
                          {role.color} badge
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 pt-3 border-t">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedRole(role);
                            setShowEditDialog(true);
                          }}
                          className="flex-1 gap-2"
                          disabled={role.isSystem}
                        >
                          <Edit className="w-3 h-3" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedRole(role);
                            setShowDeleteDialog(true);
                          }}
                          className="flex-1 gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                          disabled={role.isSystem || role.userCount > 0}
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </Button>
                      </div>

                      {role.userCount > 0 && !role.isSystem && (
                        <p className="text-xs text-yellow-600">
                          Cannot delete: {role.userCount} user{role.userCount !== 1 ? 's' : ''} assigned
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Permission Matrix Tab */}
          <TabsContent value="matrix">
            <PermissionMatrix />
          </TabsContent>

          {/* Modules Tab */}
          <TabsContent value="modules">
            <Card>
              <CardHeader>
                <CardTitle>Available Modules & Permissions</CardTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Complete list of all modules and their associated permissions
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {Object.entries(MODULES).map(([key, module]) => {
                    const permissions = Object.values(ACTIONS).map(action => ({
                      action,
                      permission: createPermission(module, action)
                    }));

                    return (
                      <div key={module} className="border rounded-lg p-4">
                        <h3 className="font-semibold text-lg mb-1 capitalize">
                          {module.replace(/_/g, ' ')}
                        </h3>
                        <p className="text-sm text-gray-600 mb-3">
                          Module key: <code className="bg-gray-100 px-2 py-0.5 rounded">{module}</code>
                        </p>
                        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-2">
                          {permissions.map(perm => (
                            <div key={perm.permission} className="bg-gray-50 rounded p-2">
                              <p className="font-medium text-sm capitalize">
                                {perm.action.replace(/_/g, ' ')}
                              </p>
                              <p className="text-xs text-gray-500 font-mono">
                                {perm.permission}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Role Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Custom Role</DialogTitle>
          </DialogHeader>
          <CustomRoleEditor
            onSave={handleCreateRole}
            onCancel={() => setShowCreateDialog(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Role: {selectedRole?.name}</DialogTitle>
          </DialogHeader>
          {selectedRole && (
            <CustomRoleEditor
              role={selectedRole}
              onSave={handleEditRole}
              onCancel={() => {
                setShowEditDialog(false);
                setSelectedRole(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Role</DialogTitle>
          </DialogHeader>
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-900">
              Are you sure you want to delete the role "{selectedRole?.name}"? This action cannot be undone.
            </AlertDescription>
          </Alert>
          <div className="flex justify-end gap-3 mt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowDeleteDialog(false);
                setSelectedRole(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteRole}
            >
              Delete Role
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}