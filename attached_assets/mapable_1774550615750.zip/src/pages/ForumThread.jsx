import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft,
  ThumbsUp,
  Flag,
  MessageSquare,
  Pin,
  Lock,
  CheckCircle,
  Megaphone,
  Shield,
  Edit,
  Trash2,
  MoreVertical
} from "lucide-react";
import { format } from "date-fns";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { hasPermission, PERMISSIONS, getRoleLabel, getRoleColor } from "@/components/utils/permissions";

export default function ForumThreadPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const postId = urlParams.get("id");
  const queryClient = useQueryClient();

  const [replyContent, setReplyContent] = useState("");
  const [replyingTo, setReplyingTo] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: post, isLoading: postLoading } = useQuery({
    queryKey: ["forumPost", postId],
    queryFn: async () => {
      const posts = await base44.entities.ForumPost.filter({ id: postId });
      const post = posts[0];
      
      // Increment view count
      if (post) {
        await base44.entities.ForumPost.update(postId, {
          view_count: (post.view_count || 0) + 1
        });
      }
      
      return post;
    },
    enabled: !!postId,
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["forumComments", postId],
    queryFn: () => base44.entities.ForumComment.filter({ post_id: postId }),
    enabled: !!postId,
  });

  const createCommentMutation = useMutation({
    mutationFn: async (commentData) => {
      const comment = await base44.entities.ForumComment.create(commentData);
      
      // Update post comment count and last activity
      await base44.entities.ForumPost.update(postId, {
        comment_count: (post.comment_count || 0) + 1,
        last_activity_date: new Date().toISOString()
      });
      
      return comment;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forumComments", postId] });
      queryClient.invalidateQueries({ queryKey: ["forumPost", postId] });
      setReplyContent("");
      setReplyingTo(null);
      toast.success("Reply posted!");
    },
  });

  const likePostMutation = useMutation({
    mutationFn: async () => {
      const likedBy = post.liked_by || [];
      const hasLiked = likedBy.includes(currentUser.email);
      
      const newLikedBy = hasLiked 
        ? likedBy.filter(email => email !== currentUser.email)
        : [...likedBy, currentUser.email];
      
      return await base44.entities.ForumPost.update(postId, {
        liked_by: newLikedBy,
        like_count: newLikedBy.length
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forumPost", postId] });
    },
  });

  const likeCommentMutation = useMutation({
    mutationFn: async (commentId) => {
      const comment = comments.find(c => c.id === commentId);
      const likedBy = comment.liked_by || [];
      const hasLiked = likedBy.includes(currentUser.email);
      
      const newLikedBy = hasLiked 
        ? likedBy.filter(email => email !== currentUser.email)
        : [...likedBy, currentUser.email];
      
      return await base44.entities.ForumComment.update(commentId, {
        liked_by: newLikedBy,
        like_count: newLikedBy.length
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forumComments", postId] });
    },
  });

  const markAsSolvedMutation = useMutation({
    mutationFn: async (commentId) => {
      await base44.entities.ForumComment.update(commentId, {
        is_accepted_answer: true
      });
      
      return await base44.entities.ForumPost.update(postId, {
        solved: true,
        accepted_answer_id: commentId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forumPost", postId] });
      queryClient.invalidateQueries({ queryKey: ["forumComments", postId] });
      toast.success("Marked as solved!");
    },
  });

  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId) => {
      await base44.entities.ForumComment.update(commentId, { status: "deleted" });
      await base44.entities.ForumPost.update(postId, {
        comment_count: Math.max((post.comment_count || 1) - 1, 0)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["forumComments", postId] });
      queryClient.invalidateQueries({ queryKey: ["forumPost", postId] });
      toast.success("Comment deleted");
    },
  });

  const handleReply = () => {
    if (!replyContent.trim()) return;
    
    createCommentMutation.mutate({
      post_id: postId,
      parent_comment_id: replyingTo?.id,
      content: replyContent,
      author_email: currentUser.email,
      author_name: currentUser.full_name,
      author_role: currentUser.role,
    });
  };

  const isAdmin = hasPermission(currentUser, PERMISSIONS.USERS_MANAGE_ROLES);
  const isAuthor = currentUser?.email === post?.author_email;

  if (postLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertDescription>Post not found</AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  // Filter active comments and organize by parent
  const activeComments = comments.filter(c => c.status === "active");
  const rootComments = activeComments.filter(c => !c.parent_comment_id);
  const getReplies = (commentId) => activeComments.filter(c => c.parent_comment_id === commentId);

  const hasLikedPost = post.liked_by?.includes(currentUser?.email);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to={createPageUrl("Forum")}>
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Forum
          </Button>
        </Link>

        {/* Main Post */}
        <Card className="mb-6">
          <CardContent className="p-8">
            {/* Header Badges */}
            <div className="flex flex-wrap items-center gap-2 mb-4">
              {post.is_announcement && (
                <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                  <Megaphone className="w-3 h-3 mr-1" />
                  Announcement
                </Badge>
              )}
              {post.is_pinned && (
                <Badge className="bg-blue-100 text-blue-700">
                  <Pin className="w-3 h-3 mr-1" />
                  Pinned
                </Badge>
              )}
              {post.solved && (
                <Badge className="bg-green-100 text-green-700">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Solved
                </Badge>
              )}
              {post.is_locked && (
                <Badge variant="outline">
                  <Lock className="w-3 h-3 mr-1" />
                  Locked
                </Badge>
              )}
              <Badge variant="outline" className="capitalize">
                {post.category}
              </Badge>
            </div>

            {/* Title */}
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{post.title}</h1>

            {/* Author Info */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                  <span className="text-indigo-700 font-semibold">
                    {post.author_name?.charAt(0) || "U"}
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{post.author_name || "Anonymous"}</span>
                    {post.author_email === currentUser?.email && (
                      <Badge variant="secondary" className="text-xs">You</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    {format(new Date(post.created_date), "MMMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
              </div>

              {/* Post Actions */}
              {(isAdmin || isAuthor) && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="w-5 h-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {isAdmin && (
                      <>
                        <DropdownMenuItem>
                          <Pin className="w-4 h-4 mr-2" />
                          {post.is_pinned ? "Unpin" : "Pin"} Post
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Lock className="w-4 h-4 mr-2" />
                          {post.is_locked ? "Unlock" : "Lock"} Post
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                      </>
                    )}
                    {isAuthor && (
                      <DropdownMenuItem>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Post
                      </DropdownMenuItem>
                    )}
                    {(isAdmin || isAuthor) && (
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Post
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            <Separator className="mb-6" />

            {/* Content */}
            <div className="prose prose-indigo max-w-none mb-6">
              <ReactMarkdown>{post.content}</ReactMarkdown>
            </div>

            {/* Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {post.tags.map((tag, idx) => (
                  <Badge key={idx} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            <Separator className="mb-4" />

            {/* Actions */}
            <div className="flex items-center gap-4">
              <Button
                variant={hasLikedPost ? "default" : "outline"}
                size="sm"
                onClick={() => likePostMutation.mutate()}
                disabled={!currentUser || likePostMutation.isPending}
                className={hasLikedPost ? "bg-indigo-600" : ""}
              >
                <ThumbsUp className="w-4 h-4 mr-2" />
                {post.like_count || 0} Likes
              </Button>
              <div className="flex items-center gap-2 text-gray-600">
                <MessageSquare className="w-4 h-4" />
                <span className="text-sm">{post.comment_count || 0} replies</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Comments Section */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-6">
              {rootComments.length} {rootComments.length === 1 ? "Reply" : "Replies"}
            </h2>

            {/* Reply Form */}
            {!post.is_locked && currentUser && (
              <div className="mb-6">
                {replyingTo && (
                  <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3 mb-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-indigo-900">
                        Replying to <span className="font-semibold">{replyingTo.author_name}</span>
                      </p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setReplyingTo(null)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
                <Textarea
                  placeholder={replyingTo ? "Write your reply..." : "Join the discussion..."}
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  rows={4}
                  className="mb-3"
                />
                <div className="flex justify-end">
                  <Button
                    onClick={handleReply}
                    disabled={!replyContent.trim() || createCommentMutation.isPending}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    {createCommentMutation.isPending ? "Posting..." : "Post Reply"}
                  </Button>
                </div>
              </div>
            )}

            {post.is_locked && (
              <Alert className="mb-6 bg-yellow-50 border-yellow-200">
                <Lock className="w-4 h-4 text-yellow-600" />
                <AlertDescription className="text-yellow-900">
                  This discussion has been locked and is no longer accepting new replies.
                </AlertDescription>
              </Alert>
            )}

            <Separator className="mb-6" />

            {/* Comments List */}
            <div className="space-y-6">
              {rootComments.map(comment => {
                const replies = getReplies(comment.id);
                const hasLiked = comment.liked_by?.includes(currentUser?.email);
                const isCommentAuthor = currentUser?.email === comment.author_email;
                
                return (
                  <div key={comment.id}>
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-purple-700 font-semibold">
                          {comment.author_name?.charAt(0) || "U"}
                        </span>
                      </div>
                      
                      <div className="flex-1">
                        <div className="bg-gray-50 rounded-lg p-4 mb-2">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-semibold">{comment.author_name || "Anonymous"}</span>
                                {comment.author_role && (
                                  <Badge className={getRoleColor(comment.author_role)}>
                                    {getRoleLabel(comment.author_role)}
                                  </Badge>
                                )}
                                {comment.is_accepted_answer && (
                                  <Badge className="bg-green-100 text-green-700">
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Accepted Answer
                                  </Badge>
                                )}
                                {comment.is_official && (
                                  <Badge className="bg-indigo-100 text-indigo-700">
                                    <Shield className="w-3 h-3 mr-1" />
                                    Official
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-gray-500">
                                {format(new Date(comment.created_date), "MMM d, yyyy 'at' h:mm a")}
                                {comment.edited && " (edited)"}
                              </p>
                            </div>
                          </div>
                          
                          <div className="prose prose-sm max-w-none">
                            <ReactMarkdown>{comment.content}</ReactMarkdown>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3 text-sm">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => likeCommentMutation.mutate(comment.id)}
                            disabled={!currentUser}
                            className={hasLiked ? "text-indigo-600" : ""}
                          >
                            <ThumbsUp className="w-4 h-4 mr-1" />
                            {comment.like_count || 0}
                          </Button>
                          
                          {!post.is_locked && currentUser && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setReplyingTo(comment)}
                            >
                              Reply
                            </Button>
                          )}
                          
                          {isAuthor && !comment.is_accepted_answer && !post.solved && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => markAsSolvedMutation.mutate(comment.id)}
                              className="text-green-600"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Mark as Answer
                            </Button>
                          )}
                          
                          {(isAdmin || isCommentAuthor) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteCommentMutation.mutate(comment.id)}
                              className="text-red-600"
                            >
                              Delete
                            </Button>
                          )}
                        </div>
                        
                        {/* Nested Replies */}
                        {replies.length > 0 && (
                          <div className="mt-4 ml-6 space-y-4 border-l-2 border-gray-200 pl-4">
                            {replies.map(reply => {
                              const hasLikedReply = reply.liked_by?.includes(currentUser?.email);
                              
                              return (
                                <div key={reply.id} className="flex gap-3">
                                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0">
                                    <span className="text-indigo-700 text-sm font-semibold">
                                      {reply.author_name?.charAt(0) || "U"}
                                    </span>
                                  </div>
                                  
                                  <div className="flex-1">
                                    <div className="bg-white border rounded-lg p-3">
                                      <div className="flex items-center gap-2 mb-1">
                                        <span className="font-medium text-sm">{reply.author_name}</span>
                                        <span className="text-xs text-gray-500">
                                          {format(new Date(reply.created_date), "MMM d")}
                                        </span>
                                      </div>
                                      <p className="text-sm text-gray-700">{reply.content}</p>
                                      
                                      <div className="flex items-center gap-2 mt-2">
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() => likeCommentMutation.mutate(reply.id)}
                                          disabled={!currentUser}
                                          className={`h-6 text-xs ${hasLikedReply ? "text-indigo-600" : ""}`}
                                        >
                                          <ThumbsUp className="w-3 h-3 mr-1" />
                                          {reply.like_count || 0}
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              
              {rootComments.length === 0 && (
                <div className="text-center py-12">
                  <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">No replies yet. Be the first to respond!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}