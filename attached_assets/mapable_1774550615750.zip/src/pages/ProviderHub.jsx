import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Briefcase,
  Calendar,
  Shield,
  Inbox,
  BarChart3,
  Settings,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  DollarSign,
  Star,
  Users
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import ServiceManagementTab from "../components/provider/hub/ServiceManagementTab";
import AvailabilityTab from "../components/provider/hub/AvailabilityTab";
import RequestsInboxTab from "../components/provider/hub/RequestsInboxTab";
import CredentialsTab from "../components/provider/hub/CredentialsTab";
import AnalyticsTab from "../components/provider/hub/AnalyticsTab";

export default function ProviderHubPage() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["myServiceRequests"],
    queryFn: async () => {
      const allRequests = await base44.entities.ServiceRequest.list("-created_date");
      return allRequests.filter(req => {
        // Match by provider lookup - would need provider entity reference
        return req.status === "pending";
      });
    },
    enabled: !!currentUser,
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["myTransportBookings"],
    queryFn: async () => {
      const allBookings = await base44.entities.TransportBooking.list("-created_date");
      return allBookings.filter(b => b.status === "requested");
    },
    enabled: !!currentUser,
  });

  const { data: credentials = [] } = useQuery({
    queryKey: ["myCredentials"],
    queryFn: async () => {
      const allCreds = await base44.entities.ProviderCredential.filter({
        provider_email: currentUser?.email
      });
      return allCreds;
    },
    enabled: !!currentUser?.email,
  });

  const { data: availability } = useQuery({
    queryKey: ["myAvailability"],
    queryFn: async () => {
      const avail = await base44.entities.ProviderAvailability.filter({
        provider_email: currentUser?.email
      });
      return avail[0];
    },
    enabled: !!currentUser?.email,
  });

  // Check if user is a provider
  const isProvider = currentUser?.user_type === "service_provider" || 
                     currentUser?.user_type === "transport_provider";

  if (!isProvider) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-yellow-50 border-yellow-200">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            <AlertDescription>
              <span className="font-semibold text-yellow-900">Provider Access Required</span>
              <p className="text-sm text-yellow-700 mt-1">
                This area is only accessible to registered service providers.
              </p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  // Calculate stats
  const pendingRequests = serviceRequests.length + transportBookings.length;
  const credentialsExpiringSoon = credentials.filter(c => {
    if (!c.expiry_date) return false;
    const expiryDate = new Date(c.expiry_date);
    const daysUntilExpiry = (expiryDate - new Date()) / (1000 * 60 * 60 * 24);
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
  }).length;
  const credentialsPending = credentials.filter(c => c.verification_status === "submitted").length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-green-600 flex items-center justify-center shadow-lg">
                  <Briefcase className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl font-bold text-primary">Provider Hub</h1>
                  <p className="text-gray-600">Manage your services and bookings</p>
                </div>
              </div>
            </div>
            <Link to={createPageUrl("ProviderProfile")} target="_blank">
              <Button variant="outline" className="gap-2">
                <Users className="w-4 h-4" />
                View Public Profile
              </Button>
            </Link>
          </div>

          {/* Quick Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-2 border-orange-100 hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Pending Requests</p>
                    <p className="text-3xl font-bold text-orange-600">{pendingRequests}</p>
                  </div>
                  <Inbox className="w-10 h-10 text-orange-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-100 hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Credentials Verified</p>
                    <p className="text-3xl font-bold text-green-600">
                      {credentials.filter(c => c.verification_status === "verified").length}
                    </p>
                  </div>
                  <CheckCircle className="w-10 h-10 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-yellow-100 hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Expiring Soon</p>
                    <p className="text-3xl font-bold text-yellow-600">{credentialsExpiringSoon}</p>
                  </div>
                  <Clock className="w-10 h-10 text-yellow-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-blue-100 hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Accepting Bookings</p>
                    <p className="text-3xl font-bold text-blue-600">
                      {availability?.accepting_bookings ? "Yes" : "No"}
                    </p>
                  </div>
                  <Calendar className="w-10 h-10 text-blue-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alerts */}
          {credentialsExpiringSoon > 0 && (
            <Alert className="mt-4 bg-yellow-50 border-yellow-200">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900">
                You have {credentialsExpiringSoon} credential{credentialsExpiringSoon !== 1 ? 's' : ''} expiring within 30 days.
                <Link to={createPageUrl("ProviderCredentials")} className="font-semibold underline ml-2">
                  Review credentials
                </Link>
              </AlertDescription>
            </Alert>
          )}

          {credentialsPending > 0 && (
            <Alert className="mt-4 bg-blue-50 border-blue-200">
              <Shield className="w-4 h-4 text-blue-600" />
              <AlertDescription className="text-blue-900">
                {credentialsPending} credential{credentialsPending !== 1 ? 's are' : ' is'} pending verification.
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white shadow-md rounded-xl p-1">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="requests" className="gap-2 relative">
              <Inbox className="w-4 h-4" />
              <span className="hidden sm:inline">Requests</span>
              {pendingRequests > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-orange-500 text-xs">
                  {pendingRequests}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="services" className="gap-2">
              <Briefcase className="w-4 h-4" />
              <span className="hidden sm:inline">Services</span>
            </TabsTrigger>
            <TabsTrigger value="availability" className="gap-2">
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">Availability</span>
            </TabsTrigger>
            <TabsTrigger value="credentials" className="gap-2">
              <Shield className="w-4 h-4" />
              <span className="hidden sm:inline">Credentials</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    className="w-full justify-start gap-3 h-auto py-4"
                    variant="outline"
                    onClick={() => setActiveTab("requests")}
                  >
                    <Inbox className="w-5 h-5 text-orange-600" />
                    <div className="text-left">
                      <div className="font-semibold">View Pending Requests</div>
                      <div className="text-xs text-gray-500">{pendingRequests} waiting for response</div>
                    </div>
                  </Button>

                  <Button 
                    className="w-full justify-start gap-3 h-auto py-4"
                    variant="outline"
                    onClick={() => setActiveTab("availability")}
                  >
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <div className="text-left">
                      <div className="font-semibold">Update Availability</div>
                      <div className="text-xs text-gray-500">Manage your schedule</div>
                    </div>
                  </Button>

                  <Link to={createPageUrl("ProviderProfile")}>
                    <Button className="w-full justify-start gap-3 h-auto py-4" variant="outline">
                      <Users className="w-5 h-5 text-green-600" />
                      <div className="text-left">
                        <div className="font-semibold">Edit Public Profile</div>
                        <div className="text-xs text-gray-500">Update your profile information</div>
                      </div>
                    </Button>
                  </Link>

                  <Link to={createPageUrl("ProviderCredentials")}>
                    <Button className="w-full justify-start gap-3 h-auto py-4" variant="outline">
                      <Shield className="w-5 h-5 text-purple-600" />
                      <div className="text-left">
                        <div className="font-semibold">Manage Credentials</div>
                        <div className="text-xs text-gray-500">Upload and verify documents</div>
                      </div>
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {serviceRequests.slice(0, 5).map(req => (
                      <div key={req.id} className="flex items-center gap-3 pb-3 border-b last:border-0">
                        <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center">
                          <Inbox className="w-4 h-4 text-orange-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            New {req.service_type?.replace(/_/g, ' ')} request
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(req.created_date).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant="outline" className="text-orange-600">Pending</Badge>
                      </div>
                    ))}
                    
                    {serviceRequests.length === 0 && (
                      <p className="text-sm text-gray-500 text-center py-6">
                        No recent activity
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Profile Completion */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Profile Completion</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Basic Information</span>
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Services & Pricing</span>
                      {currentUser?.services_offered ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <Badge variant="outline" className="text-orange-600">Incomplete</Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Credentials Verified</span>
                      {credentials.some(c => c.verification_status === "verified") ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <Badge variant="outline" className="text-orange-600">Pending</Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Availability Schedule</span>
                      {availability?.weekly_schedule ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <Badge variant="outline" className="text-orange-600">Not Set</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Requests Tab */}
          <TabsContent value="requests">
            <RequestsInboxTab />
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services">
            <ServiceManagementTab />
          </TabsContent>

          {/* Availability Tab */}
          <TabsContent value="availability">
            <AvailabilityTab />
          </TabsContent>

          {/* Credentials Tab */}
          <TabsContent value="credentials">
            <CredentialsTab />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <AnalyticsTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}