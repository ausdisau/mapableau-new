import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  MessageSquare, 
  Plus, 
  Search, 
  Pin,
  Lock,
  Eye,
  ThumbsUp,
  CheckCircle,
  Megaphone,
  TrendingUp,
  Clock,
  Users,
  Flame
} from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

const categories = [
  { value: "all", label: "All Topics", icon: MessageSquare, color: "blue" },
  { value: "general", label: "General Discussion", icon: MessageSquare, color: "gray" },
  { value: "transport", label: "Transport & Travel", icon: MessageSquare, color: "blue" },
  { value: "care_services", label: "Care Services", icon: MessageSquare, color: "green" },
  { value: "employment", label: "Employment", icon: MessageSquare, color: "orange" },
  { value: "accessibility", label: "Accessibility", icon: MessageSquare, color: "purple" },
  { value: "ndis_support", label: "NDIS Support", icon: MessageSquare, color: "indigo" },
  { value: "technology", label: "Technology Help", icon: MessageSquare, color: "teal" },
  { value: "events", label: "Events", icon: MessageSquare, color: "pink" },
  { value: "feedback", label: "Platform Feedback", icon: MessageSquare, color: "yellow" },
];

export default function ForumPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("recent");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["forumPosts"],
    queryFn: () => base44.entities.ForumPost.list("-created_date"),
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["forumComments"],
    queryFn: () => base44.entities.ForumComment.list(),
  });

  // Filter posts
  const filteredPosts = posts.filter(post => {
    if (post.status === "hidden") return false;
    
    const matchesSearch = !searchQuery || 
      post.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = categoryFilter === "all" || post.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  // Sort posts
  const sortedPosts = [...filteredPosts].sort((a, b) => {
    // Pinned posts always on top
    if (a.is_pinned && !b.is_pinned) return -1;
    if (!a.is_pinned && b.is_pinned) return 1;
    
    // Announcements next
    if (a.is_announcement && !b.is_announcement) return -1;
    if (!a.is_announcement && b.is_announcement) return 1;
    
    switch (sortBy) {
      case "recent":
        return new Date(b.last_activity_date || b.created_date) - new Date(a.last_activity_date || a.created_date);
      case "popular":
        return (b.like_count + b.comment_count * 2) - (a.like_count + a.comment_count * 2);
      case "oldest":
        return new Date(a.created_date) - new Date(b.created_date);
      case "unanswered":
        return (a.comment_count || 0) - (b.comment_count || 0);
      default:
        return 0;
    }
  });

  // Stats
  const totalPosts = posts.filter(p => p.status === "active").length;
  const totalComments = comments.filter(c => c.status === "active").length;
  const activeToday = posts.filter(p => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(p.created_date) >= today;
  }).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl font-bold text-primary">Community Forum</h1>
                  <p className="text-gray-600">Connect, share, and learn together</p>
                </div>
              </div>
            </div>
            <Link to={createPageUrl("CreateForumPost")}>
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 gap-2 shadow-lg">
                <Plus className="w-5 h-5" />
                New Post
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid sm:grid-cols-3 gap-4 mb-6">
            <Card className="border-2 border-indigo-100">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Total Discussions</p>
                    <p className="text-3xl font-bold text-indigo-600">{totalPosts}</p>
                  </div>
                  <MessageSquare className="w-10 h-10 text-indigo-400" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-purple-100">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Total Comments</p>
                    <p className="text-3xl font-bold text-purple-600">{totalComments}</p>
                  </div>
                  <Users className="w-10 h-10 text-purple-400" />
                </div>
              </CardContent>
            </Card>
            <Card className="border-2 border-pink-100">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 font-medium">Active Today</p>
                    <p className="text-3xl font-bold text-pink-600">{activeToday}</p>
                  </div>
                  <Flame className="w-10 h-10 text-pink-400" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search discussions, topics, or tags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12"
                />
              </div>
              
              <div className="grid sm:grid-cols-2 gap-4">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Recent Activity
                      </div>
                    </SelectItem>
                    <SelectItem value="popular">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        Most Popular
                      </div>
                    </SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="unanswered">Unanswered</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Category Tabs */}
        <Tabs value={categoryFilter} onValueChange={setCategoryFilter} className="mb-6">
          <TabsList className="w-full flex flex-wrap justify-start gap-2 bg-white p-3 rounded-lg shadow-sm">
            {categories.slice(0, 6).map(cat => (
              <TabsTrigger 
                key={cat.value} 
                value={cat.value}
                className="flex items-center gap-2"
              >
                <cat.icon className="w-4 h-4" />
                {cat.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Posts List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="text-gray-600 mt-4">Loading discussions...</p>
            </div>
          ) : sortedPosts.length === 0 ? (
            <Card className="border-2 border-dashed">
              <CardContent className="py-12 text-center">
                <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No discussions found</h3>
                <p className="text-gray-600 mb-4">
                  {searchQuery || categoryFilter !== "all" 
                    ? "Try adjusting your filters or search" 
                    : "Be the first to start a discussion!"}
                </p>
                <Link to={createPageUrl("CreateForumPost")}>
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create First Post
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            sortedPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link to={`${createPageUrl("ForumThread")}?id=${post.id}`}>
                  <Card className="hover:shadow-lg transition-all hover:border-indigo-200 cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex gap-4">
                        {/* Stats Column */}
                        <div className="flex flex-col items-center gap-2 min-w-[80px]">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-gray-900">{post.comment_count || 0}</div>
                            <div className="text-xs text-gray-500">replies</div>
                          </div>
                          <div className="text-center">
                            <div className="flex items-center gap-1 text-gray-600">
                              <Eye className="w-4 h-4" />
                              <span className="text-sm">{post.view_count || 0}</span>
                            </div>
                          </div>
                        </div>

                        {/* Content Column */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start gap-3 mb-2">
                            <div className="flex-1">
                              {/* Badges */}
                              <div className="flex items-center gap-2 mb-2">
                                {post.is_announcement && (
                                  <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                                    <Megaphone className="w-3 h-3 mr-1" />
                                    Announcement
                                  </Badge>
                                )}
                                {post.is_pinned && (
                                  <Badge className="bg-blue-100 text-blue-700">
                                    <Pin className="w-3 h-3 mr-1" />
                                    Pinned
                                  </Badge>
                                )}
                                {post.solved && (
                                  <Badge className="bg-green-100 text-green-700">
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Solved
                                  </Badge>
                                )}
                                {post.is_locked && (
                                  <Badge variant="outline">
                                    <Lock className="w-3 h-3 mr-1" />
                                    Locked
                                  </Badge>
                                )}
                                <Badge variant="outline" className="capitalize">
                                  {categories.find(c => c.value === post.category)?.label || post.category}
                                </Badge>
                              </div>

                              {/* Title */}
                              <h3 className="text-lg font-semibold text-gray-900 mb-2 hover:text-indigo-600 transition-colors">
                                {post.title}
                              </h3>

                              {/* Meta */}
                              <div className="flex items-center gap-4 text-sm text-gray-600">
                                <span>by <span className="font-medium">{post.author_name || "Anonymous"}</span></span>
                                <span>•</span>
                                <span>{format(new Date(post.created_date), "MMM d, yyyy")}</span>
                                {post.last_activity_date && post.last_activity_date !== post.created_date && (
                                  <>
                                    <span>•</span>
                                    <span className="text-indigo-600">
                                      Updated {format(new Date(post.last_activity_date), "MMM d")}
                                    </span>
                                  </>
                                )}
                              </div>

                              {/* Tags */}
                              {post.tags && post.tags.length > 0 && (
                                <div className="flex flex-wrap gap-2 mt-3">
                                  {post.tags.slice(0, 3).map((tag, idx) => (
                                    <Badge key={idx} variant="secondary" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Like Button */}
                            <div className="flex items-center gap-1 text-gray-600">
                              <ThumbsUp className="w-4 h-4" />
                              <span className="text-sm font-medium">{post.like_count || 0}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))
          )}
        </div>

        {/* Pagination info */}
        {sortedPosts.length > 0 && (
          <div className="mt-6 text-center text-sm text-gray-600">
            Showing {sortedPosts.length} of {filteredPosts.length} discussions
          </div>
        )}
      </div>
    </div>
  );
}