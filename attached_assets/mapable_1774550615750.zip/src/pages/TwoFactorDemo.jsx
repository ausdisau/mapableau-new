import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Smartphone, Key, CheckCircle, Info } from "lucide-react";
import TwoFactorSetup from "../components/auth/TwoFactorSetup";
import TwoFactorVerification from "../components/auth/TwoFactorVerification";
import TwoFactorSettings from "../components/auth/TwoFactorSettings";

export default function TwoFactorDemoPage() {
  const [demoStep, setDemoStep] = useState("setup");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: twoFactorAuth } = useQuery({
    queryKey: ["twoFactorAuth", currentUser?.email],
    queryFn: async () => {
      const results = await base44.entities.TwoFactorAuth.filter({ 
        user_email: currentUser?.email 
      });
      return results[0] || null;
    },
    enabled: !!currentUser?.email,
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-primary mb-2">
            Two-Factor Authentication Demo
          </h1>
          <p className="text-gray-600 text-lg">
            Experience the complete 2FA flow with TOTP and SMS options
          </p>
        </div>

        {/* Info Alert */}
        <Alert className="mb-8 bg-blue-50 border-blue-200 border-2">
          <Info className="w-5 h-5 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <p className="font-semibold mb-2">Demo Features:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>TOTP support (Google Authenticator, Authy, etc.)</li>
              <li>SMS-based verification (simulated via email)</li>
              <li>Backup recovery codes</li>
              <li>Trusted device management</li>
              <li>Account lockout after failed attempts</li>
              <li>Complete security settings interface</li>
            </ul>
          </AlertDescription>
        </Alert>

        {/* Demo Tabs */}
        <Tabs value={demoStep} onValueChange={setDemoStep} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="setup" className="gap-2">
              <Smartphone className="w-4 h-4" />
              Setup Flow
            </TabsTrigger>
            <TabsTrigger value="verification" className="gap-2">
              <Key className="w-4 h-4" />
              Verification Flow
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <CheckCircle className="w-4 h-4" />
              Settings Management
            </TabsTrigger>
          </TabsList>

          {/* Setup Flow */}
          <TabsContent value="setup">
            <Card>
              <CardHeader>
                <CardTitle>2FA Setup Wizard</CardTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Complete guided setup with choice of TOTP or SMS authentication
                </p>
              </CardHeader>
              <CardContent>
                <TwoFactorSetup
                  userEmail={currentUser?.email}
                  onComplete={() => {
                    setDemoStep("settings");
                  }}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Verification Flow */}
          <TabsContent value="verification">
            <Card>
              <CardHeader>
                <CardTitle>2FA Verification</CardTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Enter verification code (shown during login)
                </p>
              </CardHeader>
              <CardContent>
                {twoFactorAuth?.enabled ? (
                  <TwoFactorVerification
                    userEmail={currentUser?.email}
                    twoFactorAuth={twoFactorAuth}
                    onVerified={() => {
                      console.log("Verified!");
                      setDemoStep("settings");
                    }}
                  />
                ) : (
                  <Alert>
                    <Info className="w-4 h-4" />
                    <AlertDescription>
                      Please enable 2FA in the "Setup Flow" tab first to test verification.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Management */}
          <TabsContent value="settings">
            <TwoFactorSettings userEmail={currentUser?.email} />
          </TabsContent>
        </Tabs>

        {/* Implementation Guide */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Implementation Guide</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Components Created:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                <li><code className="bg-gray-100 px-2 py-0.5 rounded">TwoFactorSetup</code> - Setup wizard with TOTP/SMS options</li>
                <li><code className="bg-gray-100 px-2 py-0.5 rounded">TwoFactorVerification</code> - Login verification interface</li>
                <li><code className="bg-gray-100 px-2 py-0.5 rounded">TwoFactorSettings</code> - Manage 2FA in account settings</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Entity Created:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                <li><code className="bg-gray-100 px-2 py-0.5 rounded">TwoFactorAuth</code> - Stores 2FA settings, backup codes, trusted devices</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Utilities Created:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                <li><code className="bg-gray-100 px-2 py-0.5 rounded">utils/twoFactorUtils.js</code> - Helper functions for TOTP, SMS, codes, device fingerprinting</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Integration:</h3>
              <p className="text-sm text-gray-700">
                The <code className="bg-gray-100 px-2 py-0.5 rounded">TwoFactorSettings</code> component has been 
                integrated into the Account Settings page under a new "Security" tab.
              </p>
            </div>

            <Alert className="bg-yellow-50 border-yellow-200">
              <Info className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900 text-sm">
                <p className="font-semibold mb-1">Production Note:</p>
                SMS functionality currently sends codes via email for demonstration. 
                Replace with a real SMS provider (Twilio, AWS SNS, etc.) in production.
                TOTP verification should also be done server-side for security.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}