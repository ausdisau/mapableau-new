import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Workflow,
  Plus,
  Play,
  Pause,
  Edit,
  Trash2,
  Copy,
  Search,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  BarChart3,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import WorkflowBuilder from "../components/workflows/WorkflowBuilder";
import { hasPermission, MODULES, ACTIONS as PERM_ACTIONS, createPermission } from "@/utils/permissions";

// Workflow templates
const WORKFLOW_TEMPLATES = [
  {
    name: "Booking Confirmation",
    description: "Automatically send confirmation emails when bookings are created",
    category: "bookings",
    trigger: { type: "entity_created", entity: "TransportBooking" },
    actions: [
      {
        type: "send_email",
        config: {
          to: "{{booking.created_by}}",
          subject: "Booking Confirmed",
          body: "Your transport booking has been confirmed."
        }
      }
    ]
  },
  {
    name: "Credential Expiry Reminder",
    description: "Notify providers when credentials are about to expire",
    category: "credentials",
    trigger: { type: "scheduled", schedule: "daily" },
    actions: [
      {
        type: "send_notification",
        config: {
          message: "Your credential is expiring soon"
        }
      }
    ]
  },
  {
    name: "Driver Assignment Notification",
    description: "Notify participants when a driver is assigned",
    category: "bookings",
    trigger: { type: "entity_updated", entity: "TransportBooking" },
    actions: [
      {
        type: "send_notification",
        config: {
          message: "A driver has been assigned to your booking"
        }
      }
    ]
  }
];

export default function WorkflowManagerPage() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [showBuilder, setShowBuilder] = useState(false);
  const [editingWorkflow, setEditingWorkflow] = useState(null);
  const [showTemplates, setShowTemplates] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const canManage = hasPermission(
    currentUser,
    createPermission(MODULES.SETTINGS, PERM_ACTIONS.MANAGE)
  );

  const { data: workflows = [], isLoading } = useQuery({
    queryKey: ["workflows"],
    queryFn: () => base44.entities.WorkflowDefinition.list("-created_date"),
    enabled: canManage,
  });

  const { data: executions = [] } = useQuery({
    queryKey: ["workflowExecutions"],
    queryFn: () => base44.entities.WorkflowExecution.list("-created_date", 100),
    enabled: canManage,
  });

  const createWorkflowMutation = useMutation({
    mutationFn: (data) => base44.entities.WorkflowDefinition.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflows"] });
      setShowBuilder(false);
      setEditingWorkflow(null);
      toast.success("Workflow created successfully!");
    },
  });

  const updateWorkflowMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.WorkflowDefinition.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflows"] });
      setShowBuilder(false);
      setEditingWorkflow(null);
      toast.success("Workflow updated successfully!");
    },
  });

  const deleteWorkflowMutation = useMutation({
    mutationFn: (id) => base44.entities.WorkflowDefinition.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflows"] });
      toast.success("Workflow deleted");
    },
  });

  const toggleWorkflowMutation = useMutation({
    mutationFn: ({ id, enabled }) => base44.entities.WorkflowDefinition.update(id, { enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["workflows"] });
    },
  });

  const createFromTemplate = (template) => {
    createWorkflowMutation.mutate({
      ...template,
      is_template: false,
      enabled: false,
    });
    setShowTemplates(false);
  };

  const filteredWorkflows = workflows.filter(workflow => {
    const matchesSearch = !searchQuery ||
      workflow.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      workflow.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === "all" || workflow.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const stats = {
    total: workflows.length,
    enabled: workflows.filter(w => w.enabled).length,
    executions: executions.length,
    successful: executions.filter(e => e.status === "completed").length,
  };

  if (!canManage) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <AlertDescription className="text-red-900">
              You don't have permission to manage workflows.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Workflow className="w-8 h-8 text-purple-600" />
                <h1 className="text-4xl font-bold text-primary">
                  Workflow Automation
                </h1>
              </div>
              <p className="text-gray-600 text-lg">
                Automate common processes and streamline operations
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => setShowTemplates(true)}
                variant="outline"
                className="gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Templates
              </Button>
              <Button
                onClick={() => setShowBuilder(true)}
                className="bg-purple-600 hover:bg-purple-700 gap-2"
              >
                <Plus className="w-4 h-4" />
                Create Workflow
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Workflows</p>
                  <p className="text-3xl font-bold text-primary">{stats.total}</p>
                </div>
                <Workflow className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Active</p>
                  <p className="text-3xl font-bold text-green-600">{stats.enabled}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Executions</p>
                  <p className="text-3xl font-bold text-blue-600">{stats.executions}</p>
                </div>
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Success Rate</p>
                  <p className="text-3xl font-bold text-purple-600">
                    {stats.executions > 0 
                      ? Math.round((stats.successful / stats.executions) * 100) 
                      : 0}%
                  </p>
                </div>
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search workflows..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-4 py-2 border rounded-lg"
              >
                <option value="all">All Categories</option>
                <option value="user_management">User Management</option>
                <option value="credentials">Credentials</option>
                <option value="bookings">Bookings</option>
                <option value="support">Support</option>
                <option value="approvals">Approvals</option>
                <option value="notifications">Notifications</option>
                <option value="data_sync">Data Sync</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Workflows List */}
        <div className="space-y-4">
          {filteredWorkflows.map((workflow) => (
            <Card key={workflow.id} className="hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{workflow.name}</h3>
                      {workflow.enabled ? (
                        <Badge className="bg-green-100 text-green-700">Active</Badge>
                      ) : (
                        <Badge className="bg-gray-100 text-gray-700">Paused</Badge>
                      )}
                      <Badge variant="outline" className="capitalize">
                        {workflow.category?.replace(/_/g, " ")}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">{workflow.description}</p>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Zap className="w-4 h-4" />
                        {workflow.actions?.length || 0} actions
                      </span>
                      <span className="flex items-center gap-1">
                        <BarChart3 className="w-4 h-4" />
                        {workflow.execution_count || 0} runs
                      </span>
                      {workflow.last_executed && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          Last: {format(new Date(workflow.last_executed), "MMM d")}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        toggleWorkflowMutation.mutate({
                          id: workflow.id,
                          enabled: !workflow.enabled,
                        })
                      }
                    >
                      {workflow.enabled ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingWorkflow(workflow);
                        setShowBuilder(true);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        if (confirm("Delete this workflow?")) {
                          deleteWorkflowMutation.mutate(workflow.id);
                        }
                      }}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredWorkflows.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <Workflow className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  No workflows found
                </h3>
                <p className="text-gray-600 mb-4">
                  Create your first workflow or use a template
                </p>
                <Button
                  onClick={() => setShowBuilder(true)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Create Workflow
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Builder Dialog */}
      <Dialog open={showBuilder} onOpenChange={setShowBuilder}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingWorkflow ? "Edit Workflow" : "Create New Workflow"}
            </DialogTitle>
          </DialogHeader>
          <WorkflowBuilder
            workflow={editingWorkflow}
            onSave={(data) => {
              if (editingWorkflow) {
                updateWorkflowMutation.mutate({ id: editingWorkflow.id, data });
              } else {
                createWorkflowMutation.mutate(data);
              }
            }}
            onCancel={() => {
              setShowBuilder(false);
              setEditingWorkflow(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Templates Dialog */}
      <Dialog open={showTemplates} onOpenChange={setShowTemplates}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Workflow Templates</DialogTitle>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-4">
            {WORKFLOW_TEMPLATES.map((template, idx) => (
              <Card key={idx} className="hover-lift">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{template.name}</CardTitle>
                    <Badge variant="outline" className="capitalize">
                      {template.category.replace(/_/g, " ")}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">{template.description}</p>
                  <Button
                    size="sm"
                    onClick={() => createFromTemplate(template)}
                    className="w-full gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}