import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Eye } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PopularArticles({ articles }) {
  if (!articles || articles.length === 0) return null;

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <TrendingUp className="w-5 h-5 text-purple-600" />
          Popular Articles
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {articles.map((article, idx) => (
          <Link
            key={article.id}
            to={`${createPageUrl("HelpArticle")}?id=${article.id}`}
            className="flex items-start gap-3 p-3 rounded-lg hover:bg-white transition-colors group"
          >
            <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0 group-hover:bg-purple-200 transition-colors">
              <span className="text-xs font-bold text-purple-700">{idx + 1}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-gray-900 line-clamp-2 group-hover:text-purple-700 transition-colors">
                {article.title}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <span className="flex items-center gap-1 text-xs text-gray-600">
                  <Eye className="w-3 h-3" />
                  {article.view_count || 0} views
                </span>
              </div>
            </div>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}