import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, ThumbsUp, Clock } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function HelpArticleCard({ article, compact = false }) {
  const getCategoryColor = (category) => {
    const colors = {
      getting_started: "bg-blue-100 text-blue-700",
      ndis_funding: "bg-green-100 text-green-700",
      booking_services: "bg-purple-100 text-purple-700",
      finding_jobs: "bg-orange-100 text-orange-700",
      accessibility: "bg-teal-100 text-teal-700",
      troubleshooting: "bg-red-100 text-red-700",
      billing_payments: "bg-indigo-100 text-indigo-700"
    };
    return colors[category] || "bg-gray-100 text-gray-700";
  };

  const getCategoryLabel = (category) => {
    const labels = {
      getting_started: "Getting Started",
      ndis_funding: "NDIS Funding",
      booking_services: "Booking Services",
      finding_jobs: "Finding Jobs",
      accessibility: "Accessibility",
      troubleshooting: "Troubleshooting",
      billing_payments: "Billing & Payments"
    };
    return labels[category] || category;
  };

  // Get first paragraph or preview of content
  const getPreview = (content) => {
    if (!content) return "";
    const text = content.replace(/[#*_`]/g, '').trim();
    return text.length > 150 ? text.substring(0, 150) + "..." : text;
  };

  if (compact) {
    return (
      <Link to={`${createPageUrl("HelpArticle")}?id=${article.id}`}>
        <Card className="hover:shadow-md transition-all cursor-pointer border-l-4 border-l-blue-500">
          <CardContent className="py-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-primary mb-1 line-clamp-1">
                  {article.title}
                </h3>
                <div className="flex items-center gap-3 text-xs text-gray-600">
                  {article.view_count > 0 && (
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {article.view_count}
                    </span>
                  )}
                  {article.helpful_count > 0 && (
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3 h-3" />
                      {article.helpful_count}
                    </span>
                  )}
                </div>
              </div>
              <Badge className={getCategoryColor(article.category)} variant="secondary">
                {getCategoryLabel(article.category)}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  }

  return (
    <Link to={`${createPageUrl("HelpArticle")}?id=${article.id}`}>
      <Card className="hover:shadow-lg transition-all hover:scale-[1.01] cursor-pointer">
        <CardContent className="pt-6">
          <div className="flex items-start justify-between gap-3 mb-3">
            <Badge className={getCategoryColor(article.category)} variant="secondary">
              {getCategoryLabel(article.category)}
            </Badge>
            <div className="flex items-center gap-3 text-sm text-gray-600">
              {article.view_count > 0 && (
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {article.view_count}
                </span>
              )}
              {article.helpful_count > 0 && (
                <span className="flex items-center gap-1">
                  <ThumbsUp className="w-4 h-4" />
                  {article.helpful_count}
                </span>
              )}
            </div>
          </div>

          <h3 className="text-xl font-bold text-primary mb-2 line-clamp-2">
            {article.title}
          </h3>

          <p className="text-gray-700 mb-4 line-clamp-3">
            {getPreview(article.content)}
          </p>

          <div className="flex items-center justify-between pt-3 border-t">
            <div className="flex flex-wrap gap-1">
              {article.tags?.slice(0, 3).map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded"
                >
                  {tag}
                </span>
              ))}
            </div>
            {article.updated_date && (
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {format(new Date(article.updated_date), "MMM d, yyyy")}
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}