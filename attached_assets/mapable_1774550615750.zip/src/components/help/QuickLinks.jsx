import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Rocket,
  DollarSign,
  Car,
  Users,
  MapPin,
  Shield
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function QuickLinks() {
  const quickLinks = [
    {
      title: "Getting Started",
      description: "New to MapAble?",
      icon: Rocket,
      color: "blue",
      category: "getting_started"
    },
    {
      title: "NDIS Funding",
      description: "Budget & plans",
      icon: DollarSign,
      color: "green",
      category: "ndis_funding"
    },
    {
      title: "Book Transport",
      description: "How to book rides",
      icon: Car,
      color: "purple",
      category: "booking_services"
    },
    {
      title: "Find Jobs",
      description: "Employment help",
      icon: Users,
      color: "orange",
      category: "finding_jobs"
    },
    {
      title: "Accessibility",
      description: "Features & ratings",
      icon: MapPin,
      color: "teal",
      category: "accessibility"
    },
    {
      title: "Account & Security",
      description: "Settings & privacy",
      icon: Shield,
      color: "indigo",
      category: "troubleshooting"
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
      {quickLinks.map((link, idx) => (
        <Card
          key={idx}
          className="hover:shadow-lg transition-all hover:scale-105 cursor-pointer group"
        >
          <CardContent className="p-4 text-center">
            <div className={`w-12 h-12 rounded-xl bg-${link.color}-100 flex items-center justify-center mx-auto mb-3 group-hover:bg-${link.color}-200 transition-colors`}>
              <link.icon className={`w-6 h-6 text-${link.color}-600`} />
            </div>
            <h3 className="font-semibold text-sm text-gray-900 mb-1">
              {link.title}
            </h3>
            <p className="text-xs text-gray-600">
              {link.description}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}