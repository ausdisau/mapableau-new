import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Settings, Eye, EyeOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function WidgetCustomizer({ availableWidgets, visibleWidgets, onUpdateVisibility }) {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleWidget = (widgetId) => {
    const newVisibleWidgets = visibleWidgets.includes(widgetId)
      ? visibleWidgets.filter(id => id !== widgetId)
      : [...visibleWidgets, widgetId];
    
    onUpdateVisibility(newVisibleWidgets);
  };

  const visibleCount = visibleWidgets.length;
  const totalCount = availableWidgets.length;

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        variant="outline"
        className="gap-2"
      >
        <Settings className="w-4 h-4" />
        Customize Dashboard
        <Badge variant="secondary" className="ml-1">
          {visibleCount}/{totalCount}
        </Badge>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Customize Dashboard Widgets</DialogTitle>
            <DialogDescription>
              Select which widgets to display on your dashboard. You can also reorder them by dragging.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            {availableWidgets.map((widget) => {
              const isVisible = visibleWidgets.includes(widget.id);
              
              return (
                <div 
                  key={widget.id}
                  className={`flex items-start space-x-3 p-3 border rounded-lg transition-colors ${
                    isVisible ? 'bg-blue-50 border-blue-200' : 'bg-gray-50'
                  }`}
                >
                  <Checkbox
                    id={widget.id}
                    checked={isVisible}
                    onCheckedChange={() => handleToggleWidget(widget.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <Label 
                      htmlFor={widget.id} 
                      className="cursor-pointer flex items-center gap-2"
                    >
                      <widget.icon className="w-4 h-4" />
                      <span className="font-semibold">{widget.title}</span>
                      {isVisible ? (
                        <Eye className="w-3 h-3 text-blue-600 ml-auto" />
                      ) : (
                        <EyeOff className="w-3 h-3 text-gray-400 ml-auto" />
                      )}
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">{widget.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end gap-2 mt-6 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                onUpdateVisibility(availableWidgets.map(w => w.id));
              }}
            >
              Show All
            </Button>
            <Button
              onClick={() => setIsOpen(false)}
              className="bg-primary"
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}