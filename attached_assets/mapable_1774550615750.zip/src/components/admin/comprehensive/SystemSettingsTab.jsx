import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Settings,
  Database,
  Bell,
  Mail,
  Shield,
  Key,
  Link as LinkIcon,
  FileText
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function SystemSettingsTab() {
  return (
    <div className="space-y-6">
      <Alert className="bg-blue-50 border-blue-200">
        <AlertDescription className="text-blue-900">
          <strong>System Configuration</strong>
          <p className="text-sm mt-1">
            Access various system settings and configurations. Changes to these settings affect the entire platform.
          </p>
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 gap-6">
        {/* User Management */}
        <Card className="hover-lift cursor-pointer" onClick={() => window.location.href = createPageUrl("RoleManagement")}>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-purple-600" />
              Role Management
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Manage user roles, permissions, and access control settings
            </p>
            <Link to={createPageUrl("RoleManagement")}>
              <Button className="w-full">
                Configure Roles
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* RBAC Settings */}
        <Card className="hover-lift cursor-pointer" onClick={() => window.location.href = createPageUrl("RBACSettings")}>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Key className="w-6 h-6 text-blue-600" />
              RBAC Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Configure role-based access control and permission matrix
            </p>
            <Link to={createPageUrl("RBACSettings")}>
              <Button className="w-full">
                Manage Permissions
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* OAuth Settings */}
        <Card className="hover-lift cursor-pointer" onClick={() => window.location.href = createPageUrl("OAuthSettings")}>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <LinkIcon className="w-6 h-6 text-green-600" />
              OAuth Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Configure social login and OAuth integrations
            </p>
            <Link to={createPageUrl("OAuthSettings")}>
              <Button className="w-full">
                Configure OAuth
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Audit Logs */}
        <Card className="hover-lift cursor-pointer" onClick={() => window.location.href = createPageUrl("AuditLog")}>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-indigo-600" />
              Audit Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              View detailed system activity and audit trails
            </p>
            <Link to={createPageUrl("AuditLog")}>
              <Button className="w-full">
                View Audit Logs
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Bell className="w-6 h-6 text-amber-600" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Configure system-wide notification settings and templates
            </p>
            <Button className="w-full" variant="outline" disabled>
              Coming Soon
            </Button>
          </CardContent>
        </Card>

        {/* Email Templates */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Mail className="w-6 h-6 text-red-600" />
              Email Templates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Customize email templates for automated communications
            </p>
            <Button className="w-full" variant="outline" disabled>
              Coming Soon
            </Button>
          </CardContent>
        </Card>

        {/* Database Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Database className="w-6 h-6 text-gray-600" />
              Database
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Database backups, exports, and maintenance operations
            </p>
            <Button className="w-full" variant="outline" disabled>
              Coming Soon
            </Button>
          </CardContent>
        </Card>

        {/* System Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Settings className="w-6 h-6 text-slate-600" />
              General Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Platform name, logo, branding, and general configuration
            </p>
            <Button className="w-full" variant="outline" disabled>
              Coming Soon
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}