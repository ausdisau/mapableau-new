import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Flag,
  MessageSquare,
  MapPin,
  CheckCircle,
  XCircle,
  Eye,
  Star,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ContentModerationTab() {
  const queryClient = useQueryClient();
  const [selectedItem, setSelectedItem] = useState(null);
  const [showActionDialog, setShowActionDialog] = useState(false);
  const [actionType, setActionType] = useState("");
  const [actionNotes, setActionNotes] = useState("");

  const { data: reviews = [] } = useQuery({
    queryKey: ["allReviews"],
    queryFn: () => base44.entities.Review.list("-created_date", 100),
  });

  const { data: locations = [] } = useQuery({
    queryKey: ["allLocations"],
    queryFn: () => base44.entities.Location.list("-created_date", 100),
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["allMessages"],
    queryFn: () => base44.entities.Message.list("-created_date", 50),
  });

  // Delete review mutation
  const deleteReviewMutation = useMutation({
    mutationFn: async (reviewId) => {
      return await base44.entities.Review.delete(reviewId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allReviews"] });
      setShowActionDialog(false);
      setSelectedItem(null);
      toast.success("Review removed successfully!");
    },
  });

  // Delete location mutation
  const deleteLocationMutation = useMutation({
    mutationFn: async (locationId) => {
      return await base44.entities.Location.delete(locationId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allLocations"] });
      setShowActionDialog(false);
      setSelectedItem(null);
      toast.success("Location removed successfully!");
    },
  });

  const handleModerateAction = () => {
    if (actionType === "delete_review" && selectedItem) {
      deleteReviewMutation.mutate(selectedItem.id);
    } else if (actionType === "delete_location" && selectedItem) {
      deleteLocationMutation.mutate(selectedItem.id);
    }
  };

  // Filter potentially problematic content
  const suspiciousReviews = reviews.filter(r => 
    r.rating === 1 || 
    (r.content && r.content.length < 20) ||
    (r.content && /spam|scam|fake/i.test(r.content))
  );

  const unverifiedLocations = locations.filter(l => !l.verified);
  const lowRatedLocations = locations.filter(l => l.overall_score && l.overall_score < 30);

  return (
    <div className="space-y-6">
      {/* Overview */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="border-2 border-amber-200 bg-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-700 font-medium mb-1">Flagged Reviews</p>
                <p className="text-4xl font-bold text-amber-600">{suspiciousReviews.length}</p>
              </div>
              <Flag className="w-12 h-12 text-amber-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 font-medium mb-1">Unverified Locations</p>
                <p className="text-4xl font-bold text-blue-600">{unverifiedLocations.length}</p>
              </div>
              <MapPin className="w-12 h-12 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 font-medium mb-1">Low Rated Places</p>
                <p className="text-4xl font-bold text-red-600">{lowRatedLocations.length}</p>
              </div>
              <AlertTriangle className="w-12 h-12 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="reviews">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="reviews">
            <MessageSquare className="w-4 h-4 mr-2" />
            Reviews
          </TabsTrigger>
          <TabsTrigger value="locations">
            <MapPin className="w-4 h-4 mr-2" />
            Locations
          </TabsTrigger>
          <TabsTrigger value="messages">
            <MessageSquare className="w-4 h-4 mr-2" />
            Messages
          </TabsTrigger>
        </TabsList>

        {/* Reviews Tab */}
        <TabsContent value="reviews">
          <Card>
            <CardHeader>
              <CardTitle>Recent Reviews ({reviews.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reviews.slice(0, 20).map(review => (
                  <div key={review.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i}
                                className={`w-4 h-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                              />
                            ))}
                          </div>
                          {review.rating <= 2 && (
                            <Badge variant="outline" className="text-red-600 border-red-200">
                              <Flag className="w-3 h-3 mr-1" />
                              Low Rating
                            </Badge>
                          )}
                        </div>

                        {review.title && (
                          <h4 className="font-semibold mb-1">{review.title}</h4>
                        )}
                        
                        <p className="text-sm text-gray-700 mb-2 line-clamp-2">{review.content}</p>

                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span>By: {review.created_by}</span>
                          <span>•</span>
                          <span>{format(new Date(review.created_date), "MMM d, yyyy")}</span>
                          {review.helpful_count > 0 && (
                            <>
                              <span>•</span>
                              <span>{review.helpful_count} found helpful</span>
                            </>
                          )}
                        </div>
                      </div>

                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedItem(review);
                          setActionType("delete_review");
                          setShowActionDialog(true);
                        }}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <XCircle className="w-4 h-4 mr-1" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Locations Tab */}
        <TabsContent value="locations">
          <Card>
            <CardHeader>
              <CardTitle>Locations Requiring Review ({unverifiedLocations.length} unverified)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {unverifiedLocations.slice(0, 20).map(location => (
                  <div key={location.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{location.name}</h3>
                          {!location.verified && (
                            <Badge variant="outline" className="text-amber-600 border-amber-200">
                              Unverified
                            </Badge>
                          )}
                          {location.overall_score < 30 && (
                            <Badge variant="outline" className="text-red-600 border-red-200">
                              Low Score: {location.overall_score}
                            </Badge>
                          )}
                        </div>

                        <p className="text-sm text-gray-600 mb-2">{location.address}</p>
                        
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span>Category: {location.category}</span>
                          <span>•</span>
                          <span>Added: {format(new Date(location.created_date), "MMM d, yyyy")}</span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={async () => {
                            await base44.entities.Location.update(location.id, { verified: true });
                            queryClient.invalidateQueries({ queryKey: ["allLocations"] });
                            toast.success("Location verified!");
                          }}
                          className="text-green-600 hover:bg-green-50"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Verify
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedItem(location);
                            setActionType("delete_location");
                            setShowActionDialog(true);
                          }}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Messages Tab */}
        <TabsContent value="messages">
          <Card>
            <CardHeader>
              <CardTitle>Recent Messages ({messages.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {messages.slice(0, 20).map(message => (
                  <div key={message.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="font-semibold">{message.sender_email}</span>
                          <span className="text-gray-400">→</span>
                          <span className="text-gray-600">{message.recipient_email}</span>
                          {!message.read && (
                            <Badge variant="outline" className="text-blue-600 border-blue-200">
                              Unread
                            </Badge>
                          )}
                        </div>

                        <p className="text-sm text-gray-700 mb-2 line-clamp-2">{message.content}</p>

                        <p className="text-xs text-gray-500">
                          {format(new Date(message.created_date), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Action Confirmation Dialog */}
      <Dialog open={showActionDialog} onOpenChange={setShowActionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Moderation Action</DialogTitle>
          </DialogHeader>

          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-900">
              Are you sure you want to permanently delete this {actionType.includes("review") ? "review" : "location"}?
              This action cannot be undone.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <label className="text-sm font-medium">Reason for removal (optional)</label>
            <Textarea
              placeholder="Explain why this content is being removed..."
              value={actionNotes}
              onChange={(e) => setActionNotes(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              onClick={() => {
                setShowActionDialog(false);
                setSelectedItem(null);
                setActionNotes("");
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleModerateAction}
              disabled={deleteReviewMutation.isPending || deleteLocationMutation.isPending}
            >
              {(deleteReviewMutation.isPending || deleteLocationMutation.isPending) ? "Removing..." : "Confirm Removal"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}