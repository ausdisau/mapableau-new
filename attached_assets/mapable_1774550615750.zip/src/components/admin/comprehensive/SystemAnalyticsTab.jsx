import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  TrendingUp, 
  Users, 
  MapPin,
  Briefcase,
  Car,
  DollarSign,
  Star,
  Activity
} from "lucide-react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, subDays, startOfDay } from "date-fns";

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

export default function SystemAnalyticsTab() {
  const { data: users = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
  });

  const { data: locations = [] } = useQuery({
    queryKey: ["allLocations"],
    queryFn: () => base44.entities.Location.list(),
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ["allJobs"],
    queryFn: () => base44.entities.Job.list(),
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["allBookings"],
    queryFn: () => base44.entities.TransportBooking.list(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["allReviews"],
    queryFn: () => base44.entities.Review.list(),
  });

  // Calculate user growth over last 30 days
  const userGrowthData = [...Array(30)].map((_, i) => {
    const date = subDays(new Date(), 29 - i);
    const count = users.filter(u => 
      new Date(u.created_date) <= date
    ).length;
    
    return {
      date: format(date, "MMM d"),
      users: count
    };
  });

  // User type distribution
  const userTypeData = [
    { name: "Participants", value: users.filter(u => u.user_type === "participant").length },
    { name: "Providers", value: users.filter(u => u.user_type === "service_provider").length },
    { name: "Transport", value: users.filter(u => u.user_type === "transport_provider").length },
    { name: "Coordinators", value: users.filter(u => u.user_type === "support_coordinator").length },
  ].filter(d => d.value > 0);

  // Bookings by status
  const bookingStatusData = [
    { name: "Completed", value: bookings.filter(b => b.status === "completed").length },
    { name: "Active", value: bookings.filter(b => ["confirmed", "driver_assigned", "en_route_to_pickup"].includes(b.status)).length },
    { name: "Cancelled", value: bookings.filter(b => b.status === "cancelled").length },
  ].filter(d => d.value > 0);

  // Location categories
  const locationCategories = {};
  locations.forEach(loc => {
    locationCategories[loc.category] = (locationCategories[loc.category] || 0) + 1;
  });

  const locationCategoryData = Object.entries(locationCategories)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);

  // Calculate stats
  const totalRevenue = bookings
    .filter(b => b.status === "completed" && b.actual_cost)
    .reduce((sum, b) => sum + b.actual_cost, 0);

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  const activeJobs = jobs.filter(j => j.status === "active").length;

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total Users</p>
                <p className="text-3xl font-bold text-primary">{users.length}</p>
                <p className="text-xs text-green-600 mt-1">↑ {users.filter(u => new Date(u.created_date) > subDays(new Date(), 7)).length} this week</p>
              </div>
              <Users className="w-10 h-10 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total Bookings</p>
                <p className="text-3xl font-bold text-primary">{bookings.length}</p>
                <p className="text-xs text-gray-600 mt-1">{bookings.filter(b => b.status === "completed").length} completed</p>
              </div>
              <Car className="w-10 h-10 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total Revenue</p>
                <p className="text-3xl font-bold text-primary">${totalRevenue.toFixed(0)}</p>
                <p className="text-xs text-gray-600 mt-1">From completed trips</p>
              </div>
              <DollarSign className="w-10 h-10 text-amber-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Avg. Rating</p>
                <p className="text-3xl font-bold text-primary">{averageRating.toFixed(1)}</p>
                <p className="text-xs text-gray-600 mt-1">From {reviews.length} reviews</p>
              </div>
              <Star className="w-10 h-10 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* User Growth */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              User Growth (Last 30 Days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="users" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* User Type Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-green-600" />
              User Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={userTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {userTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Location Categories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-purple-600" />
              Top Location Categories
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={locationCategoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Booking Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-600" />
              Booking Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={bookingStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {bookingStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Activity Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Activity Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                Locations
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total:</span>
                  <span className="font-semibold">{locations.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Verified:</span>
                  <span className="font-semibold">{locations.filter(l => l.verified).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Unverified:</span>
                  <span className="font-semibold text-amber-600">{locations.filter(l => !l.verified).length}</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-green-600" />
                Jobs
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total:</span>
                  <span className="font-semibold">{jobs.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Active:</span>
                  <span className="font-semibold text-green-600">{activeJobs}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Filled:</span>
                  <span className="font-semibold">{jobs.filter(j => j.status === "filled").length}</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Star className="w-5 h-5 text-purple-600" />
                Reviews
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total:</span>
                  <span className="font-semibold">{reviews.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Average Rating:</span>
                  <span className="font-semibold">{averageRating.toFixed(1)} ⭐</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">This Week:</span>
                  <span className="font-semibold">{reviews.filter(r => new Date(r.created_date) > subDays(new Date(), 7)).length}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}