import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Car, 
  Search,
  MapPin,
  Calendar,
  User,
  DollarSign,
  Eye,
  XCircle
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function BookingManagementTab() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["allBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-created_date"),
  });

  const { data: drivers = [] } = useQuery({
    queryKey: ["allDrivers"],
    queryFn: () => base44.entities.Driver.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["allVehicles"],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const cancelBookingMutation = useMutation({
    mutationFn: async (bookingId) => {
      return await base44.entities.TransportBooking.update(bookingId, {
        status: "cancelled"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allBookings"] });
      toast.success("Booking cancelled successfully!");
    },
  });

  const getStatusColor = (status) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-700";
      case "confirmed": return "bg-blue-100 text-blue-700";
      case "driver_assigned": return "bg-purple-100 text-purple-700";
      case "cancelled": return "bg-red-100 text-red-700";
      case "no_show": return "bg-gray-100 text-gray-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const filteredBookings = bookings.filter(booking => {
    const matchesSearch = !searchQuery || 
      booking.passenger_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.pickup_location?.address?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || booking.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getDriver = (driverId) => drivers.find(d => d.id === driverId);
  const getVehicle = (vehicleId) => vehicles.find(v => v.id === vehicleId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search bookings by passenger name or location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="requested">Requested</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="driver_assigned">Driver Assigned</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Bookings List */}
      <Card>
        <CardHeader>
          <CardTitle>All Bookings ({filteredBookings.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredBookings.map(booking => {
              const driver = getDriver(booking.driver_id);
              const vehicle = getVehicle(booking.vehicle_id);

              return (
                <div key={booking.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h3 className="font-semibold text-lg">{booking.passenger_name}</h3>
                        <Badge className={getStatusColor(booking.status)}>
                          {booking.status}
                        </Badge>
                        {booking.is_recurring && (
                          <Badge variant="outline" className="text-blue-600 border-blue-200">
                            Recurring
                          </Badge>
                        )}
                      </div>

                      <div className="grid md:grid-cols-2 gap-3 text-sm mb-3">
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Pickup:</p>
                            <p className="text-gray-600">{booking.pickup_location?.address || "N/A"}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Drop-off:</p>
                            <p className="text-gray-600">{booking.dropoff_location?.address || "N/A"}</p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{format(new Date(booking.pickup_datetime), "MMM d, yyyy 'at' h:mm a")}</span>
                        </div>
                        {driver && (
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span>Driver: {driver.full_name}</span>
                          </div>
                        )}
                        {vehicle && (
                          <div className="flex items-center gap-2">
                            <Car className="w-4 h-4" />
                            <span>{vehicle.vehicle_name}</span>
                          </div>
                        )}
                        {booking.estimated_cost && (
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-4 h-4" />
                            <span>${booking.estimated_cost}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedBooking(booking);
                          setShowDetailsDialog(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                      {!["completed", "cancelled"].includes(booking.status) && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            if (confirm("Are you sure you want to cancel this booking?")) {
                              cancelBookingMutation.mutate(booking.id);
                            }
                          }}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Cancel
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredBookings.length === 0 && (
              <div className="text-center py-12">
                <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No bookings found matching your filters</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Booking Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
          </DialogHeader>

          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Passenger</p>
                  <p className="font-semibold">{selectedBooking.passenger_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Status</p>
                  <Badge className={getStatusColor(selectedBooking.status)}>
                    {selectedBooking.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Pickup Time</p>
                  <p className="font-semibold">
                    {format(new Date(selectedBooking.pickup_datetime), "MMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Booking Type</p>
                  <p className="font-semibold capitalize">{selectedBooking.booking_type}</p>
                </div>
              </div>

              {selectedBooking.special_instructions && (
                <div>
                  <p className="text-sm text-gray-600 mb-1">Special Instructions</p>
                  <p className="text-sm bg-gray-50 p-3 rounded">{selectedBooking.special_instructions}</p>
                </div>
              )}

              {selectedBooking.accessibility_requirements?.length > 0 && (
                <div>
                  <p className="text-sm text-gray-600 mb-1">Accessibility Requirements</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedBooking.accessibility_requirements.map((req, i) => (
                      <Badge key={i} variant="outline">{req}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}