import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  XCircle, 
  Clock,
  Eye,
  AlertTriangle,
  Shield,
  FileText,
  Calendar,
  User
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ProviderVerificationTab() {
  const queryClient = useQueryClient();
  const [selectedCredential, setSelectedCredential] = useState(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [reviewAction, setReviewAction] = useState("");
  const [reviewNotes, setReviewNotes] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: credentials = [], isLoading } = useQuery({
    queryKey: ["allCredentials"],
    queryFn: () => base44.entities.ProviderCredential.list("-submitted_date"),
  });

  const { data: providers = [] } = useQuery({
    queryKey: ["allProviders"],
    queryFn: () => base44.entities.ServiceProvider.list(),
  });

  // Review credential mutation
  const reviewCredentialMutation = useMutation({
    mutationFn: async ({ credentialId, status, notes }) => {
      return await base44.entities.ProviderCredential.update(credentialId, {
        verification_status: status,
        reviewed_by: currentUser.email,
        reviewed_date: new Date().toISOString(),
        ...(status === "rejected" ? { rejection_reason: notes } : {}),
        admin_notes: notes,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allCredentials"] });
      setShowReviewDialog(false);
      setSelectedCredential(null);
      setReviewNotes("");
      toast.success("Credential reviewed successfully!");
    },
  });

  const handleReview = () => {
    if (!selectedCredential || !reviewAction) return;
    
    reviewCredentialMutation.mutate({
      credentialId: selectedCredential.id,
      status: reviewAction,
      notes: reviewNotes,
    });
  };

  // Group credentials by status
  const pendingCredentials = credentials.filter(c => 
    c.verification_status === "submitted" || c.verification_status === "under_review"
  );
  const verifiedCredentials = credentials.filter(c => c.verification_status === "verified");
  const rejectedCredentials = credentials.filter(c => c.verification_status === "rejected");

  const getStatusColor = (status) => {
    switch (status) {
      case "verified": return "bg-green-100 text-green-700";
      case "rejected": return "bg-red-100 text-red-700";
      case "submitted": return "bg-blue-100 text-blue-700";
      case "under_review": return "bg-yellow-100 text-yellow-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "verified": return <CheckCircle className="w-4 h-4" />;
      case "rejected": return <XCircle className="w-4 h-4" />;
      case "submitted": 
      case "under_review": return <Clock className="w-4 h-4" />;
      default: return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="border-2 border-amber-200 bg-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-700 font-medium mb-1">Pending Review</p>
                <p className="text-4xl font-bold text-amber-600">{pendingCredentials.length}</p>
              </div>
              <Clock className="w-12 h-12 text-amber-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 font-medium mb-1">Verified</p>
                <p className="text-4xl font-bold text-green-600">{verifiedCredentials.length}</p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 font-medium mb-1">Rejected</p>
                <p className="text-4xl font-bold text-red-600">{rejectedCredentials.length}</p>
              </div>
              <XCircle className="w-12 h-12 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Credentials */}
      {pendingCredentials.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              Pending Verification ({pendingCredentials.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingCredentials.map(credential => (
                <div key={credential.id} className="border-2 border-amber-200 rounded-lg p-4 bg-amber-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="w-5 h-5 text-amber-600" />
                        <h3 className="font-semibold text-lg">{credential.credential_name}</h3>
                        <Badge className={getStatusColor(credential.verification_status)}>
                          {getStatusIcon(credential.verification_status)}
                          <span className="ml-1">{credential.verification_status}</span>
                        </Badge>
                      </div>

                      <div className="grid md:grid-cols-2 gap-2 text-sm text-gray-700 mb-3">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>Provider: {credential.provider_email}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          <span>Type: {credential.credential_type}</span>
                        </div>
                        {credential.issue_date && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>Issued: {format(new Date(credential.issue_date), "MMM d, yyyy")}</span>
                          </div>
                        )}
                        {credential.expiry_date && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>Expires: {format(new Date(credential.expiry_date), "MMM d, yyyy")}</span>
                          </div>
                        )}
                      </div>

                      {credential.credential_number && (
                        <p className="text-sm text-gray-600 mb-2">
                          <strong>Number:</strong> {credential.credential_number}
                        </p>
                      )}

                      {credential.issuing_organization && (
                        <p className="text-sm text-gray-600">
                          <strong>Issuing Org:</strong> {credential.issuing_organization}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-col gap-2 ml-4">
                      {credential.document_url && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(credential.document_url, "_blank")}
                          className="gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          View
                        </Button>
                      )}
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedCredential(credential);
                          setReviewAction("verified");
                          setShowReviewDialog(true);
                        }}
                        className="bg-green-600 hover:bg-green-700 gap-2"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          setSelectedCredential(credential);
                          setReviewAction("rejected");
                          setShowReviewDialog(true);
                        }}
                        className="gap-2"
                      >
                        <XCircle className="w-4 h-4" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {pendingCredentials.length === 0 && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">All Caught Up!</h3>
              <p className="text-gray-600">No pending credentials to review at this time.</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {reviewAction === "verified" ? "Approve Credential" : "Reject Credential"}
            </DialogTitle>
          </DialogHeader>

          {selectedCredential && (
            <div className="space-y-4">
              <Alert className={reviewAction === "verified" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
                <AlertDescription>
                  <p className="font-semibold mb-2">{selectedCredential.credential_name}</p>
                  <p className="text-sm">Provider: {selectedCredential.provider_email}</p>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {reviewAction === "verified" ? "Admin Notes (Optional)" : "Rejection Reason (Required)"}
                </label>
                <Textarea
                  placeholder={reviewAction === "verified" 
                    ? "Add any internal notes about this verification..." 
                    : "Explain why this credential is being rejected..."}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowReviewDialog(false);
                    setSelectedCredential(null);
                    setReviewNotes("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleReview}
                  disabled={reviewCredentialMutation.isPending || (reviewAction === "rejected" && !reviewNotes)}
                  className={reviewAction === "verified" ? "bg-green-600 hover:bg-green-700" : ""}
                >
                  {reviewCredentialMutation.isPending ? "Processing..." : "Confirm"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}