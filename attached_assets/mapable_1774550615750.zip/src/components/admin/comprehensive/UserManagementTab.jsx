import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Users, 
  Search, 
  Filter,
  UserX,
  UserCheck,
  Mail,
  Download,
  Upload,
  MoreVertical,
  Ban,
  CheckCircle,
  Shield,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { getAllRoles, getRoleLabel, getRoleColor } from "@/utils/permissions";
import AuditLogService from "../../audit/AuditLogService";

export default function UserManagementTab() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showBulkDialog, setShowBulkDialog] = useState(false);
  const [bulkAction, setBulkAction] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list("-created_date"),
  });

  // Bulk update mutation
  const bulkUpdateMutation = useMutation({
    mutationFn: async ({ userIds, updateData }) => {
      const promises = userIds.map(id => 
        base44.entities.User.update(id, updateData)
      );
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allUsers"] });
      setSelectedUsers([]);
      setShowBulkDialog(false);
      toast.success("Users updated successfully!");
    },
  });

  // Export users
  const handleExport = () => {
    const csv = [
      ["Email", "Name", "Role", "Status", "Created Date", "State"].join(","),
      ...filteredUsers.map(u => [
        u.email,
        u.full_name,
        u.role || "user",
        u.account_status || "active",
        format(new Date(u.created_date), "yyyy-MM-dd"),
        u.state || ""
      ].join(","))
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `users-export-${Date.now()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    toast.success("Users exported successfully!");
  };

  // Send bulk email
  const handleBulkEmail = async () => {
    const subject = prompt("Enter email subject:");
    if (!subject) return;

    const message = prompt("Enter email message:");
    if (!message) return;

    try {
      for (const userId of selectedUsers) {
        const user = allUsers.find(u => u.id === userId);
        if (user) {
          await base44.integrations.Core.SendEmail({
            to: user.email,
            subject: subject,
            body: message,
          });
        }
      }
      toast.success(`Email sent to ${selectedUsers.length} users!`);
      setSelectedUsers([]);
    } catch (error) {
      toast.error("Failed to send emails");
    }
  };

  // Handle bulk action
  const handleBulkAction = () => {
    if (bulkAction === "activate") {
      bulkUpdateMutation.mutate({
        userIds: selectedUsers,
        updateData: { account_status: "active" }
      });
    } else if (bulkAction === "suspend") {
      bulkUpdateMutation.mutate({
        userIds: selectedUsers,
        updateData: { account_status: "suspended" }
      });
    } else if (bulkAction === "email") {
      setShowBulkDialog(false);
      handleBulkEmail();
    }
  };

  // Filter users
  const filteredUsers = allUsers.filter(user => {
    const matchesSearch = !searchQuery || 
      user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    const matchesStatus = statusFilter === "all" || (user.account_status || "active") === statusFilter;
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  // Toggle user selection
  const toggleUserSelection = (userId) => {
    setSelectedUsers(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  // Select all
  const toggleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(u => u.id));
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="relative md:col-span-2">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search users by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {getAllRoles().map(role => (
                    <SelectItem key={role.value} value={role.value}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                  <SelectItem value="pending_verification">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Bulk Actions */}
            {selectedUsers.length > 0 && (
              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="flex items-center justify-between">
                  <span className="text-blue-900">
                    <strong>{selectedUsers.length}</strong> user{selectedUsers.length !== 1 ? 's' : ''} selected
                  </span>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setBulkAction("email");
                        handleBulkEmail();
                      }}
                      className="gap-2"
                    >
                      <Mail className="w-4 h-4" />
                      Email
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setBulkAction("activate");
                        setShowBulkDialog(true);
                      }}
                      className="gap-2"
                    >
                      <UserCheck className="w-4 h-4" />
                      Activate
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setBulkAction("suspend");
                        setShowBulkDialog(true);
                      }}
                      className="gap-2 text-red-600"
                    >
                      <UserX className="w-4 h-4" />
                      Suspend
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedUsers([])}
                    >
                      Clear
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                  onCheckedChange={toggleSelectAll}
                />
                <span className="text-sm text-gray-600">
                  Select all ({filteredUsers.length} users)
                </span>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleExport} className="gap-2">
                  <Download className="w-4 h-4" />
                  Export
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Users ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {filteredUsers.map(user => {
              const isSelected = selectedUsers.includes(user.id);
              
              return (
                <div 
                  key={user.id}
                  className={`flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors ${
                    isSelected ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                >
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => toggleUserSelection(user.id)}
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{user.full_name}</h3>
                      <Badge className={getRoleColor(user.role || "user")}>
                        {getRoleLabel(user.role || "user")}
                      </Badge>
                      {(user.account_status === "suspended" || user.account_status === "pending_verification") && (
                        <Badge variant="outline" className="text-red-600 border-red-200">
                          {user.account_status}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{user.email}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>Joined: {format(new Date(user.created_date), "MMM d, yyyy")}</span>
                      {user.state && <span>• State: {user.state}</span>}
                      {user.user_type && <span>• Type: {user.user_type}</span>}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={async () => {
                        const subject = prompt("Email subject:");
                        if (!subject) return;
                        const message = prompt("Email message:");
                        if (!message) return;
                        
                        try {
                          await base44.integrations.Core.SendEmail({
                            to: user.email,
                            subject: subject,
                            body: message,
                          });
                          toast.success("Email sent!");
                        } catch {
                          toast.error("Failed to send email");
                        }
                      }}
                    >
                      <Mail className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}

            {filteredUsers.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No users found matching your filters</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Bulk Action Confirmation Dialog */}
      <Dialog open={showBulkDialog} onOpenChange={setShowBulkDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Bulk Action</DialogTitle>
          </DialogHeader>
          <Alert className="bg-yellow-50 border-yellow-200">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-yellow-900">
              Are you sure you want to {bulkAction} {selectedUsers.length} user{selectedUsers.length !== 1 ? 's' : ''}?
            </AlertDescription>
          </Alert>
          <div className="flex justify-end gap-3 mt-4">
            <Button variant="outline" onClick={() => setShowBulkDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleBulkAction}
              disabled={bulkUpdateMutation.isPending}
            >
              {bulkUpdateMutation.isPending ? "Processing..." : "Confirm"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}