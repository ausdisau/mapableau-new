import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Users, Calendar } from "lucide-react";
import { format, subDays, isAfter } from "date-fns";

export default function NewUsersWidget() {
  const { data: users = [], isLoading } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list('-created_date'),
  });

  if (isLoading) {
    return <WidgetLoadingState />;
  }

  const now = new Date();
  const last7Days = subDays(now, 7);
  const last30Days = subDays(now, 30);

  const newUsersLast7Days = users.filter(u => 
    u.created_date && isAfter(new Date(u.created_date), last7Days)
  ).length;

  const newUsersLast30Days = users.filter(u => 
    u.created_date && isAfter(new Date(u.created_date), last30Days)
  ).length;

  const roleBreakdown = users
    .filter(u => u.created_date && isAfter(new Date(u.created_date), last30Days))
    .reduce((acc, user) => {
      const role = user.role || 'participant';
      acc[role] = (acc[role] || 0) + 1;
      return acc;
    }, {});

  const topRoles = Object.entries(roleBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  const recentUsers = users.slice(0, 5);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            <Badge variant="outline" className="text-xs">7 days</Badge>
          </div>
          <p className="text-3xl font-bold text-blue-900">{newUsersLast7Days}</p>
          <p className="text-xs text-blue-700">New Users</p>
        </div>

        <div className="bg-purple-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-5 h-5 text-purple-600" />
            <Badge variant="outline" className="text-xs">30 days</Badge>
          </div>
          <p className="text-3xl font-bold text-purple-900">{newUsersLast30Days}</p>
          <p className="text-xs text-purple-700">New Users</p>
        </div>
      </div>

      <div>
        <p className="text-sm font-semibold text-gray-700 mb-2">Top User Types (30 days)</p>
        <div className="space-y-2">
          {topRoles.length > 0 ? topRoles.map(([role, count]) => (
            <div key={role} className="flex items-center justify-between text-sm">
              <span className="text-gray-600 capitalize">{role.replace(/_/g, ' ')}</span>
              <Badge variant="secondary">{count}</Badge>
            </div>
          )) : (
            <p className="text-xs text-gray-500">No data available</p>
          )}
        </div>
      </div>

      <div>
        <p className="text-sm font-semibold text-gray-700 mb-2">Recent Sign-ups</p>
        <div className="space-y-2">
          {recentUsers.map((user) => (
            <div key={user.id} className="flex items-center justify-between text-xs p-2 bg-gray-50 rounded">
              <div className="flex items-center gap-2">
                <Users className="w-3 h-3 text-gray-400" />
                <span className="font-medium truncate max-w-[120px]">{user.full_name}</span>
              </div>
              <span className="text-gray-500">
                {user.created_date ? format(new Date(user.created_date), 'MMM d') : 'N/A'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function WidgetLoadingState() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="grid grid-cols-2 gap-4">
        <div className="h-24 bg-gray-200 rounded-lg" />
        <div className="h-24 bg-gray-200 rounded-lg" />
      </div>
      <div className="space-y-2">
        <div className="h-4 bg-gray-200 rounded" />
        <div className="h-4 bg-gray-200 rounded w-3/4" />
      </div>
    </div>
  );
}