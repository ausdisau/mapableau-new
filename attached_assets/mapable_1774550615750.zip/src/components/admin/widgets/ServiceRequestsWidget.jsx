import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Briefcase, Car, Users, TrendingUp } from "lucide-react";

export default function ServiceRequestsWidget() {
  const { data: serviceRequests = [], isLoading: loadingServices } = useQuery({
    queryKey: ['allServiceRequests'],
    queryFn: () => base44.entities.ServiceRequest.list('-created_date'),
  });

  const { data: transportBookings = [], isLoading: loadingTransport } = useQuery({
    queryKey: ['allTransportBookings'],
    queryFn: () => base44.entities.TransportBooking.list('-created_date'),
  });

  if (loadingServices || loadingTransport) {
    return <WidgetLoadingState />;
  }

  // Service Requests Stats
  const activeServices = serviceRequests.filter(s => 
    ['pending', 'confirmed'].includes(s.status)
  ).length;

  const completedServices = serviceRequests.filter(s => 
    s.status === 'completed'
  ).length;

  // Transport Bookings Stats
  const activeTransport = transportBookings.filter(b => 
    ['requested', 'confirmed', 'driver_assigned', 'en_route_to_pickup', 'passenger_on_board', 'in_transit'].includes(b.status)
  ).length;

  const completedTransport = transportBookings.filter(b => 
    b.status === 'completed'
  ).length;

  const totalActive = activeServices + activeTransport;
  const totalCompleted = completedServices + completedTransport;
  const totalRequests = totalActive + totalCompleted;
  const completionRate = totalRequests > 0 ? Math.round((totalCompleted / totalRequests) * 100) : 0;

  const categories = [
    {
      label: 'Care Services',
      icon: Users,
      active: activeServices,
      completed: completedServices,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: 'Transport',
      icon: Car,
      active: activeTransport,
      completed: completedTransport,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-3xl font-bold text-primary">{totalActive}</p>
          <p className="text-sm text-gray-600">Active Requests</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-semibold text-green-600">{completionRate}%</p>
          <p className="text-xs text-gray-500">Completion Rate</p>
        </div>
      </div>

      <Progress value={completionRate} className="h-2" />

      <div className="space-y-3">
        {categories.map((cat) => (
          <div key={cat.label} className={`${cat.bgColor} rounded-lg p-3`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <cat.icon className={`w-4 h-4 ${cat.color}`} />
                <span className="text-sm font-semibold text-gray-900">{cat.label}</span>
              </div>
              <Badge variant="secondary">{cat.active} active</Badge>
            </div>
            <div className="flex items-center justify-between text-xs text-gray-600">
              <span>Completed: {cat.completed}</span>
              <span>Total: {cat.active + cat.completed}</span>
            </div>
          </div>
        ))}
      </div>

      {totalActive > 0 && (
        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">
              {totalActive} requests in progress
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

function WidgetLoadingState() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-12 bg-gray-200 rounded" />
      <div className="h-2 bg-gray-200 rounded" />
      <div className="space-y-3">
        <div className="h-20 bg-gray-200 rounded" />
        <div className="h-20 bg-gray-200 rounded" />
      </div>
    </div>
  );
}