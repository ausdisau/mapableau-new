import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Users, MapPin, Briefcase, Car, Star, TrendingUp } from "lucide-react";

export default function PlatformStatsWidget() {
  const { data: users = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
  });

  const { data: locations = [] } = useQuery({
    queryKey: ['allLocations'],
    queryFn: () => base44.entities.Location.list(),
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ['allJobs'],
    queryFn: () => base44.entities.Job.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['allVehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['allReviews'],
    queryFn: () => base44.entities.Review.list(),
  });

  const stats = [
    {
      label: 'Total Users',
      value: users.length,
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      change: '+12%',
      trend: 'up'
    },
    {
      label: 'Locations',
      value: locations.length,
      icon: MapPin,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      verified: locations.filter(l => l.verified).length
    },
    {
      label: 'Job Listings',
      value: jobs.length,
      icon: Briefcase,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      active: jobs.filter(j => j.status === 'active').length
    },
    {
      label: 'Vehicles',
      value: vehicles.length,
      icon: Car,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
      available: vehicles.filter(v => v.status === 'available').length
    },
    {
      label: 'Reviews',
      value: reviews.length,
      icon: Star,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100',
      avgRating: reviews.length > 0 
        ? (reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length).toFixed(1)
        : '0.0'
    }
  ];

  // Calculate active users (users with activity in last 30 days)
  const activeUsers = users.filter(u => {
    if (!u.updated_date) return false;
    const daysSinceUpdate = Math.floor((Date.now() - new Date(u.updated_date).getTime()) / (1000 * 60 * 60 * 24));
    return daysSinceUpdate <= 30;
  }).length;

  const activeUserRate = users.length > 0 ? Math.round((activeUsers / users.length) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-gray-700">Active Users (30 days)</span>
          <TrendingUp className="w-4 h-4 text-blue-600" />
        </div>
        <div className="flex items-baseline gap-2">
          <p className="text-3xl font-bold text-blue-900">{activeUsers}</p>
          <span className="text-sm text-gray-600">/ {users.length} total</span>
        </div>
        <p className="text-xs text-blue-700 mt-1">{activeUserRate}% activity rate</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat) => (
          <div key={stat.label} className={`${stat.bgColor} rounded-lg p-3`}>
            <div className="flex items-center justify-between mb-2">
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
              {stat.change && (
                <span className="text-xs text-green-700 font-semibold">{stat.change}</span>
              )}
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600 mb-1">{stat.label}</p>
            {stat.verified !== undefined && (
              <p className="text-xs text-gray-500">{stat.verified} verified</p>
            )}
            {stat.active !== undefined && (
              <p className="text-xs text-gray-500">{stat.active} active</p>
            )}
            {stat.available !== undefined && (
              <p className="text-xs text-gray-500">{stat.available} available</p>
            )}
            {stat.avgRating !== undefined && (
              <p className="text-xs text-gray-500">Avg: {stat.avgRating} ⭐</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}