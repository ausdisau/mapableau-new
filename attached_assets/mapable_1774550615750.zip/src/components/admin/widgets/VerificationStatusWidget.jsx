import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Clock, XCircle, AlertCircle } from "lucide-react";

export default function VerificationStatusWidget() {
  const { data: credentials = [], isLoading } = useQuery({
    queryKey: ['allCredentials'],
    queryFn: () => base44.entities.ProviderCredential.list(),
  });

  if (isLoading) {
    return <WidgetLoadingState />;
  }

  const statusCounts = credentials.reduce((acc, cred) => {
    acc[cred.verification_status] = (acc[cred.verification_status] || 0) + 1;
    return acc;
  }, {});

  const verified = statusCounts.verified || 0;
  const pending = (statusCounts.submitted || 0) + (statusCounts.under_review || 0);
  const rejected = statusCounts.rejected || 0;
  const total = credentials.length;
  const verificationRate = total > 0 ? Math.round((verified / total) * 100) : 0;

  const stats = [
    { label: 'Verified', count: verified, icon: CheckCircle, color: 'text-green-600', bgColor: 'bg-green-100' },
    { label: 'Pending Review', count: pending, icon: Clock, color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
    { label: 'Rejected', count: rejected, icon: XCircle, color: 'text-red-600', bgColor: 'bg-red-100' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-3xl font-bold text-primary">{verified}</p>
          <p className="text-sm text-gray-600">Verified Credentials</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-semibold text-green-600">{verificationRate}%</p>
          <p className="text-xs text-gray-500">Verification Rate</p>
        </div>
      </div>

      <Progress value={verificationRate} className="h-2" />

      <div className="grid grid-cols-3 gap-3">
        {stats.map((stat) => (
          <div key={stat.label} className={`${stat.bgColor} rounded-lg p-3 text-center`}>
            <stat.icon className={`w-5 h-5 ${stat.color} mx-auto mb-1`} />
            <p className="text-2xl font-bold text-gray-900">{stat.count}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </div>
        ))}
      </div>

      {pending > 0 && (
        <div className="flex items-center gap-2 p-2 bg-yellow-50 rounded text-xs text-yellow-800">
          <AlertCircle className="w-4 h-4" />
          <span>{pending} credential{pending !== 1 ? 's' : ''} awaiting review</span>
        </div>
      )}
    </div>
  );
}

function WidgetLoadingState() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-12 bg-gray-200 rounded" />
      <div className="h-2 bg-gray-200 rounded" />
      <div className="grid grid-cols-3 gap-3">
        <div className="h-20 bg-gray-200 rounded" />
        <div className="h-20 bg-gray-200 rounded" />
        <div className="h-20 bg-gray-200 rounded" />
      </div>
    </div>
  );
}