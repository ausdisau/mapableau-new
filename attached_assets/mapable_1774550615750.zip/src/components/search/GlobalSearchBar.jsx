import React, { useState, useEffect, useRef, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Search, X, MapPin, Users, Briefcase, TrendingUp, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function GlobalSearchBar({ onSearchChange, onResultsOpen }) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef(null);
  const suggestionsRef = useRef(null);

  const { data: locations = [] } = useQuery({
    queryKey: ["locations"],
    queryFn: () => base44.entities.Location.list(),
  });

  const { data: providers = [] } = useQuery({
    queryKey: ["serviceProviders"],
    queryFn: () => base44.entities.ServiceProvider.list(),
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ["jobs"],
    queryFn: () => base44.entities.Job.filter({ status: "active" }),
  });

  // Get recent searches from localStorage
  const [recentSearches, setRecentSearches] = useState(() => {
    try {
      const saved = localStorage.getItem("mapable_recent_searches");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const suggestions = useMemo(() => {
    if (!query.trim()) return { locations: [], providers: [], jobs: [], total: 0 };
    
    const lowerQuery = query.toLowerCase();
    const results = {
      locations: [],
      providers: [],
      jobs: [],
      total: 0
    };

    // Search locations (limit to 4)
    locations.forEach(loc => {
      if (results.locations.length < 4 && (
        loc.name?.toLowerCase().includes(lowerQuery) ||
        loc.suburb?.toLowerCase().includes(lowerQuery) ||
        loc.address?.toLowerCase().includes(lowerQuery)
      )) {
        results.locations.push({
          type: "location",
          data: loc,
          label: loc.name,
          sublabel: `${loc.suburb}, ${loc.state}`,
          url: `${createPageUrl("LocationDetails")}?id=${loc.id}`
        });
      }
    });

    // Search providers (limit to 3)
    providers.forEach(prov => {
      if (results.providers.length < 3 && (
        prov.name?.toLowerCase().includes(lowerQuery) ||
        prov.bio?.toLowerCase().includes(lowerQuery)
      )) {
        results.providers.push({
          type: "provider",
          data: prov,
          label: prov.name,
          sublabel: prov.type?.replace(/_/g, " "),
          url: `${createPageUrl("ProviderProfile")}?id=${prov.id}`
        });
      }
    });

    // Search jobs (limit to 3)
    jobs.forEach(job => {
      if (results.jobs.length < 3 && (
        job.title?.toLowerCase().includes(lowerQuery) ||
        job.company?.toLowerCase().includes(lowerQuery)
      )) {
        results.jobs.push({
          type: "job",
          data: job,
          label: job.title,
          sublabel: job.company,
          url: `${createPageUrl("JobDetails")}?id=${job.id}`
        });
      }
    });

    results.total = results.locations.length + results.providers.length + results.jobs.length;
    return results;
  }, [query, locations, providers, jobs]);

  const allSuggestions = useMemo(() => {
    return [
      ...suggestions.locations,
      ...suggestions.providers,
      ...suggestions.jobs
    ];
  }, [suggestions]);

  useEffect(() => {
    onSearchChange(query);
    if (query.trim()) {
      setShowSuggestions(true);
      setSelectedIndex(-1);
    } else {
      setShowSuggestions(false);
    }
  }, [query, onSearchChange]);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        suggestionsRef.current &&
        !suggestionsRef.current.contains(event.target) &&
        !inputRef.current.contains(event.target)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleClear = () => {
    setQuery("");
    setShowSuggestions(false);
    inputRef.current?.focus();
  };

  const saveRecentSearch = (searchTerm) => {
    const updated = [searchTerm, ...recentSearches.filter(s => s !== searchTerm)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("mapable_recent_searches", JSON.stringify(updated));
  };

  const handleSelectSuggestion = (suggestion) => {
    saveRecentSearch(suggestion.label);
    setShowSuggestions(false);
    navigate(suggestion.url);
  };

  const handleKeyDown = (e) => {
    if (!showSuggestions || allSuggestions.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex(prev => 
        prev < allSuggestions.length - 1 ? prev + 1 : prev
      );
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
    } else if (e.key === "Enter" && selectedIndex >= 0) {
      e.preventDefault();
      handleSelectSuggestion(allSuggestions[selectedIndex]);
    } else if (e.key === "Escape") {
      setShowSuggestions(false);
    }
  };

  const handleViewAll = () => {
    saveRecentSearch(query);
    onResultsOpen(true, query, allSuggestions);
    setShowSuggestions(false);
  };

  const showRecentSearches = !query.trim() && recentSearches.length > 0 && isFocused;
  const showResults = query.trim() && suggestions.total > 0;
  const showNoResults = query.trim() && suggestions.total === 0;

  return (
    <div className="relative w-full">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 z-10" />
        <Input
          ref={inputRef}
          type="text"
          placeholder="Search locations, care providers, jobs..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => {
            setIsFocused(true);
            if (query.trim() || recentSearches.length > 0) {
              setShowSuggestions(true);
            }
          }}
          onBlur={() => setIsFocused(false)}
          onKeyDown={handleKeyDown}
          className="pl-10 pr-10 h-12 text-base bg-white/10 text-white placeholder:text-gray-300 border-white/20 focus:bg-white focus:text-gray-900 focus:placeholder:text-gray-400 transition-all"
          autoComplete="off"
        />
        {query && (
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClear}
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-10 w-10 text-gray-400 hover:text-gray-600 z-10"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Autocomplete Suggestions Dropdown */}
      {showSuggestions && (showRecentSearches || showResults || showNoResults) && (
        <Card
          ref={suggestionsRef}
          className="absolute top-full mt-2 w-full max-h-[500px] overflow-y-auto shadow-2xl z-50 border-2"
        >
          {/* Recent Searches */}
          {showRecentSearches && (
            <div className="p-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-2">
                <Clock className="w-4 h-4" />
                Recent Searches
              </div>
              <div className="space-y-1">
                {recentSearches.map((search, idx) => (
                  <button
                    key={idx}
                    onClick={() => setQuery(search)}
                    className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 transition-colors text-sm"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {showResults && (
            <>
              {/* Locations */}
              {suggestions.locations.length > 0 && (
                <div className="p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-2">
                    <MapPin className="w-4 h-4 text-secondary" />
                    Accessible Places
                  </div>
                  <div className="space-y-1">
                    {suggestions.locations.map((suggestion, idx) => {
                      const globalIndex = idx;
                      return (
                        <button
                          key={suggestion.data.id}
                          onClick={() => handleSelectSuggestion(suggestion)}
                          className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                            selectedIndex === globalIndex
                              ? "bg-secondary/10 border border-secondary"
                              : "hover:bg-gray-100"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-sm text-gray-900 truncate">
                                {suggestion.label}
                              </div>
                              <div className="text-xs text-gray-500 truncate">
                                {suggestion.sublabel}
                              </div>
                            </div>
                            <Badge variant="outline" className="ml-2 text-xs">
                              {suggestion.data.overall_score || 0}
                            </Badge>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {suggestions.locations.length > 0 && (suggestions.providers.length > 0 || suggestions.jobs.length > 0) && (
                <Separator />
              )}

              {/* Care Providers */}
              {suggestions.providers.length > 0 && (
                <div className="p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-2">
                    <Users className="w-4 h-4 text-secondary" />
                    Care Providers
                  </div>
                  <div className="space-y-1">
                    {suggestions.providers.map((suggestion, idx) => {
                      const globalIndex = suggestions.locations.length + idx;
                      return (
                        <button
                          key={suggestion.data.id}
                          onClick={() => handleSelectSuggestion(suggestion)}
                          className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                            selectedIndex === globalIndex
                              ? "bg-secondary/10 border border-secondary"
                              : "hover:bg-gray-100"
                          }`}
                        >
                          <div className="font-medium text-sm text-gray-900 truncate">
                            {suggestion.label}
                          </div>
                          <div className="text-xs text-gray-500 truncate">
                            {suggestion.sublabel}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {suggestions.providers.length > 0 && suggestions.jobs.length > 0 && (
                <Separator />
              )}

              {/* Jobs */}
              {suggestions.jobs.length > 0 && (
                <div className="p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-2">
                    <Briefcase className="w-4 h-4 text-secondary" />
                    Job Opportunities
                  </div>
                  <div className="space-y-1">
                    {suggestions.jobs.map((suggestion, idx) => {
                      const globalIndex = suggestions.locations.length + suggestions.providers.length + idx;
                      return (
                        <button
                          key={suggestion.data.id}
                          onClick={() => handleSelectSuggestion(suggestion)}
                          className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                            selectedIndex === globalIndex
                              ? "bg-secondary/10 border border-secondary"
                              : "hover:bg-gray-100"
                          }`}
                        >
                          <div className="font-medium text-sm text-gray-900 truncate">
                            {suggestion.label}
                          </div>
                          <div className="text-xs text-gray-500 truncate">
                            {suggestion.sublabel}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* View All Results */}
              <Separator />
              <div className="p-3">
                <Button
                  onClick={handleViewAll}
                  variant="outline"
                  className="w-full justify-center gap-2"
                >
                  <TrendingUp className="w-4 h-4" />
                  View All {suggestions.total} Results
                </Button>
              </div>
            </>
          )}

          {/* No Results */}
          {showNoResults && (
            <div className="p-6 text-center">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-gray-900 mb-1">
                No results found for "{query}"
              </p>
              <p className="text-xs text-gray-500">
                Try a different search term or check for typos
              </p>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}