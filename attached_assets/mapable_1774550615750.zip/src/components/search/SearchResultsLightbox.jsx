import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, MapPin, Users, Briefcase, Star, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import AccessibilityScore from "../shared/AccessibilityScore";

export default function SearchResultsLightbox({ isOpen, query, results, onClose }) {
  if (!isOpen) return null;

  const locationResults = results.filter(r => r.type === "location");
  const providerResults = results.filter(r => r.type === "provider");
  const jobResults = results.filter(r => r.type === "job");

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Lightbox */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed top-24 left-1/2 transform -translate-x-1/2 w-full max-w-4xl max-h-[80vh] z-50 px-4"
          >
            <Card className="shadow-2xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-primary to-secondary text-white pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">
                    Search Results for "{query}"
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>
                <p className="text-sm text-white/80 mt-2">
                  Found {results.length} result{results.length !== 1 ? 's' : ''} across MapAble
                </p>
              </CardHeader>

              <CardContent className="p-6 overflow-y-auto max-h-[calc(80vh-120px)]">
                {results.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500 text-lg">No results found</p>
                    <p className="text-gray-400 text-sm mt-2">Try adjusting your search terms</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Accessible Places */}
                    {locationResults.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <MapPin className="w-5 h-5 text-secondary" />
                          <h3 className="font-bold text-lg text-primary">
                            Accessible Places ({locationResults.length})
                          </h3>
                        </div>
                        <div className="grid gap-3">
                          {locationResults.map((result) => (
                            <Link
                              key={result.data.id}
                              to={`${createPageUrl("LocationDetails")}?id=${result.data.id}`}
                              onClick={onClose}
                            >
                              <Card className="hover-lift cursor-pointer">
                                <CardContent className="p-4">
                                  <div className="flex items-start gap-4">
                                    {result.data.photo_url && (
                                      <img
                                        src={result.data.photo_url}
                                        alt={result.data.name}
                                        className="w-20 h-20 rounded-lg object-cover"
                                      />
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-start justify-between gap-2">
                                        <div className="flex-1">
                                          <div className="flex items-center gap-2 mb-1">
                                            <h4 className="font-semibold text-primary">{result.data.name}</h4>
                                            {result.data.verified && (
                                              <CheckCircle className="w-4 h-4 text-secondary" />
                                            )}
                                          </div>
                                          <p className="text-sm text-gray-600 mb-2">
                                            {result.data.suburb}, {result.data.state}
                                          </p>
                                          <Badge variant="outline" className="text-xs">
                                            {result.data.category?.replace(/_/g, " ")}
                                          </Badge>
                                        </div>
                                        <AccessibilityScore score={result.data.overall_score || 0} size="sm" />
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Care Providers */}
                    {providerResults.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <Users className="w-5 h-5 text-secondary" />
                          <h3 className="font-bold text-lg text-primary">
                            Care Providers ({providerResults.length})
                          </h3>
                        </div>
                        <div className="grid gap-3">
                          {providerResults.map((result) => (
                            <Link
                              key={result.data.id}
                              to={`${createPageUrl("ProviderProfile")}?id=${result.data.id}`}
                              onClick={onClose}
                            >
                              <Card className="hover-lift cursor-pointer">
                                <CardContent className="p-4">
                                  <div className="flex items-center gap-3">
                                    {result.data.photo_url ? (
                                      <img
                                        src={result.data.photo_url}
                                        alt={result.data.name}
                                        className="w-16 h-16 rounded-full object-cover"
                                      />
                                    ) : (
                                      <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                                        <span className="text-white font-bold text-xl">
                                          {result.data.name?.charAt(0)}
                                        </span>
                                      </div>
                                    )}
                                    <div className="flex-1">
                                      <h4 className="font-semibold text-primary mb-1">{result.data.name}</h4>
                                      <div className="flex items-center gap-2 mb-1">
                                        {result.data.rating > 0 && (
                                          <div className="flex items-center gap-1">
                                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                            <span className="text-sm font-medium">{result.data.rating.toFixed(1)}</span>
                                          </div>
                                        )}
                                        {result.data.ndis_registered && (
                                          <Badge className="bg-green-100 text-green-700 text-xs">NDIS</Badge>
                                        )}
                                      </div>
                                      <Badge variant="outline" className="text-xs">
                                        {result.data.type?.replace(/_/g, " ")}
                                      </Badge>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Jobs */}
                    {jobResults.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <Briefcase className="w-5 h-5 text-secondary" />
                          <h3 className="font-bold text-lg text-primary">
                            Job Opportunities ({jobResults.length})
                          </h3>
                        </div>
                        <div className="grid gap-3">
                          {jobResults.map((result) => (
                            <Link
                              key={result.data.id}
                              to={`${createPageUrl("JobDetails")}?id=${result.data.id}`}
                              onClick={onClose}
                            >
                              <Card className="hover-lift cursor-pointer">
                                <CardContent className="p-4">
                                  <div className="flex items-start gap-3">
                                    <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center">
                                      <Briefcase className="w-6 h-6 text-white" />
                                    </div>
                                    <div className="flex-1">
                                      <h4 className="font-semibold text-primary mb-1">{result.data.title}</h4>
                                      <p className="text-sm text-gray-600 mb-2">{result.data.company}</p>
                                      <div className="flex flex-wrap gap-2">
                                        <Badge variant="outline" className="text-xs">
                                          {result.data.employment_type?.replace(/_/g, " ")}
                                        </Badge>
                                        {result.data.disability_confident && (
                                          <Badge className="bg-green-100 text-green-700 text-xs">
                                            <CheckCircle className="w-3 h-3 mr-1" />
                                            Disability Confident
                                          </Badge>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}