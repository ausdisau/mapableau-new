import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Sparkles,
  Loader2,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Clock,
  MapPin
} from "lucide-react";
import { format, parse } from "date-fns";

export default function RouteOptimizerEngine({
  bookings,
  vehicles,
  drivers,
  selectedDate,
  vehicleConstraints,
  onOptimized,
  isOptimizing,
  setIsOptimizing
}) {
  const [progress, setProgress] = useState(0);
  const [optimizationResult, setOptimizationResult] = useState(null);

  // Calculate distance between two points (Haversine formula)
  const calculateDistance = (loc1, loc2) => {
    const lat1 = loc1?.latitude || -33.8688;
    const lon1 = loc1?.longitude || 151.2093;
    const lat2 = loc2?.latitude || -33.8688;
    const lon2 = loc2?.longitude || 151.2093;

    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Check if driver is available at a specific time
  const isDriverAvailable = (driver, date, timeStr) => {
    const dayOfWeek = format(date, "EEEE").toLowerCase();
    const schedule = driver.availability_schedule?.[dayOfWeek];
    if (!schedule || schedule.length === 0) return false;
    if (driver.status === "off_duty" || !driver.active) return false;
    return true;
  };

  // Check vehicle capacity constraint
  const canVehicleHandle = (vehicle, bookings) => {
    const constraints = vehicleConstraints[vehicle.id] || {};
    const maxBookings = constraints.maxBookings || 10;
    const maxPassengers = vehicle.capacity?.standard_seats || 4;
    
    const totalPassengers = bookings.reduce((sum, b) => sum + (b.passenger_count || 1), 0);
    
    return bookings.length <= maxBookings && totalPassengers <= maxPassengers;
  };

  // Nearest neighbor algorithm with time windows
  const optimizeRoute = (bookings, vehicle, driver, startLocation) => {
    const unvisited = [...bookings];
    const route = [];
    let currentLocation = startLocation;
    let currentTime = new Date(`${selectedDate}T06:00:00`); // Start at 6 AM
    let totalDistance = 0;
    let totalDuration = 0;

    while (unvisited.length > 0) {
      let nearest = null;
      let minDistance = Infinity;
      let bestIndex = -1;

      // Find nearest unvisited booking
      for (let i = 0; i < unvisited.length; i++) {
        const booking = unvisited[i];
        const distance = calculateDistance(currentLocation, booking.pickup_location);
        
        // Check time window constraint
        const pickupTime = new Date(booking.pickup_datetime);
        const arrivalTime = new Date(currentTime.getTime() + (distance / 40) * 60 * 60 * 1000);
        const timeDiff = Math.abs(pickupTime - arrivalTime) / (1000 * 60); // minutes
        
        // Prefer bookings within 30 min of scheduled time
        const penalty = timeDiff > 30 ? timeDiff * 2 : 0;
        const adjustedDistance = distance + penalty;
        
        if (adjustedDistance < minDistance) {
          minDistance = adjustedDistance;
          nearest = booking;
          bestIndex = i;
        }
      }

      if (nearest) {
        const travelDistance = calculateDistance(currentLocation, nearest.pickup_location);
        const travelTime = (travelDistance / 40) * 60; // 40 km/h average speed
        
        const tripDistance = calculateDistance(nearest.pickup_location, nearest.dropoff_location);
        const tripTime = (tripDistance / 40) * 60;
        
        totalDistance += travelDistance + tripDistance;
        totalDuration += travelTime + tripTime + 10; // 10 min for pickup/dropoff
        
        route.push({
          booking: nearest,
          pickupDistance: travelDistance,
          tripDistance: tripDistance,
          estimatedPickupTime: new Date(currentTime.getTime() + travelTime * 60 * 1000),
          estimatedDropoffTime: new Date(currentTime.getTime() + (travelTime + tripTime) * 60 * 1000)
        });
        
        currentLocation = nearest.dropoff_location;
        currentTime = new Date(currentTime.getTime() + (travelTime + tripTime + 10) * 60 * 1000);
        unvisited.splice(bestIndex, 1);
      } else {
        break;
      }
    }

    return {
      route,
      totalDistance,
      totalDuration,
      unassigned: unvisited
    };
  };

  // Main optimization algorithm
  const runOptimization = async () => {
    setIsOptimizing(true);
    setProgress(0);

    try {
      const routes = [];
      let remainingBookings = [...bookings];
      
      // Sort vehicles by capacity (largest first)
      const sortedVehicles = [...vehicles]
        .filter(v => v.status === "available")
        .sort((a, b) => {
          const capA = a.capacity?.standard_seats || 0;
          const capB = b.capacity?.standard_seats || 0;
          return capB - capA;
        });

      setProgress(20);

      for (let i = 0; i < sortedVehicles.length && remainingBookings.length > 0; i++) {
        const vehicle = sortedVehicles[i];
        
        // Find available driver for this vehicle
        const availableDrivers = drivers.filter(d =>
          d.active &&
          isDriverAvailable(d, new Date(selectedDate), "06:00") &&
          (!d.current_vehicle_id || d.current_vehicle_id === vehicle.id)
        );

        if (availableDrivers.length === 0) continue;

        const driver = availableDrivers.sort((a, b) => 
          (b.total_trips || 0) - (a.total_trips || 0)
        )[0];

        // Get bookings this vehicle can handle
        const vehicleBookings = remainingBookings.filter(b => {
          // Check accessibility requirements
          const hasRequired = !b.accessibility_requirements || 
            b.accessibility_requirements.every(req =>
              vehicle.accessibility_features?.includes(req)
            );
          return hasRequired;
        });

        if (vehicleBookings.length === 0) continue;

        // Optimize route for this vehicle
        const baseLocation = vehicle.base_location || { latitude: -33.8688, longitude: 151.2093 };
        const optimization = optimizeRoute(vehicleBookings, vehicle, driver, baseLocation);

        if (optimization.route.length > 0) {
          const startTime = format(optimization.route[0].estimatedPickupTime, "HH:mm");
          const endTime = format(
            optimization.route[optimization.route.length - 1].estimatedDropoffTime,
            "HH:mm"
          );

          routes.push({
            id: `route-${routes.length + 1}`,
            vehicleId: vehicle.id,
            driverId: driver.id,
            vehicle,
            driver,
            bookings: optimization.route.map(r => r.booking),
            totalDistance: optimization.totalDistance,
            totalDuration: optimization.totalDuration,
            startTime,
            endTime,
            waypoints: optimization.route.flatMap(r => [
              {
                type: "pickup",
                location: r.booking.pickup_location,
                bookingId: r.booking.id,
                estimatedTime: r.estimatedPickupTime
              },
              {
                type: "dropoff",
                location: r.booking.dropoff_location,
                bookingId: r.booking.id,
                estimatedTime: r.estimatedDropoffTime
              }
            ]),
            efficiency: Math.round((1 - (optimization.totalDistance / (optimization.route.length * 20))) * 100)
          });

          // Remove assigned bookings
          remainingBookings = remainingBookings.filter(b =>
            !optimization.route.some(r => r.booking.id === b.id)
          );
        }

        setProgress(20 + ((i + 1) / sortedVehicles.length) * 70);
      }

      setProgress(100);

      const result = {
        success: true,
        routes,
        unassignedBookings: remainingBookings,
        stats: {
          totalBookings: bookings.length,
          assignedBookings: bookings.length - remainingBookings.length,
          totalRoutes: routes.length,
          totalDistance: routes.reduce((sum, r) => sum + r.totalDistance, 0),
          totalDuration: routes.reduce((sum, r) => sum + r.totalDuration, 0),
          averageEfficiency: routes.length > 0
            ? Math.round(routes.reduce((sum, r) => sum + r.efficiency, 0) / routes.length)
            : 0
        }
      };

      setOptimizationResult(result);
      onOptimized(routes);

    } catch (error) {
      console.error("Optimization error:", error);
      setOptimizationResult({
        success: false,
        error: error.message
      });
    }

    setIsOptimizing(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <CardTitle>AI Route Optimization</CardTitle>
          </div>
          {optimizationResult?.success && (
            <Badge className="bg-green-100 text-green-700">
              <CheckCircle className="w-3 h-3 mr-1" />
              Optimized
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <TrendingUp className="w-4 h-4" />
          <AlertDescription className="text-sm">
            Our AI analyzes {bookings.length} bookings, {vehicles.filter(v => v.status === "available").length} vehicles,
            and {drivers.filter(d => d.active).length} drivers to create the most efficient routes.
            Factors include time windows, capacity, accessibility requirements, and driver availability.
          </AlertDescription>
        </Alert>

        {/* Bookings Summary */}
        <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{bookings.length}</p>
            <p className="text-xs text-gray-600">Total Bookings</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">
              {vehicles.filter(v => v.status === "available").length}
            </p>
            <p className="text-xs text-gray-600">Available Vehicles</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">
              {drivers.filter(d => d.active).length}
            </p>
            <p className="text-xs text-gray-600">Active Drivers</p>
          </div>
        </div>

        {/* Optimization Button */}
        {!isOptimizing && !optimizationResult && (
          <Button
            onClick={runOptimization}
            className="w-full bg-purple-600 hover:bg-purple-700 h-12 text-base gap-2"
            disabled={bookings.length === 0}
          >
            <Sparkles className="w-5 h-5" />
            Optimize Routes
          </Button>
        )}

        {/* Progress */}
        {isOptimizing && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Optimizing routes...</span>
              <span className="font-semibold">{progress}%</span>
            </div>
            <Progress value={progress} className="h-3" />
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>
                {progress < 20 && "Analyzing bookings..."}
                {progress >= 20 && progress < 90 && "Assigning vehicles and optimizing routes..."}
                {progress >= 90 && "Finalizing..."}
              </span>
            </div>
          </div>
        )}

        {/* Results */}
        {optimizationResult?.success && (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-green-900">Optimization Complete!</p>
                  <p className="text-sm text-green-700 mt-1">
                    Generated {optimizationResult.stats.totalRoutes} optimized routes covering{" "}
                    {optimizationResult.stats.assignedBookings} of {optimizationResult.stats.totalBookings} bookings
                  </p>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <p className="text-xs text-blue-600 font-medium">Total Distance</p>
                </div>
                <p className="text-2xl font-bold text-blue-900">
                  {optimizationResult.stats.totalDistance.toFixed(1)} km
                </p>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <p className="text-xs text-purple-600 font-medium">Total Duration</p>
                </div>
                <p className="text-2xl font-bold text-purple-900">
                  {Math.round(optimizationResult.stats.totalDuration)} min
                </p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <p className="text-xs text-green-600 font-medium">Efficiency</p>
                </div>
                <p className="text-2xl font-bold text-green-900">
                  {optimizationResult.stats.averageEfficiency}%
                </p>
              </div>
              <div className="p-3 bg-yellow-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-yellow-600" />
                  <p className="text-xs text-yellow-600 font-medium">Cost Savings</p>
                </div>
                <p className="text-2xl font-bold text-yellow-900">
                  ${(optimizationResult.stats.totalDistance * 0.15 * 0.3).toFixed(0)}
                </p>
              </div>
            </div>

            {optimizationResult.unassignedBookings.length > 0 && (
              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
                <AlertDescription>
                  <span className="font-semibold text-yellow-900">
                    {optimizationResult.unassignedBookings.length} booking(s) could not be assigned
                  </span>
                  <p className="text-sm text-yellow-700 mt-1">
                    Insufficient vehicles, capacity constraints, or accessibility requirements not met
                  </p>
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={() => {
                setOptimizationResult(null);
                setProgress(0);
              }}
              variant="outline"
              className="w-full gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Re-optimize
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}