import React, { useState } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup } from "react-leaflet";
import L from "leaflet";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Car, Clock, TrendingUp } from "lucide-react";
import "leaflet/dist/leaflet.css";

const routeColors = [
  "#EF4444", "#F59E0B", "#10B981", "#3B82F6", "#8B5CF6",
  "#EC4899", "#14B8A6", "#F97316", "#06B6D4", "#6366F1"
];

const createNumberedIcon = (number, color) => {
  return L.divIcon({
    className: "custom-numbered-marker",
    html: `
      <div style="
        width: 32px;
        height: 32px;
        background: ${color};
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: white;
        font-size: 14px;
      ">
        ${number}
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

export default function OptimizedRouteMap({
  routes,
  vehicles,
  drivers,
  onRouteSelect,
  selectedRoute
}) {
  const [visibleRoutes, setVisibleRoutes] = useState(
    routes.reduce((acc, r) => ({ ...acc, [r.id]: true }), {})
  );

  const defaultCenter = [-33.8688, 151.2093]; // Sydney

  const toggleRouteVisibility = (routeId) => {
    setVisibleRoutes(prev => ({
      ...prev,
      [routeId]: !prev[routeId]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-4 gap-6">
        {/* Map */}
        <div className="lg:col-span-3">
          <Card>
            <CardContent className="p-0">
              <div className="h-[600px] rounded-lg overflow-hidden">
                <MapContainer
                  center={defaultCenter}
                  zoom={12}
                  className="w-full h-full"
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; OpenStreetMap'
                  />

                  {routes.map((route, routeIndex) => {
                    if (!visibleRoutes[route.id]) return null;
                    
                    const color = routeColors[routeIndex % routeColors.length];
                    const polylineCoords = route.waypoints.map(w => [
                      w.location.latitude || defaultCenter[0],
                      w.location.longitude || defaultCenter[1]
                    ]);

                    return (
                      <React.Fragment key={route.id}>
                        {/* Route polyline */}
                        <Polyline
                          positions={polylineCoords}
                          color={color}
                          weight={selectedRoute?.id === route.id ? 6 : 4}
                          opacity={selectedRoute?.id === route.id ? 0.9 : 0.6}
                        />

                        {/* Waypoint markers */}
                        {route.waypoints.map((waypoint, wpIndex) => (
                          <Marker
                            key={`${route.id}-wp-${wpIndex}`}
                            position={[
                              waypoint.location.latitude || defaultCenter[0],
                              waypoint.location.longitude || defaultCenter[1]
                            ]}
                            icon={createNumberedIcon(wpIndex + 1, color)}
                          >
                            <Popup>
                              <div className="p-2">
                                <p className="font-semibold text-sm mb-1">
                                  Stop #{wpIndex + 1} - {waypoint.type}
                                </p>
                                <p className="text-xs text-gray-600">
                                  {waypoint.location.address || waypoint.location.suburb}
                                </p>
                                {waypoint.estimatedTime && (
                                  <p className="text-xs text-gray-500 mt-1">
                                    ETA: {new Date(waypoint.estimatedTime).toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </p>
                                )}
                              </div>
                            </Popup>
                          </Marker>
                        ))}
                      </React.Fragment>
                    );
                  })}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Route List Sidebar */}
        <div className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-4">Routes</h3>
              <div className="space-y-3 max-h-[550px] overflow-y-auto">
                {routes.map((route, index) => {
                  const color = routeColors[index % routeColors.length];
                  const isVisible = visibleRoutes[route.id];
                  const isSelected = selectedRoute?.id === route.id;

                  return (
                    <div
                      key={route.id}
                      className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                        isSelected
                          ? "border-purple-500 bg-purple-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => onRouteSelect(route)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: color }}
                          />
                          <span className="font-semibold text-sm">Route {index + 1}</span>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleRouteVisibility(route.id);
                          }}
                          className="h-6 px-2 text-xs"
                        >
                          {isVisible ? "Hide" : "Show"}
                        </Button>
                      </div>

                      <div className="space-y-1 text-xs">
                        <div className="flex items-center gap-1 text-gray-600">
                          <Car className="w-3 h-3" />
                          <span>{route.vehicle?.vehicle_name}</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-600">
                          <MapPin className="w-3 h-3" />
                          <span>{route.bookings.length} stops</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-600">
                          <Clock className="w-3 h-3" />
                          <span>{Math.round(route.totalDuration)} min</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-600">
                          <TrendingUp className="w-3 h-3" />
                          <span>{route.totalDistance.toFixed(1)} km</span>
                        </div>
                      </div>

                      <div className="mt-2 pt-2 border-t">
                        <Badge
                          className={
                            route.efficiency >= 70
                              ? "bg-green-100 text-green-700"
                              : route.efficiency >= 50
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-red-100 text-red-700"
                          }
                        >
                          {route.efficiency}% efficient
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Selected Route Details */}
      {selectedRoute && (
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold text-lg mb-4">
              Route Details - {selectedRoute.vehicle?.vehicle_name}
            </h3>
            
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-600 mb-1">Driver</p>
                <p className="font-semibold text-blue-900">{selectedRoute.driver?.full_name}</p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-xs text-green-600 mb-1">Shift Time</p>
                <p className="font-semibold text-green-900">
                  {selectedRoute.startTime} - {selectedRoute.endTime}
                </p>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <p className="text-xs text-purple-600 mb-1">Total Bookings</p>
                <p className="font-semibold text-purple-900">{selectedRoute.bookings.length}</p>
              </div>
              <div className="p-3 bg-yellow-50 rounded-lg">
                <p className="text-xs text-yellow-600 mb-1">Efficiency</p>
                <p className="font-semibold text-yellow-900">{selectedRoute.efficiency}%</p>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium text-sm mb-3">Stop Sequence</h4>
              {selectedRoute.waypoints.map((waypoint, index) => (
                <div key={index} className="flex items-start gap-3 p-2 hover:bg-gray-50 rounded">
                  <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={waypoint.type === "pickup" ? "default" : "secondary"} className="text-xs">
                        {waypoint.type}
                      </Badge>
                      {waypoint.estimatedTime && (
                        <span className="text-xs text-gray-500">
                          {new Date(waypoint.estimatedTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      )}
                    </div>
                    <p className="text-sm">{waypoint.location.address || waypoint.location.suburb}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}