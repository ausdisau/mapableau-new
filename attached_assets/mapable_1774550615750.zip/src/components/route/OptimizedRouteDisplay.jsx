import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, ArrowDown, Clock, Navigation } from "lucide-react";

export default function OptimizedRouteDisplay({ route }) {
  const { stops } = route;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Step-by-Step Route</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {stops.map((stop, index) => (
            <div key={index}>
              <div className="flex items-start gap-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex flex-col items-center">
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                      stop.type === 'pickup' ? 'bg-green-500' : 'bg-red-500'
                    }`}
                  >
                    {index + 1}
                  </div>
                  {index < stops.length - 1 && (
                    <div className="w-0.5 h-8 bg-blue-300 my-1"></div>
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge className={stop.type === 'pickup' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                      {stop.type === 'pickup' ? 'Pickup' : 'Drop-off'}
                    </Badge>
                    <span className="font-semibold text-sm">{stop.passenger}</span>
                  </div>

                  <div className="flex items-start gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">
                        {stop.location.address || stop.location.suburb}
                      </p>
                      {stop.location.notes && (
                        <p className="text-xs text-gray-500 mt-1">Note: {stop.location.notes}</p>
                      )}
                    </div>
                  </div>

                  {stop.distanceFromPrevious > 0 && (
                    <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Navigation className="w-3 h-3" />
                        <span>{stop.distanceFromPrevious.toFixed(1)} km</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>~{stop.estimatedTimeFromPrevious.toFixed(0)} min</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {index < stops.length - 1 && (
                <div className="flex items-center gap-2 py-2 pl-6 text-xs text-blue-600">
                  <ArrowDown className="w-4 h-4" />
                  <span>Continue to next stop</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}