import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Settings } from "lucide-react";

export default function VehicleConstraintsForm({ vehicles, onConstraintsChange }) {
  const [constraints, setConstraints] = useState({});

  const updateConstraint = (vehicleId, field, value) => {
    const newConstraints = {
      ...constraints,
      [vehicleId]: {
        ...constraints[vehicleId],
        [field]: value
      }
    };
    setConstraints(newConstraints);
    onConstraintsChange(newConstraints);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Settings className="w-5 h-5 text-gray-600" />
          <CardTitle className="text-lg">Vehicle Constraints</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-600">
          Set specific constraints for each vehicle to customize the optimization
        </p>
        
        <div className="space-y-4 max-h-[400px] overflow-y-auto">
          {vehicles
            .filter(v => v.status === "available")
            .map(vehicle => (
              <div key={vehicle.id} className="p-3 border rounded-lg space-y-3">
                <p className="font-semibold text-sm">{vehicle.vehicle_name}</p>
                
                <div className="space-y-2">
                  <div>
                    <Label className="text-xs">Max Bookings</Label>
                    <Input
                      type="number"
                      min="1"
                      max="20"
                      defaultValue={10}
                      onChange={(e) =>
                        updateConstraint(vehicle.id, "maxBookings", parseInt(e.target.value))
                      }
                      className="h-8 text-sm"
                    />
                  </div>

                  <div>
                    <Label className="text-xs">Max Hours</Label>
                    <Input
                      type="number"
                      min="1"
                      max="12"
                      defaultValue={8}
                      onChange={(e) =>
                        updateConstraint(vehicle.id, "maxHours", parseInt(e.target.value))
                      }
                      className="h-8 text-sm"
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`wheelchair-${vehicle.id}`}
                      onCheckedChange={(checked) =>
                        updateConstraint(vehicle.id, "wheelchairOnly", checked)
                      }
                    />
                    <label
                      htmlFor={`wheelchair-${vehicle.id}`}
                      className="text-xs font-medium cursor-pointer"
                    >
                      Wheelchair bookings only
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`priority-${vehicle.id}`}
                      onCheckedChange={(checked) =>
                        updateConstraint(vehicle.id, "priorityVehicle", checked)
                      }
                    />
                    <label
                      htmlFor={`priority-${vehicle.id}`}
                      className="text-xs font-medium cursor-pointer"
                    >
                      Priority vehicle (assign first)
                    </label>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
}