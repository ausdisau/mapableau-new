import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Edit, 
  Trash2, 
  Plus,
  ArrowUpDown,
  Save,
  AlertTriangle,
  CheckCircle
} from "lucide-react";

export default function RouteManualAdjustment({
  routes,
  vehicles,
  drivers,
  bookings,
  onRouteUpdate
}) {
  const [selectedRouteId, setSelectedRouteId] = useState(routes[0]?.id);
  const [draggedBooking, setDraggedBooking] = useState(null);

  const selectedRoute = routes.find(r => r.id === selectedRouteId);
  const unassignedBookings = bookings.filter(b =>
    !routes.some(r => r.bookings.some(rb => rb.id === b.id))
  );

  const handleDragStart = (e, booking, sourceRouteId) => {
    setDraggedBooking({ booking, sourceRouteId });
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e, targetRouteId) => {
    e.preventDefault();
    if (!draggedBooking) return;

    const { booking, sourceRouteId } = draggedBooking;
    
    // Remove from source route
    if (sourceRouteId) {
      const sourceRoute = routes.find(r => r.id === sourceRouteId);
      const updatedBookings = sourceRoute.bookings.filter(b => b.id !== booking.id);
      onRouteUpdate(sourceRouteId, {
        ...sourceRoute,
        bookings: updatedBookings
      });
    }

    // Add to target route
    const targetRoute = routes.find(r => r.id === targetRouteId);
    onRouteUpdate(targetRouteId, {
      ...targetRoute,
      bookings: [...targetRoute.bookings, booking]
    });

    setDraggedBooking(null);
  };

  const handleDriverChange = (routeId, driverId) => {
    const route = routes.find(r => r.id === routeId);
    const newDriver = drivers.find(d => d.id === driverId);
    onRouteUpdate(routeId, {
      ...route,
      driverId,
      driver: newDriver
    });
  };

  const handleVehicleChange = (routeId, vehicleId) => {
    const route = routes.find(r => r.id === routeId);
    const newVehicle = vehicles.find(v => v.id === vehicleId);
    onRouteUpdate(routeId, {
      ...route,
      vehicleId,
      vehicle: newVehicle
    });
  };

  const removeBookingFromRoute = (routeId, bookingId) => {
    const route = routes.find(r => r.id === routeId);
    const updatedBookings = route.bookings.filter(b => b.id !== bookingId);
    onRouteUpdate(routeId, {
      ...route,
      bookings: updatedBookings
    });
  };

  return (
    <div className="space-y-6">
      <Alert>
        <Edit className="w-4 h-4" />
        <AlertDescription className="text-sm">
          <span className="font-semibold">Manual Adjustments</span>
          <p className="mt-1">
            Drag and drop bookings between routes, reassign drivers/vehicles, or remove bookings.
            Changes are not saved until you click the Save button.
          </p>
        </AlertDescription>
      </Alert>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Routes List */}
        <div className="lg:col-span-2 space-y-6">
          {routes.map((route, index) => (
            <Card
              key={route.id}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, route.id)}
              className="border-2 hover:border-purple-300 transition-colors"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Route {index + 1}</CardTitle>
                  <Badge variant="outline">{route.bookings.length} bookings</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Driver & Vehicle Selection */}
                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block">Driver</label>
                    <Select
                      value={route.driverId}
                      onValueChange={(value) => handleDriverChange(route.id, value)}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {drivers.filter(d => d.active).map(driver => (
                          <SelectItem key={driver.id} value={driver.id}>
                            {driver.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 mb-1 block">Vehicle</label>
                    <Select
                      value={route.vehicleId}
                      onValueChange={(value) => handleVehicleChange(route.id, value)}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {vehicles.filter(v => v.status === "available").map(vehicle => (
                          <SelectItem key={vehicle.id} value={vehicle.id}>
                            {vehicle.vehicle_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Bookings List */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-gray-600">Bookings</label>
                    <span className="text-xs text-gray-500">Drag to reorder or move</span>
                  </div>
                  
                  {route.bookings.length === 0 ? (
                    <div className="p-8 border-2 border-dashed border-gray-200 rounded-lg text-center">
                      <p className="text-sm text-gray-500">Drop bookings here</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {route.bookings.map((booking, bIndex) => (
                        <div
                          key={booking.id}
                          draggable
                          onDragStart={(e) => handleDragStart(e, booking, route.id)}
                          className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-move hover:bg-gray-100 transition-colors"
                        >
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <ArrowUpDown className="w-4 h-4 text-gray-400" />
                            <span className="text-sm font-semibold text-gray-700">{bIndex + 1}</span>
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">
                              {booking.pickup_location.suburb} → {booking.dropoff_location.suburb}
                            </p>
                            <p className="text-xs text-gray-600">
                              {new Date(booking.pickup_datetime).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>

                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeBookingFromRoute(route.id, booking.id)}
                            className="flex-shrink-0"
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Route Stats */}
                <div className="grid grid-cols-3 gap-2 pt-3 border-t">
                  <div className="text-center">
                    <p className="text-xs text-gray-600">Distance</p>
                    <p className="font-semibold text-sm">{route.totalDistance.toFixed(1)} km</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-600">Duration</p>
                    <p className="font-semibold text-sm">{Math.round(route.totalDuration)} min</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-gray-600">Efficiency</p>
                    <p className="font-semibold text-sm">{route.efficiency}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Unassigned Bookings Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Unassigned Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              {unassignedBookings.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">All bookings assigned!</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {unassignedBookings.map(booking => (
                    <div
                      key={booking.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, booking, null)}
                      className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg cursor-move hover:bg-yellow-100 transition-colors"
                    >
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {booking.pickup_location.suburb} → {booking.dropoff_location.suburb}
                          </p>
                          <p className="text-xs text-gray-600">
                            {new Date(booking.pickup_datetime).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full gap-2">
                <Plus className="w-4 h-4" />
                Add New Route
              </Button>
              <Button className="w-full bg-green-600 hover:bg-green-700 gap-2">
                <Save className="w-4 h-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}