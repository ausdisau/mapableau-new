import React, { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { MapPin, Navigation } from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Fix Leaflet default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

// Custom icons for pickup and dropoff
const createPickupIcon = (number) => {
  return L.divIcon({
    html: `<div style="background-color: #10B981; width: 32px; height: 32px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; font-size: 14px;">${number}</div>`,
    className: "",
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

const createDropoffIcon = (number) => {
  return L.divIcon({
    html: `<div style="background-color: #EF4444; width: 32px; height: 32px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; font-size: 14px;">${number}</div>`,
    className: "",
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

function MapCenterUpdater({ stops }) {
  const map = useMap();
  
  useEffect(() => {
    if (stops && stops.length > 0) {
      const validStops = stops.filter(s => s.location?.latitude && s.location?.longitude);
      if (validStops.length > 0) {
        const bounds = L.latLngBounds(
          validStops.map(stop => [stop.location.latitude, stop.location.longitude])
        );
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [stops, map]);
  
  return null;
}

export default function RouteMapVisualization({ route }) {
  const { stops } = route;
  
  // Filter out stops without coordinates
  const validStops = stops.filter(s => s.location?.latitude && s.location?.longitude);
  
  if (validStops.length === 0) {
    return (
      <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
        <p className="text-gray-500">No location data available for map display</p>
      </div>
    );
  }

  // Create polyline coordinates
  const polylinePositions = validStops.map(stop => [
    stop.location.latitude,
    stop.location.longitude
  ]);

  // Calculate center
  const centerLat = validStops.reduce((sum, s) => sum + s.location.latitude, 0) / validStops.length;
  const centerLon = validStops.reduce((sum, s) => sum + s.location.longitude, 0) / validStops.length;

  return (
    <div className="h-96 rounded-lg overflow-hidden border border-gray-200">
      <MapContainer
        center={[centerLat, centerLon]}
        zoom={12}
        style={{ height: "100%", width: "100%" }}
        className="z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          maxZoom={19}
        />
        
        <MapCenterUpdater stops={validStops} />

        {/* Route line */}
        <Polyline
          positions={polylinePositions}
          color="#3B82F6"
          weight={4}
          opacity={0.7}
        />

        {/* Markers for each stop */}
        {validStops.map((stop, index) => (
          <Marker
            key={index}
            position={[stop.location.latitude, stop.location.longitude]}
            icon={stop.type === 'pickup' ? createPickupIcon(index + 1) : createDropoffIcon(index + 1)}
          >
            <Popup>
              <div className="p-2 min-w-[200px]">
                <div className="flex items-center gap-2 mb-2">
                  <Badge className={stop.type === 'pickup' ? 'bg-green-500' : 'bg-red-500'}>
                    {stop.type === 'pickup' ? 'Pickup' : 'Drop-off'}
                  </Badge>
                  <span className="font-semibold">Stop #{index + 1}</span>
                </div>
                <p className="font-medium text-sm mb-1">{stop.passenger}</p>
                <p className="text-xs text-gray-600 mb-1">
                  {stop.location.address || stop.location.suburb}
                </p>
                {stop.distanceFromPrevious > 0 && (
                  <div className="text-xs text-gray-500 mt-2 pt-2 border-t">
                    <div className="flex justify-between">
                      <span>Distance from previous:</span>
                      <span className="font-medium">{stop.distanceFromPrevious.toFixed(1)} km</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Est. travel time:</span>
                      <span className="font-medium">{stop.estimatedTimeFromPrevious.toFixed(0)} min</span>
                    </div>
                  </div>
                )}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}