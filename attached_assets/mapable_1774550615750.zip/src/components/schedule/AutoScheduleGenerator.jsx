import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  Zap, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Loader2,
  TrendingUp
} from "lucide-react";
import { format, addDays } from "date-fns";
import { toast } from "sonner";
import NotificationService from "../notifications/NotificationService";

// Automated schedule generator component
export default function AutoScheduleGenerator({ 
  targetDate, 
  bookings, 
  vehicles, 
  drivers,
  onScheduleGenerated 
}) {
  const queryClient = useQueryClient();
  const [generating, setGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationResult, setGenerationResult] = useState(null);

  // Calculate distance between two points (simplified)
  const calculateDistance = (loc1, loc2) => {
    if (!loc1?.latitude || !loc2?.latitude) return 10;
    const R = 6371;
    const dLat = ((loc2.latitude - loc1.latitude) * Math.PI) / 180;
    const dLon = ((loc2.longitude - loc1.longitude) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos((loc1.latitude * Math.PI) / 180) *
              Math.cos((loc2.latitude * Math.PI) / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Check driver availability
  const isDriverAvailable = (driver, date) => {
    const dayOfWeek = format(date, "EEEE").toLowerCase();
    const schedule = driver.availability_schedule?.[dayOfWeek];
    
    if (!schedule || schedule.length === 0) return false;
    if (driver.status === "off_duty") return false;
    
    return true;
  };

  // Check vehicle availability
  const isVehicleAvailable = (vehicle) => {
    if (vehicle.status !== "available") return false;
    
    // Check maintenance due
    const maintenanceDue = vehicle.last_maintenance && 
      new Date(vehicle.last_maintenance) < addDays(new Date(), -90);
    
    // Check registration
    const registrationExpired = vehicle.registration_expiry &&
      new Date(vehicle.registration_expiry) < new Date();
    
    return !maintenanceDue && !registrationExpired;
  };

  // Detect conflicts
  const detectConflicts = (driver, vehicle, bookings, date) => {
    const conflicts = [];

    if (!isDriverAvailable(driver, date)) {
      conflicts.push({
        type: "driver_unavailable",
        severity: "error",
        message: `Driver ${driver.full_name} is not available on this day`,
        resolved: false
      });
    }

    if (!isVehicleAvailable(vehicle)) {
      conflicts.push({
        type: "vehicle_maintenance",
        severity: "error",
        message: `Vehicle ${vehicle.vehicle_name} requires maintenance or has expired registration`,
        resolved: false
      });
    }

    // Check license expiry
    if (driver.license_expiry && new Date(driver.license_expiry) < addDays(new Date(), 7)) {
      conflicts.push({
        type: "license_expired",
        severity: driver.license_expiry < new Date() ? "critical" : "warning",
        message: `Driver license expiring soon (${format(new Date(driver.license_expiry), "MMM d")})`,
        resolved: false
      });
    }

    // Check capacity
    const totalPassengers = bookings.reduce((sum, b) => sum + (b.passenger_count || 1), 0);
    const vehicleCapacity = vehicle.capacity?.standard_seats || 4;
    if (totalPassengers > vehicleCapacity) {
      conflicts.push({
        type: "capacity_exceeded",
        severity: "error",
        message: `Total passengers (${totalPassengers}) exceeds vehicle capacity (${vehicleCapacity})`,
        resolved: false
      });
    }

    return conflicts;
  };

  // Optimize route for bookings
  const optimizeRoute = (bookings) => {
    if (bookings.length === 0) return { distance: 0, duration: 0, waypoints: [] };

    let sortedBookings = [...bookings].sort((a, b) => 
      new Date(a.pickup_datetime) - new Date(b.pickup_datetime)
    );

    let totalDistance = 0;
    let totalDuration = 0;
    const waypoints = [];

    for (let i = 0; i < sortedBookings.length; i++) {
      const booking = sortedBookings[i];
      waypoints.push({
        booking_id: booking.id,
        order: i + 1,
        type: "pickup",
        location: booking.pickup_location,
        time: booking.pickup_datetime
      });

      const distance = calculateDistance(booking.pickup_location, booking.dropoff_location);
      totalDistance += distance;
      totalDuration += Math.ceil(distance * 3); // 3 minutes per km estimate

      waypoints.push({
        booking_id: booking.id,
        order: i + 1,
        type: "dropoff",
        location: booking.dropoff_location,
        time: null
      });
    }

    return {
      total_distance_km: totalDistance,
      total_duration_minutes: totalDuration,
      estimated_fuel_cost: totalDistance * 0.15, // $0.15 per km
      waypoints
    };
  };

  // Generate schedules
  const generateSchedules = async () => {
    setGenerating(true);
    setGenerationProgress(0);
    const schedules = [];

    try {
      // Filter bookings for target date
      const targetBookings = bookings.filter(b => {
        if (!b.pickup_datetime) return false;
        const bookingDate = format(new Date(b.pickup_datetime), "yyyy-MM-dd");
        const targetDateStr = format(targetDate, "yyyy-MM-dd");
        return bookingDate === targetDateStr && ["requested", "confirmed"].includes(b.status);
      });

      setGenerationProgress(10);

      if (targetBookings.length === 0) {
        setGenerationResult({
          success: true,
          message: "No bookings found for this date",
          schedules: []
        });
        setGenerating(false);
        return;
      }

      // Group bookings by vehicle preference
      const vehicleGroups = {};
      targetBookings.forEach(booking => {
        const vehicleId = booking.vehicle_id || "unassigned";
        if (!vehicleGroups[vehicleId]) {
          vehicleGroups[vehicleId] = [];
        }
        vehicleGroups[vehicleId].push(booking);
      });

      setGenerationProgress(30);

      // Create schedules for each vehicle
      const progressStep = 60 / Object.keys(vehicleGroups).length;
      let currentProgress = 30;

      for (const [vehicleId, vehicleBookings] of Object.entries(vehicleGroups)) {
        if (vehicleId === "unassigned") continue;

        const vehicle = vehicles.find(v => v.id === vehicleId);
        if (!vehicle) continue;

        // Find best available driver for this vehicle
        const availableDrivers = drivers.filter(d => 
          d.active && 
          isDriverAvailable(d, targetDate) &&
          (!d.current_vehicle_id || d.current_vehicle_id === vehicleId)
        );

        if (availableDrivers.length === 0) {
          schedules.push({
            vehicle,
            bookings: vehicleBookings,
            driver: null,
            conflicts: [{
              type: "driver_unavailable",
              severity: "critical",
              message: "No available drivers for this vehicle",
              resolved: false
            }]
          });
          continue;
        }

        // Select driver with most experience
        const driver = availableDrivers.sort((a, b) => 
          (b.total_trips || 0) - (a.total_trips || 0)
        )[0];

        // Optimize route
        const routeData = optimizeRoute(vehicleBookings);

        // Detect conflicts
        const conflicts = detectConflicts(driver, vehicle, vehicleBookings, targetDate);

        // Calculate shift times
        const firstBooking = vehicleBookings.sort((a, b) => 
          new Date(a.pickup_datetime) - new Date(b.pickup_datetime)
        )[0];
        const lastBooking = vehicleBookings[vehicleBookings.length - 1];

        const shiftStart = format(new Date(firstBooking.pickup_datetime), "HH:mm");
        const shiftEndTime = new Date(lastBooking.pickup_datetime);
        shiftEndTime.setMinutes(shiftEndTime.getMinutes() + routeData.total_duration_minutes);
        const shiftEnd = format(shiftEndTime, "HH:mm");

        schedules.push({
          schedule_date: format(targetDate, "yyyy-MM-dd"),
          vehicle_id: vehicle.id,
          driver_id: driver.id,
          vehicle,
          driver,
          bookings: vehicleBookings,
          shift_start_time: shiftStart,
          shift_end_time: shiftEnd,
          assigned_bookings: vehicleBookings.map(b => b.id),
          route_data: routeData,
          schedule_type: "auto_generated",
          status: conflicts.some(c => c.severity === "critical" || c.severity === "error") ? "draft" : "published",
          conflicts,
          exceptions: [],
          total_revenue: vehicleBookings.reduce((sum, b) => sum + (b.estimated_cost || 0), 0)
        });

        currentProgress += progressStep;
        setGenerationProgress(Math.min(90, currentProgress));
      }

      setGenerationProgress(100);

      setGenerationResult({
        success: true,
        message: `Generated ${schedules.length} schedule(s) for ${targetBookings.length} booking(s)`,
        schedules,
        stats: {
          totalBookings: targetBookings.length,
          schedulesCreated: schedules.length,
          conflictsDetected: schedules.reduce((sum, s) => sum + s.conflicts.length, 0),
          totalRevenue: schedules.reduce((sum, s) => sum + (s.total_revenue || 0), 0)
        }
      });

      if (onScheduleGenerated) {
        onScheduleGenerated(schedules);
      }

    } catch (error) {
      console.error("Schedule generation error:", error);
      setGenerationResult({
        success: false,
        message: `Error: ${error.message}`,
        schedules: []
      });
    }

    setGenerating(false);
  };

  const createScheduleMutation = useMutation({
    mutationFn: async (schedules) => {
      const created = [];
      for (const schedule of schedules) {
        const data = {
          schedule_date: schedule.schedule_date,
          operator_id: schedule.vehicle.operator_id,
          vehicle_id: schedule.vehicle_id,
          driver_id: schedule.driver_id,
          shift_start_time: schedule.shift_start_time,
          shift_end_time: schedule.shift_end_time,
          assigned_bookings: schedule.assigned_bookings,
          route_data: schedule.route_data,
          schedule_type: schedule.schedule_type,
          status: schedule.status,
          conflicts: schedule.conflicts,
          exceptions: schedule.exceptions,
          total_revenue: schedule.total_revenue
        };
        const result = await base44.entities.DailySchedule.create(data);
        created.push(result);
        
        // Notify driver if schedule is published
        if (result.status === "published" && schedule.driver?.email) {
          await NotificationService.notifySchedulePublished(result, schedule.driver);
        }
        
        // Notify provider if conflicts exist
        if (result.conflicts && result.conflicts.length > 0) {
          const user = await base44.auth.me();
          await NotificationService.notifyConflictDetected(result, user.email);
        }
      }
      return created;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dailySchedules"] });
      toast.success("Schedules created and notifications sent!");
    }
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-600" />
            <CardTitle>Automated Schedule Generator</CardTitle>
          </div>
          {targetDate && (
            <Badge variant="outline" className="text-sm">
              <Calendar className="w-3 h-3 mr-1" />
              {format(targetDate, "MMM d, yyyy")}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <TrendingUp className="w-4 h-4" />
          <AlertDescription className="text-sm">
            Automatically assigns drivers to vehicles based on availability, optimizes routes, 
            and detects scheduling conflicts. Review generated schedules before publishing.
          </AlertDescription>
        </Alert>

        {!generating && !generationResult && (
          <Button
            onClick={generateSchedules}
            className="w-full bg-yellow-600 hover:bg-yellow-700 gap-2"
            size="lg"
          >
            <Zap className="w-5 h-5" />
            Generate Schedules for {format(targetDate, "MMMM d")}
          </Button>
        )}

        {generating && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Generating schedules...</span>
              <span className="font-semibold">{generationProgress}%</span>
            </div>
            <Progress value={generationProgress} className="h-3" />
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>
                {generationProgress < 30 && "Analyzing bookings..."}
                {generationProgress >= 30 && generationProgress < 90 && "Optimizing routes and assigning drivers..."}
                {generationProgress >= 90 && "Finalizing schedules..."}
              </span>
            </div>
          </div>
        )}

        {generationResult && (
          <div className="space-y-4">
            <Alert className={generationResult.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
              {generationResult.success ? (
                <CheckCircle className="w-4 h-4 text-green-600" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-600" />
              )}
              <AlertDescription>
                <span className="font-semibold">{generationResult.message}</span>
              </AlertDescription>
            </Alert>

            {generationResult.stats && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-600 mb-1">Bookings</p>
                  <p className="text-2xl font-bold text-blue-900">{generationResult.stats.totalBookings}</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-xs text-green-600 mb-1">Schedules</p>
                  <p className="text-2xl font-bold text-green-900">{generationResult.stats.schedulesCreated}</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="text-xs text-yellow-600 mb-1">Conflicts</p>
                  <p className="text-2xl font-bold text-yellow-900">{generationResult.stats.conflictsDetected}</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <p className="text-xs text-purple-600 mb-1">Revenue</p>
                  <p className="text-2xl font-bold text-purple-900">${generationResult.stats.totalRevenue?.toFixed(0)}</p>
                </div>
              </div>
            )}

            {generationResult.schedules.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Generated Schedules</h4>
                {generationResult.schedules.map((schedule, idx) => (
                  <div key={idx} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">{schedule.vehicle.vehicle_name}</p>
                        <p className="text-sm text-gray-600">
                          {schedule.driver ? schedule.driver.full_name : "No driver assigned"}
                        </p>
                      </div>
                      <Badge className={
                        schedule.conflicts.some(c => c.severity === "critical") ? "bg-red-100 text-red-700" :
                        schedule.conflicts.some(c => c.severity === "error") ? "bg-orange-100 text-orange-700" :
                        schedule.conflicts.length > 0 ? "bg-yellow-100 text-yellow-700" :
                        "bg-green-100 text-green-700"
                      }>
                        {schedule.conflicts.length > 0 ? `${schedule.conflicts.length} conflicts` : "Ready"}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span>{schedule.shift_start_time} - {schedule.shift_end_time}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">{schedule.bookings.length} trips</span>
                      </div>
                    </div>

                    {schedule.conflicts.length > 0 && (
                      <div className="space-y-1">
                        {schedule.conflicts.map((conflict, cIdx) => (
                          <Alert key={cIdx} className="py-2">
                            <AlertTriangle className="w-3 h-3" />
                            <AlertDescription className="text-xs">
                              {conflict.message}
                            </AlertDescription>
                          </Alert>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                <div className="flex gap-3">
                  <Button
                    onClick={() => {
                      const validSchedules = generationResult.schedules.filter(s => 
                        !s.conflicts.some(c => c.severity === "critical" || c.severity === "error")
                      );
                      if (validSchedules.length > 0) {
                        createScheduleMutation.mutate(validSchedules);
                      }
                    }}
                    disabled={
                      createScheduleMutation.isPending ||
                      generationResult.schedules.every(s => 
                        s.conflicts.some(c => c.severity === "critical" || c.severity === "error")
                      )
                    }
                    className="flex-1"
                  >
                    {createScheduleMutation.isPending ? "Saving..." : "Save Valid Schedules"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setGenerationResult(null);
                      setGenerationProgress(0);
                    }}
                    className="flex-1"
                  >
                    Generate Again
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}