import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Edit, CheckCircle } from "lucide-react";
import { format } from "date-fns";

export default function ScheduleOverrideManager({ schedule, drivers, vehicles, onUpdate }) {
  const queryClient = useQueryClient();
  const [overrideType, setOverrideType] = useState("");
  const [newDriverId, setNewDriverId] = useState(schedule.driver_id);
  const [newVehicleId, setNewVehicleId] = useState(schedule.vehicle_id);
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const updateScheduleMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.DailySchedule.update(schedule.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dailySchedules"] });
      if (onUpdate) onUpdate();
    }
  });

  const handleOverride = async () => {
    if (!overrideType || !reason) {
      alert("Please select override type and provide a reason");
      return;
    }

    setSaving(true);

    const exception = {
      booking_id: null,
      exception_type: overrideType === "reassign_driver" ? "manually_reassigned" : overrideType,
      reason,
      handled_by: (await base44.auth.me()).email,
      timestamp: new Date().toISOString()
    };

    const updates = {
      schedule_type: "modified",
      exceptions: [...(schedule.exceptions || []), exception]
    };

    if (overrideType === "reassign_driver") {
      updates.driver_id = newDriverId;
    } else if (overrideType === "reassign_vehicle") {
      updates.vehicle_id = newVehicleId;
    }

    await updateScheduleMutation.mutateAsync(updates);
    setSaving(false);
    setOverrideType("");
    setReason("");
  };

  const resolveConflict = async (conflictIndex) => {
    const updatedConflicts = [...(schedule.conflicts || [])];
    updatedConflicts[conflictIndex] = {
      ...updatedConflicts[conflictIndex],
      resolved: true
    };

    await updateScheduleMutation.mutateAsync({
      conflicts: updatedConflicts
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Edit className="w-5 h-5" />
          Manual Overrides & Exceptions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Existing Conflicts */}
        {schedule.conflicts && schedule.conflicts.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Active Conflicts</h4>
            {schedule.conflicts.map((conflict, idx) => (
              <Alert 
                key={idx} 
                className={
                  conflict.resolved ? "bg-gray-50 border-gray-200" :
                  conflict.severity === "critical" ? "bg-red-50 border-red-200" :
                  conflict.severity === "error" ? "bg-orange-50 border-orange-200" :
                  "bg-yellow-50 border-yellow-200"
                }
              >
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium">{conflict.message}</p>
                    <Badge className="mt-1 text-xs">
                      {conflict.type.replace(/_/g, " ")}
                    </Badge>
                  </div>
                  {!conflict.resolved && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => resolveConflict(idx)}
                      disabled={updateScheduleMutation.isPending}
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Mark Resolved
                    </Button>
                  )}
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}

        {/* Existing Exceptions */}
        {schedule.exceptions && schedule.exceptions.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Exception History</h4>
            {schedule.exceptions.slice(-3).reverse().map((exception, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded-lg text-sm">
                <div className="flex items-center justify-between mb-1">
                  <Badge variant="outline" className="text-xs capitalize">
                    {exception.exception_type?.replace(/_/g, " ")}
                  </Badge>
                  <span className="text-xs text-gray-600">
                    {format(new Date(exception.timestamp), "MMM d, h:mm a")}
                  </span>
                </div>
                <p className="text-gray-700">{exception.reason}</p>
                <p className="text-xs text-gray-500 mt-1">By: {exception.handled_by}</p>
              </div>
            ))}
          </div>
        )}

        {/* Override Form */}
        <div className="space-y-4 pt-4 border-t">
          <h4 className="font-semibold text-sm">Apply Manual Override</h4>
          
          <div className="space-y-2">
            <Label>Override Type</Label>
            <Select value={overrideType} onValueChange={setOverrideType}>
              <SelectTrigger>
                <SelectValue placeholder="Select override type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="reassign_driver">Reassign Driver</SelectItem>
                <SelectItem value="reassign_vehicle">Reassign Vehicle</SelectItem>
                <SelectItem value="time_changed">Modify Time</SelectItem>
                <SelectItem value="emergency_added">Add Emergency Booking</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {overrideType === "reassign_driver" && (
            <div className="space-y-2">
              <Label>New Driver</Label>
              <Select value={newDriverId} onValueChange={setNewDriverId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select driver" />
                </SelectTrigger>
                <SelectContent>
                  {drivers.filter(d => d.active).map(driver => (
                    <SelectItem key={driver.id} value={driver.id}>
                      {driver.full_name} {driver.id === schedule.driver_id && "(Current)"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {overrideType === "reassign_vehicle" && (
            <div className="space-y-2">
              <Label>New Vehicle</Label>
              <Select value={newVehicleId} onValueChange={setNewVehicleId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select vehicle" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.filter(v => v.status === "available").map(vehicle => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.vehicle_name} {vehicle.id === schedule.vehicle_id && "(Current)"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label>Reason for Override *</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Explain why this manual override is necessary..."
              rows={3}
            />
          </div>

          <Button
            onClick={handleOverride}
            disabled={!overrideType || !reason || saving}
            className="w-full"
          >
            {saving ? "Applying..." : "Apply Override"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}