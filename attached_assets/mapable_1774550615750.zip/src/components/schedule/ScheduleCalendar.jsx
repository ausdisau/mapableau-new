import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar, Plus } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, isToday } from "date-fns";

export default function ScheduleCalendar({ schedules, onDateSelect, selectedDate }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getSchedulesForDay = (date) => {
    return schedules.filter(s => 
      isSameDay(new Date(s.schedule_date), date)
    );
  };

  const getDayColor = (date) => {
    const daySchedules = getSchedulesForDay(date);
    if (daySchedules.length === 0) return "bg-white";
    
    const hasConflicts = daySchedules.some(s => 
      s.conflicts?.some(c => c.severity === "critical" || c.severity === "error")
    );
    
    if (hasConflicts) return "bg-red-50 border-red-200";
    if (daySchedules.some(s => s.status === "draft")) return "bg-yellow-50 border-yellow-200";
    return "bg-green-50 border-green-200";
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Schedule Calendar</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm font-semibold min-w-[120px] text-center">
              {format(currentMonth, "MMMM yyyy")}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-2">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="text-center text-xs font-semibold text-gray-600 py-2">
              {day}
            </div>
          ))}
          
          {days.map((day, idx) => {
            const daySchedules = getSchedulesForDay(day);
            const isSelected = selectedDate && isSameDay(day, selectedDate);
            const isPast = day < new Date() && !isToday(day);
            
            return (
              <button
                key={idx}
                onClick={() => onDateSelect(day)}
                disabled={isPast}
                className={`
                  min-h-[60px] p-2 rounded-lg border-2 transition-all
                  ${getDayColor(day)}
                  ${isSelected ? "border-blue-600 ring-2 ring-blue-600 ring-opacity-50" : "border-transparent"}
                  ${isToday(day) ? "ring-2 ring-primary" : ""}
                  ${isPast ? "opacity-50 cursor-not-allowed" : "hover:shadow-md cursor-pointer"}
                `}
              >
                <div className="text-left">
                  <p className={`text-sm font-semibold mb-1 ${isToday(day) ? "text-primary" : ""}`}>
                    {format(day, "d")}
                  </p>
                  {daySchedules.length > 0 && (
                    <div className="space-y-1">
                      <Badge variant="secondary" className="text-xs px-1">
                        {daySchedules.length} schedule{daySchedules.length !== 1 ? 's' : ''}
                      </Badge>
                      {daySchedules.some(s => s.conflicts?.length > 0) && (
                        <Badge className="bg-red-100 text-red-700 text-xs px-1 block w-fit">
                          Conflicts
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-4 pt-4 border-t text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-50 border-2 border-green-200 rounded"></div>
            <span>Published</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-50 border-2 border-yellow-200 rounded"></div>
            <span>Draft</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-50 border-2 border-red-200 rounded"></div>
            <span>Has Conflicts</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}