import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Circle, Clock } from "lucide-react";
import { format } from "date-fns";

const tripStages = [
  { key: "requested", label: "Booking Requested" },
  { key: "confirmed", label: "Booking Confirmed" },
  { key: "driver_assigned", label: "Driver Assigned" },
  { key: "en_route_to_pickup", label: "Driver En Route" },
  { key: "passenger_on_board", label: "Passenger On Board" },
  { key: "in_transit", label: "In Transit" },
  { key: "completed", label: "Trip Completed" }
];

export default function TripProgressTimeline({ booking }) {
  const currentStageIndex = tripStages.findIndex(s => s.key === booking.status);
  const isCancelled = booking.status === "cancelled";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Trip Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {tripStages.map((stage, index) => {
            const isCompleted = index < currentStageIndex || booking.status === "completed";
            const isCurrent = index === currentStageIndex;
            const isPending = index > currentStageIndex;

            return (
              <div key={stage.key} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    isCompleted ? "bg-green-100" :
                    isCurrent ? "bg-blue-100" :
                    "bg-gray-100"
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : isCurrent ? (
                      <Circle className="w-5 h-5 text-blue-600 fill-blue-600" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-400" />
                    )}
                  </div>
                  {index < tripStages.length - 1 && (
                    <div className={`w-0.5 h-8 ${
                      isCompleted ? "bg-green-300" : "bg-gray-200"
                    }`} />
                  )}
                </div>

                <div className="flex-1 pb-4">
                  <div className="flex items-center justify-between">
                    <p className={`font-medium ${
                      isCompleted ? "text-green-700" :
                      isCurrent ? "text-blue-700" :
                      "text-gray-500"
                    }`}>
                      {stage.label}
                    </p>
                    {isCurrent && (
                      <Badge className="bg-blue-100 text-blue-700">
                        <Clock className="w-3 h-3 mr-1" />
                        Now
                      </Badge>
                    )}
                  </div>
                  
                  {/* Show timestamp for completed stages */}
                  {isCompleted && booking.actual_pickup_time && stage.key === "passenger_on_board" && (
                    <p className="text-xs text-gray-500 mt-1">
                      {format(new Date(booking.actual_pickup_time), "h:mm a")}
                    </p>
                  )}
                  {booking.status === "completed" && booking.actual_dropoff_time && stage.key === "completed" && (
                    <p className="text-xs text-gray-500 mt-1">
                      {format(new Date(booking.actual_dropoff_time), "h:mm a")}
                    </p>
                  )}
                </div>
              </div>
            );
          })}

          {isCancelled && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full flex items-center justify-center bg-red-100">
                <Circle className="w-5 h-5 text-red-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-red-700">Booking Cancelled</p>
                <p className="text-xs text-gray-500 mt-1">
                  {format(new Date(booking.updated_date), "MMM d, h:mm a")}
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}