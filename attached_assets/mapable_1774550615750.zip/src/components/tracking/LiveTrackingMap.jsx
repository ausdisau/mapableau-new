import React, { useEffect, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, Circle, useMap } from "react-leaflet";
import L from "leaflet";
import { Car, MapPin, Navigation, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import "leaflet/dist/leaflet.css";

// Custom driver icon
const createDriverIcon = (heading = 0) => {
  return L.divIcon({
    className: "custom-driver-marker",
    html: `
      <div style="transform: rotate(${heading}deg); width: 40px; height: 40px; position: relative;">
        <div style="
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #00B8A9 0%, #0F2947 100%);
          border-radius: 50%;
          border: 3px solid white;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
          </svg>
        </div>
        <div style="
          position: absolute;
          bottom: -8px;
          left: 50%;
          transform: translateX(-50%);
          width: 0;
          height: 0;
          border-left: 8px solid transparent;
          border-right: 8px solid transparent;
          border-top: 8px solid white;
        "></div>
      </div>
    `,
    iconSize: [40, 48],
    iconAnchor: [20, 48],
  });
};

// Custom pickup icon
const pickupIcon = L.divIcon({
  className: "custom-pickup-marker",
  html: `
    <div style="width: 32px; height: 32px; position: relative;">
      <div style="
        width: 32px;
        height: 32px;
        background: #10B981;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
        </svg>
      </div>
    </div>
  `,
  iconSize: [32, 32],
  iconAnchor: [16, 16],
});

// Custom dropoff icon
const dropoffIcon = L.divIcon({
  className: "custom-dropoff-marker",
  html: `
    <div style="width: 32px; height: 32px; position: relative;">
      <div style="
        width: 32px;
        height: 32px;
        background: #EF4444;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
        </svg>
      </div>
    </div>
  `,
  iconSize: [32, 32],
  iconAnchor: [16, 16],
});

// Component to auto-center map on driver
function MapController({ driverLocation, pickupLocation }) {
  const map = useMap();

  useEffect(() => {
    if (driverLocation) {
      map.setView([driverLocation.latitude, driverLocation.longitude], 14);
    } else if (pickupLocation) {
      map.setView([pickupLocation.latitude || -33.8688, pickupLocation.longitude || 151.2093], 13);
    }
  }, [driverLocation, pickupLocation, map]);

  return null;
}

export default function LiveTrackingMap({ booking, driver, vehicle, isActive }) {
  const [trafficData, setTrafficData] = useState([]);

  // Default to Sydney if no coordinates
  const defaultCenter = [-33.8688, 151.2093];
  
  const pickupCoords = booking?.pickup_location?.latitude && booking?.pickup_location?.longitude
    ? [booking.pickup_location.latitude, booking.pickup_location.longitude]
    : defaultCenter;

  const dropoffCoords = booking?.dropoff_location?.latitude && booking?.dropoff_location?.longitude
    ? [booking.dropoff_location.latitude, booking.dropoff_location.longitude]
    : defaultCenter;

  const driverCoords = driver?.current_location?.latitude && driver?.current_location?.longitude
    ? [driver.current_location.latitude, driver.current_location.longitude]
    : null;

  // Simulate traffic data (in real app, use Google Maps Traffic Layer)
  useEffect(() => {
    if (driverCoords && pickupCoords) {
      // Simulate some traffic points along the route
      const traffic = [];
      const steps = 5;
      for (let i = 0; i < steps; i++) {
        const lat = driverCoords[0] + (pickupCoords[0] - driverCoords[0]) * (i / steps);
        const lng = driverCoords[1] + (pickupCoords[1] - driverCoords[1]) * (i / steps);
        traffic.push({
          center: [lat, lng],
          radius: 100,
          color: i < 2 ? '#EF4444' : i < 4 ? '#F59E0B' : '#10B981'
        });
      }
      setTrafficData(traffic);
    }
  }, [driverCoords, pickupCoords]);

  // Route line coordinates
  const routeCoords = driverCoords 
    ? [driverCoords, pickupCoords, dropoffCoords]
    : [pickupCoords, dropoffCoords];

  return (
    <div className="relative w-full h-[500px] rounded-lg overflow-hidden">
      <MapContainer
        center={driverCoords || pickupCoords}
        zoom={13}
        className="w-full h-full"
        zoomControl={true}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        />

        <MapController driverLocation={driver?.current_location} pickupLocation={booking?.pickup_location} />

        {/* Driver Marker with real-time location */}
        {driverCoords && isActive && (
          <Marker
            position={driverCoords}
            icon={createDriverIcon(driver?.current_location?.heading || 0)}
          >
            <Popup>
              <div className="p-2">
                <p className="font-semibold mb-1">{driver?.full_name}</p>
                <p className="text-sm text-gray-600">{vehicle?.vehicle_name}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className="text-xs bg-green-100 text-green-700">
                    En Route
                  </Badge>
                  {driver?.current_location?.speed && (
                    <span className="text-xs text-gray-600">
                      {driver.current_location.speed.toFixed(0)} km/h
                    </span>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Pickup Marker */}
        <Marker position={pickupCoords} icon={pickupIcon}>
          <Popup>
            <div className="p-2">
              <p className="font-semibold text-green-700 mb-1">Pickup Location</p>
              <p className="text-sm">{booking?.pickup_location?.address || booking?.pickup_location?.suburb}</p>
              {booking?.pickup_location?.notes && (
                <p className="text-xs text-gray-600 mt-1">{booking.pickup_location.notes}</p>
              )}
            </div>
          </Popup>
        </Marker>

        {/* Dropoff Marker */}
        <Marker position={dropoffCoords} icon={dropoffIcon}>
          <Popup>
            <div className="p-2">
              <p className="font-semibold text-red-700 mb-1">Drop-off Location</p>
              <p className="text-sm">{booking?.dropoff_location?.address || booking?.dropoff_location?.suburb}</p>
            </div>
          </Popup>
        </Marker>

        {/* Route Line */}
        <Polyline
          positions={routeCoords}
          color="#0F2947"
          weight={4}
          opacity={0.7}
          dashArray="10, 10"
        />

        {/* Traffic Indicators */}
        {trafficData.map((traffic, idx) => (
          <Circle
            key={idx}
            center={traffic.center}
            radius={traffic.radius}
            pathOptions={{
              fillColor: traffic.color,
              fillOpacity: 0.3,
              color: traffic.color,
              weight: 2,
              opacity: 0.6
            }}
          />
        ))}

        {/* Driver's accuracy circle */}
        {driverCoords && driver?.current_location?.accuracy && (
          <Circle
            center={driverCoords}
            radius={driver.current_location.accuracy}
            pathOptions={{
              fillColor: '#00B8A9',
              fillOpacity: 0.1,
              color: '#00B8A9',
              weight: 1,
              opacity: 0.3
            }}
          />
        )}
      </MapContainer>

      {/* Live Indicator */}
      {isActive && driverCoords && (
        <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg px-4 py-2 flex items-center gap-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-sm font-semibold">Live Tracking</span>
        </div>
      )}

      {/* Traffic Legend */}
      {isActive && trafficData.length > 0 && (
        <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg p-3">
          <p className="text-xs font-semibold mb-2">Traffic Conditions</p>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span>Light</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <span>Moderate</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span>Heavy</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}