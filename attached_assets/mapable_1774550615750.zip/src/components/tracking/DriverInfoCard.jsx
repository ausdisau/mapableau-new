import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Star, Car, User, Navigation } from "lucide-react";

export default function DriverInfoCard({ driver, vehicle, booking }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start gap-4 mb-4">
          {driver.photo_url ? (
            <img
              src={driver.photo_url}
              alt={driver.full_name}
              className="w-16 h-16 rounded-full object-cover"
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-secondary to-blue-600 flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
          )}
          <div className="flex-1">
            <h3 className="font-bold text-lg">{driver.full_name}</h3>
            <div className="flex items-center gap-2 mt-1">
              {driver.rating > 0 && (
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{driver.rating.toFixed(1)}</span>
                </div>
              )}
              <span className="text-xs text-gray-500">
                {driver.total_trips} trips
              </span>
            </div>
            {driver.current_location?.timestamp && (
              <p className="text-xs text-gray-500 mt-1">
                Location updated {new Date(driver.current_location.timestamp).toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>

        {/* Vehicle Info */}
        <div className="p-3 bg-gray-50 rounded-lg mb-4">
          <div className="flex items-center gap-3">
            <Car className="w-5 h-5 text-primary" />
            <div>
              <p className="font-semibold text-sm">{vehicle.vehicle_name}</p>
              <p className="text-xs text-gray-600">{vehicle.vehicle_type?.replace(/_/g, " ")}</p>
            </div>
          </div>
        </div>

        {/* Driver Languages */}
        {driver.languages && driver.languages.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-600 mb-2">Languages spoken</p>
            <div className="flex flex-wrap gap-1">
              {driver.languages.map((lang, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {lang}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Driver Specializations */}
        {driver.specializations && driver.specializations.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-600 mb-2">Specializations</p>
            <div className="flex flex-wrap gap-1">
              {driver.specializations.slice(0, 3).map((spec, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {spec.replace(/_/g, " ")}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Contact Button */}
        <Button className="w-full gap-2" variant="outline">
          <Phone className="w-4 h-4" />
          Call Driver
        </Button>
      </CardContent>
    </Card>
  );
}