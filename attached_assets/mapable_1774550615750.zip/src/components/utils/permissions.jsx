// Permission definitions for MapAble RBAC system
export const MODULES = {
  USERS: "users",
  PROVIDERS: "providers",
  BOOKINGS: "bookings",
  CREDENTIALS: "credentials",
  VEHICLES: "vehicles",
  DRIVERS: "drivers",
  PAYMENTS: "payments",
  LOCATIONS: "locations",
  JOBS: "jobs",
  REVIEWS: "reviews",
  SCHEDULES: "schedules",
  REPORTS: "reports",
  SETTINGS: "settings",
  AUDIT_LOGS: "audit_logs",
};

export const ACTIONS = {
  VIEW: "view",
  VIEW_ALL: "view_all",
  CREATE: "create",
  EDIT: "edit",
  DELETE: "delete",
  APPROVE: "approve",
  REJECT: "reject",
  EXPORT: "export",
  MANAGE: "manage",
};

export function createPermission(module, action) {
  return `${module}:${action}`;
}

export const PERMISSIONS = {
  USERS_VIEW: createPermission(MODULES.USERS, ACTIONS.VIEW),
  USERS_VIEW_ALL: createPermission(MODULES.USERS, ACTIONS.VIEW_ALL),
  USERS_CREATE: createPermission(MODULES.USERS, ACTIONS.CREATE),
  USERS_EDIT: createPermission(MODULES.USERS, ACTIONS.EDIT),
  USERS_DELETE: createPermission(MODULES.USERS, ACTIONS.DELETE),
  USERS_MANAGE_ROLES: createPermission(MODULES.USERS, ACTIONS.MANAGE),
  
  PROVIDERS_VIEW: createPermission(MODULES.PROVIDERS, ACTIONS.VIEW),
  PROVIDERS_VIEW_ALL: createPermission(MODULES.PROVIDERS, ACTIONS.VIEW_ALL),
  PROVIDERS_CREATE: createPermission(MODULES.PROVIDERS, ACTIONS.CREATE),
  PROVIDERS_EDIT: createPermission(MODULES.PROVIDERS, ACTIONS.EDIT),
  PROVIDERS_DELETE: createPermission(MODULES.PROVIDERS, ACTIONS.DELETE),
  PROVIDERS_APPROVE: createPermission(MODULES.PROVIDERS, ACTIONS.APPROVE),
  
  BOOKINGS_VIEW: createPermission(MODULES.BOOKINGS, ACTIONS.VIEW),
  BOOKINGS_VIEW_ALL: createPermission(MODULES.BOOKINGS, ACTIONS.VIEW_ALL),
  BOOKINGS_CREATE: createPermission(MODULES.BOOKINGS, ACTIONS.CREATE),
  BOOKINGS_EDIT: createPermission(MODULES.BOOKINGS, ACTIONS.EDIT),
  BOOKINGS_DELETE: createPermission(MODULES.BOOKINGS, ACTIONS.DELETE),
  BOOKINGS_MANAGE: createPermission(MODULES.BOOKINGS, ACTIONS.MANAGE),
  
  CREDENTIALS_VIEW: createPermission(MODULES.CREDENTIALS, ACTIONS.VIEW),
  CREDENTIALS_VIEW_ALL: createPermission(MODULES.CREDENTIALS, ACTIONS.VIEW_ALL),
  CREDENTIALS_CREATE: createPermission(MODULES.CREDENTIALS, ACTIONS.CREATE),
  CREDENTIALS_EDIT: createPermission(MODULES.CREDENTIALS, ACTIONS.EDIT),
  CREDENTIALS_DELETE: createPermission(MODULES.CREDENTIALS, ACTIONS.DELETE),
  CREDENTIALS_APPROVE: createPermission(MODULES.CREDENTIALS, ACTIONS.APPROVE),
  CREDENTIALS_REJECT: createPermission(MODULES.CREDENTIALS, ACTIONS.REJECT),
  
  SETTINGS_VIEW: createPermission(MODULES.SETTINGS, ACTIONS.VIEW),
  SETTINGS_EDIT: createPermission(MODULES.SETTINGS, ACTIONS.EDIT),
  SETTINGS_OAUTH: createPermission(MODULES.SETTINGS, ACTIONS.MANAGE),
  
  AUDIT_LOGS_VIEW: createPermission(MODULES.AUDIT_LOGS, ACTIONS.VIEW),
  AUDIT_LOGS_EXPORT: createPermission(MODULES.AUDIT_LOGS, ACTIONS.EXPORT),
};

export const MODULE_PERMISSIONS = {
  [MODULES.USERS]: [
    { action: ACTIONS.VIEW, label: "View Own Profile" },
    { action: ACTIONS.VIEW_ALL, label: "View All Users" },
    { action: ACTIONS.CREATE, label: "Create Users" },
    { action: ACTIONS.EDIT, label: "Edit Users" },
    { action: ACTIONS.DELETE, label: "Delete Users" },
    { action: ACTIONS.MANAGE, label: "Manage User Roles" },
  ],
  [MODULES.PROVIDERS]: [
    { action: ACTIONS.VIEW, label: "View Providers" },
    { action: ACTIONS.VIEW_ALL, label: "View All Providers" },
    { action: ACTIONS.CREATE, label: "Create Providers" },
    { action: ACTIONS.EDIT, label: "Edit Providers" },
    { action: ACTIONS.DELETE, label: "Delete Providers" },
    { action: ACTIONS.APPROVE, label: "Verify Providers" },
  ],
  [MODULES.CREDENTIALS]: [
    { action: ACTIONS.VIEW, label: "View Own Credentials" },
    { action: ACTIONS.VIEW_ALL, label: "View All Credentials" },
    { action: ACTIONS.CREATE, label: "Upload Credentials" },
    { action: ACTIONS.EDIT, label: "Edit Credentials" },
    { action: ACTIONS.DELETE, label: "Delete Credentials" },
    { action: ACTIONS.APPROVE, label: "Approve Credentials" },
    { action: ACTIONS.REJECT, label: "Reject Credentials" },
  ],
  [MODULES.SETTINGS]: [
    { action: ACTIONS.VIEW, label: "View Settings" },
    { action: ACTIONS.EDIT, label: "Edit Settings" },
    { action: ACTIONS.MANAGE, label: "Manage OAuth Settings" },
  ],
};

export const DEFAULT_ROLES = {
  administrator: {
    name: "Administrator",
    description: "Full system access",
    permissions: Object.values(PERMISSIONS),
    color: "purple",
    isSystem: true,
  },
  moderator: {
    name: "Moderator",
    description: "Can review and approve content",
    permissions: [
      PERMISSIONS.USERS_VIEW_ALL,
      PERMISSIONS.PROVIDERS_VIEW_ALL,
      PERMISSIONS.PROVIDERS_APPROVE,
      PERMISSIONS.CREDENTIALS_VIEW_ALL,
      PERMISSIONS.CREDENTIALS_APPROVE,
      PERMISSIONS.CREDENTIALS_REJECT,
    ],
    color: "blue",
    isSystem: true,
  },
  user: {
    name: "User",
    description: "Basic user access",
    permissions: [
      PERMISSIONS.USERS_VIEW,
    ],
    color: "gray",
    isSystem: true,
  },
};

export function getModulePermissions(module) {
  const permissions = MODULE_PERMISSIONS[module] || [];
  return permissions.map(p => ({
    ...p,
    permission: createPermission(module, p.action),
  }));
}

export function getAllPermissions() {
  const all = [];
  Object.keys(MODULES).forEach(moduleKey => {
    const module = MODULES[moduleKey];
    const permissions = getModulePermissions(module);
    all.push(...permissions);
  });
  return all;
}

export function hasPermission(user, permission) {
  if (!user) return false;
  if (user.role === "administrator") return true;
  
  if (user.custom_permissions && Array.isArray(user.custom_permissions)) {
    if (user.custom_permissions.includes(permission)) {
      return true;
    }
  }
  
  const role = user.role || "user";
  const roleConfig = DEFAULT_ROLES[role];
  
  if (roleConfig && roleConfig.permissions) {
    return roleConfig.permissions.includes(permission);
  }
  
  return false;
}

export function hasAnyPermission(user, permissions) {
  if (!user || !Array.isArray(permissions)) return false;
  return permissions.some(permission => hasPermission(user, permission));
}

export function hasRole(user, role) {
  if (!user) return false;
  return user.role === role;
}

export function hasAnyRole(user, roles) {
  if (!user || !Array.isArray(roles)) return false;
  return roles.includes(user.role);
}

export function getUserPermissions(user) {
  if (!user) return [];
  if (user.role === "administrator") {
    return getAllPermissions().map(p => p.permission);
  }
  
  const role = user.role || "user";
  const roleConfig = DEFAULT_ROLES[role];
  const rolePermissions = roleConfig ? roleConfig.permissions : [];
  const customPermissions = user.custom_permissions || [];
  
  return [...new Set([...rolePermissions, ...customPermissions])];
}

export function isAdmin(user) {
  return hasRole(user, "administrator");
}

export function getAllRoles() {
  return Object.keys(DEFAULT_ROLES).map(key => ({
    value: key,
    ...DEFAULT_ROLES[key],
  }));
}

export function getModuleLabel(module) {
  return module.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

export function isSystemRole(role) {
  const roleConfig = DEFAULT_ROLES[role];
  return roleConfig ? roleConfig.isSystem : false;
}

export function getRoleLabel(role) {
  const roleConfig = DEFAULT_ROLES[role];
  return roleConfig ? roleConfig.name : role;
}

export function getRoleColor(role) {
  const roleConfig = DEFAULT_ROLES[role];
  if (!roleConfig) return "bg-gray-100 text-gray-700";
  
  const colorMap = {
    purple: "bg-purple-100 text-purple-700",
    blue: "bg-blue-100 text-blue-700",
    gray: "bg-gray-100 text-gray-700",
    green: "bg-green-100 text-green-700",
    red: "bg-red-100 text-red-700",
    yellow: "bg-yellow-100 text-yellow-700",
    indigo: "bg-indigo-100 text-indigo-700",
    pink: "bg-pink-100 text-pink-700",
  };
  
  return colorMap[roleConfig.color] || "bg-gray-100 text-gray-700";
}

export function getRoleDescription(role) {
  const roleConfig = DEFAULT_ROLES[role];
  return roleConfig ? roleConfig.description : "";
}

export default {
  MODULES,
  ACTIONS,
  PERMISSIONS,
  MODULE_PERMISSIONS,
  DEFAULT_ROLES,
  createPermission,
  getModulePermissions,
  getAllPermissions,
  hasPermission,
  hasAnyPermission,
  hasRole,
  hasAnyRole,
  getUserPermissions,
  isAdmin,
  getAllRoles,
  getModuleLabel,
  isSystemRole,
  getRoleLabel,
  getRoleColor,
  getRoleDescription,
};