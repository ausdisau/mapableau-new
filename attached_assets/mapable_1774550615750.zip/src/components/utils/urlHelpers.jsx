/**
 * Creates a URL for a page by name
 * @param pageName - Name of the page
 * @returns URL string for the page
 */
export function createPageUrl(pageName) {
  return `/${pageName.toLowerCase().replace(/\s+/g, '-')}`;
}