import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Star, MessageSquare, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import AccessibilityScore from "../shared/AccessibilityScore";

export default function LocationCard({ location, averageRating, reviewCount, onClick, isSelected }) {
  return (
    <Card
      className={`cursor-pointer transition-all duration-200 hover-lift ${
        isSelected ? "ring-2 ring-secondary shadow-lg" : ""
      }`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex gap-3">
          {location.photo_url && (
            <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-gray-100">
              <img
                src={location.photo_url}
                alt={location.name}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-base text-primary truncate">
                    {location.name}
                  </h3>
                  {location.verified && (
                    <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0" />
                  )}
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-600 mb-1">
                  <MapPin className="w-3 h-3" />
                  <span className="truncate">{location.suburb}, {location.state}</span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {location.category?.replace(/_/g, " ")}
                </Badge>
              </div>
              <AccessibilityScore score={location.overall_score || 0} size="sm" />
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-600 mt-2">
              {averageRating > 0 && (
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{averageRating.toFixed(1)}</span>
                </div>
              )}
              {reviewCount > 0 && (
                <div className="flex items-center gap-1">
                  <MessageSquare className="w-4 h-4" />
                  <span>{reviewCount} {reviewCount === 1 ? 'review' : 'reviews'}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}