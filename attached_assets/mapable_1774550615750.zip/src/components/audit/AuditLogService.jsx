import { base44 } from "@/api/base44Client";

// Service for creating audit log entries
export const AuditLogService = {
  // Get browser/device information
  getUserAgent() {
    if (typeof window !== 'undefined') {
      return window.navigator.userAgent;
    }
    return 'Unknown';
  },

  // Create an audit log entry
  async log(data) {
    try {
      const currentUser = await base44.auth.me();
      
      const auditEntry = {
        actor_email: currentUser.email,
        actor_role: currentUser.role,
        user_agent: this.getUserAgent(),
        ...data,
        metadata: {
          timestamp: new Date().toISOString(),
          ...data.metadata
        }
      };

      await base44.entities.AuditLog.create(auditEntry);
    } catch (error) {
      console.error("Failed to create audit log:", error);
      // Don't throw - audit logging should not break the main flow
    }
  },

  // Log role change
  async logRoleChange(targetUser, oldRole, newRole, customPermissions = []) {
    await this.log({
      action_type: "user_role_changed",
      target_entity_type: "User",
      target_entity_id: targetUser.id,
      target_email: targetUser.email,
      description: `Changed role from ${oldRole} to ${newRole} for ${targetUser.full_name}`,
      changes: {
        before: { role: oldRole },
        after: { role: newRole, custom_permissions: customPermissions },
        fields_changed: ['role', 'custom_permissions']
      },
      severity: "high"
    });
  },

  // Log user suspension
  async logUserSuspension(targetUser, reason) {
    await this.log({
      action_type: "user_suspended",
      target_entity_type: "User",
      target_entity_id: targetUser.id,
      target_email: targetUser.email,
      description: `Suspended user ${targetUser.full_name}`,
      metadata: { reason },
      severity: "high"
    });
  },

  // Log credential approval
  async logCredentialApproval(credential, providerEmail) {
    await this.log({
      action_type: "credential_approved",
      target_entity_type: "ProviderCredential",
      target_entity_id: credential.id,
      target_email: providerEmail,
      description: `Approved ${credential.credential_type} credential for ${providerEmail}`,
      metadata: {
        credential_name: credential.credential_name,
        credential_type: credential.credential_type
      },
      severity: "high"
    });
  },

  // Log credential rejection
  async logCredentialRejection(credential, providerEmail, reason) {
    await this.log({
      action_type: "credential_rejected",
      target_entity_type: "ProviderCredential",
      target_entity_id: credential.id,
      target_email: providerEmail,
      description: `Rejected ${credential.credential_type} credential for ${providerEmail}`,
      metadata: {
        credential_name: credential.credential_name,
        credential_type: credential.credential_type,
        rejection_reason: reason
      },
      severity: "high"
    });
  },

  // Log booking cancellation
  async logBookingCancellation(booking, reason = null) {
    await this.log({
      action_type: "booking_cancelled",
      target_entity_type: "TransportBooking",
      target_entity_id: booking.id,
      description: `Cancelled transport booking for ${booking.passenger_name}`,
      metadata: {
        pickup_datetime: booking.pickup_datetime,
        pickup_location: booking.pickup_location?.address,
        reason
      },
      severity: "medium"
    });
  },

  // Log schedule publication
  async logSchedulePublished(schedule) {
    await this.log({
      action_type: "schedule_published",
      target_entity_type: "DailySchedule",
      target_entity_id: schedule.id,
      description: `Published schedule for ${schedule.schedule_date}`,
      metadata: {
        schedule_date: schedule.schedule_date,
        assigned_bookings: schedule.assigned_bookings?.length || 0,
        vehicle_id: schedule.vehicle_id,
        driver_id: schedule.driver_id
      },
      severity: "medium"
    });
  },

  // Log schedule modification
  async logScheduleModification(schedule, changes) {
    await this.log({
      action_type: "schedule_modified",
      target_entity_type: "DailySchedule",
      target_entity_id: schedule.id,
      description: `Modified schedule for ${schedule.schedule_date}`,
      changes,
      severity: "medium"
    });
  },

  // Log payment processing
  async logPaymentProcessed(payment, serviceRequest) {
    await this.log({
      action_type: "payment_processed",
      target_entity_type: "Payment",
      target_entity_id: payment.id,
      description: `Processed payment of $${payment.amount} via ${payment.payment_method}`,
      metadata: {
        amount: payment.amount,
        payment_method: payment.payment_method,
        service_request_id: serviceRequest?.id
      },
      severity: "high"
    });
  },

  // Log settings changes
  async logSettingsChange(settingType, changes) {
    await this.log({
      action_type: "settings_changed",
      description: `Modified ${settingType} settings`,
      changes,
      severity: "high"
    });
  },

  // Log permissions modification
  async logPermissionsModified(targetUser, addedPermissions = [], removedPermissions = []) {
    await this.log({
      action_type: "permissions_modified",
      target_entity_type: "User",
      target_entity_id: targetUser.id,
      target_email: targetUser.email,
      description: `Modified permissions for ${targetUser.full_name}`,
      metadata: {
        added: addedPermissions,
        removed: removedPermissions
      },
      severity: "high"
    });
  },

  // Log bulk operations
  async logBulkOperation(operationType, entityType, count, details = {}) {
    await this.log({
      action_type: "bulk_operation",
      description: `Performed bulk ${operationType} on ${count} ${entityType} records`,
      metadata: {
        operation_type: operationType,
        entity_type: entityType,
        count,
        ...details
      },
      severity: "high"
    });
  },

  // Log data export
  async logDataExport(entityType, recordCount, filters = {}) {
    await this.log({
      action_type: "data_export",
      description: `Exported ${recordCount} ${entityType} records`,
      metadata: {
        entity_type: entityType,
        record_count: recordCount,
        filters
      },
      severity: "medium"
    });
  }
};

export default AuditLogService;