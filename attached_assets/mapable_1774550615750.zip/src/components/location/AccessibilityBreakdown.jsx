import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { DoorOpen, Building, Bath, Car, Users } from "lucide-react";

export default function AccessibilityBreakdown({ location }) {
  const categories = [
    {
      icon: DoorOpen,
      label: "Entrance",
      score: location.entrance_score || 0,
      color: "bg-blue-500",
    },
    {
      icon: Building,
      label: "Interior",
      score: location.interior_score || 0,
      color: "bg-purple-500",
    },
    {
      icon: Bath,
      label: "Bathrooms",
      score: location.bathroom_score || 0,
      color: "bg-green-500",
    },
    {
      icon: Car,
      label: "Parking",
      score: location.parking_score || 0,
      color: "bg-orange-500",
    },
    {
      icon: Users,
      label: "Staff Support",
      score: location.staff_score || 0,
      color: "bg-pink-500",
    },
  ];

  return (
    <Card className="hover-lift">
      <CardHeader>
        <CardTitle>Accessibility Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {categories.map((category) => (
          <div key={category.label} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <category.icon className="w-5 h-5 text-secondary" />
                <span className="font-medium text-gray-700">{category.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-primary">
                  {category.score}
                </span>
                <span className="text-sm text-gray-500">/10</span>
              </div>
            </div>
            <Progress value={category.score * 10} className={`h-2 ${category.color}`} />
          </div>
        ))}
      </CardContent>
    </Card>
  );
}