import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, ThumbsUp, Calendar, Accessibility } from "lucide-react";
import { format } from "date-fns";

export default function ReviewCard({ review }) {
  return (
    <Card className="hover-lift">
      <CardContent className="pt-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= review.rating
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                by {review.created_by}
              </span>
            </div>
            {review.title && (
              <h4 className="font-semibold text-base mb-2">{review.title}</h4>
            )}
          </div>
          {review.visit_date && (
            <div className="flex items-center gap-1 text-xs text-gray-500">
              <Calendar className="w-3 h-3" />
              {format(new Date(review.visit_date), "MMM yyyy")}
            </div>
          )}
        </div>

        <p className="text-gray-700 leading-relaxed mb-3">{review.content}</p>

        <div className="flex flex-wrap gap-2">
          {review.mobility_aid && review.mobility_aid !== "none" && (
            <Badge variant="outline" className="text-xs">
              <Accessibility className="w-3 h-3 mr-1" />
              {review.mobility_aid.replace(/_/g, " ")}
            </Badge>
          )}
          {review.would_recommend && (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs">
              <ThumbsUp className="w-3 h-3 mr-1" />
              Recommends
            </Badge>
          )}
          {review.helpful_count > 0 && (
            <Badge variant="outline" className="text-xs">
              {review.helpful_count} found helpful
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}