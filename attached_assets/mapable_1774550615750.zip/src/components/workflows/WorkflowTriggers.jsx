/**
 * Workflow Triggers - Auto-execute workflows based on platform events
 * This would ideally run server-side, but we'll simulate client-side triggers
 */
import { triggerWorkflows } from "@/utils/workflowEngine";

/**
 * Hook into user creation
 */
export async function onUserCreated(user) {
  await triggerWorkflows("user_created", { user });
}

/**
 * Hook into user updates
 */
export async function onUserUpdated(user, oldData) {
  await triggerWorkflows("user_updated", { user, oldData });
}

/**
 * Hook into credential uploads
 */
export async function onCredentialUploaded(credential) {
  await triggerWorkflows("credential_uploaded", { credential });
}

/**
 * Hook into booking creation
 */
export async function onBookingCreated(booking) {
  await triggerWorkflows("booking_created", { booking });
}

/**
 * Hook into support ticket creation
 */
export async function onTicketCreated(ticket) {
  await triggerWorkflows("ticket_created", { ticket });
}

/**
 * Scheduled workflow checker
 * This should run as a cron job server-side
 */
export async function checkScheduledWorkflows() {
  const { base44 } = await import("@/api/base44Client");
  
  const workflows = await base44.entities.WorkflowDefinition.filter({
    enabled: true,
  });

  const now = new Date();
  const currentHour = now.getHours();
  const currentDay = now.toLocaleDateString('en-US', { weekday: 'lowercase' });

  for (const workflow of workflows) {
    if (workflow.trigger.type === "schedule") {
      const schedule = workflow.trigger.schedule;
      let shouldRun = false;

      if (schedule.frequency === "hourly") {
        shouldRun = true;
      } else if (schedule.frequency === "daily" && schedule.time) {
        const [hour] = schedule.time.split(":");
        shouldRun = currentHour === parseInt(hour);
      } else if (schedule.frequency === "weekly" && schedule.day_of_week) {
        shouldRun = currentDay === schedule.day_of_week.toLowerCase();
      }

      if (shouldRun) {
        await triggerWorkflows("schedule", { workflow, timestamp: now.toISOString() });
      }
    }
  }
}

export default {
  onUserCreated,
  onUserUpdated,
  onCredentialUploaded,
  onBookingCreated,
  onTicketCreated,
  checkScheduledWorkflows,
};