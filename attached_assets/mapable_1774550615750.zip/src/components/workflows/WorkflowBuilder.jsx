import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Plus,
  Trash2,
  Play,
  Zap,
  Mail,
  Bell,
  UserCheck,
  CheckSquare,
  Clock,
  GitBranch,
  Webhook,
  Info,
  Save
} from "lucide-react";

const ACTION_TYPES = [
  { value: "assign_role", label: "Assign Role", icon: UserCheck, color: "blue" },
  { value: "send_notification", label: "Send Notification", icon: Bell, color: "yellow" },
  { value: "send_email", label: "Send Email", icon: Mail, color: "purple" },
  { value: "create_task", label: "Create Task", icon: CheckSquare, color: "green" },
  { value: "update_record", label: "Update Record", icon: Zap, color: "orange" },
  { value: "request_approval", label: "Request Approval", icon: UserCheck, color: "red" },
  { value: "call_webhook", label: "Call Webhook", icon: Webhook, color: "indigo" },
];

const TRIGGER_TYPES = [
  { value: "user_created", label: "User Created" },
  { value: "user_updated", label: "User Updated" },
  { value: "credential_uploaded", label: "Credential Uploaded" },
  { value: "credential_expiring", label: "Credential Expiring" },
  { value: "booking_created", label: "Booking Created" },
  { value: "booking_pending", label: "Booking Pending" },
  { value: "ticket_created", label: "Ticket Created" },
  { value: "ticket_stale", label: "Ticket Stale" },
  { value: "schedule", label: "Schedule" },
  { value: "manual", label: "Manual Trigger" },
];

export default function WorkflowBuilder({ workflow, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: workflow?.name || "",
    description: workflow?.description || "",
    category: workflow?.category || "user_management",
    trigger: workflow?.trigger || {
      type: "user_created",
      conditions: [],
    },
    actions: workflow?.actions || [],
    enabled: workflow?.enabled !== false,
  });

  const [showActionConfig, setShowActionConfig] = useState(null);

  const addAction = (type) => {
    const newAction = {
      type,
      config: {},
    };
    setFormData({
      ...formData,
      actions: [...formData.actions, newAction],
    });
  };

  const removeAction = (index) => {
    const newActions = formData.actions.filter((_, i) => i !== index);
    setFormData({ ...formData, actions: newActions });
  };

  const updateAction = (index, config) => {
    const newActions = [...formData.actions];
    newActions[index] = { ...newActions[index], config };
    setFormData({ ...formData, actions: newActions });
  };

  const addCondition = () => {
    const newConditions = [
      ...(formData.trigger.conditions || []),
      { field: "", operator: "equals", value: "" },
    ];
    setFormData({
      ...formData,
      trigger: { ...formData.trigger, conditions: newConditions },
    });
  };

  const removeCondition = (index) => {
    const newConditions = formData.trigger.conditions.filter((_, i) => i !== index);
    setFormData({
      ...formData,
      trigger: { ...formData.trigger, conditions: newConditions },
    });
  };

  const updateCondition = (index, field, value) => {
    const newConditions = [...formData.trigger.conditions];
    newConditions[index] = { ...newConditions[index], [field]: value };
    setFormData({
      ...formData,
      trigger: { ...formData.trigger, conditions: newConditions },
    });
  };

  const getActionIcon = (type) => {
    const action = ACTION_TYPES.find(a => a.value === type);
    const Icon = action?.icon || Zap;
    return <Icon className="w-4 h-4" />;
  };

  const getActionColor = (type) => {
    const action = ACTION_TYPES.find(a => a.value === type);
    return action?.color || "gray";
  };

  return (
    <div className="space-y-6">
      {/* Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle>Workflow Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Workflow Name</Label>
            <Input
              placeholder="e.g., Auto-Assign Provider Role"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              placeholder="Describe what this workflow does..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user_management">User Management</SelectItem>
                  <SelectItem value="credentials">Credentials</SelectItem>
                  <SelectItem value="bookings">Bookings</SelectItem>
                  <SelectItem value="support">Support</SelectItem>
                  <SelectItem value="approvals">Approvals</SelectItem>
                  <SelectItem value="notifications">Notifications</SelectItem>
                  <SelectItem value="data_sync">Data Sync</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={formData.enabled ? "enabled" : "disabled"}
                onValueChange={(value) => setFormData({ ...formData, enabled: value === "enabled" })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="enabled">Enabled</SelectItem>
                  <SelectItem value="disabled">Disabled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trigger */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Play className="w-5 h-5 text-green-600" />
              Trigger
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>When should this workflow run?</Label>
            <Select
              value={formData.trigger.type}
              onValueChange={(value) =>
                setFormData({ ...formData, trigger: { ...formData.trigger, type: value } })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TRIGGER_TYPES.map(trigger => (
                  <SelectItem key={trigger.value} value={trigger.value}>
                    {trigger.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Conditions */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label>Conditions (optional)</Label>
              <Button size="sm" variant="outline" onClick={addCondition}>
                <Plus className="w-4 h-4 mr-2" />
                Add Condition
              </Button>
            </div>

            {formData.trigger.conditions?.map((condition, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input
                  placeholder="Field (e.g., user_type)"
                  value={condition.field}
                  onChange={(e) => updateCondition(index, "field", e.target.value)}
                  className="flex-1"
                />
                <Select
                  value={condition.operator}
                  onValueChange={(value) => updateCondition(index, "operator", value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="equals">Equals</SelectItem>
                    <SelectItem value="not_equals">Not Equals</SelectItem>
                    <SelectItem value="contains">Contains</SelectItem>
                    <SelectItem value="greater_than">Greater Than</SelectItem>
                    <SelectItem value="less_than">Less Than</SelectItem>
                    <SelectItem value="in">In List</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  placeholder="Value"
                  value={condition.value}
                  onChange={(e) => updateCondition(index, "value", e.target.value)}
                  className="flex-1"
                />
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => removeCondition(index)}
                  className="text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-600" />
              Actions ({formData.actions.length})
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {/* Action List */}
          <div className="space-y-3 mb-4">
            {formData.actions.map((action, index) => {
              const color = getActionColor(action.type);
              return (
                <div
                  key={index}
                  className={`p-4 border-2 rounded-lg border-${color}-200 bg-${color}-50`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full bg-${color}-100 flex items-center justify-center`}>
                        {getActionIcon(action.type)}
                      </div>
                      <div>
                        <p className="font-semibold">
                          {ACTION_TYPES.find(a => a.value === action.type)?.label}
                        </p>
                        <p className="text-sm text-gray-600">
                          Step {index + 1}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeAction(index)}
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Action */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {ACTION_TYPES.map(actionType => {
              const Icon = actionType.icon;
              return (
                <button
                  key={actionType.value}
                  onClick={() => addAction(actionType.value)}
                  className={`p-4 border-2 rounded-lg text-left hover:shadow-md transition-all border-${actionType.color}-200 hover:border-${actionType.color}-400`}
                >
                  <Icon className={`w-6 h-6 text-${actionType.color}-600 mb-2`} />
                  <p className="font-medium text-sm">{actionType.label}</p>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Info */}
      <Alert className="bg-blue-50 border-blue-200">
        <Info className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900 text-sm">
          <p className="font-semibold mb-1">How workflows work:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>Choose a trigger event (e.g., user created, booking made)</li>
            <li>Add conditions to filter when the workflow runs</li>
            <li>Define actions that execute automatically</li>
            <li>Actions run in sequence from top to bottom</li>
          </ul>
        </AlertDescription>
      </Alert>

      {/* Actions */}
      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          onClick={() => onSave(formData)}
          className="bg-blue-600 hover:bg-blue-700 gap-2"
          disabled={!formData.name || formData.actions.length === 0}
        >
          <Save className="w-4 h-4" />
          Save Workflow
        </Button>
      </div>
    </div>
  );
}