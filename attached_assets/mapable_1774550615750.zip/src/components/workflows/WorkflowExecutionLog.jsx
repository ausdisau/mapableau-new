import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  CheckCircle,
  XCircle,
  Clock,
  Activity,
  AlertTriangle,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";

export default function WorkflowExecutionLog({ workflowId, limit = 10 }) {
  const { data: executions = [], isLoading } = useQuery({
    queryKey: ["workflowExecutions", workflowId],
    queryFn: async () => {
      if (workflowId) {
        return await base44.entities.WorkflowExecution.filter(
          { workflow_id: workflowId },
          "-created_date",
          limit
        );
      }
      return await base44.entities.WorkflowExecution.list("-created_date", limit);
    },
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-600" />;
      case "running":
        return <Activity className="w-5 h-5 text-blue-600 animate-pulse" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      default:
        return <Clock className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      completed: "bg-green-100 text-green-700",
      failed: "bg-red-100 text-red-700",
      running: "bg-blue-100 text-blue-700",
      pending: "bg-yellow-100 text-yellow-700",
      cancelled: "bg-gray-100 text-gray-700",
    };
    return colors[status] || colors.pending;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Execution History
        </CardTitle>
      </CardHeader>
      <CardContent>
        {executions.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600">No executions yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {executions.map((execution) => (
              <div key={execution.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(execution.status)}
                    <div>
                      <p className="font-semibold">{execution.workflow_name}</p>
                      <p className="text-sm text-gray-600">
                        {formatDistanceToNow(new Date(execution.created_date), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(execution.status)}>
                    {execution.status}
                  </Badge>
                </div>

                {execution.steps_completed && execution.steps_completed.length > 0 && (
                  <div className="space-y-2">
                    {execution.steps_completed.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm pl-8">
                        {step.status === "success" ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-600" />
                        )}
                        <span className="text-gray-700 capitalize">
                          {step.action_type?.replace(/_/g, " ")}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {execution.error_message && (
                  <Alert className="mt-3 bg-red-50 border-red-200">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    <AlertDescription className="text-red-900 text-sm">
                      {execution.error_message}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}