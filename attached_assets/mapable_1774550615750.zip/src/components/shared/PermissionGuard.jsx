import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { hasPermission, hasAnyPermission, hasRole, hasAnyRole } from "@/components/utils/permissions";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Lock } from "lucide-react";

/**
 * Permission Guard Component
 * Conditionally renders children based on user permissions
 * 
 * Usage:
 * <PermissionGuard permission="users.edit">
 *   <Button>Edit User</Button>
 * </PermissionGuard>
 * 
 * <PermissionGuard anyPermission={["bookings.view_all", "bookings.view_own"]}>
 *   <BookingsList />
 * </PermissionGuard>
 * 
 * <PermissionGuard role="administrator">
 *   <AdminPanel />
 * </PermissionGuard>
 */
export default function PermissionGuard({
  children,
  permission,
  anyPermission,
  allPermissions,
  role,
  anyRole,
  fallback = null,
  showMessage = false,
  message = "You don't have permission to access this feature."
}) {
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // Check permissions
  let hasAccess = false;

  if (permission) {
    hasAccess = hasPermission(currentUser, permission);
  } else if (anyPermission) {
    hasAccess = hasAnyPermission(currentUser, anyPermission);
  } else if (allPermissions) {
    hasAccess = allPermissions.every(p => hasPermission(currentUser, p));
  } else if (role) {
    hasAccess = hasRole(currentUser, role);
  } else if (anyRole) {
    hasAccess = hasAnyRole(currentUser, anyRole);
  } else {
    // No permission check specified, default to allow
    hasAccess = true;
  }

  // If user doesn't have access
  if (!hasAccess) {
    if (showMessage) {
      return (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Lock className="w-4 h-4 text-yellow-600" />
          <AlertDescription>
            <span className="font-semibold text-yellow-900">Access Restricted</span>
            <p className="text-sm text-yellow-700 mt-1">{message}</p>
          </AlertDescription>
        </Alert>
      );
    }
    return fallback;
  }

  // User has access, render children
  return <>{children}</>;
}

/**
 * Role Badge Component
 * Displays user's role with appropriate styling
 */
export function RoleBadge({ role, className = "" }) {
  const roleColors = {
    administrator: "bg-red-100 text-red-700",
    transport_provider: "bg-blue-100 text-blue-700",
    service_provider: "bg-green-100 text-green-700",
    driver: "bg-purple-100 text-purple-700",
    participant: "bg-yellow-100 text-yellow-700",
    support_coordinator: "bg-indigo-100 text-indigo-700",
    plan_manager: "bg-pink-100 text-pink-700",
  };

  const roleLabels = {
    administrator: "Administrator",
    transport_provider: "Transport Provider",
    service_provider: "Service Provider",
    driver: "Driver",
    participant: "Participant",
    support_coordinator: "Support Coordinator",
    plan_manager: "Plan Manager",
  };

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${roleColors[role] || "bg-gray-100 text-gray-700"} ${className}`}>
      {roleLabels[role] || role}
    </span>
  );
}

/**
 * Permission Check Hook
 * Returns permission checking functions for use in components
 */
export function usePermissionCheck() {
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  return {
    hasPermission: (permission) => hasPermission(currentUser, permission),
    hasAnyPermission: (permissions) => hasAnyPermission(currentUser, permissions),
    hasAllPermissions: (permissions) => permissions.every(p => hasPermission(currentUser, p)),
    hasRole: (role) => hasRole(currentUser, role),
    hasAnyRole: (roles) => hasAnyRole(currentUser, roles),
    isAdmin: currentUser?.role === 'administrator',
    currentRole: currentUser?.role,
    currentUser,
  };
}