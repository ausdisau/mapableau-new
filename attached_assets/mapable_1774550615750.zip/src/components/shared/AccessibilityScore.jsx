
import React from "react";

export default function AccessibilityScore({ score, size = "md" }) {
  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600 bg-green-50 border-green-200";
    if (score >= 60) return "text-yellow-600 bg-yellow-50 border-yellow-200";
    return "text-red-600 bg-red-50 border-red-200";
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Good";
    if (score >= 40) return "Fair";
    return "Limited";
  };

  const sizeClasses = {
    sm: "text-lg px-2 py-1",
    md: "text-2xl px-3 py-1.5",
    lg: "text-4xl px-4 py-2",
  };

  const labelSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={`font-bold border-2 rounded-lg ${getScoreColor(
          score
        )} ${sizeClasses[size]} transition-all`}
      >
        {Math.round(score)}
      </div>
      <span className={`font-medium ${getScoreColor(score).split(" ")[0]} ${labelSizeClasses[size]}`}>
        {getScoreLabel(score)}
      </span>
    </div>
  );
}
