import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Bell } from "lucide-react";
import { useNotifications } from "../notifications/NotificationProvider";
import InAppNotificationCenter from "../notifications/InAppNotificationCenter";
import { cn } from "@/lib/utils";

export default function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  
  // Safely access notifications with fallback
  let notifications = { unreadCount: 0, urgentCount: 0 };
  try {
    notifications = useNotifications();
  } catch (error) {
    // NotificationProvider not available, use defaults
    console.log("NotificationProvider not available");
  }

  const { unreadCount = 0, urgentCount = 0 } = notifications;
  const hasNotifications = unreadCount > 0;
  const hasUrgent = urgentCount > 0;

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon" 
          className="relative text-white hover:bg-white/10"
        >
          <Bell className={cn(
            "w-5 h-5",
            hasUrgent && "animate-pulse"
          )} />
          {hasNotifications && (
            <span className={cn(
              "absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold text-white",
              hasUrgent ? "bg-red-600" : "bg-blue-600"
            )}>
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:w-[500px] p-0 overflow-hidden">
        <InAppNotificationCenter onClose={() => setIsOpen(false)} />
      </SheetContent>
    </Sheet>
  );
}