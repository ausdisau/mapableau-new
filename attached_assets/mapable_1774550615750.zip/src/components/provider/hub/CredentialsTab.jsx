import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, ExternalLink, AlertTriangle } from "lucide-react";
import CredentialsList from "../../credentials/CredentialsList";
import CredentialExpiryChecker from "../../verification/CredentialExpiryChecker";

export default function CredentialsTab() {
  return (
    <div className="space-y-6">
      <Alert className="bg-blue-50 border-blue-200">
        <Shield className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <div className="flex items-center justify-between">
            <span>Keep your credentials up to date to maintain your verified status.</span>
            <Link to={createPageUrl("ProviderCredentials")}>
              <Button size="sm" variant="outline" className="gap-2">
                Full Management
                <ExternalLink className="w-3 h-3" />
              </Button>
            </Link>
          </div>
        </AlertDescription>
      </Alert>

      <CredentialExpiryChecker />
      
      <Card>
        <CardHeader>
          <CardTitle>My Credentials</CardTitle>
        </CardHeader>
        <CardContent>
          <CredentialsList />
        </CardContent>
      </Card>
    </div>
  );
}