import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Plus, X, Save, Calendar } from "lucide-react";
import { toast } from "sonner";

const DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

export default function AvailabilityTab() {
  const queryClient = useQueryClient();
  
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: availability, isLoading } = useQuery({
    queryKey: ["myAvailability"],
    queryFn: async () => {
      const avail = await base44.entities.ProviderAvailability.filter({
        provider_email: currentUser?.email
      });
      return avail[0] || null;
    },
    enabled: !!currentUser?.email,
  });

  const [schedule, setSchedule] = useState({});
  const [acceptingBookings, setAcceptingBookings] = useState(true);
  const [leadTimeHours, setLeadTimeHours] = useState(24);

  useEffect(() => {
    if (availability) {
      setSchedule(availability.weekly_schedule || {});
      setAcceptingBookings(availability.accepting_bookings ?? true);
      setLeadTimeHours(availability.lead_time_hours || 24);
    }
  }, [availability]);

  const saveAvailabilityMutation = useMutation({
    mutationFn: async (data) => {
      if (availability) {
        return await base44.entities.ProviderAvailability.update(availability.id, data);
      } else {
        return await base44.entities.ProviderAvailability.create({
          ...data,
          provider_email: currentUser.email,
          provider_type: currentUser.user_type === "transport_provider" ? "transport_provider" : "care_provider",
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myAvailability"] });
      toast.success("Availability updated!");
    },
  });

  const addTimeSlot = (day) => {
    const daySlots = schedule[day] || [];
    setSchedule({
      ...schedule,
      [day]: [...daySlots, { start: "09:00", end: "17:00", max_bookings: 5 }]
    });
  };

  const removeTimeSlot = (day, index) => {
    const daySlots = schedule[day] || [];
    setSchedule({
      ...schedule,
      [day]: daySlots.filter((_, i) => i !== index)
    });
  };

  const updateTimeSlot = (day, index, field, value) => {
    const daySlots = schedule[day] || [];
    const updated = daySlots.map((slot, i) => 
      i === index ? { ...slot, [field]: value } : slot
    );
    setSchedule({ ...schedule, [day]: updated });
  };

  const handleSave = () => {
    saveAvailabilityMutation.mutate({
      weekly_schedule: schedule,
      accepting_bookings: acceptingBookings,
      lead_time_hours: leadTimeHours,
    });
  };

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Booking Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Accepting New Bookings</Label>
              <p className="text-sm text-gray-600">
                Toggle to stop accepting new booking requests
              </p>
            </div>
            <Switch
              checked={acceptingBookings}
              onCheckedChange={setAcceptingBookings}
            />
          </div>

          <div className="space-y-2">
            <Label>Minimum Lead Time (hours)</Label>
            <Input
              type="number"
              value={leadTimeHours}
              onChange={(e) => setLeadTimeHours(Number(e.target.value))}
              min="0"
            />
            <p className="text-xs text-gray-500">
              Minimum hours notice required before a booking
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Schedule */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Schedule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {DAYS.map(day => {
            const slots = schedule[day] || [];
            return (
              <div key={day} className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="capitalize font-semibold">{day}</Label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => addTimeSlot(day)}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add Slot
                  </Button>
                </div>

                {slots.length === 0 ? (
                  <p className="text-sm text-gray-500 italic">Not available</p>
                ) : (
                  <div className="space-y-2">
                    {slots.map((slot, index) => (
                      <div key={index} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                        <Input
                          type="time"
                          value={slot.start}
                          onChange={(e) => updateTimeSlot(day, index, 'start', e.target.value)}
                          className="w-32"
                        />
                        <span>to</span>
                        <Input
                          type="time"
                          value={slot.end}
                          onChange={(e) => updateTimeSlot(day, index, 'end', e.target.value)}
                          className="w-32"
                        />
                        <Input
                          type="number"
                          placeholder="Max bookings"
                          value={slot.max_bookings}
                          onChange={(e) => updateTimeSlot(day, index, 'max_bookings', Number(e.target.value))}
                          className="w-32"
                          min="1"
                        />
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => removeTimeSlot(day, index)}
                          className="text-red-600"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
                <Separator />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={saveAvailabilityMutation.isPending}
          className="bg-green-600 hover:bg-green-700 gap-2"
          size="lg"
        >
          <Save className="w-4 h-4" />
          {saveAvailabilityMutation.isPending ? "Saving..." : "Save Availability"}
        </Button>
      </div>
    </div>
  );
}