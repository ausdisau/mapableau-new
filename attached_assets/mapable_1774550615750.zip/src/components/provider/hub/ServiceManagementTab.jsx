import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, DollarSign, Clock } from "lucide-react";
import { toast } from "sonner";

export default function ServiceManagementTab() {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [serviceForm, setServiceForm] = useState({
    service_name: "",
    description: "",
    price: "",
    duration: "",
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const updateServicesMutation = useMutation({
    mutationFn: (services) => base44.auth.updateMe({ services_offered: services }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });
      setShowAddDialog(false);
      setEditingService(null);
      setServiceForm({ service_name: "", description: "", price: "", duration: "" });
      toast.success("Services updated!");
    },
  });

  const servicesOffered = currentUser?.services_offered || [];

  const handleAddService = () => {
    if (!serviceForm.service_name || !serviceForm.price) {
      toast.error("Please fill in required fields");
      return;
    }

    const newServices = [...servicesOffered, serviceForm];
    updateServicesMutation.mutate(newServices);
  };

  const handleEditService = () => {
    const updatedServices = servicesOffered.map((s, idx) => 
      idx === editingService ? serviceForm : s
    );
    updateServicesMutation.mutate(updatedServices);
  };

  const handleDeleteService = (index) => {
    const newServices = servicesOffered.filter((_, idx) => idx !== index);
    updateServicesMutation.mutate(newServices);
  };

  const openEditDialog = (service, index) => {
    setEditingService(index);
    setServiceForm(service);
    setShowAddDialog(true);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Your Services</CardTitle>
            <Button
              onClick={() => {
                setEditingService(null);
                setServiceForm({ service_name: "", description: "", price: "", duration: "" });
                setShowAddDialog(true);
              }}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Service
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {servicesOffered.length === 0 ? (
            <div className="text-center py-12">
              <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No services added yet</p>
              <Button
                onClick={() => setShowAddDialog(true)}
                variant="outline"
              >
                Add Your First Service
              </Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {servicesOffered.map((service, index) => (
                <Card key={index} className="border-2">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold text-lg">{service.service_name}</h3>
                      <div className="flex gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => openEditDialog(service, index)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDeleteService(index)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{service.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-green-600">
                        <DollarSign className="w-4 h-4" />
                        <span className="font-semibold">${service.price}</span>
                      </div>
                      {service.duration && (
                        <div className="flex items-center gap-1 text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span className="text-sm">{service.duration}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Service Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingService !== null ? "Edit Service" : "Add New Service"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Service Name *</Label>
              <Input
                placeholder="e.g., Personal Care Support"
                value={serviceForm.service_name}
                onChange={(e) => setServiceForm({ ...serviceForm, service_name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Describe what this service includes..."
                value={serviceForm.description}
                onChange={(e) => setServiceForm({ ...serviceForm, description: e.target.value })}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Price (AUD) *</Label>
                <Input
                  type="number"
                  placeholder="50"
                  value={serviceForm.price}
                  onChange={(e) => setServiceForm({ ...serviceForm, price: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Duration</Label>
                <Input
                  placeholder="e.g., 1 hour"
                  value={serviceForm.duration}
                  onChange={(e) => setServiceForm({ ...serviceForm, duration: e.target.value })}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={editingService !== null ? handleEditService : handleAddService}
                disabled={updateServicesMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {updateServicesMutation.isPending ? "Saving..." : "Save Service"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}