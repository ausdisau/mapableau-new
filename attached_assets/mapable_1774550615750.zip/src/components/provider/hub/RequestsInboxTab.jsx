import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Inbox, 
  CheckCircle, 
  XCircle, 
  Clock, 
  MapPin,
  Calendar,
  User,
  MessageSquare,
  DollarSign
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function RequestsInboxTab() {
  const queryClient = useQueryClient();
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showResponseDialog, setShowResponseDialog] = useState(false);
  const [responseMessage, setResponseMessage] = useState("");
  const [responseAction, setResponseAction] = useState(null);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["allServiceRequests"],
    queryFn: () => base44.entities.ServiceRequest.list("-created_date"),
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["allTransportBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-created_date"),
  });

  const respondToRequestMutation = useMutation({
    mutationFn: async ({ requestId, action, message }) => {
      const newStatus = action === "accept" ? "confirmed" : "cancelled";
      await base44.entities.ServiceRequest.update(requestId, { status: newStatus });
      
      // Send notification to requester
      if (message) {
        // Could create a message or notification here
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allServiceRequests"] });
      setShowResponseDialog(false);
      setSelectedRequest(null);
      setResponseMessage("");
      toast.success("Request updated!");
    },
  });

  const pendingRequests = serviceRequests.filter(r => r.status === "pending");
  const confirmedRequests = serviceRequests.filter(r => r.status === "confirmed");
  const completedRequests = serviceRequests.filter(r => r.status === "completed");

  const handleRespond = (request, action) => {
    setSelectedRequest(request);
    setResponseAction(action);
    setShowResponseDialog(true);
  };

  const submitResponse = () => {
    respondToRequestMutation.mutate({
      requestId: selectedRequest.id,
      action: responseAction,
      message: responseMessage,
    });
  };

  const RequestCard = ({ request }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="space-y-3">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold text-lg capitalize">
                {request.service_type?.replace(/_/g, " ")}
              </h3>
              <p className="text-sm text-gray-600">Requested by {request.created_by}</p>
            </div>
            <Badge variant="outline" className="capitalize">
              {request.status}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-500" />
              <span>{format(new Date(request.date), "MMM d, yyyy")}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-500" />
              <span>{request.time || "Flexible"}</span>
            </div>
            {request.location && (
              <div className="flex items-center gap-2 col-span-2">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span className="truncate">{request.location}</span>
              </div>
            )}
            {request.total_cost && (
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-gray-500" />
                <span className="font-semibold text-green-600">${request.total_cost}</span>
              </div>
            )}
          </div>

          {request.notes && (
            <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">
              {request.notes}
            </p>
          )}

          {request.status === "pending" && (
            <div className="flex gap-2 pt-3 border-t">
              <Button
                onClick={() => handleRespond(request, "accept")}
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Accept
              </Button>
              <Button
                onClick={() => handleRespond(request, "decline")}
                variant="outline"
                className="flex-1 text-red-600 hover:bg-red-50 gap-2"
              >
                <XCircle className="w-4 h-4" />
                Decline
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <Tabs defaultValue="pending" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending" className="gap-2">
            <Inbox className="w-4 h-4" />
            Pending ({pendingRequests.length})
          </TabsTrigger>
          <TabsTrigger value="confirmed" className="gap-2">
            <CheckCircle className="w-4 h-4" />
            Confirmed ({confirmedRequests.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="gap-2">
            <Calendar className="w-4 h-4" />
            Completed ({completedRequests.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          {pendingRequests.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Inbox className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No pending requests</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {pendingRequests.map(request => (
                <RequestCard key={request.id} request={request} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="confirmed">
          {confirmedRequests.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No confirmed bookings</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {confirmedRequests.map(request => (
                <RequestCard key={request.id} request={request} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed">
          {completedRequests.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No completed bookings</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {completedRequests.map(request => (
                <RequestCard key={request.id} request={request} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Response Dialog */}
      <Dialog open={showResponseDialog} onOpenChange={setShowResponseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {responseAction === "accept" ? "Accept Request" : "Decline Request"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Message to Client (Optional)</Label>
              <Textarea
                placeholder={
                  responseAction === "accept" 
                    ? "Thank you for your booking. I look forward to working with you!"
                    : "Please provide a reason for declining..."
                }
                value={responseMessage}
                onChange={(e) => setResponseMessage(e.target.value)}
                rows={4}
              />
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowResponseDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={submitResponse}
                disabled={respondToRequestMutation.isPending}
                className={responseAction === "accept" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}
              >
                {respondToRequestMutation.isPending ? "Processing..." : "Confirm"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}