import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Star, Quote, ThumbsUp, Calendar, User } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function TestimonialsSection({ providerId, isOwnProfile = false }) {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [testimonialText, setTestimonialText] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["providerReviews", providerId],
    queryFn: () => base44.entities.ProviderReview.filter({ provider_id: providerId }),
    enabled: !!providerId,
  });

  // Featured testimonials (4+ stars with comments)
  const testimonials = reviews
    .filter(r => r.rating >= 4 && r.content && r.content.length > 20)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 6);

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Quote className="w-6 h-6 text-blue-600" />
              Client Testimonials
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              {reviews.length} total reviews • {averageRating.toFixed(1)} average rating
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {testimonials.length === 0 ? (
          <div className="text-center py-12">
            <Quote className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No testimonials yet</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {testimonials.map((review) => (
              <Card key={review.id} className="border-2 border-blue-100 bg-gradient-to-br from-white to-blue-50">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                      <User className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold">{review.created_by}</span>
                        {review.would_recommend && (
                          <Badge className="bg-green-100 text-green-700 text-xs">
                            <ThumbsUp className="w-3 h-3 mr-1" />
                            Recommended
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-600">
                          {format(new Date(review.created_date), "MMM d, yyyy")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {review.title && (
                    <h4 className="font-semibold mb-2">{review.title}</h4>
                  )}
                  
                  <p className="text-gray-700 text-sm leading-relaxed">
                    "{review.content}"
                  </p>

                  {/* Rating Breakdown */}
                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t text-xs">
                    {review.professionalism_rating && (
                      <div>
                        <span className="text-gray-600">Professionalism:</span>
                        <span className="ml-1 font-semibold">{review.professionalism_rating}/5</span>
                      </div>
                    )}
                    {review.communication_rating && (
                      <div>
                        <span className="text-gray-600">Communication:</span>
                        <span className="ml-1 font-semibold">{review.communication_rating}/5</span>
                      </div>
                    )}
                    {review.reliability_rating && (
                      <div>
                        <span className="text-gray-600">Reliability:</span>
                        <span className="ml-1 font-semibold">{review.reliability_rating}/5</span>
                      </div>
                    )}
                    {review.quality_of_service_rating && (
                      <div>
                        <span className="text-gray-600">Quality:</span>
                        <span className="ml-1 font-semibold">{review.quality_of_service_rating}/5</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {testimonials.length > 0 && reviews.length > testimonials.length && (
          <div className="text-center mt-6">
            <p className="text-sm text-gray-600">
              Showing {testimonials.length} of {reviews.length} reviews
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}