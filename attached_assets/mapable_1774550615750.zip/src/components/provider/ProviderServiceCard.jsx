import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Clock, Plus, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProviderServiceCard({ provider, onBookNow }) {
  const services = provider.services_offered || [];
  const rating = provider.rating || 0;
  const reviewCount = provider.review_count || 0;

  return (
    <Card className="hover:shadow-lg transition-all hover:border-blue-200 cursor-pointer">
      <CardContent className="p-6">
        <div className="flex gap-4">
          {/* Provider Photo */}
          <div className="flex-shrink-0">
            {provider.photo_url ? (
              <img
                src={provider.photo_url}
                alt={provider.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
            ) : (
              <div className="w-20 h-20 rounded-lg bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-2xl">
                  {provider.name?.charAt(0) || "P"}
                </span>
              </div>
            )}
          </div>

          {/* Provider Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-bold text-lg">{provider.name}</h3>
                <p className="text-sm text-gray-600 capitalize">
                  {provider.type?.replace(/_/g, " ")}
                </p>
              </div>
              {provider.verified && (
                <Badge className="bg-green-100 text-green-700">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>

            {/* Rating */}
            {rating > 0 && (
              <div className="flex items-center gap-2 mb-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className={i < Math.floor(rating) ? "text-yellow-400" : "text-gray-300"}>
                      ★
                    </span>
                  ))}
                </div>
                <span className="text-sm text-gray-600">
                  {rating.toFixed(1)} ({reviewCount} reviews)
                </span>
              </div>
            )}

            {/* Location */}
            {provider.location_suburb && (
              <p className="text-sm text-gray-600 mb-3">
                📍 {provider.location_suburb}, {provider.location_state}
              </p>
            )}

            {/* Services */}
            {services.length > 0 && (
              <div className="space-y-2 mb-4">
                {services.slice(0, 2).map((service, idx) => (
                  <div key={idx} className="flex items-center justify-between text-sm bg-gray-50 p-2 rounded">
                    <span className="font-medium">{service.service_name}</span>
                    <div className="flex items-center gap-3">
                      {service.duration && (
                        <span className="text-gray-600 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {service.duration}
                        </span>
                      )}
                      <span className="text-green-600 font-semibold flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />
                        {service.price}
                      </span>
                    </div>
                  </div>
                ))}
                {services.length > 2 && (
                  <p className="text-xs text-gray-500">+{services.length - 2} more services</p>
                )}
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <Link to={`${createPageUrl("ServiceProviderProfile")}?id=${provider.id}`} className="flex-1">
                <Button variant="outline" className="w-full">
                  View Profile
                </Button>
              </Link>
              {onBookNow && (
                <Button
                  onClick={() => onBookNow(provider)}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Book Now
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}