import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Star, ThumbsUp, CheckCircle, MessageSquare } from "lucide-react";
import { format } from "date-fns";

function RatingBreakdown({ label, rating }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm font-medium w-32">{label}</span>
      <Progress value={rating * 20} className="flex-1 h-2" />
      <span className="text-sm font-bold w-8">{rating.toFixed(1)}</span>
    </div>
  );
}

function ReviewCard({ review }) {
  return (
    <div className="p-4 border rounded-lg space-y-3">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-4 h-4 ${
                    star <= review.rating
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            {review.verified_booking && (
              <Badge className="bg-green-100 text-green-700 text-xs">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="font-medium">{review.created_by}</span>
            <span>•</span>
            <span>{format(new Date(review.created_date), "MMM d, yyyy")}</span>
          </div>
        </div>
        {review.would_recommend && (
          <Badge variant="outline" className="text-xs">
            <ThumbsUp className="w-3 h-3 mr-1" />
            Recommends
          </Badge>
        )}
      </div>

      {review.title && (
        <h4 className="font-semibold text-gray-900">{review.title}</h4>
      )}

      <p className="text-sm text-gray-700 leading-relaxed">{review.content}</p>

      {/* Sub-ratings */}
      <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
        {review.professionalism && (
          <div>Professionalism: {review.professionalism}/5</div>
        )}
        {review.communication && (
          <div>Communication: {review.communication}/5</div>
        )}
        {review.reliability && (
          <div>Reliability: {review.reliability}/5</div>
        )}
        {review.quality_of_service && (
          <div>Quality: {review.quality_of_service}/5</div>
        )}
      </div>

      {review.helpful_count > 0 && (
        <div className="flex items-center gap-2 text-sm text-gray-600 pt-2 border-t">
          <ThumbsUp className="w-4 h-4" />
          <span>{review.helpful_count} people found this helpful</span>
        </div>
      )}
    </div>
  );
}

export default function ProviderReviewsSection({ provider, reviews, averageRatings }) {
  const queryClient = useQueryClient();
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewData, setReviewData] = useState({
    rating: 5,
    professionalism: 5,
    communication: 5,
    reliability: 5,
    quality_of_service: 5,
    title: "",
    content: "",
    service_date: "",
    would_recommend: true,
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.ProviderReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["providerReviews", provider.id] });
      setShowReviewForm(false);
      setReviewData({
        rating: 5,
        professionalism: 5,
        communication: 5,
        reliability: 5,
        quality_of_service: 5,
        title: "",
        content: "",
        service_date: "",
        would_recommend: true,
      });
    },
  });

  const handleSubmitReview = () => {
    createReviewMutation.mutate({
      ...reviewData,
      provider_id: provider.id,
    });
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Reviews List */}
      <div className="lg:col-span-2 space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-secondary" />
                Client Reviews ({reviews.length})
              </CardTitle>
              {!showReviewForm && (
                <Button
                  onClick={() => setShowReviewForm(true)}
                  className="bg-secondary hover:bg-secondary/90"
                  size="sm"
                >
                  Write Review
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {showReviewForm && (
              <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
                <h3 className="font-semibold text-lg">Share Your Experience</h3>
                
                <div className="space-y-3">
                  <div>
                    <Label>Overall Rating</Label>
                    <div className="flex gap-2 mt-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setReviewData({ ...reviewData, rating: star })}
                        >
                          <Star
                            className={`w-8 h-8 cursor-pointer ${
                              star <= reviewData.rating
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-gray-300"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs">Professionalism</Label>
                      <Input
                        type="number"
                        min="1"
                        max="5"
                        value={reviewData.professionalism}
                        onChange={(e) => setReviewData({ ...reviewData, professionalism: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Communication</Label>
                      <Input
                        type="number"
                        min="1"
                        max="5"
                        value={reviewData.communication}
                        onChange={(e) => setReviewData({ ...reviewData, communication: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Reliability</Label>
                      <Input
                        type="number"
                        min="1"
                        max="5"
                        value={reviewData.reliability}
                        onChange={(e) => setReviewData({ ...reviewData, reliability: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Quality of Service</Label>
                      <Input
                        type="number"
                        min="1"
                        max="5"
                        value={reviewData.quality_of_service}
                        onChange={(e) => setReviewData({ ...reviewData, quality_of_service: parseInt(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Service Date</Label>
                    <Input
                      type="date"
                      value={reviewData.service_date}
                      onChange={(e) => setReviewData({ ...reviewData, service_date: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label>Review Title</Label>
                    <Input
                      placeholder="Brief summary of your experience"
                      value={reviewData.title}
                      onChange={(e) => setReviewData({ ...reviewData, title: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label>Your Review</Label>
                    <Textarea
                      placeholder="Share your detailed experience..."
                      value={reviewData.content}
                      onChange={(e) => setReviewData({ ...reviewData, content: e.target.value })}
                      className="h-32"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={handleSubmitReview}
                    className="bg-secondary hover:bg-secondary/90"
                    disabled={!reviewData.content || createReviewMutation.isPending}
                  >
                    Submit Review
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowReviewForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {reviews.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No reviews yet. Be the first to share your experience!
              </p>
            ) : (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Rating Summary Sidebar */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Rating Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-6">
              <div className="text-5xl font-bold text-primary mb-2">
                {averageRatings.overall.toFixed(1)}
              </div>
              <div className="flex justify-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= averageRatings.overall
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="text-sm text-gray-600">Based on {reviews.length} reviews</p>
            </div>

            <Separator className="my-4" />

            <div className="space-y-3">
              <RatingBreakdown label="Professionalism" rating={averageRatings.professionalism} />
              <RatingBreakdown label="Communication" rating={averageRatings.communication} />
              <RatingBreakdown label="Reliability" rating={averageRatings.reliability} />
              <RatingBreakdown label="Quality" rating={averageRatings.quality} />
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((rating) => {
                const count = reviews.filter((r) => r.rating === rating).length;
                const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                return (
                  <div key={rating} className="flex items-center gap-2">
                    <span className="text-sm font-medium w-8">{rating}★</span>
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-yellow-400"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600 w-8">{count}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {reviews.length > 0 && (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="text-center">
                <ThumbsUp className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                <p className="text-sm font-semibold text-blue-900 mb-1">
                  {Math.round((reviews.filter(r => r.would_recommend).length / reviews.length) * 100)}%
                </p>
                <p className="text-xs text-blue-800">
                  of clients recommend this provider
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}