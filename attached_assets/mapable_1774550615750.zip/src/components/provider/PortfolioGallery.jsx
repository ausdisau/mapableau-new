import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Image, Plus, X, Upload, ExternalLink, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function PortfolioGallery({ providerId, providerEmail, isOwnProfile = false }) {
  const queryClient = useQueryClient();
  const [selectedImage, setSelectedImage] = useState(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { data: provider } = useQuery({
    queryKey: ["provider", providerId],
    queryFn: async () => {
      const providers = await base44.entities.ServiceProvider.filter({ id: providerId });
      return providers[0];
    },
    enabled: !!providerId,
  });

  const galleryUrls = provider?.gallery_urls || [];

  const uploadImageMutation = useMutation({
    mutationFn: async (file) => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const newGallery = [...galleryUrls, file_url];
      
      return await base44.entities.ServiceProvider.update(providerId, {
        gallery_urls: newGallery
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["provider", providerId] });
      setShowUploadDialog(false);
      toast.success("Photo added to gallery!");
    },
  });

  const deleteImageMutation = useMutation({
    mutationFn: async (imageUrl) => {
      const newGallery = galleryUrls.filter(url => url !== imageUrl);
      return await base44.entities.ServiceProvider.update(providerId, {
        gallery_urls: newGallery
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["provider", providerId] });
      setSelectedImage(null);
      toast.success("Photo removed from gallery");
    },
  });

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    setUploading(true);
    try {
      await uploadImageMutation.mutateAsync(file);
    } catch (error) {
      toast.error("Failed to upload photo");
    }
    setUploading(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Image className="w-6 h-6 text-purple-600" />
            <CardTitle>Portfolio & Media Gallery</CardTitle>
          </div>
          {isOwnProfile && (
            <Button
              onClick={() => setShowUploadDialog(true)}
              className="bg-purple-600 hover:bg-purple-700 gap-2"
              size="sm"
            >
              <Plus className="w-4 h-4" />
              Add Photo
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {galleryUrls.length === 0 ? (
          <div className="text-center py-12">
            <Image className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">No portfolio items yet</p>
            {isOwnProfile && (
              <Button
                onClick={() => setShowUploadDialog(true)}
                variant="outline"
              >
                Upload Photos
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {galleryUrls.map((url, index) => (
              <div
                key={index}
                className="relative aspect-square rounded-lg overflow-hidden cursor-pointer group"
                onClick={() => setSelectedImage(url)}
              >
                <img
                  src={url}
                  alt={`Portfolio ${index + 1}`}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                  <ExternalLink className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                {isOwnProfile && (
                  <Button
                    size="icon"
                    variant="destructive"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteImageMutation.mutate(url);
                    }}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}

        {galleryUrls.length > 0 && (
          <p className="text-sm text-gray-600 text-center mt-4">
            {galleryUrls.length} photo{galleryUrls.length !== 1 ? 's' : ''} in gallery
          </p>
        )}
      </CardContent>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add to Portfolio</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                disabled={uploading}
                className="hidden"
                id="portfolio-upload"
              />
              <label htmlFor="portfolio-upload" className="cursor-pointer">
                {uploading ? (
                  <div className="flex flex-col items-center">
                    <Loader2 className="w-12 h-12 text-purple-600 animate-spin mb-3" />
                    <p className="text-gray-600">Uploading...</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <Upload className="w-12 h-12 text-gray-400 mb-3" />
                    <p className="text-gray-600 mb-1">Click to upload photo</p>
                    <p className="text-xs text-gray-500">JPG, PNG or GIF. Max 5MB.</p>
                  </div>
                )}
              </label>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Preview Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Portfolio Photo</DialogTitle>
          </DialogHeader>
          {selectedImage && (
            <div className="relative">
              <img
                src={selectedImage}
                alt="Portfolio"
                className="w-full h-auto rounded-lg"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}