import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar, Clock, DollarSign, CheckCircle } from "lucide-react";

export default function ProviderBookingSection({ provider }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [bookingData, setBookingData] = useState({
    service_type: "personal_care",
    date: "",
    time: "",
    duration_hours: 2,
    location: "",
    notes: "",
  });

  const createBookingMutation = useMutation({
    mutationFn: (data) => base44.entities.ServiceRequest.create(data),
    onSuccess: (createdRequest) => {
      queryClient.invalidateQueries({ queryKey: ["myServiceRequests"] });
      navigate(`${createPageUrl("Dashboard")}?booking_success=true`);
    },
  });

  const handleBooking = () => {
    createBookingMutation.mutate({
      ...bookingData,
      provider_id: provider.id,
      status: "pending",
      payment_status: "pending",
      total_cost: (provider.hourly_rate || 0) * bookingData.duration_hours,
    });
  };

  const totalCost = (provider.hourly_rate || 0) * bookingData.duration_hours;

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Book a Service</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Service Type</Label>
                <Select
                  value={bookingData.service_type}
                  onValueChange={(v) => setBookingData({ ...bookingData, service_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal_care">Personal Care</SelectItem>
                    <SelectItem value="community_access">Community Access</SelectItem>
                    <SelectItem value="therapy">Therapy</SelectItem>
                    <SelectItem value="employment_support">Employment Support</SelectItem>
                    <SelectItem value="transport">Transport</SelectItem>
                    <SelectItem value="household_support">Household Support</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Duration (hours)</Label>
                <Input
                  type="number"
                  min="1"
                  max="8"
                  value={bookingData.duration_hours}
                  onChange={(e) => setBookingData({ ...bookingData, duration_hours: parseInt(e.target.value) || 1 })}
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input
                  type="date"
                  value={bookingData.date}
                  onChange={(e) => setBookingData({ ...bookingData, date: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              <div className="space-y-2">
                <Label>Time</Label>
                <Input
                  type="time"
                  value={bookingData.time}
                  onChange={(e) => setBookingData({ ...bookingData, time: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Location</Label>
              <Input
                placeholder="Where will the service be provided?"
                value={bookingData.location}
                onChange={(e) => setBookingData({ ...bookingData, location: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Additional Notes</Label>
              <Textarea
                placeholder="Any specific requirements or information..."
                value={bookingData.notes}
                onChange={(e) => setBookingData({ ...bookingData, notes: e.target.value })}
                rows={4}
              />
            </div>

            <Alert>
              <CheckCircle className="w-4 h-4" />
              <AlertDescription>
                <div className="flex justify-between items-center">
                  <span>Estimated cost:</span>
                  <span className="text-lg font-bold text-primary">${totalCost.toFixed(2)}</span>
                </div>
                {provider.ndis_registered && (
                  <p className="text-xs mt-2 text-gray-600">
                    ✓ This service is NDIS claimable
                  </p>
                )}
              </AlertDescription>
            </Alert>

            <Button
              onClick={handleBooking}
              className="w-full bg-secondary hover:bg-secondary/90 h-12 text-base"
              disabled={!bookingData.date || !bookingData.time || !bookingData.location || createBookingMutation.isPending}
            >
              {createBookingMutation.isPending ? "Processing..." : "Continue to Payment"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Booking Summary Sidebar */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Booking Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {bookingData.date && (
              <div className="flex items-center gap-3 text-sm">
                <Calendar className="w-5 h-5 text-secondary" />
                <div>
                  <p className="font-medium">Date</p>
                  <p className="text-gray-600">{new Date(bookingData.date).toLocaleDateString()}</p>
                </div>
              </div>
            )}

            {bookingData.time && (
              <div className="flex items-center gap-3 text-sm">
                <Clock className="w-5 h-5 text-secondary" />
                <div>
                  <p className="font-medium">Time</p>
                  <p className="text-gray-600">{bookingData.time}</p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-3 text-sm">
              <DollarSign className="w-5 h-5 text-secondary" />
              <div>
                <p className="font-medium">Rate</p>
                <p className="text-gray-600">${provider.hourly_rate}/hour × {bookingData.duration_hours}h</p>
              </div>
            </div>

            <div className="pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total Cost</span>
                <span className="text-2xl font-bold text-primary">${totalCost.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {provider.availability && (
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg">Availability</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700">{provider.availability}</p>
            </CardContent>
          </Card>
        )}

        {provider.response_time && (
          <Card>
            <CardContent className="pt-6 text-center">
              <Clock className="w-8 h-8 text-secondary mx-auto mb-2" />
              <p className="text-sm text-gray-600">Average response time</p>
              <p className="text-lg font-bold text-primary">{provider.response_time}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}