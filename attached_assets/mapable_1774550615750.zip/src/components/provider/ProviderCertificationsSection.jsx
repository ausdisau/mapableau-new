import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Calendar, CheckCircle, AlertCircle } from "lucide-react";
import { format, isAfter, isBefore } from "date-fns";

export default function ProviderCertificationsSection({ provider }) {
  const hasCertifications = provider.certifications && provider.certifications.length > 0;
  const hasQualifications = provider.qualifications;

  if (!hasCertifications && !hasQualifications) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Award className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No certifications listed yet.</p>
        </CardContent>
      </Card>
    );
  }

  const today = new Date();

  return (
    <div className="space-y-6">
      {/* Qualifications Overview */}
      {hasQualifications && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-secondary" />
              Professional Qualifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed">{provider.qualifications}</p>
          </CardContent>
        </Card>
      )}

      {/* Certifications */}
      {hasCertifications && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-secondary" />
              Certifications & Credentials
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {provider.certifications.map((cert, idx) => {
                const isExpired = cert.expiry_date && isBefore(new Date(cert.expiry_date), today);
                const isExpiringSoon = cert.expiry_date && 
                  isAfter(new Date(cert.expiry_date), today) &&
                  isBefore(new Date(cert.expiry_date), new Date(today.getTime() + 90 * 24 * 60 * 60 * 1000));

                return (
                  <div key={idx} className="flex gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-gray-900">{cert.name}</h4>
                          {cert.issuing_organization && (
                            <p className="text-sm text-gray-600">{cert.issuing_organization}</p>
                          )}
                        </div>
                        {!isExpired && !isExpiringSoon && (
                          <Badge className="bg-green-100 text-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Active
                          </Badge>
                        )}
                        {isExpiringSoon && (
                          <Badge className="bg-yellow-100 text-yellow-700">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Expiring Soon
                          </Badge>
                        )}
                        {isExpired && (
                          <Badge variant="destructive">
                            Expired
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-3 text-xs text-gray-600">
                        {cert.issue_date && (
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>Issued: {format(new Date(cert.issue_date), "MMM yyyy")}</span>
                          </div>
                        )}
                        {cert.expiry_date && (
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>Expires: {format(new Date(cert.expiry_date), "MMM yyyy")}</span>
                          </div>
                        )}
                        {cert.credential_id && (
                          <div>
                            <span className="font-medium">ID:</span> {cert.credential_id}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}