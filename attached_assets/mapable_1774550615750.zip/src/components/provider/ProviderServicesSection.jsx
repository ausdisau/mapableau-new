import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DollarSign, Clock, CheckCircle } from "lucide-react";

export default function ProviderServicesSection({ provider }) {
  if (!provider.services_offered || provider.services_offered.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">No services listed yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {provider.services_offered.map((service, idx) => (
        <Card key={idx} className="hover-lift">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-xl">{service.service_name}</CardTitle>
                {service.duration && (
                  <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                    <Clock className="w-4 h-4" />
                    {service.duration}
                  </div>
                )}
              </div>
              {service.price && (
                <Badge className="bg-secondary text-white text-lg px-3 py-1">
                  ${service.price}
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {service.description && (
              <p className="text-gray-700 text-sm leading-relaxed mb-4">
                {service.description}
              </p>
            )}
            <Button className="w-full bg-secondary hover:bg-secondary/90">
              Book This Service
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}