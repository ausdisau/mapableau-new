import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle, Clock, AlertTriangle, Award, FileCheck } from "lucide-react";
import { format, differenceInDays } from "date-fns";

export default function CertificationsDisplay({ providerEmail }) {
  const { data: credentials = [] } = useQuery({
    queryKey: ["providerCredentials", providerEmail],
    queryFn: () => base44.entities.ProviderCredential.filter({ 
      provider_email: providerEmail,
      verification_status: "verified"
    }),
    enabled: !!providerEmail,
  });

  const getExpiryStatus = (expiryDate) => {
    if (!expiryDate) return { status: "none", daysLeft: null };
    
    const daysLeft = differenceInDays(new Date(expiryDate), new Date());
    
    if (daysLeft < 0) return { status: "expired", daysLeft };
    if (daysLeft <= 30) return { status: "expiring", daysLeft };
    return { status: "valid", daysLeft };
  };

  const groupedCredentials = {
    insurance: credentials.filter(c => c.credential_type?.includes("insurance")),
    licenses: credentials.filter(c => c.credential_type === "professional_license" || c.credential_type === "drivers_license"),
    checks: credentials.filter(c => c.credential_type?.includes("check") || c.credential_type?.includes("screening")),
    certifications: credentials.filter(c => c.credential_type?.includes("certificate")),
    other: credentials.filter(c => !c.credential_type?.includes("insurance") && 
                                    !["professional_license", "drivers_license"].includes(c.credential_type) &&
                                    !c.credential_type?.includes("check") && 
                                    !c.credential_type?.includes("screening") &&
                                    !c.credential_type?.includes("certificate"))
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="w-6 h-6 text-green-600" />
          <div>
            <CardTitle>Verified Credentials</CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              {credentials.length} verified credential{credentials.length !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {credentials.length === 0 ? (
          <div className="text-center py-8">
            <Shield className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600">No verified credentials</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Insurance */}
            {groupedCredentials.insurance.length > 0 && (
              <div>
                <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Insurance Coverage
                </h3>
                <div className="grid gap-3">
                  {groupedCredentials.insurance.map(cred => {
                    const expiry = getExpiryStatus(cred.expiry_date);
                    return (
                      <div key={cred.id} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <div>
                            <p className="font-medium text-sm">{cred.credential_name}</p>
                            <p className="text-xs text-gray-600">{cred.issuing_organization}</p>
                          </div>
                        </div>
                        {cred.expiry_date && (
                          <Badge className={
                            expiry.status === "expiring" ? "bg-yellow-100 text-yellow-700" :
                            expiry.status === "valid" ? "bg-green-100 text-green-700" :
                            "bg-red-100 text-red-700"
                          }>
                            {expiry.status === "valid" ? "Valid" :
                             expiry.status === "expiring" ? `${expiry.daysLeft}d left` :
                             "Expired"}
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Professional Licenses */}
            {groupedCredentials.licenses.length > 0 && (
              <div>
                <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                  <Award className="w-4 h-4" />
                  Professional Licenses
                </h3>
                <div className="grid gap-3">
                  {groupedCredentials.licenses.map(cred => {
                    const expiry = getExpiryStatus(cred.expiry_date);
                    return (
                      <div key={cred.id} className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-5 h-5 text-blue-600" />
                          <div>
                            <p className="font-medium text-sm">{cred.credential_name}</p>
                            {cred.credential_number && (
                              <p className="text-xs text-gray-600">License #: {cred.credential_number}</p>
                            )}
                          </div>
                        </div>
                        {cred.expiry_date && (
                          <div className="text-right">
                            <p className="text-xs text-gray-600">Expires</p>
                            <p className="text-xs font-semibold">
                              {format(new Date(cred.expiry_date), "MMM yyyy")}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Background Checks */}
            {groupedCredentials.checks.length > 0 && (
              <div>
                <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                  <FileCheck className="w-4 h-4" />
                  Background Checks
                </h3>
                <div className="grid gap-3">
                  {groupedCredentials.checks.map(cred => (
                    <div key={cred.id} className="flex items-center justify-between p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-purple-600" />
                        <div>
                          <p className="font-medium text-sm">{cred.credential_name}</p>
                          {cred.issue_date && (
                            <p className="text-xs text-gray-600">
                              Issued: {format(new Date(cred.issue_date), "MMM yyyy")}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge className="bg-purple-100 text-purple-700">
                        Verified
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Certifications */}
            {groupedCredentials.certifications.length > 0 && (
              <div>
                <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                  <Award className="w-4 h-4" />
                  Professional Certifications
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {groupedCredentials.certifications.map(cred => (
                    <div key={cred.id} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start gap-2 mb-2">
                        <CheckCircle className="w-4 h-4 text-yellow-600 mt-0.5" />
                        <p className="font-medium text-sm flex-1">{cred.credential_name}</p>
                      </div>
                      {cred.issuing_organization && (
                        <p className="text-xs text-gray-600 ml-6">{cred.issuing_organization}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Verification Badge */}
        {credentials.length > 0 && (
          <div className="mt-6 p-4 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold text-green-900">Verified Provider</p>
                <p className="text-sm text-green-700">
                  All credentials have been verified by MapAble
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}