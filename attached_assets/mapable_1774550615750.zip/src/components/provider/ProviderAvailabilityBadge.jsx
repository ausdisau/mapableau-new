import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Clock } from "lucide-react";

export default function ProviderAvailabilityBadge({ providerEmail, showDetails = false }) {
  const { data: availability } = useQuery({
    queryKey: ["providerAvailability", providerEmail],
    queryFn: async () => {
      const avail = await base44.entities.ProviderAvailability.filter({
        provider_email: providerEmail
      });
      return avail[0];
    },
    enabled: !!providerEmail,
  });

  if (!availability) {
    return (
      <Badge variant="outline" className="gap-1">
        <Clock className="w-3 h-3" />
        Availability not set
      </Badge>
    );
  }

  const isAccepting = availability.accepting_bookings;
  const hasSchedule = availability.weekly_schedule && 
    Object.values(availability.weekly_schedule).some(day => day && day.length > 0);

  if (!showDetails) {
    return (
      <Badge className={isAccepting ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
        {isAccepting ? (
          <>
            <CheckCircle className="w-3 h-3 mr-1" />
            Accepting Bookings
          </>
        ) : (
          <>
            <XCircle className="w-3 h-3 mr-1" />
            Not Accepting
          </>
        )}
      </Badge>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      <Badge className={isAccepting ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
        {isAccepting ? "Accepting Bookings" : "Not Accepting"}
      </Badge>
      {hasSchedule && (
        <Badge variant="outline">
          <Clock className="w-3 h-3 mr-1" />
          {availability.lead_time_hours}h lead time
        </Badge>
      )}
      {availability.instant_booking_enabled && (
        <Badge className="bg-blue-100 text-blue-700">
          Instant Booking
        </Badge>
      )}
    </div>
  );
}