import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  FileText, 
  Eye, 
  Edit, 
  Trash2, 
  Calendar, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { toast } from "sonner";
import VerificationBadge from "../verification/VerificationBadge";
import CredentialUploadForm from "./CredentialUploadForm";

export default function CredentialsList({ credentials }) {
  const queryClient = useQueryClient();
  const [selectedCredential, setSelectedCredential] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const deleteCredentialMutation = useMutation({
    mutationFn: async (id) => {
      // In a real app, we'd soft delete by updating status
      await base44.entities.ProviderCredential.update(id, {
        verification_status: "pending_submission"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myCredentials"] });
      setShowDeleteDialog(false);
      setSelectedCredential(null);
      toast.success("Credential removed successfully");
    },
  });

  const getCredentialTypeLabel = (type) => {
    const labels = {
      professional_license: "Professional License",
      certification: "Certification",
      insurance_professional_indemnity: "Professional Indemnity Insurance",
      insurance_public_liability: "Public Liability Insurance",
      insurance_workers_compensation: "Workers Compensation Insurance",
      police_check: "Police Check",
      working_with_children_check: "Working with Children Check",
      ndis_worker_screening: "NDIS Worker Screening",
      first_aid_certificate: "First Aid Certificate",
      disability_support_certificate: "Disability Support Certificate",
      drivers_license: "Driver's License",
      vehicle_registration: "Vehicle Registration",
      vehicle_insurance: "Vehicle Insurance",
      other: "Other"
    };
    return labels[type] || type;
  };

  const getExpiryStatus = (expiryDate) => {
    if (!expiryDate) return null;
    
    const days = differenceInDays(new Date(expiryDate), new Date());
    
    if (days < 0) {
      return { 
        type: "expired", 
        label: "Expired", 
        className: "bg-red-100 text-red-700",
        icon: AlertTriangle
      };
    } else if (days <= 7) {
      return { 
        type: "critical", 
        label: `${days} days left`, 
        className: "bg-orange-100 text-orange-700",
        icon: AlertTriangle
      };
    } else if (days <= 30) {
      return { 
        type: "warning", 
        label: `${days} days left`, 
        className: "bg-yellow-100 text-yellow-700",
        icon: Clock
      };
    } else {
      return { 
        type: "valid", 
        label: "Valid", 
        className: "bg-green-100 text-green-700",
        icon: CheckCircle
      };
    }
  };

  if (!credentials || credentials.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            No Credentials Yet
          </h3>
          <p className="text-gray-600">
            Upload your credentials to get verified and start providing services
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="grid gap-4">
        {credentials.map((credential) => {
          const expiryStatus = getExpiryStatus(credential.expiry_date);
          const ExpiryIcon = expiryStatus?.icon;

          return (
            <Card key={credential.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <FileText className="w-6 h-6 text-blue-600" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h3 className="font-semibold text-lg">{credential.credential_name}</h3>
                        <VerificationBadge status={credential.verification_status} size="sm" />
                      </div>

                      <p className="text-sm text-gray-600 mb-2">
                        {getCredentialTypeLabel(credential.credential_type)}
                      </p>

                      <div className="space-y-1 text-sm">
                        {credential.issuing_organization && (
                          <p className="text-gray-600">
                            <span className="font-medium">Issued by:</span> {credential.issuing_organization}
                          </p>
                        )}
                        {credential.credential_number && (
                          <p className="text-gray-600">
                            <span className="font-medium">Number:</span> {credential.credential_number}
                          </p>
                        )}
                        {credential.issue_date && (
                          <p className="text-gray-600">
                            <span className="font-medium">Issued:</span> {format(new Date(credential.issue_date), "MMM d, yyyy")}
                          </p>
                        )}
                        {credential.expiry_date && (
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-600">Expires:</span>
                            <span>{format(new Date(credential.expiry_date), "MMM d, yyyy")}</span>
                            {expiryStatus && (
                              <Badge className={expiryStatus.className}>
                                {ExpiryIcon && <ExpiryIcon className="w-3 h-3 mr-1" />}
                                {expiryStatus.label}
                              </Badge>
                            )}
                          </div>
                        )}
                      </div>

                      {credential.rejection_reason && (
                        <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-800">
                          <span className="font-medium">Rejection reason:</span> {credential.rejection_reason}
                        </div>
                      )}

                      {credential.reviewed_date && (
                        <p className="text-xs text-gray-500 mt-2">
                          Reviewed on {format(new Date(credential.reviewed_date), "MMM d, yyyy")}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2 flex-shrink-0">
                    {credential.document_url && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(credential.document_url, "_blank")}
                        title="View Document"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    )}
                    
                    {["pending_submission", "rejected"].includes(credential.verification_status) && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedCredential(credential);
                          setShowEditDialog(true);
                        }}
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    )}

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedCredential(credential);
                        setShowDeleteDialog(true);
                      }}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Update Credential</DialogTitle>
          </DialogHeader>
          {selectedCredential && (
            <CredentialUploadForm
              existingCredential={selectedCredential}
              onSuccess={() => {
                setShowEditDialog(false);
                setSelectedCredential(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Credential</DialogTitle>
          </DialogHeader>
          <p className="text-gray-600">
            Are you sure you want to delete this credential? This action cannot be undone.
          </p>
          <div className="flex justify-end gap-3 mt-4">
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedCredential && deleteCredentialMutation.mutate(selectedCredential.id)}
              disabled={deleteCredentialMutation.isPending}
            >
              {deleteCredentialMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}