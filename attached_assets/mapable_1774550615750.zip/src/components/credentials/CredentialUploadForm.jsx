import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function CredentialUploadForm({ onSuccess, existingCredential = null }) {
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    credential_type: existingCredential?.credential_type || "",
    credential_name: existingCredential?.credential_name || "",
    issuing_organization: existingCredential?.issuing_organization || "",
    credential_number: existingCredential?.credential_number || "",
    issue_date: existingCredential?.issue_date || "",
    expiry_date: existingCredential?.expiry_date || "",
    applies_to_service: existingCredential?.applies_to_service || ["all"],
    document_file: null,
    document_url: existingCredential?.document_url || ""
  });

  const credentialTypes = [
    { value: "professional_license", label: "Professional License" },
    { value: "certification", label: "Certification" },
    { value: "insurance_professional_indemnity", label: "Professional Indemnity Insurance" },
    { value: "insurance_public_liability", label: "Public Liability Insurance" },
    { value: "insurance_workers_compensation", label: "Workers Compensation Insurance" },
    { value: "police_check", label: "Police Check" },
    { value: "working_with_children_check", label: "Working with Children Check" },
    { value: "ndis_worker_screening", label: "NDIS Worker Screening" },
    { value: "first_aid_certificate", label: "First Aid Certificate" },
    { value: "disability_support_certificate", label: "Disability Support Certificate" },
    { value: "drivers_license", label: "Driver's License" },
    { value: "vehicle_registration", label: "Vehicle Registration" },
    { value: "vehicle_insurance", label: "Vehicle Insurance" },
    { value: "other", label: "Other" }
  ];

  const uploadFileMutation = useMutation({
    mutationFn: async (file) => {
      const result = await base44.integrations.Core.UploadFile({ file });
      return result.file_url;
    },
  });

  const saveCredentialMutation = useMutation({
    mutationFn: async (credentialData) => {
      const user = await base44.auth.me();
      
      const dataToSave = {
        ...credentialData,
        provider_email: user.email,
        verification_status: existingCredential ? credentialData.verification_status : "submitted",
        submitted_date: new Date().toISOString(),
        is_required: true
      };

      if (existingCredential) {
        return await base44.entities.ProviderCredential.update(existingCredential.id, dataToSave);
      } else {
        return await base44.entities.ProviderCredential.create(dataToSave);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myCredentials"] });
      queryClient.invalidateQueries({ queryKey: ["allCredentials"] });
      toast.success(existingCredential ? "Credential updated successfully!" : "Credential uploaded successfully!");
      if (onSuccess) onSuccess();
    },
  });

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      toast.error("Only PDF, JPG, and PNG files are allowed");
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("File size must be less than 10MB");
      return;
    }

    setFormData({ ...formData, document_file: file });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formData.credential_type || !formData.credential_name) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (!existingCredential && !formData.document_file && !formData.document_url) {
      toast.error("Please upload a document");
      return;
    }

    setUploading(true);

    try {
      let documentUrl = formData.document_url;

      // Upload file if new file selected
      if (formData.document_file) {
        documentUrl = await uploadFileMutation.mutateAsync(formData.document_file);
      }

      // Determine document type
      let documentType = "other";
      if (documentUrl) {
        if (documentUrl.toLowerCase().endsWith('.pdf')) {
          documentType = "pdf";
        } else if (documentUrl.match(/\.(jpg|jpeg|png)$/i)) {
          documentType = "image";
        }
      }

      const credentialData = {
        credential_type: formData.credential_type,
        credential_name: formData.credential_name,
        issuing_organization: formData.issuing_organization,
        credential_number: formData.credential_number,
        issue_date: formData.issue_date || null,
        expiry_date: formData.expiry_date || null,
        document_url: documentUrl,
        document_type: documentType,
        applies_to_service: formData.applies_to_service,
        verification_status: existingCredential?.verification_status || "submitted"
      };

      await saveCredentialMutation.mutateAsync(credentialData);
    } catch (error) {
      console.error("Error uploading credential:", error);
      toast.error("Failed to upload credential. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5" />
          {existingCredential ? "Update Credential" : "Upload New Credential"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Credential Type */}
          <div className="space-y-2">
            <Label>Credential Type *</Label>
            <Select
              value={formData.credential_type}
              onValueChange={(value) => setFormData({ ...formData, credential_type: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select credential type" />
              </SelectTrigger>
              <SelectContent>
                {credentialTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Credential Name */}
          <div className="space-y-2">
            <Label>Credential Name *</Label>
            <Input
              placeholder="e.g., Certificate IV in Disability Support"
              value={formData.credential_name}
              onChange={(e) => setFormData({ ...formData, credential_name: e.target.value })}
              required
            />
          </div>

          {/* Issuing Organization */}
          <div className="space-y-2">
            <Label>Issuing Organization</Label>
            <Input
              placeholder="e.g., Australian Skills Quality Authority"
              value={formData.issuing_organization}
              onChange={(e) => setFormData({ ...formData, issuing_organization: e.target.value })}
            />
          </div>

          {/* Credential Number */}
          <div className="space-y-2">
            <Label>License/Certificate Number</Label>
            <Input
              placeholder="e.g., ABC123456"
              value={formData.credential_number}
              onChange={(e) => setFormData({ ...formData, credential_number: e.target.value })}
            />
          </div>

          {/* Dates */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Issue Date</Label>
              <Input
                type="date"
                value={formData.issue_date}
                onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Expiry Date</Label>
              <Input
                type="date"
                value={formData.expiry_date}
                onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
              />
            </div>
          </div>

          {/* Document Upload */}
          <div className="space-y-2">
            <Label>Upload Document *</Label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileChange}
                className="hidden"
                id="credential-file"
              />
              <label htmlFor="credential-file" className="cursor-pointer">
                {formData.document_file ? (
                  <div className="flex items-center justify-center gap-2">
                    <FileText className="w-8 h-8 text-green-600" />
                    <div className="text-left">
                      <p className="font-medium">{formData.document_file.name}</p>
                      <p className="text-xs text-gray-500">
                        {(formData.document_file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                ) : formData.document_url ? (
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                    <span>Document already uploaded - Click to replace</span>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">
                      Click to upload or drag and drop
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      PDF, JPG, PNG (max 10MB)
                    </p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Info Alert */}
          <Alert className="bg-blue-50 border-blue-200">
            <AlertCircle className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-sm text-blue-900">
              All credentials will be reviewed by our admin team within 2-3 business days. 
              You'll receive a notification once your credential is verified.
            </AlertDescription>
          </Alert>

          {/* Submit Button */}
          <div className="flex justify-end gap-3 pt-4">
            {onSuccess && (
              <Button type="button" variant="outline" onClick={onSuccess}>
                Cancel
              </Button>
            )}
            <Button 
              type="submit" 
              disabled={uploading || saveCredentialMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {(uploading || saveCredentialMutation.isPending) ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {existingCredential ? "Updating..." : "Uploading..."}
                </>
              ) : (
                <>
                  {existingCredential ? "Update Credential" : "Upload Credential"}
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}