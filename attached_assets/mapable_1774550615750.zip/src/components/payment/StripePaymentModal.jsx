import React, { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreditCard, Lock, Loader2, CheckCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function StripePaymentModal({ isOpen, onClose, serviceRequest, onSuccess }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [cardDetails, setCardDetails] = useState({
    number: "",
    expiry: "",
    cvc: "",
    name: "",
    postcode: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    setError(null);

    try {
      // In a real implementation, this would use Stripe.js to tokenize the card
      // For now, we'll simulate the payment process
      
      // Step 1: Create payment record
      const payment = await base44.entities.Payment.create({
        service_request_id: serviceRequest.id,
        amount: serviceRequest.total_cost,
        payment_method: "stripe",
        status: "processing",
      });

      // Step 2: In real implementation, call backend to process with Stripe
      // const response = await base44.integrations.StripePayment.processPayment({
      //   payment_id: payment.id,
      //   amount: serviceRequest.total_cost,
      //   card_details: cardDetails // This would be a token in reality
      // });

      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Step 3: Update payment status
      await base44.entities.Payment.update(payment.id, {
        status: "succeeded",
        payment_date: new Date().toISOString(),
      });

      // Step 4: Update service request
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: "confirmed",
        payment_status: "paid",
      });

      onSuccess(payment);
    } catch (err) {
      setError(err.message || "Payment failed. Please try again.");
      setIsProcessing(false);
    }
  };

  const formatCardNumber = (value) => {
    return value.replace(/\s/g, "").match(/.{1,4}/g)?.join(" ") || value;
  };

  const formatExpiry = (value) => {
    return value.replace(/\D/g, "").slice(0, 4).replace(/(\d{2})(\d)/, "$1/$2");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-secondary" />
            Secure Payment
          </DialogTitle>
          <DialogDescription>
            Complete your booking by entering your payment details
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Order Summary */}
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Service</span>
              <span className="text-sm text-gray-900">
                {serviceRequest.service_type.replace(/_/g, " ")}
              </span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Duration</span>
              <span className="text-sm text-gray-900">
                {serviceRequest.duration_hours} hours
              </span>
            </div>
            <div className="border-t border-blue-200 mt-2 pt-2 flex justify-between items-center">
              <span className="font-semibold text-gray-900">Total</span>
              <span className="text-2xl font-bold text-primary">
                ${serviceRequest.total_cost.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Card Details */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cardName">Cardholder Name</Label>
              <Input
                id="cardName"
                required
                placeholder="John Smith"
                value={cardDetails.name}
                onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input
                id="cardNumber"
                required
                placeholder="4242 4242 4242 4242"
                maxLength="19"
                value={cardDetails.number}
                onChange={(e) =>
                  setCardDetails({
                    ...cardDetails,
                    number: formatCardNumber(e.target.value),
                  })
                }
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-2">
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input
                  id="expiry"
                  required
                  placeholder="MM/YY"
                  maxLength="5"
                  value={cardDetails.expiry}
                  onChange={(e) =>
                    setCardDetails({
                      ...cardDetails,
                      expiry: formatExpiry(e.target.value),
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cvc">CVC</Label>
                <Input
                  id="cvc"
                  required
                  placeholder="123"
                  maxLength="4"
                  value={cardDetails.cvc}
                  onChange={(e) =>
                    setCardDetails({
                      ...cardDetails,
                      cvc: e.target.value.replace(/\D/g, ""),
                    })
                  }
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="postcode">Postcode</Label>
              <Input
                id="postcode"
                required
                placeholder="2000"
                maxLength="4"
                value={cardDetails.postcode}
                onChange={(e) =>
                  setCardDetails({
                    ...cardDetails,
                    postcode: e.target.value.replace(/\D/g, ""),
                  })
                }
              />
            </div>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Security Notice */}
          <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 rounded-lg p-3">
            <Lock className="w-4 h-4 text-green-600" />
            <span>Your payment is secure and encrypted by Stripe</span>
          </div>

          {/* Submit Button */}
          <div className="flex gap-3">
            <Button
              type="submit"
              className="flex-1 bg-secondary hover:bg-secondary/90 h-12"
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Pay ${serviceRequest.total_cost.toFixed(2)}
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isProcessing}
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}