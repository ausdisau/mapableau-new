import React, { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Loader2, CheckCircle, Info } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function NDISClaimModal({ isOpen, onClose, serviceRequest, onSuccess }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [ndisDetails, setNdisDetails] = useState({
    participant_number: "",
    support_item_code: "",
    plan_manager_name: "",
    plan_manager_email: "",
  });

  // Common NDIS support item codes
  const supportItemCodes = [
    { code: "01_011_0107_1_1", name: "Assistance With Self-Care Activities" },
    { code: "01_013_0107_1_1", name: "Community Nursing Care" },
    { code: "04_104_0125_6_1", name: "Assistance With Travel/Transport" },
    { code: "09_001_0104_1_1", name: "Therapeutic Supports" },
    { code: "15_037_0120_1_1", name: "Group Activities" },
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    setError(null);

    try {
      // Step 1: Create payment record with NDIS details
      const payment = await base44.entities.Payment.create({
        service_request_id: serviceRequest.id,
        amount: serviceRequest.total_cost,
        payment_method: "ndis_direct",
        ndis_participant_number: ndisDetails.participant_number,
        ndis_support_item_code: ndisDetails.support_item_code,
        status: "ndis_submitted",
      });

      // Step 2: In real implementation, call backend to submit to NDIS API
      // const response = await base44.integrations.NDISPayment.submitClaim({
      //   payment_id: payment.id,
      //   participant_number: ndisDetails.participant_number,
      //   support_item_code: ndisDetails.support_item_code,
      //   amount: serviceRequest.total_cost,
      //   service_date: serviceRequest.date,
      //   provider_id: serviceRequest.provider_id
      // });

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Step 3: Update payment with claim reference
      await base44.entities.Payment.update(payment.id, {
        ndis_claim_reference: `NDIS-${Date.now()}`,
        payment_date: new Date().toISOString(),
      });

      // Step 4: Update service request
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: "confirmed",
        payment_status: "ndis_pending",
        ndis_funded: true,
      });

      // Step 5: Notify plan manager if provided
      if (ndisDetails.plan_manager_email) {
        await base44.integrations.Core.SendEmail({
          to: ndisDetails.plan_manager_email,
          subject: "NDIS Service Claim Submitted - MapAble",
          body: `A new NDIS claim has been submitted for participant ${ndisDetails.participant_number}. Claim reference: NDIS-${Date.now()}`,
        });
      }

      onSuccess(payment);
    } catch (err) {
      setError(err.message || "Failed to submit NDIS claim. Please try again.");
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-secondary" />
            NDIS Claim Submission
          </DialogTitle>
          <DialogDescription>
            Submit this service for NDIS funding approval
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Service Summary */}
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Service</span>
              <span className="text-sm text-gray-900">
                {serviceRequest.service_type.replace(/_/g, " ")}
              </span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Date</span>
              <span className="text-sm text-gray-900">{serviceRequest.date}</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Duration</span>
              <span className="text-sm text-gray-900">
                {serviceRequest.duration_hours} hours
              </span>
            </div>
            <div className="border-t border-blue-200 mt-2 pt-2 flex justify-between items-center">
              <span className="font-semibold text-gray-900">Claim Amount</span>
              <span className="text-2xl font-bold text-primary">
                ${serviceRequest.total_cost.toFixed(2)}
              </span>
            </div>
          </div>

          {/* NDIS Details */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="participantNumber">NDIS Participant Number *</Label>
              <Input
                id="participantNumber"
                required
                placeholder="430012345"
                value={ndisDetails.participant_number}
                onChange={(e) =>
                  setNdisDetails({ ...ndisDetails, participant_number: e.target.value })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="supportItemCode">NDIS Support Item Code *</Label>
              <Select
                value={ndisDetails.support_item_code}
                onValueChange={(v) => setNdisDetails({ ...ndisDetails, support_item_code: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select support item" />
                </SelectTrigger>
                <SelectContent>
                  {supportItemCodes.map((item) => (
                    <SelectItem key={item.code} value={item.code}>
                      {item.code} - {item.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="planManagerName">Plan Manager Name (Optional)</Label>
              <Input
                id="planManagerName"
                placeholder="Jane Smith"
                value={ndisDetails.plan_manager_name}
                onChange={(e) =>
                  setNdisDetails({ ...ndisDetails, plan_manager_name: e.target.value })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="planManagerEmail">Plan Manager Email (Optional)</Label>
              <Input
                id="planManagerEmail"
                type="email"
                placeholder="jane@planmanager.com.au"
                value={ndisDetails.plan_manager_email}
                onChange={(e) =>
                  setNdisDetails({ ...ndisDetails, plan_manager_email: e.target.value })
                }
              />
            </div>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Info Notice */}
          <Alert>
            <Info className="w-4 h-4" />
            <AlertDescription className="text-sm">
              Your claim will be submitted to NDIS for approval. You'll receive a confirmation
              once processed. Typical processing time is 2-5 business days.
            </AlertDescription>
          </Alert>

          {/* Submit Button */}
          <div className="flex gap-3">
            <Button
              type="submit"
              className="flex-1 bg-secondary hover:bg-secondary/90 h-12"
              disabled={isProcessing || !ndisDetails.participant_number || !ndisDetails.support_item_code}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting Claim...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4 mr-2" />
                  Submit NDIS Claim
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isProcessing}
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}