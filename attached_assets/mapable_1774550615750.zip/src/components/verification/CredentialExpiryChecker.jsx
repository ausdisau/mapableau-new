import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Calendar, Bell, CheckCircle } from "lucide-react";
import { differenceInDays, format } from "date-fns";
import { toast } from "sonner";
import NotificationService from "../notifications/NotificationService";

export default function CredentialExpiryChecker({ userEmail }) {
  const queryClient = useQueryClient();

  const { data: credentials = [] } = useQuery({
    queryKey: ["myCredentials", userEmail],
    queryFn: async () => {
      return await base44.entities.ProviderCredential.filter({ 
        provider_email: userEmail,
        verification_status: "verified"
      });
    },
    enabled: !!userEmail,
  });

  const sendExpiryReminderMutation = useMutation({
    mutationFn: async ({ credentialId, daysUntilExpiry }) => {
      const credential = credentials.find(c => c.id === credentialId);
      if (!credential) return;

      // Send notification
      await NotificationService.create({
        user_email: userEmail,
        title: "Credential Expiring Soon",
        message: `Your ${credential.credential_name} will expire in ${daysUntilExpiry} days. Please renew it to maintain your verified status.`,
        type: "system",
        priority: daysUntilExpiry <= 7 ? "urgent" : "high",
        related_entity_type: "ProviderCredential",
        related_entity_id: credentialId,
        action_url: "/provider-credentials"
      });

      // Update credential with reminder sent flag
      if (daysUntilExpiry <= 7) {
        await base44.entities.ProviderCredential.update(credentialId, {
          reminder_sent_7_days: true
        });
      } else if (daysUntilExpiry <= 30) {
        await base44.entities.ProviderCredential.update(credentialId, {
          reminder_sent_30_days: true
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myCredentials"] });
    },
  });

  const markAsExpiredMutation = useMutation({
    mutationFn: async (credentialId) => {
      await base44.entities.ProviderCredential.update(credentialId, {
        verification_status: "expired",
        auto_expiry_checked: true
      });

      const credential = credentials.find(c => c.id === credentialId);
      
      // Send urgent notification
      await NotificationService.create({
        user_email: userEmail,
        title: "Credential Expired",
        message: `Your ${credential?.credential_name} has expired. Please renew it immediately to maintain your verified status.`,
        type: "system",
        priority: "urgent",
        related_entity_type: "ProviderCredential",
        related_entity_id: credentialId,
        action_url: "/provider-credentials"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myCredentials"] });
    },
  });

  // Check for expiring and expired credentials
  useEffect(() => {
    if (!credentials.length) return;

    credentials.forEach(credential => {
      if (!credential.expiry_date) return;

      const daysUntilExpiry = differenceInDays(new Date(credential.expiry_date), new Date());

      // Auto-mark as expired
      if (daysUntilExpiry < 0 && !credential.auto_expiry_checked) {
        markAsExpiredMutation.mutate(credential.id);
      }

      // Send 7-day reminder
      if (daysUntilExpiry === 7 && !credential.reminder_sent_7_days) {
        sendExpiryReminderMutation.mutate({ 
          credentialId: credential.id, 
          daysUntilExpiry: 7 
        });
      }

      // Send 30-day reminder
      if (daysUntilExpiry === 30 && !credential.reminder_sent_30_days) {
        sendExpiryReminderMutation.mutate({ 
          credentialId: credential.id, 
          daysUntilExpiry: 30 
        });
      }
    });
  }, [credentials]);

  // Group credentials by urgency
  const expiredCredentials = credentials.filter(c => {
    if (!c.expiry_date) return false;
    return differenceInDays(new Date(c.expiry_date), new Date()) < 0;
  });

  const expiringSoon = credentials.filter(c => {
    if (!c.expiry_date) return false;
    const days = differenceInDays(new Date(c.expiry_date), new Date());
    return days >= 0 && days <= 30;
  });

  const valid = credentials.filter(c => {
    if (!c.expiry_date) return true;
    return differenceInDays(new Date(c.expiry_date), new Date()) > 30;
  });

  if (credentials.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {/* Critical Alerts */}
      {expiredCredentials.length > 0 && (
        <Alert className="bg-red-50 border-red-200">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription>
            <div>
              <span className="font-semibold text-red-900">
                {expiredCredentials.length} Credential{expiredCredentials.length !== 1 ? 's' : ''} Expired
              </span>
              <p className="text-sm text-red-700 mt-1">
                Your account verification may be affected. Please renew immediately.
              </p>
              <div className="mt-2 space-y-1">
                {expiredCredentials.map(credential => (
                  <div key={credential.id} className="text-sm text-red-800 flex items-center gap-2">
                    <span className="font-medium">{credential.credential_name}</span>
                    <span className="text-red-600">
                      Expired {format(new Date(credential.expiry_date), "MMM d, yyyy")}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Warning for expiring soon */}
      {expiringSoon.length > 0 && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Calendar className="w-4 h-4 text-yellow-600" />
          <AlertDescription>
            <div>
              <span className="font-semibold text-yellow-900">
                {expiringSoon.length} Credential{expiringSoon.length !== 1 ? 's' : ''} Expiring Soon
              </span>
              <p className="text-sm text-yellow-700 mt-1">
                Renew before expiry to maintain uninterrupted service.
              </p>
              <div className="mt-2 space-y-1">
                {expiringSoon.map(credential => {
                  const days = differenceInDays(new Date(credential.expiry_date), new Date());
                  return (
                    <div key={credential.id} className="text-sm text-yellow-800 flex items-center gap-2">
                      <span className="font-medium">{credential.credential_name}</span>
                      <span className="text-yellow-600">
                        Expires in {days} day{days !== 1 ? 's' : ''} ({format(new Date(credential.expiry_date), "MMM d, yyyy")})
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Summary Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg">Credential Status</h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = '/provider-credentials'}
            >
              Manage Credentials
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{valid.length}</p>
              <p className="text-xs text-gray-600 mt-1">Valid</p>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <p className="text-2xl font-bold text-yellow-600">{expiringSoon.length}</p>
              <p className="text-xs text-gray-600 mt-1">Expiring Soon</p>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <p className="text-2xl font-bold text-red-600">{expiredCredentials.length}</p>
              <p className="text-xs text-gray-600 mt-1">Expired</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}