import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Clock, AlertTriangle, Shield } from "lucide-react";

export default function VerificationBadge({ status, size = "default", showIcon = true }) {
  const configs = {
    verified: {
      icon: CheckCircle,
      label: "Verified",
      className: "bg-green-100 text-green-700 border-green-200",
      iconColor: "text-green-600"
    },
    pending_submission: {
      icon: Clock,
      label: "Pending",
      className: "bg-gray-100 text-gray-700 border-gray-200",
      iconColor: "text-gray-600"
    },
    submitted: {
      icon: Clock,
      label: "Under Review",
      className: "bg-blue-100 text-blue-700 border-blue-200",
      iconColor: "text-blue-600"
    },
    under_review: {
      icon: Clock,
      label: "Under Review",
      className: "bg-blue-100 text-blue-700 border-blue-200",
      iconColor: "text-blue-600"
    },
    rejected: {
      icon: XCircle,
      label: "Rejected",
      className: "bg-red-100 text-red-700 border-red-200",
      iconColor: "text-red-600"
    },
    expired: {
      icon: AlertTriangle,
      label: "Expired",
      className: "bg-orange-100 text-orange-700 border-orange-200",
      iconColor: "text-orange-600"
    }
  };

  const config = configs[status] || configs.pending_submission;
  const Icon = config.icon;

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5",
    default: "text-sm px-2.5 py-1",
    lg: "text-base px-3 py-1.5"
  };

  const iconSizes = {
    sm: "w-3 h-3",
    default: "w-3.5 h-3.5",
    lg: "w-4 h-4"
  };

  return (
    <Badge 
      variant="outline" 
      className={`${config.className} ${sizeClasses[size]} flex items-center gap-1.5 font-medium border`}
    >
      {showIcon && <Icon className={`${iconSizes[size]} ${config.iconColor}`} />}
      {config.label}
    </Badge>
  );
}

export function ProviderVerificationBadge({ credentials, verified, size = "default" }) {
  // If no credentials provided, check the verified flag
  if (!credentials || credentials.length === 0) {
    if (verified) {
      return (
        <Badge className={`bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 ${
          size === "sm" ? "text-xs px-2 py-0.5" : 
          size === "lg" ? "text-base px-3 py-1.5" : "text-sm px-2.5 py-1"
        } flex items-center gap-1.5 font-semibold`}>
          <Shield className={size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} />
          Verified Provider
        </Badge>
      );
    }
    return <VerificationBadge status="pending_submission" size={size} />;
  }

  // Check if provider has any expired or rejected credentials
  const hasIssues = credentials.some(c => 
    c.verification_status === "expired" || c.verification_status === "rejected"
  );

  const allVerified = credentials.every(c => 
    c.verification_status === "verified"
  ) && credentials.length > 0;

  if (hasIssues) {
    return <VerificationBadge status="expired" size={size} />;
  }

  if (allVerified && verified) {
    return (
      <Badge className={`bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 ${
        size === "sm" ? "text-xs px-2 py-0.5" : 
        size === "lg" ? "text-base px-3 py-1.5" : "text-sm px-2.5 py-1"
      } flex items-center gap-1.5 font-semibold`}>
        <Shield className={size === "sm" ? "w-3 h-3" : size === "lg" ? "w-4 h-4" : "w-3.5 h-3.5"} />
        Verified Provider
      </Badge>
    );
  }

  return <VerificationBadge status="pending_submission" size={size} />;
}