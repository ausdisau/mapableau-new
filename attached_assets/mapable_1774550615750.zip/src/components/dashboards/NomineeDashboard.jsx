import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Users,
  Calendar,
  DollarSign,
  Car,
  Shield,
  UserPlus,
  Bell,
  FileText,
  TrendingUp,
  Clock,
  AlertTriangle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function NomineeDashboard({ user }) {
  // For nominees managing multiple participants
  const { data: participants = [] } = useQuery({
    queryKey: ["managedParticipants"],
    queryFn: async () => {
      // In production, this would fetch users where nominee_email = user.email
      // For now, return participants created by this user
      return await base44.entities.User.filter({ 
        user_type: "participant"
      });
    },
  });

  const { data: allServiceRequests = [] } = useQuery({
    queryKey: ["allServiceRequests"],
    queryFn: () => base44.entities.ServiceRequest.list("-created_date"),
  });

  const { data: allTransportBookings = [] } = useQuery({
    queryKey: ["allTransportBookings"],
    queryFn: () => base44.entities.TransportBooking.list("-created_date"),
  });

  const { data: allNDISPlans = [] } = useQuery({
    queryKey: ["allNDISPlans"],
    queryFn: () => base44.entities.NDISPlanBudget.list("-created_date"),
  });

  // Aggregate stats across all managed participants
  const participantEmails = participants.map(p => p.email);
  
  const upcomingServices = allServiceRequests.filter(r =>
    participantEmails.includes(r.created_by) &&
    r.status === "confirmed" &&
    new Date(r.date) >= new Date()
  );

  const upcomingTransport = allTransportBookings.filter(b =>
    participantEmails.includes(b.created_by) &&
    ['confirmed', 'driver_assigned'].includes(b.status) &&
    new Date(b.pickup_datetime) >= new Date()
  );

  const pendingApprovals = allServiceRequests.filter(r =>
    participantEmails.includes(r.created_by) && r.status === "pending"
  ).length + allTransportBookings.filter(b =>
    participantEmails.includes(b.created_by) && b.status === "requested"
  ).length;

  const activePlans = allNDISPlans.filter(p =>
    participantEmails.includes(p.created_by) &&
    new Date(p.plan_end_date) >= new Date()
  );

  const totalBudgetUtilization = activePlans.length > 0
    ? activePlans.reduce((sum, p) => sum + ((p.total_spent / p.total_plan_budget) * 100), 0) / activePlans.length
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">
            Nominee Dashboard
          </h1>
          <p className="text-gray-600 text-lg">
            Managing {participants.length} participant{participants.length !== 1 ? 's' : ''}
          </p>
        </div>

        {/* Pending Approvals Alert */}
        {pendingApprovals > 0 && (
          <Alert className="mb-6 bg-orange-50 border-orange-200">
            <Bell className="w-5 h-5 text-orange-600" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-orange-900">
                    {pendingApprovals} Request{pendingApprovals !== 1 ? 's' : ''} Awaiting Approval
                  </p>
                  <p className="text-sm text-orange-700">
                    Review and approve service requests and bookings
                  </p>
                </div>
                <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                  Review Now
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Overview Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Participants</p>
                  <p className="text-3xl font-bold text-primary">{participants.length}</p>
                </div>
                <Users className="w-10 h-10 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Upcoming Services</p>
                  <p className="text-3xl font-bold text-primary">{upcomingServices.length}</p>
                </div>
                <Calendar className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Transport Bookings</p>
                  <p className="text-3xl font-bold text-primary">{upcomingTransport.length}</p>
                </div>
                <Car className="w-10 h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Avg Budget Use</p>
                  <p className="text-3xl font-bold text-primary">{totalBudgetUtilization.toFixed(0)}%</p>
                </div>
                <TrendingUp className="w-10 h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Managed Participants */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                Managed Participants
              </CardTitle>
              <Button variant="outline" size="sm">
                <UserPlus className="w-4 h-4 mr-2" />
                Add Participant
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {participants.slice(0, 5).map((participant) => {
                const participantPlan = activePlans.find(p => p.created_by === participant.email);
                const participantServices = upcomingServices.filter(s => s.created_by === participant.email);
                
                return (
                  <div key={participant.id} className="p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        {participant.profile_photo_url ? (
                          <img 
                            src={participant.profile_photo_url}
                            alt={participant.full_name}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                            <span className="text-purple-600 font-semibold">
                              {participant.full_name?.charAt(0) || "P"}
                            </span>
                          </div>
                        )}
                        <div>
                          <p className="font-semibold">{participant.full_name}</p>
                          <p className="text-sm text-gray-600">{participant.email}</p>
                        </div>
                      </div>
                      <Link to={createPageUrl("ParticipantProfile") + `?email=${participant.email}`}>
                        <Button size="sm" variant="outline">
                          View Profile
                        </Button>
                      </Link>
                    </div>

                    <div className="grid grid-cols-3 gap-3 text-center">
                      <div className="p-2 bg-blue-50 rounded">
                        <p className="text-xs text-gray-600">Upcoming</p>
                        <p className="text-lg font-bold text-blue-600">{participantServices.length}</p>
                      </div>
                      {participantPlan && (
                        <>
                          <div className="p-2 bg-green-50 rounded">
                            <p className="text-xs text-gray-600">Budget</p>
                            <p className="text-lg font-bold text-green-600">
                              {((participantPlan.total_spent / participantPlan.total_plan_budget) * 100).toFixed(0)}%
                            </p>
                          </div>
                          <div className="p-2 bg-orange-50 rounded">
                            <p className="text-xs text-gray-600">Remaining</p>
                            <p className="text-lg font-bold text-orange-600">
                              ${(participantPlan.total_plan_budget - participantPlan.total_spent).toLocaleString()}
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Recent Services
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {upcomingServices.slice(0, 5).map((service) => (
                  <div key={service.id} className="flex justify-between items-center p-2 border-b">
                    <div>
                      <p className="font-medium text-sm">{service.service_type.replace(/_/g, " ")}</p>
                      <p className="text-xs text-gray-600">
                        {format(new Date(service.date), "MMM d")} • {service.time}
                      </p>
                    </div>
                    <Badge>{service.status}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="w-5 h-5 text-green-600" />
                Recent Transport
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {upcomingTransport.slice(0, 5).map((booking) => (
                  <div key={booking.id} className="flex justify-between items-center p-2 border-b">
                    <div>
                      <p className="font-medium text-sm">{booking.purpose?.replace(/_/g, " ") || "Transport"}</p>
                      <p className="text-xs text-gray-600">
                        {format(new Date(booking.pickup_datetime), "MMM d 'at' h:mm a")}
                      </p>
                    </div>
                    <Badge>{booking.status.replace(/_/g, " ")}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}