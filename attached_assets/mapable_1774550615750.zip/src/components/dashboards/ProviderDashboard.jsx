import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  DollarSign,
  Star,
  TrendingUp,
  Users,
  Clock,
  Car,
  Inbox,
  Settings,
  BarChart3
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function ProviderDashboard({ user, providerType }) {
  // Fetch provider-specific data
  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["providerServiceRequests"],
    queryFn: async () => {
      const allRequests = await base44.entities.ServiceRequest.list("-created_date");
      const providers = await base44.entities.ServiceProvider.filter({ email: user.email });
      if (providers.length === 0) return [];
      const providerId = providers[0].id;
      return allRequests.filter(r => r.provider_id === providerId);
    },
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["providerTransportBookings"],
    queryFn: async () => {
      if (providerType !== 'transport' && providerType !== 'driver') return [];
      const allBookings = await base44.entities.TransportBooking.list("-created_date");
      const vehicles = await base44.entities.Vehicle.filter({ operator_id: user.email });
      if (vehicles.length === 0) return allBookings.filter(b => b.created_by === user.email);
      return allBookings;
    },
    enabled: providerType === 'transport' || providerType === 'driver',
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["providerPayments"],
    queryFn: async () => {
      const allPayments = await base44.entities.Payment.list("-created_date");
      const myRequestIds = serviceRequests.map(r => r.id);
      return allPayments.filter(p => myRequestIds.includes(p.service_request_id));
    },
    enabled: serviceRequests.length > 0,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["providerReviews"],
    queryFn: async () => {
      const providers = await base44.entities.ServiceProvider.filter({ email: user.email });
      if (providers.length === 0) return [];
      return await base44.entities.ProviderReview.filter({ provider_id: providers[0].id });
    },
  });

  // Stats
  const pendingRequests = serviceRequests.filter(r => r.status === "pending");
  const upcomingBookings = [...serviceRequests, ...transportBookings].filter(b => 
    (b.status === "confirmed" || b.status === "driver_assigned") && 
    new Date(b.date || b.pickup_datetime) >= new Date()
  );
  
  const totalEarnings = payments
    .filter(p => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  const getDashboardLink = () => {
    if (providerType === 'transport') return createPageUrl("ProviderTransportDashboard");
    return createPageUrl("ProviderHub");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-primary mb-2">
                Provider Dashboard
              </h1>
              <p className="text-gray-600 text-lg">
                Welcome back, {user.full_name}
              </p>
            </div>
            <Link to={getDashboardLink()}>
              <Button className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 gap-2">
                <Settings className="w-4 h-4" />
                Manage Services
              </Button>
            </Link>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-lift bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600 mb-1">Pending Requests</p>
                  <p className="text-3xl font-bold text-primary">{pendingRequests.length}</p>
                </div>
                <Inbox className="w-10 h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600 mb-1">Upcoming Bookings</p>
                  <p className="text-3xl font-bold text-primary">{upcomingBookings.length}</p>
                </div>
                <Calendar className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600 mb-1">Total Earnings</p>
                  <p className="text-3xl font-bold text-primary">${totalEarnings.toFixed(0)}</p>
                </div>
                <DollarSign className="w-10 h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-yellow-600 mb-1">Average Rating</p>
                  <div className="flex items-center gap-2">
                    <p className="text-3xl font-bold text-primary">
                      {averageRating > 0 ? averageRating.toFixed(1) : "N/A"}
                    </p>
                    {averageRating > 0 && <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />}
                  </div>
                </div>
                <Star className="w-10 h-10 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Requests Alert */}
        {pendingRequests.length > 0 && (
          <Card className="mb-6 border-2 border-orange-300 bg-orange-50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Inbox className="w-8 h-8 text-orange-600" />
                  <div>
                    <p className="font-semibold text-lg">You have {pendingRequests.length} pending request{pendingRequests.length !== 1 ? 's' : ''}</p>
                    <p className="text-sm text-gray-600">Review and respond to participant requests</p>
                  </div>
                </div>
                <Link to={getDashboardLink() + "?tab=requests"}>
                  <Button className="bg-orange-600 hover:bg-orange-700">
                    Review Requests
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Upcoming Schedule */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-secondary" />
                Upcoming Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              {upcomingBookings.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No upcoming bookings</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingBookings.slice(0, 5).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex-1">
                        <p className="font-medium">
                          {booking.service_type?.replace(/_/g, " ") || booking.purpose?.replace(/_/g, " ") || "Service"}
                        </p>
                        <p className="text-sm text-gray-600">
                          {format(new Date(booking.date || booking.pickup_datetime), "EEE, MMM d 'at' h:mm a")}
                        </p>
                        <p className="text-xs text-gray-500">
                          {booking.location || booking.pickup_location?.address}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-secondary">
                          {booking.duration_hours ? `${booking.duration_hours}h` : ""}
                        </p>
                        <p className="text-xs text-gray-500">
                          ${booking.total_cost || booking.estimated_cost || 0}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Reviews */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Recent Reviews
              </CardTitle>
            </CardHeader>
            <CardContent>
              {reviews.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No reviews yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {reviews.slice(0, 5).map((review) => (
                    <div key={review.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${
                                star <= review.rating
                                  ? "fill-yellow-400 text-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-xs text-gray-500">
                          {format(new Date(review.created_date), "MMM d")}
                        </p>
                      </div>
                      {review.title && (
                        <p className="font-medium text-sm mb-1">{review.title}</p>
                      )}
                      <p className="text-sm text-gray-600 line-clamp-2">{review.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <Link to={getDashboardLink() + "?tab=services"}>
            <Card className="hover-lift cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Users className="w-10 h-10 text-blue-600" />
                  <div>
                    <h3 className="font-semibold">Manage Services</h3>
                    <p className="text-sm text-gray-600">Update offerings & pricing</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={getDashboardLink() + "?tab=availability"}>
            <Card className="hover-lift cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Clock className="w-10 h-10 text-green-600" />
                  <div>
                    <h3 className="font-semibold">Set Availability</h3>
                    <p className="text-sm text-gray-600">Manage your schedule</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={getDashboardLink() + "?tab=analytics"}>
            <Card className="hover-lift cursor-pointer">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-10 h-10 text-purple-600" />
                  <div>
                    <h3 className="font-semibold">View Analytics</h3>
                    <p className="text-sm text-gray-600">Track performance</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  );
}