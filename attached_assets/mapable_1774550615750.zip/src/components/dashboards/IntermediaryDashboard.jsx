import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  DollarSign,
  FileText,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Calendar,
  Briefcase,
  Shield
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function IntermediaryDashboard({ user, role }) {
  const isPlanManager = role === 'plan_manager';
  const isSupportCoordinator = role === 'support_coordinator';

  // Fetch managed participants and their data
  const { data: managedParticipants = [] } = useQuery({
    queryKey: ["managedParticipants"],
    queryFn: async () => {
      // Get participants where this user is listed as plan manager or coordinator
      const allPlans = await base44.entities.NDISPlanBudget.list();
      const relevantPlans = isPlanManager
        ? allPlans.filter(p => p.plan_manager_email === user.email)
        : allPlans; // Support coordinators see all
      
      const participantNumbers = [...new Set(relevantPlans.map(p => p.participant_number))];
      return participantNumbers;
    },
  });

  const { data: ndisPlans = [] } = useQuery({
    queryKey: ["clientNDISPlans"],
    queryFn: async () => {
      const allPlans = await base44.entities.NDISPlanBudget.list("-created_date");
      return isPlanManager
        ? allPlans.filter(p => p.plan_manager_email === user.email)
        : allPlans;
    },
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["clientServiceRequests"],
    queryFn: () => base44.entities.ServiceRequest.list("-created_date"),
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["clientPayments"],
    queryFn: () => base44.entities.Payment.list("-created_date"),
  });

  // Calculate aggregated stats
  const totalBudgetManaged = ndisPlans.reduce((sum, p) => sum + (p.total_plan_budget || 0), 0);
  const totalSpent = ndisPlans.reduce((sum, p) => sum + (p.total_spent || 0), 0);
  const overallUtilization = totalBudgetManaged > 0 ? (totalSpent / totalBudgetManaged) * 100 : 0;

  const pendingClaims = payments.filter(p => 
    p.payment_method === 'ndis_direct' && 
    ['pending', 'ndis_submitted'].includes(p.status)
  );

  const plansNeedingReview = ndisPlans.filter(p => {
    const endDate = new Date(p.plan_end_date);
    const today = new Date();
    const daysRemaining = Math.ceil((endDate - today) / (1000 * 60 * 60 * 24));
    return daysRemaining <= 60 && daysRemaining > 0;
  });

  const recentRequests = serviceRequests.filter(r => r.status === "pending").slice(0, 5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-10 h-10 text-indigo-600" />
            <div>
              <h1 className="text-4xl font-bold text-primary">
                {isPlanManager ? "Plan Manager" : "Support Coordinator"} Dashboard
              </h1>
              <p className="text-gray-600 text-lg">
                Welcome, {user.full_name}
              </p>
            </div>
          </div>
        </div>

        {/* Alerts */}
        {plansNeedingReview.length > 0 && (
          <Alert className="mb-6 bg-yellow-50 border-yellow-200">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <AlertDescription>
              <p className="font-semibold text-yellow-900">
                {plansNeedingReview.length} Plan{plansNeedingReview.length !== 1 ? 's' : ''} Expiring Soon
              </p>
              <p className="text-sm text-yellow-700">
                Review and prepare renewal documentation for participants
              </p>
            </AlertDescription>
          </Alert>
        )}

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Clients</p>
                  <p className="text-3xl font-bold text-primary">{managedParticipants.length}</p>
                </div>
                <Users className="w-10 h-10 text-indigo-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Budget Managed</p>
                  <p className="text-2xl font-bold text-primary">${(totalBudgetManaged / 1000).toFixed(0)}k</p>
                </div>
                <DollarSign className="w-10 h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Pending Claims</p>
                  <p className="text-3xl font-bold text-primary">{pendingClaims.length}</p>
                </div>
                <FileText className="w-10 h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Utilization</p>
                  <p className="text-3xl font-bold text-primary">{overallUtilization.toFixed(0)}%</p>
                </div>
                <TrendingUp className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Requests */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                Pending Approvals
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentRequests.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No pending requests</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentRequests.map((request) => (
                    <div key={request.id} className="p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold">{request.service_type.replace(/_/g, " ")}</p>
                          <p className="text-sm text-gray-600">
                            {format(new Date(request.date), "MMM d, yyyy")} at {request.time}
                          </p>
                        </div>
                        <Badge className="bg-orange-100 text-orange-700">Pending</Badge>
                      </div>
                      <div className="flex gap-2 mt-2">
                        <Button size="sm" className="flex-1 bg-green-600 hover:bg-green-700">
                          Approve
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Budget Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Budget Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ndisPlans.slice(0, 5).map((plan) => {
                  const utilization = (plan.total_spent / plan.total_plan_budget) * 100;
                  const isHighUtilization = utilization > 80;
                  const isLowUtilization = utilization < 30;
                  
                  return (
                    <div key={plan.id} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">
                          Participant #{plan.participant_number}
                        </span>
                        <span className={`${isHighUtilization ? 'text-red-600' : isLowUtilization ? 'text-yellow-600' : 'text-green-600'}`}>
                          {utilization.toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={utilization} className="h-2" />
                      <div className="flex justify-between text-xs text-gray-600">
                        <span>${plan.total_spent.toLocaleString()} spent</span>
                        <span>${plan.total_plan_budget.toLocaleString()} total</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <Card className="hover-lift cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <FileText className="w-10 h-10 text-blue-600" />
                <div>
                  <h3 className="font-semibold">Process Claims</h3>
                  <p className="text-sm text-gray-600">Review NDIS claims</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Calendar className="w-10 h-10 text-green-600" />
                <div>
                  <h3 className="font-semibold">Manage Schedules</h3>
                  <p className="text-sm text-gray-600">Coordinate appointments</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift cursor-pointer">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Users className="w-10 h-10 text-purple-600" />
                <div>
                  <h3 className="font-semibold">Client Reports</h3>
                  <p className="text-sm text-gray-600">Generate reports</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}