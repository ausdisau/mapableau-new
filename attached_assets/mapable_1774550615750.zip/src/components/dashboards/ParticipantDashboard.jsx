import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  Calendar,
  Users,
  Briefcase,
  DollarSign,
  Car,
  Clock,
  TrendingUp,
  AlertTriangle,
  Plus,
  ArrowRight,
  CheckCircle,
  MapPin
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, isAfter, isBefore, addDays } from "date-fns";

export default function ParticipantDashboard({ user }) {
  // Fetch participant data
  const { data: serviceRequests = [] } = useQuery({
    queryKey: ["myServiceRequests"],
    queryFn: () => base44.entities.ServiceRequest.filter({ created_by: user.email }),
  });

  const { data: transportBookings = [] } = useQuery({
    queryKey: ["myTransportBookings"],
    queryFn: () => base44.entities.TransportBooking.filter({ created_by: user.email }),
  });

  const { data: jobApplications = [] } = useQuery({
    queryKey: ["myJobApplications"],
    queryFn: () => base44.entities.JobApplication.filter({ created_by: user.email }),
  });

  const { data: ndisPlans = [] } = useQuery({
    queryKey: ["myNDISPlans"],
    queryFn: () => base44.entities.NDISPlanBudget.filter({ created_by: user.email }),
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["myPayments"],
    queryFn: async () => {
      const allPayments = await base44.entities.Payment.list("-created_date");
      const myRequestIds = serviceRequests.map(r => r.id);
      return allPayments.filter(p => myRequestIds.includes(p.service_request_id));
    },
    enabled: serviceRequests.length > 0,
  });

  // Calculate stats
  const activePlan = ndisPlans[0];
  const budgetUtilization = activePlan ? (activePlan.total_spent / activePlan.total_plan_budget) * 100 : 0;
  
  const upcomingServices = serviceRequests.filter(r => 
    r.status === "confirmed" && new Date(r.date) >= new Date()
  );

  const upcomingTransport = transportBookings.filter(b => 
    ['confirmed', 'driver_assigned'].includes(b.status) && 
    new Date(b.pickup_datetime) >= new Date()
  );

  const activeApplications = jobApplications.filter(a => 
    ['submitted', 'under_review', 'interview_scheduled'].includes(a.status)
  );

  const totalSpent = payments
    .filter(p => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  const needsProfileUpdate = !user.ndis_number || !user.phone || !user.date_of_birth;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">
            Welcome back, {user.full_name?.split(' ')[0] || 'there'}! 👋
          </h1>
          <p className="text-gray-600 text-lg">
            Your personalized NDIS dashboard
          </p>
        </div>

        {/* Profile Completion Alert */}
        {needsProfileUpdate && (
          <Alert className="mb-6 bg-yellow-50 border-yellow-200">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-yellow-900">Complete Your Profile</p>
                  <p className="text-sm text-yellow-700">
                    Add your NDIS details and contact information to access all features
                  </p>
                </div>
                <Link to={createPageUrl("AccountSettings")}>
                  <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700">
                    Complete Now
                  </Button>
                </Link>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* NDIS Plan Progress */}
        {activePlan && (
          <Card className="mb-6 border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  NDIS Plan Progress
                </CardTitle>
                <Link to={createPageUrl("NDISBudget")}>
                  <Button variant="outline" size="sm">View Full Budget</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">Budget Utilization</span>
                    <span className="text-gray-600">
                      ${activePlan.total_spent?.toLocaleString() || 0} / ${activePlan.total_plan_budget?.toLocaleString() || 0}
                    </span>
                  </div>
                  <Progress value={budgetUtilization} className="h-3" />
                  <p className="text-xs text-gray-600 mt-1">
                    {budgetUtilization.toFixed(1)}% utilized
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs text-gray-600">Plan Start</p>
                    <p className="text-sm font-semibold">
                      {format(new Date(activePlan.plan_start_date), "MMM d, yy")}
                    </p>
                  </div>
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs text-gray-600">Plan End</p>
                    <p className="text-sm font-semibold">
                      {format(new Date(activePlan.plan_end_date), "MMM d, yy")}
                    </p>
                  </div>
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs text-gray-600">Remaining</p>
                    <p className="text-sm font-semibold text-green-600">
                      ${(activePlan.total_plan_budget - activePlan.total_spent).toLocaleString()}
                    </p>
                  </div>
                </div>

                {activePlan.alerts && activePlan.alerts.length > 0 && (
                  <Alert className="bg-yellow-50 border-yellow-200">
                    <AlertTriangle className="w-4 h-4 text-yellow-600" />
                    <AlertDescription className="text-sm text-yellow-900">
                      {activePlan.alerts[0].message}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Upcoming Services</p>
                  <p className="text-3xl font-bold text-primary">{upcomingServices.length}</p>
                </div>
                <Users className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Transport Bookings</p>
                  <p className="text-3xl font-bold text-primary">{upcomingTransport.length}</p>
                </div>
                <Car className="w-10 h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Job Applications</p>
                  <p className="text-3xl font-bold text-primary">{activeApplications.length}</p>
                </div>
                <Briefcase className="w-10 h-10 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Spent</p>
                  <p className="text-3xl font-bold text-primary">${totalSpent.toFixed(0)}</p>
                </div>
                <DollarSign className="w-10 h-10 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link to={createPageUrl("FindCare")}>
            <Card className="hover-lift cursor-pointer hover:border-blue-400 transition-all">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Users className="w-12 h-12 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-lg">Find Care</h3>
                    <p className="text-sm text-gray-600">Browse providers & book services</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("FindTransport")}>
            <Card className="hover-lift cursor-pointer hover:border-green-400 transition-all">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Car className="w-12 h-12 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-lg">Book Transport</h3>
                    <p className="text-sm text-gray-600">Schedule accessible rides</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to={createPageUrl("FindJobs")}>
            <Card className="hover-lift cursor-pointer hover:border-orange-400 transition-all">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Briefcase className="w-12 h-12 text-orange-600" />
                  <div>
                    <h3 className="font-semibold text-lg">Find Employment</h3>
                    <p className="text-sm text-gray-600">Explore job opportunities</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Upcoming Activities */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Upcoming Services */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-secondary" />
                  Upcoming Services
                </CardTitle>
                <Link to={createPageUrl("ParticipantProfile") + "?tab=care"}>
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {upcomingServices.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600 mb-3">No upcoming services</p>
                  <Link to={createPageUrl("FindCare")}>
                    <Button size="sm" className="bg-secondary hover:bg-secondary/90">
                      <Plus className="w-4 h-4 mr-2" />
                      Book a Service
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingServices.slice(0, 3).map((service) => (
                    <div key={service.id} className="p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold">{service.service_type.replace(/_/g, " ")}</p>
                          <p className="text-sm text-gray-600">{service.location}</p>
                        </div>
                        <Badge className={
                          service.status === "confirmed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                        }>
                          {service.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(service.date), "EEE, MMM d")}
                        </span>
                        <span>{service.time}</span>
                        <span>{service.duration_hours}h</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Transport */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Car className="w-5 h-5 text-green-600" />
                  Upcoming Transport
                </CardTitle>
                <Link to={createPageUrl("MyTransportBookings")}>
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {upcomingTransport.length === 0 ? (
                <div className="text-center py-8">
                  <Car className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600 mb-3">No upcoming transport</p>
                  <Link to={createPageUrl("FindTransport")}>
                    <Button size="sm" className="bg-green-600 hover:bg-green-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Book Transport
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {upcomingTransport.slice(0, 3).map((booking) => (
                    <div key={booking.id} className="p-3 border rounded-lg hover:bg-gray-50">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold">{booking.purpose?.replace(/_/g, " ") || "Transport"}</p>
                          <p className="text-sm text-gray-600 line-clamp-1">
                            {booking.pickup_location?.address}
                          </p>
                        </div>
                        <Badge className={
                          booking.status === "confirmed" ? "bg-blue-100 text-blue-700" :
                          booking.status === "driver_assigned" ? "bg-green-100 text-green-700" :
                          "bg-gray-100 text-gray-700"
                        }>
                          {booking.status.replace(/_/g, " ")}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {format(new Date(booking.pickup_datetime), "EEE, MMM d 'at' h:mm a")}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Job Applications */}
        {activeApplications.length > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-orange-600" />
                  Active Job Applications
                </CardTitle>
                <Link to={createPageUrl("ParticipantProfile") + "?tab=jobs"}>
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {activeApplications.slice(0, 3).map((app) => (
                  <div key={app.id} className="p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">Application</p>
                        <p className="text-sm text-gray-600">
                          Submitted {format(new Date(app.created_date), "MMM d, yyyy")}
                        </p>
                      </div>
                      <Badge className={
                        app.status === "under_review" ? "bg-blue-100 text-blue-700" :
                        app.status === "interview_scheduled" ? "bg-green-100 text-green-700" :
                        "bg-gray-100 text-gray-700"
                      }>
                        {app.status.replace(/_/g, " ")}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}