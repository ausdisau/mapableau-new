// Tour management system for onboarding

export const TOUR_STEPS = {
  welcome: {
    id: "welcome",
    title: "Welcome to MapAble!",
    description: "Let's take a quick tour to help you discover everything MapAble has to offer for NDIS participants.",
    page: "Home",
    position: "center",
    action: "next",
  },
  dashboard: {
    id: "dashboard",
    title: "Your Dashboard",
    description: "This is your central hub where you can see all your bookings, services, and NDIS budget at a glance.",
    page: "Dashboard",
    target: "[data-tour='dashboard']",
    position: "bottom",
    action: "next",
  },
  globalSearch: {
    id: "global-search",
    title: "Global Search",
    description: "Quickly find services, providers, locations, and more using our powerful search feature.",
    page: "Dashboard",
    target: "[data-tour='global-search']",
    position: "bottom",
    action: "next",
  },
  notifications: {
    id: "notifications",
    title: "Stay Updated",
    description: "Get notified about bookings, messages, and important updates right here.",
    page: "Dashboard",
    target: "[data-tour='notifications']",
    position: "bottom-left",
    action: "next",
  },
  mainNav: {
    id: "main-nav",
    title: "Main Navigation",
    description: "Access all features of MapAble from this menu - care services, transport, jobs, and more.",
    page: "Dashboard",
    target: "[data-tour='main-nav']",
    position: "bottom",
    action: "next",
  },
  findCare: {
    id: "find-care",
    title: "Find Care Services",
    description: "Browse and book NDIS-registered care providers, support workers, and therapists.",
    page: "FindCare",
    target: "[data-tour='find-care']",
    position: "bottom",
    action: "navigate",
    navigateTo: "FindTransport",
  },
  transport: {
    id: "transport",
    title: "Book Transport",
    description: "Schedule accessible transport for medical appointments, community access, and more.",
    page: "FindTransport",
    target: "[data-tour='transport']",
    position: "bottom",
    action: "navigate",
    navigateTo: "Map",
  },
  accessiblePlaces: {
    id: "accessible-places",
    title: "Explore Accessible Places",
    description: "Discover wheelchair-accessible restaurants, venues, and facilities with detailed accessibility ratings.",
    page: "Map",
    target: "[data-tour='accessible-places']",
    position: "bottom",
    action: "navigate",
    navigateTo: "FindJobs",
  },
  findJobs: {
    id: "find-jobs",
    title: "Find Employment",
    description: "Explore inclusive job opportunities from disability-confident employers.",
    page: "FindJobs",
    target: "[data-tour='find-jobs']",
    position: "bottom",
    action: "navigate",
    navigateTo: "NDISBudget",
  },
  ndisBudget: {
    id: "ndis-budget",
    title: "Manage Your Budget",
    description: "Track your NDIS plan spending, view remaining funds, and manage your allocations.",
    page: "NDISBudget",
    target: "[data-tour='ndis-budget']",
    position: "bottom",
    action: "navigate",
    navigateTo: "Dashboard",
  },
  aiAssistant: {
    id: "ai-assistant",
    title: "AI Assistant",
    description: "Need help? Our AI assistant is here 24/7 to answer questions and guide you through the platform.",
    page: "Dashboard",
    target: "[data-tour='ai-assistant']",
    position: "left",
    action: "navigate",
    navigateTo: "ParticipantProfile",
  },
  profile: {
    id: "profile",
    title: "Your Profile",
    description: "Manage your personal information, NDIS details, and view all your bookings and services.",
    page: "ParticipantProfile",
    target: "[data-tour='profile']",
    position: "bottom",
    action: "navigate",
    navigateTo: "Forum",
  },
  forum: {
    id: "forum",
    title: "Community Forum",
    description: "Connect with other NDIS participants, share experiences, and get advice from the community.",
    page: "Forum",
    target: "[data-tour='forum']",
    position: "bottom",
    action: "navigate",
    navigateTo: "Dashboard",
  },
  finish: {
    id: "finish",
    title: "You're All Set!",
    description: "You've completed the tour! Feel free to explore MapAble at your own pace. You can restart this tour anytime from your account settings.",
    page: "Dashboard",
    position: "center",
    action: "finish",
  },
};

// Get a specific tour step by ID
export function getTourStep(stepId) {
  return TOUR_STEPS[stepId];
}

// Calculate progress percentage
export function calculateProgress(currentStepId) {
  const steps = Object.keys(TOUR_STEPS);
  const currentIndex = steps.indexOf(currentStepId);
  return ((currentIndex + 1) / steps.length) * 100;
}

// Mark tour as completed
export function markTourCompleted() {
  localStorage.setItem('tour_completed', 'true');
  localStorage.removeItem('tour_active');
  localStorage.removeItem('tour_step');
}

// Check if tour should be shown
export function shouldShowTour() {
  return !localStorage.getItem('tour_completed') && !localStorage.getItem('tour_dismissed');
}

// Tour Manager
class TourManager {
  constructor() {
    this.listeners = [];
    this.state = {
      currentStep: null,
      isActive: false,
      completedSteps: [],
    };
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(listener => listener(this.state));
  }

  loadState() {
    const isActive = localStorage.getItem('tour_active') === 'true';
    const currentStep = localStorage.getItem('tour_step');
    const completedSteps = JSON.parse(localStorage.getItem('tour_completed_steps') || '[]');

    this.state = {
      isActive,
      currentStep: currentStep || 'welcome',
      completedSteps,
    };

    this.notify();
  }

  saveState() {
    localStorage.setItem('tour_active', this.state.isActive.toString());
    localStorage.setItem('tour_step', this.state.currentStep || '');
    localStorage.setItem('tour_completed_steps', JSON.stringify(this.state.completedSteps));
  }

  start() {
    this.state = {
      isActive: true,
      currentStep: 'welcome',
      completedSteps: [],
    };
    this.saveState();
    this.notify();
    window.dispatchEvent(new CustomEvent('tour-start'));
  }

  next() {
    if (!this.state.currentStep) return;

    const steps = Object.keys(TOUR_STEPS);
    const currentIndex = steps.indexOf(this.state.currentStep);
    
    // Mark current step as completed
    if (!this.state.completedSteps.includes(this.state.currentStep)) {
      this.state.completedSteps.push(this.state.currentStep);
    }

    // Move to next step
    if (currentIndex < steps.length - 1) {
      this.state.currentStep = steps[currentIndex + 1];
    } else {
      this.complete();
      return;
    }

    this.saveState();
    this.notify();
  }

  previous() {
    if (!this.state.currentStep) return;

    const steps = Object.keys(TOUR_STEPS);
    const currentIndex = steps.indexOf(this.state.currentStep);

    if (currentIndex > 0) {
      this.state.currentStep = steps[currentIndex - 1];
      this.saveState();
      this.notify();
    }
  }

  skip() {
    this.state.isActive = false;
    this.state.currentStep = null;
    markTourCompleted();
    this.saveState();
    this.notify();
  }

  complete() {
    this.state.isActive = false;
    this.state.currentStep = null;
    markTourCompleted();
    this.saveState();
    this.notify();
    window.dispatchEvent(new CustomEvent('tour-complete'));
  }

  restart() {
    localStorage.removeItem('tour_completed');
    localStorage.removeItem('tour_dismissed');
    this.start();
  }

  goToStep(stepId) {
    if (TOUR_STEPS[stepId]) {
      this.state.currentStep = stepId;
      this.state.isActive = true;
      this.saveState();
      this.notify();
    }
  }
}

export const tourManager = new TourManager();