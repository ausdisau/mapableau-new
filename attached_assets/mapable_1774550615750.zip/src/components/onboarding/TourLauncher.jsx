import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sparkles, Play } from "lucide-react";
import { toast } from "sonner";
import { tourManager, shouldShowTour } from "./tourUtils";

export default function TourLauncher() {
  const [showWelcome, setShowWelcome] = useState(false);
  const [showLauncher, setShowLauncher] = useState(false);

  useEffect(() => {
    const checkTour = setTimeout(() => {
      if (shouldShowTour()) {
        setShowWelcome(true);
      } else {
        setShowLauncher(true);
      }
    }, 1000);

    return () => clearTimeout(checkTour);
  }, []);

  const handleStartTour = () => {
    setShowWelcome(false);
    tourManager.start();
    toast.success("Tour started! Follow the steps to learn about MapAble.");
  };

  const handleDismiss = () => {
    setShowWelcome(false);
    setShowLauncher(true);
    localStorage.setItem('tour_dismissed', 'true');
  };

  return (
    <>
      <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <Sparkles className="w-6 h-6 text-purple-600" />
              Welcome to MapAble!
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex justify-center">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd9fa667dccdceb12f629e/05d1cd4bf_mapable-logo-original.png"
                alt="MapAble"
                className="h-20"
              />
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <AlertDescription className="text-blue-900">
                <p className="font-semibold mb-2">New to MapAble?</p>
                <p className="text-sm">
                  Take a quick interactive tour to discover the platform's key features and learn how to make the most of your NDIS services.
                </p>
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-gray-900">What you'll learn:</h4>
              <ul className="text-sm text-gray-700 space-y-1 list-disc list-inside">
                <li>How to search and navigate the platform</li>
                <li>Finding accessible locations and services</li>
                <li>Booking transport and care providers</li>
                <li>Managing your NDIS budget</li>
                <li>Using the AI assistant for help</li>
              </ul>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={handleDismiss}
                className="flex-1"
              >
                Maybe Later
              </Button>
              <Button
                onClick={handleStartTour}
                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 gap-2"
              >
                <Play className="w-4 h-4" />
                Start Tour
              </Button>
            </div>

            <p className="text-xs text-center text-gray-500">
              Takes about 3 minutes • You can skip or restart anytime
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {showLauncher && !showWelcome && (
        <button
          onClick={() => setShowWelcome(true)}
          className="fixed bottom-20 right-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full p-3 shadow-lg hover:shadow-xl transition-all z-30 group"
          title="Start Tour"
        >
          <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" />
        </button>
      )}
    </>
  );
}