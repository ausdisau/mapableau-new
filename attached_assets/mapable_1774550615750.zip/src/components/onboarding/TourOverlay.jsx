import React, { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  X,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Check,
  SkipForward
} from "lucide-react";
import { tourManager, getTourStep, calculateProgress, markTourCompleted, TOUR_STEPS } from "./tourUtils";
import { createPageUrl } from "@/utils";

export default function TourOverlay({ currentPage }) {
  const [tourState, setTourState] = useState({
    currentStep: null,
    isActive: false,
    completedSteps: []
  });
  const [highlightedElement, setHighlightedElement] = useState(null);

  // Subscribe to tour state changes
  useEffect(() => {
    const unsubscribe = tourManager.subscribe(setTourState);
    tourManager.loadState();
    return unsubscribe;
  }, []);

  // Update highlighted element when step changes
  useEffect(() => {
    if (tourState.isActive && tourState.currentStep) {
      const step = getTourStep(tourState.currentStep);
      if (step && step.target) {
        const element = document.querySelector(step.target);
        setHighlightedElement(element);
      } else {
        setHighlightedElement(null);
      }
    } else {
      setHighlightedElement(null);
    }
  }, [tourState.currentStep, tourState.isActive]);

  if (!tourState.isActive || !tourState.currentStep) {
    return null;
  }

  const currentStepData = getTourStep(tourState.currentStep);
  
  if (!currentStepData) {
    return null;
  }

  // Only show overlay if we're on the correct page
  if (currentStepData.page && currentStepData.page !== currentPage) {
    return null;
  }

  const progress = calculateProgress(tourState.currentStep);
  const isFirstStep = tourState.currentStep === "welcome";
  const isLastStep = currentStepData.action === "finish";

  const handleNext = () => {
    if (currentStepData.action === "navigate" && currentStepData.navigateTo) {
      window.location.href = createPageUrl(currentStepData.navigateTo);
      tourManager.next();
    } else if (currentStepData.action === "finish") {
      markTourCompleted();
      tourManager.complete();
    } else {
      tourManager.next();
    }
  };

  const handlePrevious = () => {
    tourManager.previous();
  };

  const handleSkip = () => {
    if (confirm("Are you sure you want to skip the tour? You can always restart it from your account settings.")) {
      markTourCompleted();
      tourManager.skip();
    }
  };

  const getPosition = () => {
    if (!highlightedElement) {
      return { top: "50%", left: "50%", transform: "translate(-50%, -50%)" };
    }

    const rect = highlightedElement.getBoundingClientRect();
    const position = currentStepData.position || "bottom";

    switch (position) {
      case "top":
        return { top: rect.top - 20, left: rect.left + rect.width / 2, transform: "translate(-50%, -100%)" };
      case "bottom":
        return { top: rect.bottom + 20, left: rect.left + rect.width / 2, transform: "translate(-50%, 0)" };
      case "left":
        return { top: rect.top + rect.height / 2, left: rect.left - 20, transform: "translate(-100%, -50%)" };
      case "right":
        return { top: rect.top + rect.height / 2, left: rect.right + 20, transform: "translate(0, -50%)" };
      case "bottom-left":
        return { top: rect.bottom + 20, left: rect.left, transform: "translate(0, 0)" };
      case "bottom-right":
        return { top: rect.bottom + 20, left: rect.right, transform: "translate(-100%, 0)" };
      case "center":
      default:
        return { top: "50%", left: "50%", transform: "translate(-50%, -50%)" };
    }
  };

  return createPortal(
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 z-[9998]" style={{ backdropFilter: "blur(2px)" }} />
      
      {/* Spotlight on highlighted element */}
      {highlightedElement && (
        <div
          className="fixed z-[9999] pointer-events-none"
          style={{
            top: highlightedElement.getBoundingClientRect().top - 8,
            left: highlightedElement.getBoundingClientRect().left - 8,
            width: highlightedElement.getBoundingClientRect().width + 16,
            height: highlightedElement.getBoundingClientRect().height + 16,
            boxShadow: "0 0 0 9999px rgba(0, 0, 0, 0.5)",
            borderRadius: "12px",
            border: "3px solid #8B5CF6",
            animation: "pulse 2s infinite"
          }}
        />
      )}

      {/* Tour Card */}
      <div className="fixed z-[10000]" style={getPosition()}>
        <Card className="w-96 shadow-2xl border-2 border-purple-200 bg-white">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                <CardTitle className="text-lg">
                  Step {tourState.completedSteps.length + 1} of {Object.keys(TOUR_STEPS).length}
                </CardTitle>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleSkip}
                className="text-white hover:bg-white/20 h-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <Progress value={progress} className="mt-2 h-1 bg-white/30" />
          </CardHeader>
          <CardContent className="pt-6">
            {/* Optional image */}
            {currentStepData.image && (
              <div className="mb-4 flex justify-center">
                <img
                  src={currentStepData.image}
                  alt={currentStepData.title}
                  className="h-16 object-contain"
                />
              </div>
            )}

            <div className="mb-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {currentStepData.title}
              </h3>
              <p className="text-gray-700 leading-relaxed">
                {currentStepData.description}
              </p>
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between gap-3">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={isFirstStep}
                className="gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <div className="flex gap-2">
                {!isLastStep && (
                  <Button
                    variant="ghost"
                    onClick={handleSkip}
                    className="gap-2 text-gray-600"
                  >
                    <SkipForward className="w-4 h-4" />
                    Skip Tour
                  </Button>
                )}
                <Button
                  onClick={handleNext}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 gap-2"
                >
                  {isLastStep ? (
                    <>
                      <Check className="w-4 h-4" />
                      Finish
                    </>
                  ) : (
                    <>
                      Next
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Animation styles */}
      <style jsx>{`
        @keyframes pulse {
          0%, 100% {
            border-color: #8B5CF6;
            box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5), 0 0 20px rgba(139, 92, 246, 0.5);
          }
          50% {
            border-color: #A78BFA;
            box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5), 0 0 30px rgba(167, 139, 250, 0.8);
          }
        }
      `}</style>
    </>,
    document.body
  );
}