import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Info, X } from "lucide-react";

/**
 * Contextual tooltip that appears next to complex features
 * Can be used independently of the main tour
 */
export default function TourTooltip({ 
  title, 
  description, 
  position = "right",
  visible = true,
  onDismiss 
}) {
  if (!visible) return null;

  const positionClasses = {
    top: "bottom-full mb-2 left-1/2 -translate-x-1/2",
    bottom: "top-full mt-2 left-1/2 -translate-x-1/2",
    left: "right-full mr-2 top-1/2 -translate-y-1/2",
    right: "left-full ml-2 top-1/2 -translate-y-1/2",
  };

  const arrowClasses = {
    top: "top-full left-1/2 -translate-x-1/2 border-t-blue-500 border-l-transparent border-r-transparent",
    bottom: "bottom-full left-1/2 -translate-x-1/2 border-b-blue-500 border-l-transparent border-r-transparent",
    left: "left-full top-1/2 -translate-y-1/2 border-l-blue-500 border-t-transparent border-b-transparent",
    right: "right-full top-1/2 -translate-y-1/2 border-r-blue-500 border-t-transparent border-b-transparent",
  };

  return (
    <div className={`absolute z-50 ${positionClasses[position]} w-72`}>
      <Card className="border-2 border-blue-500 shadow-lg bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              {title && (
                <h4 className="font-semibold text-blue-900 mb-1">{title}</h4>
              )}
              <p className="text-sm text-blue-800">{description}</p>
            </div>
            {onDismiss && (
              <button
                onClick={onDismiss}
                className="text-blue-600 hover:text-blue-800 flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Arrow */}
      <div
        className={`absolute w-0 h-0 border-8 ${arrowClasses[position]}`}
      />
    </div>
  );
}