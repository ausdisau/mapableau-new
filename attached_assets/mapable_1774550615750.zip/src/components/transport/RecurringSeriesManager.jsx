import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Repeat, Calendar, XCircle, AlertCircle, CheckCircle } from "lucide-react";
import { format } from "date-fns";

export default function RecurringSeriesManager({ seriesBookings, onClose }) {
  const queryClient = useQueryClient();
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [cancelType, setCancelType] = useState("all"); // "all" or "future"

  if (!seriesBookings || seriesBookings.length === 0) return null;

  const firstBooking = seriesBookings[0];
  const upcomingBookings = seriesBookings.filter(b => 
    new Date(b.pickup_datetime) >= new Date() && !["cancelled", "completed"].includes(b.status)
  );
  const completedBookings = seriesBookings.filter(b => b.status === "completed");
  const cancelledBookings = seriesBookings.filter(b => b.status === "cancelled");

  const cancelSeriesMutation = useMutation({
    mutationFn: async (type) => {
      const bookingsToCancel = type === "all" 
        ? seriesBookings.filter(b => !["cancelled", "completed"].includes(b.status))
        : upcomingBookings;

      for (const booking of bookingsToCancel) {
        await base44.entities.TransportBooking.update(booking.id, { status: "cancelled" });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] });
      setShowCancelDialog(false);
      if (onClose) onClose();
    },
  });

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Repeat className="w-5 h-5 text-blue-600" />
            <CardTitle>Recurring Series Details</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Series Info */}
          <div className="grid sm:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="text-sm text-gray-600 mb-1">Frequency</p>
              <p className="font-semibold capitalize">
                {firstBooking.recurrence_pattern?.frequency?.replace(/_/g, " ")}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Trips</p>
              <p className="font-semibold">{seriesBookings.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Route</p>
              <p className="font-semibold text-sm">
                {firstBooking.pickup_location.suburb} → {firstBooking.dropoff_location.suburb}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Purpose</p>
              <p className="font-semibold capitalize text-sm">
                {firstBooking.purpose?.replace(/_/g, " ")}
              </p>
            </div>
          </div>

          {/* Status Summary */}
          <div className="flex flex-wrap gap-3">
            <Badge className="bg-blue-100 text-blue-700">
              <Calendar className="w-3 h-3 mr-1" />
              {upcomingBookings.length} Upcoming
            </Badge>
            <Badge className="bg-green-100 text-green-700">
              <CheckCircle className="w-3 h-3 mr-1" />
              {completedBookings.length} Completed
            </Badge>
            {cancelledBookings.length > 0 && (
              <Badge className="bg-gray-100 text-gray-700">
                <XCircle className="w-3 h-3 mr-1" />
                {cancelledBookings.length} Cancelled
              </Badge>
            )}
          </div>

          {/* Upcoming Trips */}
          {upcomingBookings.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Upcoming Trips</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {upcomingBookings.slice(0, 10).map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium">
                          {format(new Date(booking.pickup_datetime), "EEEE, MMM d, yyyy")}
                        </p>
                        <p className="text-xs text-gray-600">
                          {format(new Date(booking.pickup_datetime), "h:mm a")}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="capitalize text-xs">
                      {booking.status.replace(/_/g, " ")}
                    </Badge>
                  </div>
                ))}
                {upcomingBookings.length > 10 && (
                  <p className="text-xs text-gray-500 text-center pt-2">
                    +{upcomingBookings.length - 10} more trips
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          {upcomingBookings.length > 0 && (
            <div className="space-y-3 pt-4 border-t">
              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertCircle className="w-4 h-4 text-yellow-600" />
                <AlertDescription className="text-sm text-yellow-800">
                  Cancelling will affect {upcomingBookings.length} upcoming trip{upcomingBookings.length !== 1 ? 's' : ''}
                </AlertDescription>
              </Alert>

              <div className="flex gap-3">
                <Button
                  variant="destructive"
                  onClick={() => {
                    setCancelType("future");
                    setShowCancelDialog(true);
                  }}
                  className="flex-1"
                >
                  Cancel Future Trips
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setCancelType("all");
                    setShowCancelDialog(true);
                  }}
                  className="flex-1"
                >
                  Cancel Entire Series
                </Button>
              </div>
            </div>
          )}

          {upcomingBookings.length === 0 && (
            <Alert>
              <CheckCircle className="w-4 h-4" />
              <AlertDescription>
                All trips in this recurring series have been completed or cancelled.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Cancel Confirmation Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Recurring Series</DialogTitle>
            <DialogDescription>
              {cancelType === "all" 
                ? `This will cancel all ${seriesBookings.filter(b => !["cancelled", "completed"].includes(b.status)).length} remaining trips in this recurring series.`
                : `This will cancel ${upcomingBookings.length} upcoming trip${upcomingBookings.length !== 1 ? 's' : ''}.`
              }
            </DialogDescription>
          </DialogHeader>
          <Alert className="bg-red-50 border-red-200">
            <AlertCircle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-sm text-red-800">
              This action cannot be undone. You'll need to create a new recurring booking if needed.
            </AlertDescription>
          </Alert>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
              Keep Series
            </Button>
            <Button
              variant="destructive"
              onClick={() => cancelSeriesMutation.mutate(cancelType)}
              disabled={cancelSeriesMutation.isPending}
            >
              {cancelSeriesMutation.isPending ? "Cancelling..." : "Yes, Cancel"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}