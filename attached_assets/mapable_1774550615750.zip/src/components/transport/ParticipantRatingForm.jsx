import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Star, CheckCircle } from "lucide-react";

function StarRating({ value, onChange, label }) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="transition-transform hover:scale-110"
          >
            <Star
              className={`w-8 h-8 ${
                star <= value
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-300"
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );
}

export default function ParticipantRatingForm({ booking, vehicle, driver, onSuccess }) {
  const queryClient = useQueryClient();
  const [submitted, setSubmitted] = useState(false);
  const [ratings, setRatings] = useState({
    overall_rating: 0,
    punctuality_rating: 0,
    professionalism_rating: 0,
    vehicle_condition_rating: 0,
    safety_rating: 0,
    accessibility_rating: 0,
    comment: "",
    would_recommend: true
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.TransportReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myTransportBookings"] });
      queryClient.invalidateQueries({ queryKey: ["transportReviews"] });
      queryClient.invalidateQueries({ queryKey: ["driverReviews"] });
      queryClient.invalidateQueries({ queryKey: ["vehicleReviews"] });
      setSubmitted(true);
      if (onSuccess) onSuccess();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (ratings.overall_rating === 0) {
      alert("Please provide an overall rating");
      return;
    }

    createReviewMutation.mutate({
      booking_id: booking.id,
      reviewer_type: "participant",
      vehicle_id: booking.vehicle_id,
      driver_id: booking.driver_id,
      participant_email: booking.created_by,
      ...ratings
    });
  };

  if (submitted) {
    return (
      <Card className="bg-green-50 border-green-200">
        <CardContent className="py-8 text-center">
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-green-900 mb-2">
            Thank You for Your Feedback!
          </h3>
          <p className="text-green-800 text-sm">
            Your review helps us maintain high quality service for all participants
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rate Your Ride</CardTitle>
        {vehicle && (
          <p className="text-sm text-gray-600">
            {vehicle.vehicle_name} {driver && `• Driver: ${driver.full_name}`}
          </p>
        )}
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Overall Rating */}
          <StarRating
            value={ratings.overall_rating}
            onChange={(value) => setRatings({ ...ratings, overall_rating: value })}
            label="Overall Experience *"
          />

          {/* Detailed Ratings */}
          <div className="grid sm:grid-cols-2 gap-6">
            <StarRating
              value={ratings.punctuality_rating}
              onChange={(value) => setRatings({ ...ratings, punctuality_rating: value })}
              label="Punctuality"
            />
            <StarRating
              value={ratings.professionalism_rating}
              onChange={(value) => setRatings({ ...ratings, professionalism_rating: value })}
              label="Professionalism"
            />
            <StarRating
              value={ratings.vehicle_condition_rating}
              onChange={(value) => setRatings({ ...ratings, vehicle_condition_rating: value })}
              label="Vehicle Condition"
            />
            <StarRating
              value={ratings.safety_rating}
              onChange={(value) => setRatings({ ...ratings, safety_rating: value })}
              label="Safety & Driving"
            />
            <StarRating
              value={ratings.accessibility_rating}
              onChange={(value) => setRatings({ ...ratings, accessibility_rating: value })}
              label="Accessibility Support"
            />
          </div>

          {/* Written Feedback */}
          <div className="space-y-2">
            <Label>Your Feedback (Optional)</Label>
            <Textarea
              value={ratings.comment}
              onChange={(e) => setRatings({ ...ratings, comment: e.target.value })}
              placeholder="Share your experience with other participants..."
              rows={4}
            />
          </div>

          {/* Recommendation */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="recommend"
              checked={ratings.would_recommend}
              onCheckedChange={(checked) => setRatings({ ...ratings, would_recommend: checked })}
            />
            <label htmlFor="recommend" className="text-sm font-medium cursor-pointer">
              I would recommend this service to other NDIS participants
            </label>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="submit"
              disabled={ratings.overall_rating === 0 || createReviewMutation.isPending}
              className="bg-secondary hover:bg-secondary/90"
            >
              {createReviewMutation.isPending ? "Submitting..." : "Submit Review"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}