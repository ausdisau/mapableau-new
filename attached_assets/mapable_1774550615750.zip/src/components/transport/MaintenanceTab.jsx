import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Car, AlertCircle, CheckCircle, Calendar, AlertTriangle } from "lucide-react";
import { format, isBefore, differenceInDays } from "date-fns";

export default function MaintenanceTab({ vehicles }) {
  const getMaintenanceStatus = (vehicle) => {
    const alerts = [];
    const today = new Date();

    if (vehicle.insurance_expiry) {
      const daysUntilExpiry = differenceInDays(new Date(vehicle.insurance_expiry), today);
      if (daysUntilExpiry < 0) {
        alerts.push({ type: "critical", message: "Insurance EXPIRED" });
      } else if (daysUntilExpiry <= 30) {
        alerts.push({ type: "warning", message: `Insurance expires in ${daysUntilExpiry} days` });
      }
    }

    if (vehicle.registration_expiry) {
      const daysUntilExpiry = differenceInDays(new Date(vehicle.registration_expiry), today);
      if (daysUntilExpiry < 0) {
        alerts.push({ type: "critical", message: "Registration EXPIRED" });
      } else if (daysUntilExpiry <= 30) {
        alerts.push({ type: "warning", message: `Registration expires in ${daysUntilExpiry} days` });
      }
    }

    if (vehicle.last_maintenance) {
      const daysSinceMaintenance = differenceInDays(today, new Date(vehicle.last_maintenance));
      if (daysSinceMaintenance >= 90) {
        alerts.push({ type: "warning", message: `Maintenance overdue (${daysSinceMaintenance} days)` });
      }
    }

    return alerts;
  };

  const vehiclesWithAlerts = vehicles.map(v => ({
    ...v,
    alerts: getMaintenanceStatus(v)
  })).filter(v => v.alerts.length > 0);

  const criticalVehicles = vehiclesWithAlerts.filter(v => 
    v.alerts.some(a => a.type === "critical")
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-primary">Maintenance Schedule</h2>

      {/* Critical Alerts */}
      {criticalVehicles.length > 0 && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription>
            <span className="font-semibold text-red-900">
              {criticalVehicles.length} vehicle(s) with CRITICAL issues
            </span>
            <p className="text-sm text-red-800 mt-1">
              These vehicles should not be used until issues are resolved
            </p>
          </AlertDescription>
        </Alert>
      )}

      {/* Vehicles Requiring Attention */}
      {vehiclesWithAlerts.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-6">
          {vehiclesWithAlerts.map((vehicle) => {
            const hasCritical = vehicle.alerts.some(a => a.type === "critical");
            return (
              <Card key={vehicle.id} className={hasCritical ? "border-red-300 bg-red-50" : "border-yellow-300 bg-yellow-50"}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Car className={`w-6 h-6 ${hasCritical ? "text-red-600" : "text-yellow-600"}`} />
                      <div>
                        <CardTitle className="text-lg">{vehicle.vehicle_name}</CardTitle>
                        <p className="text-sm text-gray-600">{vehicle.registration_number}</p>
                      </div>
                    </div>
                    <Badge variant={hasCritical ? "destructive" : "default"}>
                      {hasCritical ? "Critical" : "Warning"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {vehicle.alerts.map((alert, idx) => (
                      <div key={idx} className="flex items-start gap-2 p-2 bg-white rounded">
                        {alert.type === "critical" ? (
                          <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5" />
                        )}
                        <p className="text-sm font-medium">{alert.message}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 pt-4 border-t space-y-2 text-sm">
                    {vehicle.insurance_expiry && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Insurance Expiry:</span>
                        <span className="font-medium">
                          {format(new Date(vehicle.insurance_expiry), "d MMM yyyy")}
                        </span>
                      </div>
                    )}
                    {vehicle.registration_expiry && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Registration Expiry:</span>
                        <span className="font-medium">
                          {format(new Date(vehicle.registration_expiry), "d MMM yyyy")}
                        </span>
                      </div>
                    )}
                    {vehicle.last_maintenance && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Last Maintenance:</span>
                        <span className="font-medium">
                          {format(new Date(vehicle.last_maintenance), "d MMM yyyy")}
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">All Vehicles Up to Date</h3>
            <p className="text-gray-600">No maintenance or compliance issues found</p>
          </CardContent>
        </Card>
      )}

      {/* All Vehicles Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Complete Fleet Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {vehicles.map((vehicle) => {
              const alerts = getMaintenanceStatus(vehicle);
              return (
                <div key={vehicle.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Car className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-medium">{vehicle.vehicle_name}</p>
                      <p className="text-sm text-gray-600">{vehicle.registration_number}</p>
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    {vehicle.last_maintenance && (
                      <p className="text-xs text-gray-600">
                        Last service: {format(new Date(vehicle.last_maintenance), "d MMM yyyy")}
                      </p>
                    )}
                    {alerts.length === 0 ? (
                      <Badge className="bg-green-100 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Up to date
                      </Badge>
                    ) : (
                      <Badge variant={alerts.some(a => a.type === "critical") ? "destructive" : "default"}>
                        {alerts.length} alert{alerts.length !== 1 ? "s" : ""}
                      </Badge>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}