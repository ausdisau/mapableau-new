import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Users, Plus, Edit, Star, CheckCircle, AlertCircle } from "lucide-react";
import { format, isBefore, differenceInDays } from "date-fns";

export default function DriverManagementTab({ drivers }) {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingDriver, setEditingDriver] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    license_number: "",
    license_expiry: "",
    license_class: "C",
    phone: "",
    email: "",
    experience_years: 0,
    specializations: [],
    languages: ["English"],
    background_checks: {
      police_check_date: "",
      working_with_children_check: false,
      ndis_worker_screening: false
    },
    status: "available",
    active: true
  });

  const createDriverMutation = useMutation({
    mutationFn: (data) => base44.entities.Driver.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myDrivers"] });
      setShowForm(false);
      resetForm();
    },
  });

  const updateDriverMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Driver.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myDrivers"] });
      setShowForm(false);
      resetForm();
    },
  });

  const resetForm = () => {
    setEditingDriver(null);
    setFormData({
      full_name: "",
      license_number: "",
      license_expiry: "",
      license_class: "C",
      phone: "",
      email: "",
      experience_years: 0,
      specializations: [],
      languages: ["English"],
      background_checks: {
        police_check_date: "",
        working_with_children_check: false,
        ndis_worker_screening: false
      },
      status: "available",
      active: true
    });
  };

  const handleEdit = (driver) => {
    setEditingDriver(driver);
    setFormData({
      full_name: driver.full_name || "",
      license_number: driver.license_number || "",
      license_expiry: driver.license_expiry || "",
      license_class: driver.license_class || "C",
      phone: driver.phone || "",
      email: driver.email || "",
      experience_years: driver.experience_years || 0,
      specializations: driver.specializations || [],
      languages: driver.languages || ["English"],
      background_checks: driver.background_checks || {
        police_check_date: "",
        working_with_children_check: false,
        ndis_worker_screening: false
      },
      status: driver.status || "available",
      active: driver.active !== false
    });
    setShowForm(true);
  };

  const handleSubmit = () => {
    if (editingDriver) {
      updateDriverMutation.mutate({ id: editingDriver.id, data: formData });
    } else {
      createDriverMutation.mutate({ ...formData, operator_id: "self" });
    }
  };

  const specializationOptions = [
    "wheelchair_assistance", "mobility_aid_support", "medical_appointments",
    "community_access", "behavioral_support", "communication_assistance"
  ];

  const toggleSpecialization = (spec) => {
    setFormData(prev => ({
      ...prev,
      specializations: prev.specializations.includes(spec)
        ? prev.specializations.filter(s => s !== spec)
        : [...prev.specializations, spec]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-primary">Driver Team</h2>
        <Button onClick={() => { resetForm(); setShowForm(true); }} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Driver
        </Button>
      </div>

      {drivers.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No drivers yet</h3>
            <p className="text-gray-600 mb-4">Add your first driver to start accepting bookings</p>
            <Button onClick={() => setShowForm(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Driver
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {drivers.map((driver) => {
            const licenseExpiringSoon = driver.license_expiry && 
              differenceInDays(new Date(driver.license_expiry), new Date()) <= 60;
            const policeCheckExpiringSoon = driver.background_checks?.police_check_date && 
              differenceInDays(new Date(), new Date(driver.background_checks.police_check_date)) >= 335;

            return (
              <Card key={driver.id} className="hover-lift">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-primary">{driver.full_name}</h3>
                        <p className="text-sm text-gray-600">{driver.license_number}</p>
                        {driver.rating > 0 && (
                          <div className="flex items-center gap-1 mt-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs">{driver.rating.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(driver)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Experience:</span>
                      <span className="font-medium">{driver.experience_years} years</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Trips:</span>
                      <span className="font-medium">{driver.total_trips}</span>
                    </div>

                    {driver.specializations && driver.specializations.length > 0 && (
                      <div className="pt-2">
                        <div className="flex flex-wrap gap-1">
                          {driver.specializations.slice(0, 2).map((spec, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {spec.replace(/_/g, " ")}
                            </Badge>
                          ))}
                          {driver.specializations.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{driver.specializations.length - 2}
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="pt-2 border-t space-y-1">
                      {driver.background_checks?.ndis_worker_screening && (
                        <div className="flex items-center gap-1 text-xs text-green-700">
                          <CheckCircle className="w-3 h-3" />
                          NDIS Worker Screening
                        </div>
                      )}
                      {driver.background_checks?.working_with_children_check && (
                        <div className="flex items-center gap-1 text-xs text-green-700">
                          <CheckCircle className="w-3 h-3" />
                          Working with Children
                        </div>
                      )}
                      {(licenseExpiringSoon || policeCheckExpiringSoon) && (
                        <div className="flex items-center gap-1 text-xs text-yellow-700">
                          <AlertCircle className="w-3 h-3" />
                          Checks expiring soon
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <Badge variant={driver.status === "available" ? "default" : "secondary"}>
                        {driver.status?.replace(/_/g, " ")}
                      </Badge>
                      {!driver.active && (
                        <Badge variant="destructive" className="text-xs">Inactive</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Driver Dialog */}
      <Dialog open={showForm} onOpenChange={(open) => { setShowForm(open); if (!open) resetForm(); }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingDriver ? "Edit Driver" : "Add New Driver"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Basic Info */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Full Name *</Label>
                <Input
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  placeholder="John Smith"
                />
              </div>
              <div className="space-y-2">
                <Label>License Number *</Label>
                <Input
                  value={formData.license_number}
                  onChange={(e) => setFormData({ ...formData, license_number: e.target.value })}
                  placeholder="NSW12345"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>License Class</Label>
                <Select value={formData.license_class} onValueChange={(v) => setFormData({ ...formData, license_class: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="C">C (Car)</SelectItem>
                    <SelectItem value="LR">LR (Light Rigid)</SelectItem>
                    <SelectItem value="MR">MR (Medium Rigid)</SelectItem>
                    <SelectItem value="HR">HR (Heavy Rigid)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>License Expiry</Label>
                <Input
                  type="date"
                  value={formData.license_expiry}
                  onChange={(e) => setFormData({ ...formData, license_expiry: e.target.value })}
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="0412 345 678"
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="driver@example.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Experience (years)</Label>
              <Input
                type="number"
                min="0"
                value={formData.experience_years}
                onChange={(e) => setFormData({ ...formData, experience_years: parseInt(e.target.value) || 0 })}
              />
            </div>

            {/* Specializations */}
            <div className="space-y-3">
              <Label>Specializations</Label>
              <div className="grid sm:grid-cols-2 gap-3">
                {specializationOptions.map((spec) => (
                  <div key={spec} className="flex items-center space-x-2">
                    <Checkbox
                      id={spec}
                      checked={formData.specializations.includes(spec)}
                      onCheckedChange={() => toggleSpecialization(spec)}
                    />
                    <label htmlFor={spec} className="text-sm cursor-pointer">
                      {spec.replace(/_/g, " ")}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Background Checks */}
            <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
              <h3 className="font-semibold">Background Checks</h3>
              <div className="space-y-2">
                <Label>Police Check Date</Label>
                <Input
                  type="date"
                  value={formData.background_checks.police_check_date}
                  onChange={(e) => setFormData({
                    ...formData,
                    background_checks: { ...formData.background_checks, police_check_date: e.target.value }
                  })}
                />
              </div>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="wwcc"
                    checked={formData.background_checks.working_with_children_check}
                    onCheckedChange={(checked) => setFormData({
                      ...formData,
                      background_checks: { ...formData.background_checks, working_with_children_check: checked }
                    })}
                  />
                  <label htmlFor="wwcc" className="text-sm cursor-pointer">
                    Working with Children Check
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ndis_screening"
                    checked={formData.background_checks.ndis_worker_screening}
                    onCheckedChange={(checked) => setFormData({
                      ...formData,
                      background_checks: { ...formData.background_checks, ndis_worker_screening: checked }
                    })}
                  />
                  <label htmlFor="ndis_screening" className="text-sm cursor-pointer">
                    NDIS Worker Screening
                  </label>
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="on_trip">On Trip</SelectItem>
                    <SelectItem value="off_duty">Off Duty</SelectItem>
                    <SelectItem value="break">Break</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 pt-8">
                <Checkbox
                  id="active"
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
                <label htmlFor="active" className="text-sm font-medium cursor-pointer">
                  Active Driver
                </label>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={() => { setShowForm(false); resetForm(); }}>
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={!formData.full_name || !formData.license_number || createDriverMutation.isPending || updateDriverMutation.isPending}
              >
                {editingDriver ? "Update" : "Create"} Driver
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}