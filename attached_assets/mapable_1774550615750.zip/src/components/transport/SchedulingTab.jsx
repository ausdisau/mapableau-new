import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar, Zap, ArrowRight, Clock, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, isToday, isTomorrow } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function SchedulingTab() {
  const { data: schedules = [] } = useQuery({
    queryKey: ["dailySchedules"],
    queryFn: () => base44.entities.DailySchedule.list("-schedule_date"),
  });

  const todaySchedules = schedules.filter(s => isToday(new Date(s.schedule_date)));
  const tomorrowSchedules = schedules.filter(s => isTomorrow(new Date(s.schedule_date)));
  const draftSchedules = schedules.filter(s => s.status === "draft");
  const conflictSchedules = schedules.filter(s => 
    s.conflicts && s.conflicts.some(c => !c.resolved)
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-primary">Automated Scheduling</h2>
          <p className="text-gray-600 text-sm mt-1">
            AI-powered daily route scheduling with conflict detection
          </p>
        </div>
        <Link to={createPageUrl("ScheduleManagement")}>
          <Button className="gap-2">
            <Calendar className="w-4 h-4" />
            Open Schedule Manager
          </Button>
        </Link>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Today</p>
              <Clock className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{todaySchedules.length}</p>
            <p className="text-xs text-gray-500 mt-1">Active schedules</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Tomorrow</p>
              <Calendar className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{tomorrowSchedules.length}</p>
            <p className="text-xs text-gray-500 mt-1">Planned schedules</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Needs Review</p>
              <TrendingUp className="w-5 h-5 text-yellow-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{draftSchedules.length}</p>
            <p className="text-xs text-gray-500 mt-1">Draft schedules</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Conflicts</p>
              <Zap className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{conflictSchedules.length}</p>
            <p className="text-xs text-gray-500 mt-1">Require attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Features Overview */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-2 border-yellow-200 bg-yellow-50/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-600" />
              <CardTitle className="text-lg">Auto-Generate Schedules</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-700">
              Automatically create daily schedules by analyzing bookings, driver availability, 
              and vehicle status. The system optimizes routes and assigns the best driver for each vehicle.
            </p>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-yellow-600 mt-0.5" />
                <span>Intelligent driver-to-vehicle matching</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-yellow-600 mt-0.5" />
                <span>Route optimization for efficiency</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-yellow-600 mt-0.5" />
                <span>Automatic conflict detection</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-yellow-600 mt-0.5" />
                <span>Capacity and compliance checks</span>
              </li>
            </ul>
            <Link to={createPageUrl("ScheduleManagement")}>
              <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                Generate Today's Schedule
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 bg-blue-50/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              <CardTitle className="text-lg">Manual Overrides</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-700">
              Handle exceptions and make manual adjustments when needed. Full audit trail 
              of all changes with reason tracking.
            </p>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5" />
                <span>Reassign drivers or vehicles</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5" />
                <span>Modify shift times</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5" />
                <span>Add emergency bookings</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5" />
                <span>Resolve scheduling conflicts</span>
              </li>
            </ul>
            <Link to={createPageUrl("ScheduleManagement")}>
              <Button variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-50">
                Manage Schedules
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Active Conflicts Alert */}
      {conflictSchedules.length > 0 && (
        <Alert className="bg-red-50 border-red-200">
          <Zap className="w-4 h-4 text-red-600" />
          <AlertDescription>
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-red-900">
                  {conflictSchedules.length} schedule{conflictSchedules.length !== 1 ? 's' : ''} 
                </span>
                <span className="text-red-800"> require{conflictSchedules.length === 1 ? 's' : ''} attention due to conflicts</span>
              </div>
              <Link to={createPageUrl("ScheduleManagement")}>
                <Button size="sm" variant="outline" className="border-red-600 text-red-600">
                  Review Now
                </Button>
              </Link>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Help Alert */}
      <Alert>
        <Calendar className="w-4 h-4" />
        <AlertDescription>
          <span className="font-semibold">Getting Started:</span>
          <p className="text-sm mt-1">
            Use the Schedule Manager to generate daily schedules automatically. The system analyzes 
            all confirmed bookings, checks driver availability, and creates optimized routes. 
            You can review and manually adjust schedules before publishing them to drivers.
          </p>
        </AlertDescription>
      </Alert>
    </div>
  );
}