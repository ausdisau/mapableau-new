import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Star, TrendingUp, CheckCircle } from "lucide-react";

export default function RatingSummary({ reviews }) {
  if (reviews.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No ratings yet</p>
        </CardContent>
      </Card>
    );
  }

  // Calculate averages
  const averageOverall = reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length;
  const recommendCount = reviews.filter(r => r.would_recommend).length;
  const recommendPercent = (recommendCount / reviews.length) * 100;

  // Rating distribution
  const ratingCounts = [5, 4, 3, 2, 1].map(rating => 
    reviews.filter(r => Math.round(r.overall_rating) === rating).length
  );

  // Calculate category averages (for participant reviews)
  const participantReviews = reviews.filter(r => r.reviewer_type === "participant");
  const categoryAverages = participantReviews.length > 0 ? {
    punctuality: participantReviews.reduce((sum, r) => sum + (r.punctuality_rating || 0), 0) / participantReviews.length,
    professionalism: participantReviews.reduce((sum, r) => sum + (r.professionalism_rating || 0), 0) / participantReviews.length,
    vehicle: participantReviews.reduce((sum, r) => sum + (r.vehicle_condition_rating || 0), 0) / participantReviews.length,
    safety: participantReviews.reduce((sum, r) => sum + (r.safety_rating || 0), 0) / participantReviews.length,
    accessibility: participantReviews.reduce((sum, r) => sum + (r.accessibility_rating || 0), 0) / participantReviews.length,
  } : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rating Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Rating */}
        <div className="text-center pb-6 border-b">
          <div className="flex items-center justify-center gap-3 mb-2">
            <span className="text-5xl font-bold text-primary">{averageOverall.toFixed(1)}</span>
            <Star className="w-12 h-12 fill-yellow-400 text-yellow-400" />
          </div>
          <p className="text-gray-600">Based on {reviews.length} review{reviews.length !== 1 ? 's' : ''}</p>
          {recommendCount > 0 && (
            <div className="flex items-center justify-center gap-2 mt-3">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-700">
                {recommendPercent.toFixed(0)}% would recommend
              </span>
            </div>
          )}
        </div>

        {/* Rating Distribution */}
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((rating, idx) => {
            const count = ratingCounts[idx];
            const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
            return (
              <div key={rating} className="flex items-center gap-3">
                <span className="text-sm font-medium w-8">{rating} ★</span>
                <Progress value={percentage} className="flex-1 h-2" />
                <span className="text-sm text-gray-600 w-12 text-right">{count}</span>
              </div>
            );
          })}
        </div>

        {/* Category Breakdown */}
        {categoryAverages && (
          <div className="space-y-3 pt-6 border-t">
            <h4 className="font-semibold text-sm text-gray-700 mb-3">Rating Breakdown</h4>
            {categoryAverages.punctuality > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Punctuality</span>
                <div className="flex items-center gap-2">
                  <Progress value={(categoryAverages.punctuality / 5) * 100} className="w-24 h-2" />
                  <span className="text-sm font-medium w-8">{categoryAverages.punctuality.toFixed(1)}</span>
                </div>
              </div>
            )}
            {categoryAverages.professionalism > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Professionalism</span>
                <div className="flex items-center gap-2">
                  <Progress value={(categoryAverages.professionalism / 5) * 100} className="w-24 h-2" />
                  <span className="text-sm font-medium w-8">{categoryAverages.professionalism.toFixed(1)}</span>
                </div>
              </div>
            )}
            {categoryAverages.vehicle > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Vehicle Condition</span>
                <div className="flex items-center gap-2">
                  <Progress value={(categoryAverages.vehicle / 5) * 100} className="w-24 h-2" />
                  <span className="text-sm font-medium w-8">{categoryAverages.vehicle.toFixed(1)}</span>
                </div>
              </div>
            )}
            {categoryAverages.safety > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Safety</span>
                <div className="flex items-center gap-2">
                  <Progress value={(categoryAverages.safety / 5) * 100} className="w-24 h-2" />
                  <span className="text-sm font-medium w-8">{categoryAverages.safety.toFixed(1)}</span>
                </div>
              </div>
            )}
            {categoryAverages.accessibility > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Accessibility</span>
                <div className="flex items-center gap-2">
                  <Progress value={(categoryAverages.accessibility / 5) * 100} className="w-24 h-2" />
                  <span className="text-sm font-medium w-8">{categoryAverages.accessibility.toFixed(1)}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}