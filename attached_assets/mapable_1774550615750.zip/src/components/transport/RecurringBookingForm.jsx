import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Calendar, Repeat, Info } from "lucide-react";
import { addDays, addWeeks, addMonths, format } from "date-fns";

export default function RecurringBookingForm({ 
  isRecurring, 
  setIsRecurring, 
  recurrencePattern, 
  setRecurrencePattern,
  firstPickupDate 
}) {
  const [endType, setEndType] = useState("date"); // "date" or "occurrences"

  const daysOfWeek = [
    { value: "monday", label: "Mon" },
    { value: "tuesday", label: "Tue" },
    { value: "wednesday", label: "Wed" },
    { value: "thursday", label: "Thu" },
    { value: "friday", label: "Fri" },
    { value: "saturday", label: "Sat" },
    { value: "sunday", label: "Sun" }
  ];

  const toggleDayOfWeek = (day) => {
    const currentDays = recurrencePattern.days_of_week || [];
    const newDays = currentDays.includes(day)
      ? currentDays.filter(d => d !== day)
      : [...currentDays, day];
    setRecurrencePattern({ ...recurrencePattern, days_of_week: newDays });
  };

  // Calculate preview dates
  const generatePreviewDates = () => {
    if (!firstPickupDate || !recurrencePattern.frequency) return [];
    
    const dates = [];
    let currentDate = new Date(firstPickupDate);
    const maxPreview = 5;

    try {
      for (let i = 0; i < maxPreview; i++) {
        if (recurrencePattern.frequency === "daily") {
          dates.push(new Date(currentDate));
          currentDate = addDays(currentDate, 1);
        } else if (recurrencePattern.frequency === "weekly") {
          if (i === 0) {
            dates.push(new Date(currentDate));
          }
          currentDate = addWeeks(currentDate, 1);
          if (i > 0) dates.push(new Date(currentDate));
        } else if (recurrencePattern.frequency === "biweekly") {
          dates.push(new Date(currentDate));
          currentDate = addWeeks(currentDate, 2);
        } else if (recurrencePattern.frequency === "monthly") {
          dates.push(new Date(currentDate));
          currentDate = addMonths(currentDate, 1);
        }
      }
    } catch (error) {
      console.error("Error generating preview dates:", error);
    }

    return dates;
  };

  const previewDates = generatePreviewDates();

  return (
    <Card className="border-2 border-blue-200 bg-blue-50/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Repeat className="w-5 h-5 text-blue-600" />
            <CardTitle className="text-lg">Recurring Booking</CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="is_recurring"
              checked={isRecurring}
              onCheckedChange={setIsRecurring}
            />
            <label htmlFor="is_recurring" className="text-sm font-medium cursor-pointer">
              Make this recurring
            </label>
          </div>
        </div>
      </CardHeader>

      {isRecurring && (
        <CardContent className="space-y-6">
          <Alert>
            <Info className="w-4 h-4" />
            <AlertDescription className="text-sm">
              Set up regular transport for consistent needs like weekly appointments or daily work commutes. 
              You can modify or cancel individual trips later.
            </AlertDescription>
          </Alert>

          {/* Frequency Selection */}
          <div className="space-y-2">
            <Label>Repeat Frequency *</Label>
            <Select
              value={recurrencePattern.frequency}
              onValueChange={(value) => setRecurrencePattern({ ...recurrencePattern, frequency: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily (Every day)</SelectItem>
                <SelectItem value="weekly">Weekly (Once per week)</SelectItem>
                <SelectItem value="biweekly">Bi-weekly (Every 2 weeks)</SelectItem>
                <SelectItem value="monthly">Monthly (Once per month)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Days of Week (for weekly/biweekly) */}
          {(recurrencePattern.frequency === "weekly" || recurrencePattern.frequency === "biweekly") && (
            <div className="space-y-2">
              <Label>Repeat On (Optional)</Label>
              <div className="flex flex-wrap gap-2">
                {daysOfWeek.map((day) => (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => toggleDayOfWeek(day.value)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      (recurrencePattern.days_of_week || []).includes(day.value)
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-600">
                Leave blank to use the day of the first booking
              </p>
            </div>
          )}

          {/* End Type Selection */}
          <div className="space-y-2">
            <Label>End After</Label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setEndType("date")}
                className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  endType === "date"
                    ? "border-blue-600 bg-blue-50"
                    : "border-gray-200 bg-white hover:bg-gray-50"
                }`}
              >
                <Calendar className="w-4 h-4 mx-auto mb-1" />
                End Date
              </button>
              <button
                type="button"
                onClick={() => setEndType("occurrences")}
                className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                  endType === "occurrences"
                    ? "border-blue-600 bg-blue-50"
                    : "border-gray-200 bg-white hover:bg-gray-50"
                }`}
              >
                <Repeat className="w-4 h-4 mx-auto mb-1" />
                # of Trips
              </button>
            </div>
          </div>

          {/* End Date or Occurrences Input */}
          {endType === "date" ? (
            <div className="space-y-2">
              <Label>End Date *</Label>
              <Input
                type="date"
                value={recurrencePattern.end_date || ""}
                onChange={(e) => setRecurrencePattern({ ...recurrencePattern, end_date: e.target.value, occurrences: undefined })}
                min={firstPickupDate}
              />
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Number of Trips *</Label>
              <Input
                type="number"
                min="2"
                max="52"
                value={recurrencePattern.occurrences || ""}
                onChange={(e) => setRecurrencePattern({ 
                  ...recurrencePattern, 
                  occurrences: parseInt(e.target.value), 
                  end_date: undefined 
                })}
                placeholder="e.g., 10"
              />
              <p className="text-xs text-gray-600">Maximum 52 trips per series</p>
            </div>
          )}

          {/* Preview */}
          {previewDates.length > 0 && (
            <div className="space-y-2 pt-4 border-t">
              <Label className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Preview (First 5 trips)
              </Label>
              <div className="flex flex-wrap gap-2">
                {previewDates.map((date, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {format(date, "MMM d, yyyy")}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Summary */}
          {recurrencePattern.frequency && (recurrencePattern.end_date || recurrencePattern.occurrences) && (
            <Alert className="bg-blue-50 border-blue-200">
              <Repeat className="w-4 h-4 text-blue-600" />
              <AlertDescription>
                <span className="font-semibold text-blue-900">
                  {recurrencePattern.frequency === "daily" && "Daily recurring booking"}
                  {recurrencePattern.frequency === "weekly" && "Weekly recurring booking"}
                  {recurrencePattern.frequency === "biweekly" && "Bi-weekly recurring booking"}
                  {recurrencePattern.frequency === "monthly" && "Monthly recurring booking"}
                </span>
                <p className="text-sm text-blue-800 mt-1">
                  {recurrencePattern.end_date && `Runs until ${format(new Date(recurrencePattern.end_date), "MMMM d, yyyy")}`}
                  {recurrencePattern.occurrences && `Creates ${recurrencePattern.occurrences} trips`}
                </p>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      )}
    </Card>
  );
}