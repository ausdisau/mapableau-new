import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ThumbsUp, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

function StarDisplay({ rating, label, showLabel = true }) {
  return (
    <div className="flex items-center gap-2">
      {showLabel && <span className="text-sm text-gray-600 min-w-[120px]">{label}:</span>}
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating
                ? "fill-yellow-400 text-yellow-400"
                : "text-gray-300"
            }`}
          />
        ))}
      </div>
      <span className="text-sm font-medium">{rating.toFixed(1)}</span>
    </div>
  );
}

export default function ReviewsList({ reviews, showVehicleInfo = false, showParticipantInfo = false }) {
  const queryClient = useQueryClient();

  const markHelpfulMutation = useMutation({
    mutationFn: (reviewId) => {
      const review = reviews.find(r => r.id === reviewId);
      return base44.entities.TransportReview.update(reviewId, {
        helpful_count: (review.helpful_count || 0) + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transportReviews"] });
    },
  });

  if (reviews.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No reviews yet</h3>
          <p className="text-gray-600">Be the first to leave a review!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <Card key={review.id}>
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <StarDisplay rating={review.overall_rating} showLabel={false} />
                    {review.would_recommend && (
                      <Badge className="bg-green-100 text-green-700 text-xs">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Recommended
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    By {review.reviewer_type === "participant" ? "Participant" : "Provider"} • 
                    {format(new Date(review.created_date), " MMM d, yyyy")}
                  </p>
                </div>
              </div>

              {/* Detailed Ratings */}
              {review.reviewer_type === "participant" && (
                <div className="grid sm:grid-cols-2 gap-2 text-sm">
                  {review.punctuality_rating > 0 && (
                    <StarDisplay rating={review.punctuality_rating} label="Punctuality" />
                  )}
                  {review.professionalism_rating > 0 && (
                    <StarDisplay rating={review.professionalism_rating} label="Professionalism" />
                  )}
                  {review.vehicle_condition_rating > 0 && (
                    <StarDisplay rating={review.vehicle_condition_rating} label="Vehicle" />
                  )}
                  {review.safety_rating > 0 && (
                    <StarDisplay rating={review.safety_rating} label="Safety" />
                  )}
                  {review.accessibility_rating > 0 && (
                    <StarDisplay rating={review.accessibility_rating} label="Accessibility" />
                  )}
                </div>
              )}

              {/* Comment */}
              {review.comment && (
                <p className="text-gray-700 leading-relaxed">{review.comment}</p>
              )}

              {/* Provider Response */}
              {review.provider_response && (
                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                  <p className="text-sm font-semibold text-blue-900 mb-2">Response from Provider</p>
                  <p className="text-sm text-blue-800">{review.provider_response}</p>
                  {review.provider_response_date && (
                    <p className="text-xs text-blue-600 mt-2">
                      {format(new Date(review.provider_response_date), "MMM d, yyyy")}
                    </p>
                  )}
                </div>
              )}

              {/* Helpful Button */}
              <div className="flex items-center gap-3 pt-3 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => markHelpfulMutation.mutate(review.id)}
                  disabled={markHelpfulMutation.isPending}
                  className="gap-2"
                >
                  <ThumbsUp className="w-4 h-4" />
                  Helpful {review.helpful_count > 0 && `(${review.helpful_count})`}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}