import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Navigation, 
  MapPin, 
  Clock, 
  TrendingUp, 
  CheckCircle,
  Calendar,
  ArrowRight,
  Star
} from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ProviderRatingForm from "./ProviderRatingForm";

export default function RouteOptimizationTab({ bookings, vehicles }) {
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [ratingBooking, setRatingBooking] = useState(null);

  const todayBookings = bookings.filter(b => {
    if (!b.pickup_datetime) return false;
    const pickupDate = new Date(b.pickup_datetime);
    const today = new Date();
    return pickupDate.toDateString() === today.toDateString() &&
           ["confirmed", "driver_assigned"].includes(b.status);
  });

  const upcomingBookings = bookings.filter(b => {
    if (!b.pickup_datetime) return false;
    const pickupDate = new Date(b.pickup_datetime);
    const today = new Date();
    return pickupDate > today && ["confirmed", "driver_assigned"].includes(b.status);
  });

  const completedWithRoutes = bookings.filter(b => 
    b.status === "completed" && b.route_data?.waypoints
  );

  const avgDistance = completedWithRoutes.length > 0
    ? completedWithRoutes.reduce((sum, b) => sum + parseFloat(b.route_data.total_distance || 0), 0) / completedWithRoutes.length
    : 0;

  const avgTime = completedWithRoutes.length > 0
    ? completedWithRoutes.reduce((sum, b) => sum + parseInt(b.route_data.estimated_duration || 0), 0) / completedWithRoutes.length
    : 0;

  // Group bookings by vehicle
  const bookingsByVehicle = vehicles.map(vehicle => ({
    vehicle,
    bookings: todayBookings.filter(b => b.vehicle_id === vehicle.id)
  })).filter(item => item.bookings.length > 0);

  const { data: providerReviews = [] } = useQuery({
    queryKey: ["providerReviews"],
    queryFn: async () => {
      const user = await base44.auth.me();
      return await base44.entities.TransportReview.filter({ created_by: user.email, reviewer_type: "provider" });
    },
  });

  const hasProviderReview = (bookingId) => providerReviews.some(r => r.booking_id === bookingId);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-primary">Route Optimization</h2>
          <p className="text-gray-600 text-sm mt-1">
            Optimize multi-stop routes to save time and fuel
          </p>
        </div>
        <Link to={createPageUrl("RouteOptimizer")}>
          <Button className="gap-2">
            <Navigation className="w-4 h-4" />
            Open Route Planner
          </Button>
        </Link>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Avg. Route Distance</p>
              <MapPin className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{avgDistance.toFixed(1)} km</p>
            <p className="text-xs text-gray-500 mt-1">Per optimized route</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Avg. Route Time</p>
              <Clock className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{avgTime.toFixed(0)} min</p>
            <p className="text-xs text-gray-500 mt-1">Per optimized route</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Routes Optimized</p>
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{completedWithRoutes.length}</p>
            <p className="text-xs text-gray-500 mt-1">All time</p>
          </CardContent>
        </Card>
      </div>

      {/* Today's Bookings by Vehicle */}
      {bookingsByVehicle.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Today's Bookings by Vehicle</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {bookingsByVehicle.map(({ vehicle, bookings }) => (
                <div key={vehicle.id} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-primary">{vehicle.vehicle_name}</h3>
                      <p className="text-sm text-gray-600">{bookings.length} scheduled trips</p>
                    </div>
                    <Link to={`${createPageUrl("RouteOptimizer")}?vehicle=${vehicle.id}`}>
                      <Button size="sm" className="gap-2">
                        <Navigation className="w-4 h-4" />
                        Optimize
                      </Button>
                    </Link>
                  </div>
                  <div className="space-y-2">
                    {bookings.slice(0, 3).map((booking) => (
                      <div key={booking.id} className="flex items-center justify-between text-sm p-2 bg-white rounded">
                        <div className="flex-1">
                          <p className="font-medium">{booking.passenger_name}</p>
                          <p className="text-xs text-gray-600">
                            {format(new Date(booking.pickup_datetime), "h:mm a")} • 
                            {booking.pickup_location.suburb} → {booking.dropoff_location.suburb}
                          </p>
                        </div>
                        <Badge variant={booking.route_data ? "default" : "secondary"}>
                          {booking.route_data ? "Routed" : "Pending"}
                        </Badge>
                      </div>
                    ))}
                    {bookings.length > 3 && (
                      <p className="text-xs text-gray-500 text-center pt-2">
                        +{bookings.length - 3} more trips
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Completed Bookings Needing Review */}
      {bookings.filter(b => b.status === "completed" && !hasProviderReview(b.id)).length > 0 && (
        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle>Bookings Pending Review</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {bookings
                .filter(b => b.status === "completed" && !hasProviderReview(b.id))
                .slice(0, 5)
                .map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{booking.passenger_name}</p>
                      <p className="text-xs text-gray-600">
                        {format(new Date(booking.pickup_datetime), "MMM d, h:mm a")}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => {
                        setRatingBooking(booking);
                        setShowRatingDialog(true);
                      }}
                      className="gap-2"
                    >
                      <Star className="w-4 h-4" />
                      Rate Participant
                    </Button>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upcoming Bookings */}
      {upcomingBookings.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingBookings.slice(0, 5).map((booking) => {
                const vehicle = vehicles.find(v => v.id === booking.vehicle_id);
                return (
                  <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm">{booking.passenger_name}</p>
                        <ArrowRight className="w-3 h-3 text-gray-400" />
                        <p className="text-sm text-gray-600">{vehicle?.vehicle_name}</p>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(booking.pickup_datetime), "MMM d, h:mm a")}
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {booking.pickup_location.suburb}
                        </div>
                      </div>
                    </div>
                    <Badge variant={booking.route_data ? "default" : "outline"}>
                      {booking.route_data ? (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Optimized
                        </>
                      ) : (
                        "Not optimized"
                      )}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Alert */}
      <Alert>
        <Navigation className="w-4 h-4" />
        <AlertDescription>
          <span className="font-semibold">How Route Optimization Works</span>
          <p className="text-sm mt-1">
            Select multiple bookings for the same vehicle, and our algorithm will calculate 
            the most efficient route considering pickup/drop-off sequence, travel time, and fuel consumption. 
            This helps reduce operational costs and improve service quality.
          </p>
        </AlertDescription>
      </Alert>

      {/* Rating Dialog */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Rate Participant</DialogTitle>
          </DialogHeader>
          {ratingBooking && (
            <ProviderRatingForm
              booking={ratingBooking}
              onSuccess={() => {
                setShowRatingDialog(false);
                setRatingBooking(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}