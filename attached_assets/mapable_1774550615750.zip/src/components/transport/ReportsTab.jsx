import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Download, TrendingUp, Users, Car, DollarSign, Star } from "lucide-react";

export default function ReportsTab({ vehicles, drivers, bookings }) {
  // Vehicle Utilization
  const vehicleUtilization = vehicles.map(vehicle => {
    const vehicleBookings = bookings.filter(b => b.vehicle_id === vehicle.id);
    const completedTrips = vehicleBookings.filter(b => b.status === "completed").length;
    const revenue = vehicleBookings
      .filter(b => b.payment_status === "paid")
      .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0);
    
    return {
      ...vehicle,
      trips: completedTrips,
      revenue,
      utilization: vehicle.total_trips > 0 ? (completedTrips / vehicle.total_trips) * 100 : 0
    };
  }).sort((a, b) => b.revenue - a.revenue);

  // Driver Performance
  const driverPerformance = drivers.map(driver => {
    const driverVehicle = vehicles.find(v => v.driver_id === driver.id);
    const driverBookings = driverVehicle ? bookings.filter(b => b.vehicle_id === driverVehicle.id) : [];
    const completedTrips = driverBookings.filter(b => b.status === "completed").length;
    const revenue = driverBookings
      .filter(b => b.payment_status === "paid")
      .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0);
    
    return {
      ...driver,
      trips: completedTrips,
      revenue,
      vehicleName: driverVehicle?.vehicle_name || "Unassigned"
    };
  }).sort((a, b) => b.revenue - a.revenue);

  const totalRevenue = bookings
    .filter(b => b.payment_status === "paid")
    .reduce((sum, b) => sum + (b.actual_cost || b.estimated_cost || 0), 0);

  const totalTrips = bookings.filter(b => b.status === "completed").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-primary">Performance Reports</h2>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export All Reports
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Total Revenue</p>
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-primary">${totalRevenue.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Completed Trips</p>
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{totalTrips}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Fleet Size</p>
              <Car className="w-5 h-5 text-purple-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{vehicles.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Active Drivers</p>
              <Users className="w-5 h-5 text-yellow-600" />
            </div>
            <p className="text-3xl font-bold text-primary">{drivers.filter(d => d.active).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Vehicle Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Vehicle Performance</CardTitle>
        </CardHeader>
        <CardContent>
          {vehicleUtilization.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No vehicle data available</p>
          ) : (
            <div className="space-y-4">
              {vehicleUtilization.map((vehicle) => (
                <div key={vehicle.id} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Car className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="font-semibold text-primary">{vehicle.vehicle_name}</p>
                        <p className="text-sm text-gray-600">{vehicle.registration_number}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-primary">${vehicle.revenue.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{vehicle.trips} trips</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Utilization</span>
                      <span className="font-medium">{vehicle.utilization.toFixed(1)}%</span>
                    </div>
                    <Progress value={vehicle.utilization} className="h-2" />
                  </div>
                  {vehicle.rating > 0 && (
                    <div className="flex items-center gap-2 mt-2">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{vehicle.rating.toFixed(1)}</span>
                      <span className="text-sm text-gray-600">({vehicle.total_trips} total trips)</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Driver Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Driver Performance</CardTitle>
        </CardHeader>
        <CardContent>
          {driverPerformance.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No driver data available</p>
          ) : (
            <div className="space-y-4">
              {driverPerformance.map((driver) => (
                <div key={driver.id} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-primary">{driver.full_name}</p>
                        <p className="text-sm text-gray-600">{driver.vehicleName}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-primary">${driver.revenue.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{driver.trips} trips</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    {driver.rating > 0 && (
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{driver.rating.toFixed(1)}</span>
                      </div>
                    )}
                    <span className="text-gray-600">
                      {driver.experience_years} years experience
                    </span>
                    <Badge variant={driver.status === "available" ? "default" : "secondary"} className="text-xs">
                      {driver.status?.replace(/_/g, " ")}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Export Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Vehicle Report
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Driver Report
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Revenue Report
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Full Summary
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}