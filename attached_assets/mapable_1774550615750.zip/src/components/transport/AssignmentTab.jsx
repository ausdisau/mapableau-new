import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Car, Users, ArrowRight, CheckCircle, AlertCircle } from "lucide-react";

export default function AssignmentTab({ vehicles, drivers }) {
  const queryClient = useQueryClient();
  const [selectedVehicle, setSelectedVehicle] = useState("");
  const [selectedDriver, setSelectedDriver] = useState("");

  const assignDriverMutation = useMutation({
    mutationFn: ({ vehicleId, driverId }) => 
      base44.entities.Vehicle.update(vehicleId, { driver_id: driverId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myVehicles"] });
      setSelectedVehicle("");
      setSelectedDriver("");
    },
  });

  const updateDriverVehicleMutation = useMutation({
    mutationFn: ({ driverId, vehicleId }) => 
      base44.entities.Driver.update(driverId, { current_vehicle_id: vehicleId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myDrivers"] });
    },
  });

  const handleAssignment = () => {
    if (selectedVehicle && selectedDriver) {
      assignDriverMutation.mutate({ vehicleId: selectedVehicle, driverId: selectedDriver });
      updateDriverVehicleMutation.mutate({ driverId: selectedDriver, vehicleId: selectedVehicle });
    }
  };

  const unassignDriver = (vehicleId) => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    if (vehicle?.driver_id) {
      assignDriverMutation.mutate({ vehicleId, driverId: null });
      updateDriverVehicleMutation.mutate({ driverId: vehicle.driver_id, vehicleId: null });
    }
  };

  const assignedVehicles = vehicles.filter(v => v.driver_id);
  const unassignedVehicles = vehicles.filter(v => !v.driver_id);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-primary">Driver-Vehicle Assignments</h2>

      {/* Assignment Form */}
      <Card>
        <CardHeader>
          <CardTitle>Create New Assignment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Vehicle</label>
              <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose vehicle..." />
                </SelectTrigger>
                <SelectContent>
                  {unassignedVehicles.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.vehicle_name} - {vehicle.registration_number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-center">
              <ArrowRight className="w-6 h-6 text-gray-400" />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Driver</label>
              <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose driver..." />
                </SelectTrigger>
                <SelectContent>
                  {drivers.filter(d => d.active && d.status === "available").map((driver) => (
                    <SelectItem key={driver.id} value={driver.id}>
                      {driver.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleAssignment}
            disabled={!selectedVehicle || !selectedDriver || assignDriverMutation.isPending}
            className="mt-4"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Assign Driver
          </Button>
        </CardContent>
      </Card>

      {/* Current Assignments */}
      <Card>
        <CardHeader>
          <CardTitle>Current Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          {assignedVehicles.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No driver assignments yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {assignedVehicles.map((vehicle) => {
                const driver = drivers.find(d => d.id === vehicle.driver_id);
                return (
                  <div key={vehicle.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Car className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-primary">{vehicle.vehicle_name}</p>
                          <p className="text-sm text-gray-600">{vehicle.registration_number}</p>
                        </div>
                      </div>

                      <ArrowRight className="w-5 h-5 text-gray-400" />

                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-primary">{driver?.full_name || "Unknown"}</p>
                          <Badge variant={driver?.status === "available" ? "default" : "secondary"} className="text-xs">
                            {driver?.status?.replace(/_/g, " ") || "unknown"}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => unassignDriver(vehicle.id)}
                      disabled={assignDriverMutation.isPending}
                    >
                      Unassign
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Unassigned Resources */}
      {unassignedVehicles.length > 0 && (
        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-yellow-900">Unassigned Vehicles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {unassignedVehicles.map((vehicle) => (
                <div key={vehicle.id} className="flex items-center gap-3 p-3 bg-white rounded-lg">
                  <Car className="w-5 h-5 text-yellow-600" />
                  <div>
                    <p className="font-medium text-sm">{vehicle.vehicle_name}</p>
                    <p className="text-xs text-gray-600">{vehicle.registration_number}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}