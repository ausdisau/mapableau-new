import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Car, Plus, Edit, MapPin, Star, CheckCircle, Settings } from "lucide-react";
import { format } from "date-fns";

export default function VehicleManagementTab({ vehicles }) {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [formData, setFormData] = useState({
    vehicle_name: "",
    registration_number: "",
    vehicle_type: "wheelchair_accessible_van",
    capacity: {
      wheelchair_spaces: 1,
      standard_seats: 4,
      mobility_scooter_spaces: 0
    },
    accessibility_features: [],
    base_location: {
      suburb: "",
      state: "NSW",
      latitude: null,
      longitude: null
    },
    service_area_radius: 50,
    hourly_rate: 65,
    per_km_rate: 2.5,
    ndis_registered: true,
    insurance_expiry: "",
    registration_expiry: "",
    last_maintenance: "",
    status: "available"
  });

  const createVehicleMutation = useMutation({
    mutationFn: (data) => base44.entities.Vehicle.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myVehicles"] });
      setShowForm(false);
      resetForm();
    },
  });

  const updateVehicleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Vehicle.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["myVehicles"] });
      setShowForm(false);
      resetForm();
    },
  });

  const resetForm = () => {
    setEditingVehicle(null);
    setFormData({
      vehicle_name: "",
      registration_number: "",
      vehicle_type: "wheelchair_accessible_van",
      capacity: { wheelchair_spaces: 1, standard_seats: 4, mobility_scooter_spaces: 0 },
      accessibility_features: [],
      base_location: { suburb: "", state: "NSW", latitude: null, longitude: null },
      service_area_radius: 50,
      hourly_rate: 65,
      per_km_rate: 2.5,
      ndis_registered: true,
      insurance_expiry: "",
      registration_expiry: "",
      last_maintenance: "",
      status: "available"
    });
  };

  const handleEdit = (vehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      vehicle_name: vehicle.vehicle_name || "",
      registration_number: vehicle.registration_number || "",
      vehicle_type: vehicle.vehicle_type || "wheelchair_accessible_van",
      capacity: vehicle.capacity || { wheelchair_spaces: 1, standard_seats: 4, mobility_scooter_spaces: 0 },
      accessibility_features: vehicle.accessibility_features || [],
      base_location: vehicle.base_location || { suburb: "", state: "NSW", latitude: null, longitude: null },
      service_area_radius: vehicle.service_area_radius || 50,
      hourly_rate: vehicle.hourly_rate || 65,
      per_km_rate: vehicle.per_km_rate || 2.5,
      ndis_registered: vehicle.ndis_registered !== false,
      insurance_expiry: vehicle.insurance_expiry || "",
      registration_expiry: vehicle.registration_expiry || "",
      last_maintenance: vehicle.last_maintenance || "",
      status: vehicle.status || "available"
    });
    setShowForm(true);
  };

  const handleSubmit = () => {
    if (editingVehicle) {
      updateVehicleMutation.mutate({ id: editingVehicle.id, data: formData });
    } else {
      createVehicleMutation.mutate(formData);
    }
  };

  const accessibilityOptions = [
    "wheelchair_ramp", "wheelchair_lift", "tie_down_system", "swivel_seats",
    "lowered_floor", "wide_doors", "audio_announcements", "visual_displays", "service_animal_friendly"
  ];

  const toggleFeature = (feature) => {
    setFormData(prev => ({
      ...prev,
      accessibility_features: prev.accessibility_features.includes(feature)
        ? prev.accessibility_features.filter(f => f !== feature)
        : [...prev.accessibility_features, feature]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-primary">Vehicle Fleet</h2>
        <Button onClick={() => { resetForm(); setShowForm(true); }} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Vehicle
        </Button>
      </div>

      {vehicles.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No vehicles yet</h3>
            <p className="text-gray-600 mb-4">Add your first vehicle to start managing your fleet</p>
            <Button onClick={() => setShowForm(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Vehicle
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((vehicle) => (
            <Card key={vehicle.id} className="hover-lift">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-primary mb-1">{vehicle.vehicle_name}</h3>
                    <p className="text-sm text-gray-600">{vehicle.registration_number}</p>
                    <Badge variant="outline" className="text-xs mt-2">
                      {vehicle.vehicle_type?.replace(/_/g, " ")}
                    </Badge>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(vehicle)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2 text-sm">
                  {vehicle.capacity && (
                    <div className="flex flex-wrap gap-2">
                      {vehicle.capacity.wheelchair_spaces > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {vehicle.capacity.wheelchair_spaces} wheelchair
                        </Badge>
                      )}
                      {vehicle.capacity.standard_seats > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {vehicle.capacity.standard_seats} seats
                        </Badge>
                      )}
                    </div>
                  )}

                  {vehicle.base_location && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>{vehicle.base_location.suburb}, {vehicle.base_location.state}</span>
                    </div>
                  )}

                  {vehicle.rating > 0 && (
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{vehicle.rating.toFixed(1)} ({vehicle.total_trips} trips)</span>
                    </div>
                  )}

                  <div className="pt-2 border-t">
                    <p className="font-semibold text-primary">
                      ${vehicle.hourly_rate}/hr + ${vehicle.per_km_rate}/km
                    </p>
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge variant={vehicle.status === "available" ? "default" : "secondary"}>
                      {vehicle.status}
                    </Badge>
                    {vehicle.ndis_registered && (
                      <Badge className="bg-green-100 text-green-700 text-xs">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        NDIS
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Vehicle Dialog */}
      <Dialog open={showForm} onOpenChange={(open) => { setShowForm(open); if (!open) resetForm(); }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingVehicle ? "Edit Vehicle" : "Add New Vehicle"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Basic Info */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Vehicle Name *</Label>
                <Input
                  value={formData.vehicle_name}
                  onChange={(e) => setFormData({ ...formData, vehicle_name: e.target.value })}
                  placeholder="e.g., AccessVan Sydney 1"
                />
              </div>
              <div className="space-y-2">
                <Label>Registration Number *</Label>
                <Input
                  value={formData.registration_number}
                  onChange={(e) => setFormData({ ...formData, registration_number: e.target.value })}
                  placeholder="ABC123"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Vehicle Type</Label>
              <Select value={formData.vehicle_type} onValueChange={(v) => setFormData({ ...formData, vehicle_type: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="wheelchair_accessible_van">Wheelchair Accessible Van</SelectItem>
                  <SelectItem value="wheelchair_accessible_bus">Wheelchair Accessible Bus</SelectItem>
                  <SelectItem value="mobility_scooter_accessible">Mobility Scooter Accessible</SelectItem>
                  <SelectItem value="standard_accessible">Standard Accessible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Capacity */}
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Wheelchair Spaces</Label>
                <Input
                  type="number"
                  min="0"
                  value={formData.capacity.wheelchair_spaces}
                  onChange={(e) => setFormData({
                    ...formData,
                    capacity: { ...formData.capacity, wheelchair_spaces: parseInt(e.target.value) || 0 }
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>Standard Seats</Label>
                <Input
                  type="number"
                  min="0"
                  value={formData.capacity.standard_seats}
                  onChange={(e) => setFormData({
                    ...formData,
                    capacity: { ...formData.capacity, standard_seats: parseInt(e.target.value) || 0 }
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>Scooter Spaces</Label>
                <Input
                  type="number"
                  min="0"
                  value={formData.capacity.mobility_scooter_spaces}
                  onChange={(e) => setFormData({
                    ...formData,
                    capacity: { ...formData.capacity, mobility_scooter_spaces: parseInt(e.target.value) || 0 }
                  })}
                />
              </div>
            </div>

            {/* Accessibility Features */}
            <div className="space-y-3">
              <Label>Accessibility Features</Label>
              <div className="grid sm:grid-cols-2 gap-3">
                {accessibilityOptions.map((feature) => (
                  <div key={feature} className="flex items-center space-x-2">
                    <Checkbox
                      id={feature}
                      checked={formData.accessibility_features.includes(feature)}
                      onCheckedChange={() => toggleFeature(feature)}
                    />
                    <label htmlFor={feature} className="text-sm cursor-pointer">
                      {feature.replace(/_/g, " ")}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Location */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Base Suburb</Label>
                <Input
                  value={formData.base_location.suburb}
                  onChange={(e) => setFormData({
                    ...formData,
                    base_location: { ...formData.base_location, suburb: e.target.value }
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label>State</Label>
                <Select
                  value={formData.base_location.state}
                  onValueChange={(v) => setFormData({
                    ...formData,
                    base_location: { ...formData.base_location, state: v }
                  })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["NSW", "VIC", "QLD", "SA", "WA", "TAS", "NT", "ACT"].map(state => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Rates */}
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Hourly Rate ($)</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.50"
                  value={formData.hourly_rate}
                  onChange={(e) => setFormData({ ...formData, hourly_rate: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Per KM Rate ($)</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.10"
                  value={formData.per_km_rate}
                  onChange={(e) => setFormData({ ...formData, per_km_rate: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Service Radius (km)</Label>
                <Input
                  type="number"
                  min="0"
                  value={formData.service_area_radius}
                  onChange={(e) => setFormData({ ...formData, service_area_radius: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Insurance Expiry</Label>
                <Input
                  type="date"
                  value={formData.insurance_expiry}
                  onChange={(e) => setFormData({ ...formData, insurance_expiry: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Registration Expiry</Label>
                <Input
                  type="date"
                  value={formData.registration_expiry}
                  onChange={(e) => setFormData({ ...formData, registration_expiry: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Last Maintenance</Label>
                <Input
                  type="date"
                  value={formData.last_maintenance}
                  onChange={(e) => setFormData({ ...formData, last_maintenance: e.target.value })}
                />
              </div>
            </div>

            {/* Status & NDIS */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="in_service">In Service</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="unavailable">Unavailable</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 pt-8">
                <Checkbox
                  id="ndis_registered"
                  checked={formData.ndis_registered}
                  onCheckedChange={(checked) => setFormData({ ...formData, ndis_registered: checked })}
                />
                <label htmlFor="ndis_registered" className="text-sm font-medium cursor-pointer">
                  NDIS Registered
                </label>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={() => { setShowForm(false); resetForm(); }}>
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={!formData.vehicle_name || !formData.registration_number || createVehicleMutation.isPending || updateVehicleMutation.isPending}
              >
                {editingVehicle ? "Update" : "Create"} Vehicle
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}