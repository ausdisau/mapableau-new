import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Star, CheckCircle, AlertCircle } from "lucide-react";

function StarRating({ value, onChange, label }) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="transition-transform hover:scale-110"
          >
            <Star
              className={`w-8 h-8 ${
                star <= value
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-300"
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );
}

export default function ProviderRatingForm({ booking, onSuccess }) {
  const queryClient = useQueryClient();
  const [submitted, setSubmitted] = useState(false);
  const [ratings, setRatings] = useState({
    overall_rating: 0,
    punctuality_rating: 0,
    professionalism_rating: 0,
    comment: ""
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.TransportReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["providerBookings"] });
      queryClient.invalidateQueries({ queryKey: ["participantReviews"] });
      setSubmitted(true);
      if (onSuccess) onSuccess();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (ratings.overall_rating === 0) {
      alert("Please provide an overall rating");
      return;
    }

    createReviewMutation.mutate({
      booking_id: booking.id,
      reviewer_type: "provider",
      vehicle_id: booking.vehicle_id,
      driver_id: booking.driver_id,
      participant_email: booking.created_by,
      ...ratings
    });
  };

  if (submitted) {
    return (
      <Alert className="bg-green-50 border-green-200">
        <CheckCircle className="w-4 h-4 text-green-600" />
        <AlertDescription>
          <span className="font-semibold text-green-900">Review submitted successfully!</span>
          <p className="text-sm text-green-800 mt-1">
            Thank you for providing feedback on this trip.
          </p>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rate Participant</CardTitle>
        <p className="text-sm text-gray-600">
          {booking.passenger_name}
        </p>
      </CardHeader>
      <CardContent>
        <Alert className="mb-6">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription className="text-sm">
            Participant ratings help maintain service quality. Please be fair and professional.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Overall Rating */}
          <StarRating
            value={ratings.overall_rating}
            onChange={(value) => setRatings({ ...ratings, overall_rating: value })}
            label="Overall Experience *"
          />

          {/* Detailed Ratings */}
          <div className="grid sm:grid-cols-2 gap-6">
            <StarRating
              value={ratings.punctuality_rating}
              onChange={(value) => setRatings({ ...ratings, punctuality_rating: value })}
              label="Punctuality (Ready on Time)"
            />
            <StarRating
              value={ratings.professionalism_rating}
              onChange={(value) => setRatings({ ...ratings, professionalism_rating: value })}
              label="Courtesy & Respect"
            />
          </div>

          {/* Written Feedback */}
          <div className="space-y-2">
            <Label>Additional Comments (Optional)</Label>
            <Textarea
              value={ratings.comment}
              onChange={(e) => setRatings({ ...ratings, comment: e.target.value })}
              placeholder="Any feedback about this trip..."
              rows={3}
            />
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="submit"
              disabled={ratings.overall_rating === 0 || createReviewMutation.isPending}
              className="bg-secondary hover:bg-secondary/90"
            >
              {createReviewMutation.isPending ? "Submitting..." : "Submit Rating"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}