import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import AIAssistantWidget from "./AIAssistantWidget";

export default function AIFloatingButton() {
  const [showAssistant, setShowAssistant] = useState(false);

  return (
    <>
      {!showAssistant && (
        <Button
          onClick={() => setShowAssistant(true)}
          className="fixed bottom-4 right-4 h-14 w-14 rounded-full shadow-2xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 z-40"
          size="icon"
        >
          <Sparkles className="w-6 h-6" />
        </Button>
      )}

      {showAssistant && (
        <AIAssistantWidget onClose={() => setShowAssistant(false)} />
      )}
    </>
  );
}