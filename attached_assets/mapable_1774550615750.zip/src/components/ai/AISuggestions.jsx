import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Lightbulb, Plus } from "lucide-react";
import { toast } from "sonner";

async function suggestCategoriesAndTags(content, type = "general") {
  try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze this ${type} content and suggest the most appropriate primary category, 3-5 relevant tags, and explain why:\n\n${content}`,
      response_json_schema: {
        type: "object",
        properties: {
          primary_category: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
          explanation: { type: "string" }
        }
      }
    });

    return { success: true, content: result };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export default function AISuggestions({ content, type, onApplySuggestion }) {
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState(null);

  const getSuggestions = async () => {
    if (!content) return;
    
    setLoading(true);
    
    try {
      const result = await suggestCategoriesAndTags(content, type);
      
      if (result.success && result.content) {
        setSuggestions(result.content);
      }
    } catch (error) {
      console.error("Failed to get suggestions:", error);
    }
    
    setLoading(false);
  };

  const handleApplyTag = (tag) => {
    if (onApplySuggestion) {
      onApplySuggestion({ type: "tag", value: tag });
      toast.success(`Tag "${tag}" applied`);
    }
  };

  const handleApplyCategory = (category) => {
    if (onApplySuggestion) {
      onApplySuggestion({ type: "category", value: category });
      toast.success(`Category "${category}" applied`);
    }
  };

  return (
    <div className="space-y-3">
      {!suggestions && (
        <Button
          onClick={getSuggestions}
          disabled={loading || !content}
          variant="outline"
          size="sm"
          className="gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Getting suggestions...
            </>
          ) : (
            <>
              <Lightbulb className="w-4 h-4" />
              Get AI Suggestions
            </>
          )}
        </Button>
      )}

      {suggestions && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-4 space-y-3">
            <div>
              <p className="text-sm font-semibold text-blue-900 mb-2">
                Suggested Category:
              </p>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleApplyCategory(suggestions.primary_category)}
                className="gap-2"
              >
                <Plus className="w-3 h-3" />
                {suggestions.primary_category}
              </Button>
            </div>

            {suggestions.tags && suggestions.tags.length > 0 && (
              <div>
                <p className="text-sm font-semibold text-blue-900 mb-2">
                  Suggested Tags:
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestions.tags.map((tag, idx) => (
                    <Button
                      key={idx}
                      size="sm"
                      variant="outline"
                      onClick={() => handleApplyTag(tag)}
                      className="gap-2 h-7 text-xs"
                    >
                      <Plus className="w-3 h-3" />
                      {tag}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {suggestions.explanation && (
              <p className="text-xs text-gray-600 italic">
                {suggestions.explanation}
              </p>
            )}

            <Button
              size="sm"
              variant="ghost"
              onClick={getSuggestions}
              className="w-full"
            >
              Refresh Suggestions
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}