import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Sparkles, Copy, CheckCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";

export default function AIContentGenerator({ 
  isOpen, 
  onClose, 
  onApply,
  contentType = "general",
  context = {},
  title = "AI Content Generator"
}) {
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState("");
  const [additionalInstructions, setAdditionalInstructions] = useState("");
  const [tone, setTone] = useState("professional");

  const handleGenerate = async () => {
    setGenerating(true);
    
    try {
      // Import the specific generator based on content type
      const { default: aiAssistant } = await import("@/utils/aiAssistant");
      
      let result;
      switch (contentType) {
        case "job_description":
          result = await aiAssistant.generateJobDescription(context);
          break;
        case "location_notes":
          result = await aiAssistant.generateAccessibilityNotes(context);
          break;
        case "provider_bio":
          result = await aiAssistant.generateProviderBio(context);
          break;
        case "message_reply":
          result = await aiAssistant.generateMessageReply(context.thread || [], tone);
          break;
        case "ticket_response":
          result = await aiAssistant.generateTicketResponse(context);
          break;
        default:
          result = await aiAssistant.generateContent(additionalInstructions, context);
      }

      if (result.success) {
        // Handle both string and object responses
        if (typeof result.content === 'string') {
          setGeneratedContent(result.content);
        } else if (result.content.description) {
          setGeneratedContent(result.content.description);
        } else if (result.content.improved_text) {
          setGeneratedContent(result.content.improved_text);
        } else {
          setGeneratedContent(JSON.stringify(result.content, null, 2));
        }
      } else {
        toast.error("Failed to generate content");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
    
    setGenerating(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedContent);
    toast.success("Copied to clipboard!");
  };

  const handleApply = () => {
    onApply(generatedContent);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Alert className="bg-purple-50 border-purple-200">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <AlertDescription className="text-purple-900 text-sm">
              AI will generate content based on your input. You can refine and edit the result before applying it.
            </AlertDescription>
          </Alert>

          {/* Tone Selection */}
          {(contentType === "message_reply" || contentType === "ticket_response") && (
            <div className="space-y-2">
              <Label>Tone</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="empathetic">Empathetic</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Additional Instructions */}
          <div className="space-y-2">
            <Label>Additional Instructions (optional)</Label>
            <Textarea
              placeholder="Add any specific requirements or guidelines..."
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              rows={3}
            />
          </div>

          {/* Generate Button */}
          {!generatedContent && (
            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate Content
                </>
              )}
            </Button>
          )}

          {/* Generated Content */}
          {generatedContent && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Generated Content</Label>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopy}
                    className="gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleGenerate}
                    disabled={generating}
                    className="gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Regenerate
                  </Button>
                </div>
              </div>
              
              <Textarea
                value={generatedContent}
                onChange={(e) => setGeneratedContent(e.target.value)}
                rows={12}
                className="font-mono text-sm"
              />

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleApply}
                  className="bg-green-600 hover:bg-green-700 gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Apply Content
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}