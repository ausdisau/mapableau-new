import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, FileText, Copy } from "lucide-react";
import { toast } from "sonner";

async function summarizeText(text, length = "short") {
  try {
    const lengthMap = {
      short: "1-2 sentences",
      medium: "1 paragraph",
      long: "2-3 paragraphs"
    };

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Summarize the following text in ${lengthMap[length]}:\n\n${text}`,
      response_json_schema: {
        type: "object",
        properties: {
          summary: { type: "string" }
        }
      }
    });

    return { success: true, content: result.summary };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export default function AISummarizer({ text, onSummary }) {
  const [summarizing, setSummarizing] = useState(false);
  const [summary, setSummary] = useState("");
  const [length, setLength] = useState("short");

  const handleSummarize = async () => {
    setSummarizing(true);
    
    try {
      const result = await summarizeText(text, length);
      
      if (result.success) {
        setSummary(result.content);
        if (onSummary) onSummary(result.content);
      } else {
        toast.error("Failed to generate summary");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
    
    setSummarizing(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(summary);
    toast.success("Summary copied!");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <Select value={length} onValueChange={setLength}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="short">Short</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="long">Long</SelectItem>
          </SelectContent>
        </Select>

        <Button
          onClick={handleSummarize}
          disabled={summarizing || !text}
          variant="outline"
          className="gap-2"
        >
          {summarizing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Summarizing...
            </>
          ) : (
            <>
              <FileText className="w-4 h-4" />
              AI Summarize
            </>
          )}
        </Button>
      </div>

      {summary && (
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="pt-4">
            <div className="flex items-start justify-between gap-3 mb-2">
              <p className="text-sm font-semibold text-purple-900">AI Summary:</p>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCopy}
                className="h-6"
              >
                <Copy className="w-3 h-3" />
              </Button>
            </div>
            <p className="text-sm text-gray-700">{summary}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}