import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import NotificationService from "./NotificationService";

/**
 * Component that monitors entities and triggers notifications based on changes
 * Place this at the root of your app to enable automatic notifications
 */
export default function NotificationTriggers() {
  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  // Monitor provider credentials for verification status changes
  const { data: providerCredentials = [] } = useQuery({
    queryKey: ["providerCredentials", currentUser?.email],
    queryFn: async () => {
      if (!currentUser || currentUser.user_type !== "service_provider") return [];
      return await base44.entities.ProviderCredential.filter(
        { created_by: currentUser.email },
        "-updated_date",
        10
      );
    },
    enabled: !!currentUser && currentUser.user_type === "service_provider",
    refetchInterval: 60000, // Check every minute
  });

  // Monitor transport bookings for status changes
  const { data: myBookings = [] } = useQuery({
    queryKey: ["myBookings", currentUser?.email],
    queryFn: async () => {
      if (!currentUser) return [];
      return await base44.entities.TransportBooking.filter(
        { created_by: currentUser.email },
        "-updated_date",
        20
      );
    },
    enabled: !!currentUser,
    refetchInterval: 30000, // Check every 30 seconds
  });

  // Monitor service requests
  const { data: myServiceRequests = [] } = useQuery({
    queryKey: ["myServiceRequests", currentUser?.email],
    queryFn: async () => {
      if (!currentUser) return [];
      return await base44.entities.ServiceRequest.filter(
        { created_by: currentUser.email },
        "-updated_date",
        20
      );
    },
    enabled: !!currentUser,
    refetchInterval: 60000,
  });

  // Handle credential verification notifications
  useEffect(() => {
    if (!currentUser || !providerCredentials.length) return;

    providerCredentials.forEach(async (credential) => {
      const statusKey = `credential_${credential.id}_status`;
      const lastStatus = sessionStorage.getItem(statusKey);

      if (lastStatus && lastStatus !== credential.verification_status) {
        // Status changed - send notification and email
        let title = "";
        let message = "";
        let priority = "medium";

        switch (credential.verification_status) {
          case "verified":
            title = "Credential Verified ✓";
            message = `Your ${credential.credential_type} credential has been verified!`;
            priority = "high";
            
            // Send email notification
            await base44.integrations.Core.SendEmail({
              to: currentUser.email,
              subject: "Credential Verified - MapAble",
              body: `Great news! Your ${credential.credential_type} credential has been verified. You can now provide services on MapAble.`,
            });
            break;

          case "rejected":
            title = "Credential Rejected";
            message = `Your ${credential.credential_type} credential was rejected. ${credential.rejection_reason || "Please review and resubmit."}`;
            priority = "urgent";
            
            // Send email notification
            await base44.integrations.Core.SendEmail({
              to: currentUser.email,
              subject: "Credential Verification Failed - MapAble",
              body: `Your ${credential.credential_type} credential verification was unsuccessful. Reason: ${credential.rejection_reason || "Please contact support for details."}`,
            });
            break;

          case "under_review":
            title = "Credential Under Review";
            message = `Your ${credential.credential_type} credential is now being reviewed.`;
            break;
        }

        if (title) {
          await NotificationService.createNotification({
            user_email: currentUser.email,
            title,
            message,
            type: "system",
            priority,
            related_entity_type: "ProviderCredential",
            related_entity_id: credential.id,
          });
        }
      }

      sessionStorage.setItem(statusKey, credential.verification_status);
    });
  }, [providerCredentials, currentUser]);

  // Handle booking notifications (reminder 1 hour before pickup)
  useEffect(() => {
    if (!currentUser || !myBookings.length) return;

    const now = new Date();
    const oneHourFromNow = new Date(now.getTime() + 60 * 60 * 1000);

    myBookings.forEach(async (booking) => {
      if (!booking.pickup_datetime) return;

      const pickupTime = new Date(booking.pickup_datetime);
      const reminderKey = `booking_${booking.id}_1hr_reminder`;
      const reminderSent = sessionStorage.getItem(reminderKey);

      // Send reminder if pickup is within 1 hour and reminder hasn't been sent
      if (
        !reminderSent &&
        pickupTime > now &&
        pickupTime <= oneHourFromNow &&
        ["confirmed", "driver_assigned"].includes(booking.status)
      ) {
        await NotificationService.createNotification({
          user_email: currentUser.email,
          title: "Upcoming Ride Reminder",
          message: `Your ride is scheduled in 1 hour. Please be ready at your pickup location.`,
          type: "trip_starting",
          priority: "high",
          related_entity_type: "TransportBooking",
          related_entity_id: booking.id,
        });

        // Send email reminder
        await base44.integrations.Core.SendEmail({
          to: currentUser.email,
          subject: "Upcoming Ride Reminder - MapAble",
          body: `Your transport is scheduled to pick you up in 1 hour at ${booking.pickup_location?.address || "your location"}. Please be ready!`,
        });

        sessionStorage.setItem(reminderKey, "sent");
      }
    });
  }, [myBookings, currentUser]);

  // Handle service request status changes
  useEffect(() => {
    if (!currentUser || !myServiceRequests.length) return;

    myServiceRequests.forEach(async (request) => {
      const statusKey = `service_${request.id}_status`;
      const lastStatus = sessionStorage.getItem(statusKey);

      if (lastStatus && lastStatus !== request.status) {
        let title = "";
        let message = "";
        let priority = "medium";

        switch (request.status) {
          case "confirmed":
            title = "Service Request Confirmed";
            message = `Your service request has been confirmed for ${request.date}.`;
            priority = "high";
            
            await base44.integrations.Core.SendEmail({
              to: currentUser.email,
              subject: "Service Request Confirmed - MapAble",
              body: `Your service request for ${request.service_type} has been confirmed for ${request.date}.`,
            });
            break;

          case "completed":
            title = "Service Completed";
            message = "Your service has been completed. Please rate your experience!";
            break;

          case "cancelled":
            title = "Service Cancelled";
            message = "Your service request has been cancelled.";
            priority = "high";
            
            await base44.integrations.Core.SendEmail({
              to: currentUser.email,
              subject: "Service Cancelled - MapAble",
              body: "Your service request has been cancelled. If you have any questions, please contact support.",
            });
            break;
        }

        if (title) {
          await NotificationService.createNotification({
            user_email: currentUser.email,
            title,
            message,
            type: "system",
            priority,
            related_entity_type: "ServiceRequest",
            related_entity_id: request.id,
          });
        }
      }

      sessionStorage.setItem(statusKey, request.status);
    });
  }, [myServiceRequests, currentUser]);

  // This component doesn't render anything
  return null;
}