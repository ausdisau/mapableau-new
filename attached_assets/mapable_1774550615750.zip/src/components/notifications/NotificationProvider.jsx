import React, { createContext, useContext, useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const NotificationContext = createContext({
  notifications: [],
  unreadCount: 0,
  urgentCount: 0,
  refreshNotifications: () => {},
  isLoading: false,
});

export function useNotifications() {
  return useContext(NotificationContext);
}

export default function NotificationProvider({ children }) {
  const queryClient = useQueryClient();
  const [lastCheckTime, setLastCheckTime] = useState(Date.now());

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["userNotifications", currentUser?.email],
    queryFn: async () => {
      if (!currentUser) return [];
      const allNotifications = await base44.entities.Notification.filter(
        { user_email: currentUser.email },
        "-created_date",
        100
      );
      
      // Clean up expired notifications
      const now = new Date();
      const validNotifications = allNotifications.filter(n => {
        if (!n.expires_at) return true;
        return new Date(n.expires_at) > now;
      });
      
      return validNotifications;
    },
    enabled: !!currentUser,
    refetchInterval: 15000, // Refresh every 15 seconds
    staleTime: 10000, // Consider data stale after 10 seconds
  });

  // Calculate counts
  const unreadNotifications = notifications.filter(n => !n.read);
  const urgentNotifications = unreadNotifications.filter(n => n.priority === "urgent");
  
  const unreadCount = unreadNotifications.length;
  const urgentCount = urgentNotifications.length;

  // Show browser notification for new urgent notifications
  useEffect(() => {
    if (!notifications.length) return;
    
    const newUrgentNotifications = urgentNotifications.filter(n => {
      const notificationTime = new Date(n.created_date).getTime();
      return notificationTime > lastCheckTime;
    });

    if (newUrgentNotifications.length > 0 && 'Notification' in window && Notification.permission === 'granted') {
      newUrgentNotifications.forEach(notification => {
        new Notification(notification.title, {
          body: notification.message,
          icon: '/mapable-icon.png',
          badge: '/mapable-badge.png',
          tag: notification.type,
        });
      });
    }

    setLastCheckTime(Date.now());
  }, [urgentNotifications.length]);

  const refreshNotifications = () => {
    queryClient.invalidateQueries({ queryKey: ["userNotifications"] });
  };

  const value = {
    notifications,
    unreadCount,
    urgentCount,
    refreshNotifications,
    isLoading,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}