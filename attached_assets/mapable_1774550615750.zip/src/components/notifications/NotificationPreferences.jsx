import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Bell, Mail, MessageSquare, CheckCircle } from "lucide-react";

export default function NotificationPreferences() {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: preferences, isLoading } = useQuery({
    queryKey: ["notificationPreferences"],
    queryFn: async () => {
      const user = await base44.auth.me();
      const prefs = await base44.entities.NotificationPreference.filter({ user_email: user.email });
      if (prefs.length === 0) {
        // Create default preferences
        return await base44.entities.NotificationPreference.create({
          user_email: user.email,
          booking_confirmed: true,
          booking_cancelled: true,
          driver_assigned: true,
          driver_en_route: true,
          trip_starting: true,
          trip_completed: true,
          payment_processed: true,
          schedule_published: true,
          conflict_detected: true,
          review_request: true,
          email_notifications: false,
          sms_notifications: false
        });
      }
      return prefs[0];
    },
    enabled: !!currentUser,
  });

  const [localPreferences, setLocalPreferences] = useState(preferences || {});

  React.useEffect(() => {
    if (preferences) {
      setLocalPreferences(preferences);
    }
  }, [preferences]);

  const updatePreferencesMutation = useMutation({
    mutationFn: (data) => base44.entities.NotificationPreference.update(preferences.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notificationPreferences"] });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const handleToggle = (key) => {
    setLocalPreferences(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    await updatePreferencesMutation.mutateAsync(localPreferences);
    setSaving(false);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-secondary mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  const notificationTypes = [
    {
      category: "Booking Notifications",
      items: [
        { key: "booking_confirmed", label: "Booking Confirmed", description: "When your booking is confirmed" },
        { key: "booking_cancelled", label: "Booking Cancelled", description: "When a booking is cancelled" },
        { key: "driver_assigned", label: "Driver Assigned", description: "When a driver is assigned to your trip" },
        { key: "driver_en_route", label: "Driver En Route", description: "When your driver is on the way" },
        { key: "trip_starting", label: "Trip Starting Soon", description: "15 minutes before your trip" },
        { key: "trip_completed", label: "Trip Completed", description: "When your trip is completed" }
      ]
    },
    {
      category: "Payment & Reviews",
      items: [
        { key: "payment_processed", label: "Payment Processed", description: "When payment is completed" },
        { key: "review_request", label: "Review Requests", description: "When asked to leave a review" }
      ]
    },
    {
      category: "Provider Notifications",
      items: [
        { key: "schedule_published", label: "Schedule Published", description: "When your schedule is ready (drivers)" },
        { key: "conflict_detected", label: "Conflicts Detected", description: "When scheduling conflicts occur (providers)" }
      ]
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notification Preferences
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {saved && (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <AlertDescription className="text-green-800">
              Preferences saved successfully!
            </AlertDescription>
          </Alert>
        )}

        {/* In-App Notifications */}
        {notificationTypes.map((category, idx) => (
          <div key={idx}>
            <h3 className="font-semibold text-sm mb-4">{category.category}</h3>
            <div className="space-y-4">
              {category.items.map((item) => (
                <div key={item.key} className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label htmlFor={item.key} className="font-medium">
                      {item.label}
                    </Label>
                    <p className="text-sm text-gray-600">{item.description}</p>
                  </div>
                  <Switch
                    id={item.key}
                    checked={localPreferences[item.key] !== false}
                    onCheckedChange={() => handleToggle(item.key)}
                  />
                </div>
              ))}
            </div>
            {idx < notificationTypes.length - 1 && <Separator className="mt-6" />}
          </div>
        ))}

        <Separator />

        {/* Delivery Methods */}
        <div>
          <h3 className="font-semibold text-sm mb-4">Delivery Methods</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <div className="flex-1">
                  <Label htmlFor="email_notifications" className="font-medium">
                    Email Notifications
                  </Label>
                  <p className="text-sm text-gray-600">Receive notifications via email</p>
                </div>
              </div>
              <Switch
                id="email_notifications"
                checked={localPreferences.email_notifications || false}
                onCheckedChange={() => handleToggle("email_notifications")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-gray-400" />
                <div className="flex-1">
                  <Label htmlFor="sms_notifications" className="font-medium">
                    SMS Notifications
                  </Label>
                  <p className="text-sm text-gray-600">Receive notifications via text message</p>
                </div>
              </div>
              <Switch
                id="sms_notifications"
                checked={localPreferences.sms_notifications || false}
                onCheckedChange={() => handleToggle("sms_notifications")}
              />
            </div>
          </div>
        </div>

        <Button
          onClick={handleSave}
          disabled={saving}
          className="w-full"
        >
          {saving ? "Saving..." : "Save Preferences"}
        </Button>
      </CardContent>
    </Card>
  );
}