import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  Bell, 
  BellOff, 
  CheckCircle, 
  AlertTriangle,
  Smartphone,
  Info
} from "lucide-react";
import { toast } from "sonner";

// Push Notification Service (inline implementation)
class PushNotificationService {
  constructor() {
    this.serviceWorkerRegistration = null;
    this.subscription = null;
  }

  isSupported() {
    return 'serviceWorker' in navigator && 
           'PushManager' in window && 
           'Notification' in window;
  }

  getPermissionStatus() {
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission;
  }

  async registerServiceWorker() {
    if (!this.isSupported()) {
      throw new Error('Push notifications not supported in this browser');
    }

    try {
      const registration = await navigator.serviceWorker.register('/service-worker.js', {
        scope: '/'
      });
      
      this.serviceWorkerRegistration = registration;
      await navigator.serviceWorker.ready;

      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data.type === 'NOTIFICATION_CLICK' && event.data.url) {
          if (window.location.pathname !== event.data.url) {
            window.location.href = event.data.url;
          }
        }
      });

      return registration;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
      throw error;
    }
  }

  async requestPermission() {
    if (!this.isSupported()) {
      throw new Error('Push notifications not supported');
    }
    return await Notification.requestPermission();
  }

  urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  async subscribe(vapidPublicKey) {
    if (!this.serviceWorkerRegistration) {
      await this.registerServiceWorker();
    }

    const permission = await this.requestPermission();
    if (permission !== 'granted') {
      throw new Error('Notification permission not granted');
    }

    try {
      const subscribeOptions = vapidPublicKey ? {
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(vapidPublicKey)
      } : {
        userVisibleOnly: true
      };

      this.subscription = await this.serviceWorkerRegistration.pushManager.subscribe(
        subscribeOptions
      );

      return this.subscription;
    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
      throw error;
    }
  }

  async getSubscription() {
    if (!this.serviceWorkerRegistration) {
      await this.registerServiceWorker();
    }

    try {
      const subscription = await this.serviceWorkerRegistration.pushManager.getSubscription();
      this.subscription = subscription;
      return subscription;
    } catch (error) {
      console.error('Error getting subscription:', error);
      return null;
    }
  }

  async unsubscribe() {
    const subscription = await this.getSubscription();
    if (subscription) {
      try {
        await subscription.unsubscribe();
        this.subscription = null;
        return true;
      } catch (error) {
        console.error('Error unsubscribing:', error);
        throw error;
      }
    }
    return false;
  }

  async showLocalNotification(title, options = {}) {
    if (!this.serviceWorkerRegistration) {
      await this.registerServiceWorker();
    }

    const permission = this.getPermissionStatus();
    if (permission !== 'granted') {
      throw new Error('Notification permission not granted');
    }

    const notificationOptions = {
      body: options.body || 'Notification body',
      icon: options.icon || '/mapable-icon.png',
      badge: options.badge || '/mapable-badge.png',
      tag: options.tag || 'mapable-notification',
      data: options.data || {},
      requireInteraction: options.requireInteraction || false,
      vibrate: options.vibrate || [100, 50, 100],
      actions: options.actions || []
    };

    return this.serviceWorkerRegistration.showNotification(title, notificationOptions);
  }

  async sendSubscriptionToBackend(subscription, userEmail) {
    localStorage.setItem('push_subscription', JSON.stringify({
      subscription: subscription.toJSON(),
      userEmail,
      subscribedAt: new Date().toISOString()
    }));
    return true;
  }

  async initialize(userEmail) {
    try {
      if (!this.isSupported()) {
        return { success: false, reason: 'unsupported' };
      }

      await this.registerServiceWorker();
      const existingSubscription = await this.getSubscription();
      
      if (existingSubscription) {
        return { success: true, subscription: existingSubscription };
      }

      const permission = this.getPermissionStatus();
      if (permission === 'denied') {
        return { success: false, reason: 'denied' };
      }

      return { success: true, needsPermission: permission === 'default' };
    } catch (error) {
      console.error('Error initializing push notifications:', error);
      return { success: false, error: error.message };
    }
  }
}

const pushNotificationService = new PushNotificationService();

export default function PushNotificationSetup() {
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState('default');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  useEffect(() => {
    checkPushStatus();
  }, []);

  const checkPushStatus = async () => {
    const supported = pushNotificationService.isSupported();
    setIsSupported(supported);

    if (supported) {
      const perm = pushNotificationService.getPermissionStatus();
      setPermission(perm);

      const subscription = await pushNotificationService.getSubscription();
      setIsSubscribed(!!subscription);
    }
  };

  const handleEnablePush = async () => {
    setIsLoading(true);
    try {
      const perm = await pushNotificationService.requestPermission();
      setPermission(perm);

      if (perm !== 'granted') {
        toast.error('Notification permission denied');
        setIsLoading(false);
        return;
      }

      const subscription = await pushNotificationService.subscribe();
      
      if (currentUser?.email) {
        await pushNotificationService.sendSubscriptionToBackend(
          subscription,
          currentUser.email
        );
      }

      setIsSubscribed(true);
      toast.success('Push notifications enabled!', {
        description: "You'll receive alerts even when the app is closed"
      });

      setTimeout(() => {
        pushNotificationService.showLocalNotification(
          'Welcome to MapAble Notifications!',
          {
            body: 'You will now receive real-time updates about your bookings, drivers, and schedules.',
            icon: '/mapable-icon.png',
            requireInteraction: false
          }
        );
      }, 1000);

    } catch (error) {
      console.error('Error enabling push notifications:', error);
      toast.error('Failed to enable push notifications', {
        description: error.message
      });
    }
    setIsLoading(false);
  };

  const handleDisablePush = async () => {
    setIsLoading(true);
    try {
      await pushNotificationService.unsubscribe();
      setIsSubscribed(false);
      toast.success('Push notifications disabled');
    } catch (error) {
      console.error('Error disabling push notifications:', error);
      toast.error('Failed to disable push notifications');
    }
    setIsLoading(false);
  };

  const handleTestNotification = async () => {
    try {
      await pushNotificationService.showLocalNotification(
        'Test Notification',
        {
          body: 'This is how you\'ll receive alerts when you\'re not using the app.',
          icon: '/mapable-icon.png',
          badge: '/mapable-badge.png',
          tag: 'test-notification',
          requireInteraction: false,
          data: {
            action_url: '/dashboard'
          }
        }
      );
      toast.success('Test notification sent!');
    } catch (error) {
      toast.error('Failed to send test notification');
    }
  };

  if (!isSupported) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Push Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTriangle className="w-4 h-4" />
            <AlertDescription>
              Push notifications are not supported on this device or browser. 
              Try using Chrome, Firefox, or Safari on a supported device.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-secondary" />
            <CardTitle>Push Notifications</CardTitle>
          </div>
          {isSubscribed && (
            <Badge className="bg-green-100 text-green-700">
              <CheckCircle className="w-3 h-3 mr-1" />
              Active
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <Info className="w-4 h-4" />
          <AlertDescription className="text-sm">
            Receive instant alerts about bookings, driver assignments, and schedule updates 
            even when the app is closed. Your device will vibrate and display notifications.
          </AlertDescription>
        </Alert>

        {permission === 'denied' && (
          <Alert className="bg-red-50 border-red-200">
            <BellOff className="w-4 h-4 text-red-600" />
            <AlertDescription>
              <span className="font-semibold text-red-900">Notifications Blocked</span>
              <p className="text-sm text-red-700 mt-1">
                You've blocked notifications. To enable them, please allow notifications 
                for this site in your browser settings.
              </p>
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Bell className="w-4 h-4 text-primary" />
                <Label className="font-semibold">Enable Push Notifications</Label>
              </div>
              <p className="text-sm text-gray-600">
                Get real-time alerts on your device
              </p>
            </div>
            <Switch
              checked={isSubscribed}
              onCheckedChange={(checked) => {
                if (checked) {
                  handleEnablePush();
                } else {
                  handleDisablePush();
                }
              }}
              disabled={isLoading || permission === 'denied'}
            />
          </div>

          {isSubscribed && (
            <div className="space-y-3 pt-2">
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-green-900">Active</p>
                    <p className="text-xs text-green-700 mt-1">
                      You're all set to receive push notifications on this device
                    </p>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                onClick={handleTestNotification}
                className="w-full gap-2"
              >
                <Bell className="w-4 h-4" />
                Send Test Notification
              </Button>
            </div>
          )}

          {!isSubscribed && permission === 'default' && (
            <Button
              onClick={handleEnablePush}
              disabled={isLoading}
              className="w-full bg-secondary hover:bg-secondary/90 gap-2"
            >
              <Bell className="w-4 h-4" />
              {isLoading ? 'Setting up...' : 'Enable Push Notifications'}
            </Button>
          )}
        </div>

        <div className="pt-4 border-t">
          <h4 className="font-semibold text-sm mb-3">What you'll receive:</h4>
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
              <span>Booking confirmations and cancellations</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
              <span>Driver assignments and arrival alerts</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
              <span>Schedule updates and conflict warnings</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
              <span>Trip reminders and completion notices</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}