import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { addMinutes } from "date-fns";

// Service for creating notifications
export const NotificationService = {
  // Check if user has notifications enabled for this type
  async shouldNotify(userEmail, notificationType) {
    try {
      const prefs = await base44.entities.NotificationPreference.filter({ user_email: userEmail });
      if (prefs.length === 0) return true;
      return prefs[0][notificationType] !== false;
    } catch {
      return true;
    }
  },

  // Check if email notifications are enabled
  async shouldSendEmail(userEmail) {
    try {
      const user = await base44.entities.User.filter({ email: userEmail });
      if (user.length === 0) return false;
      return user[0].email_notifications_enabled !== false;
    } catch {
      return false;
    }
  },

  // Check if push notifications are supported
  isPushSupported() {
    return typeof window !== 'undefined' &&
           'serviceWorker' in navigator && 
           'PushManager' in window && 
           'Notification' in window;
  },

  // Get service worker registration
  async getServiceWorkerRegistration() {
    if (!this.isPushSupported()) return null;
    
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      return registration;
    } catch (error) {
      console.error('Error getting service worker registration:', error);
      return null;
    }
  },

  // Send push notification
  async sendPushNotification(notification) {
    try {
      const registration = await this.getServiceWorkerRegistration();
      if (!registration) return;

      const permission = Notification.permission;
      if (permission !== 'granted') return;

      await registration.showNotification(notification.title, {
        body: notification.message,
        icon: '/mapable-icon.png',
        badge: '/mapable-badge.png',
        tag: notification.type,
        data: {
          notificationId: notification.id,
          action_url: notification.action_url,
          ...notification.metadata
        },
        requireInteraction: notification.priority === 'urgent',
        vibrate: notification.priority === 'urgent' ? [200, 100, 200, 100, 200] : [100, 50, 100]
      });
    } catch (error) {
      console.error('Error sending push notification:', error);
    }
  },

  // Send email notification
  async sendEmailNotification(userEmail, subject, body) {
    try {
      const shouldSend = await this.shouldSendEmail(userEmail);
      if (!shouldSend) return;

      await base44.integrations.Core.SendEmail({
        to: userEmail,
        subject: `MapAble - ${subject}`,
        body: body,
      });
    } catch (error) {
      console.error('Error sending email notification:', error);
    }
  },

  // Create notification and optionally send push/email
  async createNotification(data) {
    try {
      const shouldSend = await this.shouldNotify(data.user_email, data.type);
      if (!shouldSend) return null;

      const notification = await base44.entities.Notification.create({
        ...data,
        expires_at: data.expires_at || addMinutes(new Date(), 60 * 24 * 7).toISOString()
      });

      // Send push notification if supported
      if (this.isPushSupported()) {
        try {
          await this.sendPushNotification(notification);
        } catch (pushError) {
          console.error('Failed to send push notification:', pushError);
        }
      }

      return notification;
    } catch (error) {
      console.error("Failed to create notification:", error);
      return null;
    }
  },

  // New message received
  async notifyNewMessage(message, recipientEmail) {
    await this.createNotification({
      user_email: recipientEmail,
      title: "New Message",
      message: `You have a new message from ${message.sender_name || 'a user'}`,
      type: "message",
      priority: "medium",
      action_url: createPageUrl("Messages"),
      related_entity_type: "Message",
      related_entity_id: message.id,
      metadata: {
        message_id: message.id,
        sender_name: message.sender_name
      }
    });

    // Send email
    await this.sendEmailNotification(
      recipientEmail,
      "New Message",
      `You have received a new message from ${message.sender_name || 'a user'}.\n\nMessage: ${message.content?.substring(0, 200)}${message.content?.length > 200 ? '...' : ''}\n\nReply in the MapAble app.`
    );
  },

  // Account update notification
  async notifyAccountUpdate(userEmail, updateType, details) {
    await this.createNotification({
      user_email: userEmail,
      title: "Account Updated",
      message: `Your account ${updateType} has been updated.`,
      type: "system",
      priority: "medium",
      action_url: createPageUrl("AccountSettings"),
      metadata: {
        update_type: updateType,
        details: details
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Account Update",
      `Your ${updateType} has been successfully updated.\n\nDetails: ${details}\n\nIf you didn't make this change, please contact support immediately.`
    );
  },

  // Password/Security change
  async notifySecurityChange(userEmail, changeType) {
    await this.createNotification({
      user_email: userEmail,
      title: "Security Update",
      message: `Your ${changeType} has been changed.`,
      type: "system",
      priority: "high",
      action_url: createPageUrl("AccountSettings") + "?tab=security",
      metadata: {
        change_type: changeType
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Security Alert",
      `Your ${changeType} has been changed.\n\nIf you didn't make this change, please secure your account immediately by resetting your password and enabling two-factor authentication.`
    );
  },

  // Two-factor authentication enabled
  async notify2FAEnabled(userEmail, method) {
    await this.createNotification({
      user_email: userEmail,
      title: "2FA Enabled",
      message: `Two-factor authentication via ${method} has been enabled for your account.`,
      type: "system",
      priority: "high",
      action_url: createPageUrl("AccountSettings") + "?tab=security",
      metadata: {
        method: method
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Two-Factor Authentication Enabled",
      `Two-factor authentication via ${method} has been successfully enabled for your account.\n\nYour account is now more secure. You'll need to provide a verification code when logging in from new devices.\n\nIf you didn't enable this, please contact support immediately.`
    );
  },

  // Booking confirmed
  async notifyBookingConfirmed(booking, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Booking Confirmed",
      message: `Your transport booking for ${new Date(booking.pickup_datetime).toLocaleDateString()} has been confirmed.`,
      type: "booking_confirmed",
      priority: "high",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        pickup_time: booking.pickup_datetime
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Booking Confirmed",
      `Your transport booking has been confirmed for ${new Date(booking.pickup_datetime).toLocaleDateString()} at ${new Date(booking.pickup_datetime).toLocaleTimeString()}.\n\nPickup: ${booking.pickup_location?.address}\nDrop-off: ${booking.dropoff_location?.address}\n\nYou'll receive further updates as your booking approaches.`
    );
  },

  // Booking cancelled
  async notifyBookingCancelled(booking, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Booking Cancelled",
      message: `Your transport booking for ${new Date(booking.pickup_datetime).toLocaleDateString()} has been cancelled.`,
      type: "booking_cancelled",
      priority: "high",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        pickup_time: booking.pickup_datetime
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Booking Cancelled",
      `Your transport booking for ${new Date(booking.pickup_datetime).toLocaleDateString()} has been cancelled.`
    );
  },

  // Driver assigned
  async notifyDriverAssigned(booking, driver, vehicle, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Driver Assigned",
      message: `${driver.full_name} has been assigned to your trip in ${vehicle.vehicle_name}.`,
      type: "driver_assigned",
      priority: "high",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        driver_name: driver.full_name,
        vehicle_name: vehicle.vehicle_name,
        pickup_time: booking.pickup_datetime
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Driver Assigned",
      `${driver.full_name} has been assigned to your trip.\n\nVehicle: ${vehicle.vehicle_name}\nPickup: ${new Date(booking.pickup_datetime).toLocaleString()}\n\nDriver Contact: ${driver.phone || "Available in app"}`
    );
  },

  // Driver en route
  async notifyDriverEnRoute(booking, driver, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Driver On The Way",
      message: `${driver.full_name} is heading to your pickup location.`,
      type: "driver_en_route",
      priority: "urgent",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        driver_name: driver.full_name
      }
    });

    // Send email
    await this.sendEmailNotification(
      userEmail,
      "Driver On The Way",
      `${driver.full_name} is heading to your pickup location now. Please be ready!`
    );
  },

  // Trip starting soon
  async notifyTripStarting(booking, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Trip Starting Soon",
      message: `Your trip is scheduled to start in 15 minutes. Please be ready at your pickup location.`,
      type: "trip_starting",
      priority: "urgent",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        pickup_time: booking.pickup_datetime
      }
    });
  },

  // Trip completed
  async notifyTripCompleted(booking, userEmail) {
    await this.createNotification({
      user_email: userEmail,
      title: "Trip Completed",
      message: "Your trip has been completed. Please rate your experience!",
      type: "trip_completed",
      priority: "medium",
      action_url: createPageUrl("MyTransportBookings"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id
      }
    });
  },

  // Schedule published (for drivers)
  async notifySchedulePublished(schedule, driver) {
    await this.createNotification({
      user_email: driver.email,
      title: "New Schedule Published",
      message: `Your schedule for ${new Date(schedule.schedule_date).toLocaleDateString()} is now available. Shift: ${schedule.shift_start_time} - ${schedule.shift_end_time}`,
      type: "schedule_published",
      priority: "high",
      action_url: createPageUrl("ScheduleManagement"),
      related_entity_type: "DailySchedule",
      related_entity_id: schedule.id,
      metadata: {
        schedule_date: schedule.schedule_date
      }
    });

    // Send email
    await this.sendEmailNotification(
      driver.email,
      "New Schedule Published",
      `Your schedule for ${new Date(schedule.schedule_date).toLocaleDateString()} is now available.\n\nShift: ${schedule.shift_start_time} - ${schedule.shift_end_time}\nBookings: ${schedule.assigned_bookings?.length || 0}`
    );
  },

  // Conflict detected (for providers)
  async notifyConflictDetected(schedule, providerEmail) {
    await this.createNotification({
      user_email: providerEmail,
      title: "Schedule Conflict Detected",
      message: `${schedule.conflicts.length} conflict(s) detected in schedule for ${new Date(schedule.schedule_date).toLocaleDateString()}. Review required.`,
      type: "conflict_detected",
      priority: "urgent",
      action_url: createPageUrl("ScheduleManagement"),
      related_entity_type: "DailySchedule",
      related_entity_id: schedule.id,
      metadata: {
        schedule_date: schedule.schedule_date
      }
    });

    // Send email
    await this.sendEmailNotification(
      providerEmail,
      "Schedule Conflict Detected",
      `Schedule conflicts detected for ${new Date(schedule.schedule_date).toLocaleDateString()}. Please review and resolve these conflicts in the Schedule Management dashboard.`
    );
  },

  // New booking for provider
  async notifyNewBooking(booking, providerEmail) {
    await this.createNotification({
      user_email: providerEmail,
      title: "New Booking Received",
      message: `New transport booking for ${new Date(booking.pickup_datetime).toLocaleDateString()} from ${booking.passenger_name}.`,
      type: "booking_confirmed",
      priority: "high",
      action_url: createPageUrl("ProviderTransportDashboard"),
      related_entity_type: "TransportBooking",
      related_entity_id: booking.id,
      metadata: {
        booking_id: booking.id,
        pickup_time: booking.pickup_datetime
      }
    });

    // Send email
    await this.sendEmailNotification(
      providerEmail,
      "New Booking Received",
      `You have received a new transport booking.\n\nPassenger: ${booking.passenger_name}\nPickup: ${new Date(booking.pickup_datetime).toLocaleString()}\nLocation: ${booking.pickup_location?.address}`
    );
  }
};

export default NotificationService;