import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNotifications } from "./NotificationProvider";
import { toast } from "sonner";

/**
 * Component that handles real-time notification updates and displays toasts
 * Place this component at the root of your app to enable real-time notifications
 */
export default function RealTimeNotifications() {
  const { notifications, unreadCount } = useNotifications();
  const queryClient = useQueryClient();

  // Track the last notification count to detect new notifications
  useEffect(() => {
    const lastCount = parseInt(sessionStorage.getItem("lastNotificationCount") || "0");
    const lastNotificationId = sessionStorage.getItem("lastNotificationId") || "";

    if (notifications.length > 0) {
      const latestNotification = notifications[0];

      // Check if we have a new notification
      if (latestNotification.id !== lastNotificationId && !latestNotification.read) {
        // Show toast for new notification
        const toastConfig = {
          description: latestNotification.message,
          duration: 5000,
        };

        switch (latestNotification.priority) {
          case "urgent":
            toast.error(latestNotification.title, toastConfig);
            break;
          case "high":
            toast.warning(latestNotification.title, toastConfig);
            break;
          default:
            toast.info(latestNotification.title, toastConfig);
        }

        // Update last seen notification
        sessionStorage.setItem("lastNotificationId", latestNotification.id);
      }

      // Update count
      sessionStorage.setItem("lastNotificationCount", notifications.length.toString());
    }
  }, [notifications]);

  // Periodic refresh to ensure we don't miss notifications
  useEffect(() => {
    const interval = setInterval(() => {
      queryClient.invalidateQueries({ queryKey: ["userNotifications"] });
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [queryClient]);

  // Update page title with unread count
  useEffect(() => {
    const baseTitle = "MapAble";
    if (unreadCount > 0) {
      document.title = `(${unreadCount}) ${baseTitle}`;
    } else {
      document.title = baseTitle;
    }

    return () => {
      document.title = baseTitle;
    };
  }, [unreadCount]);

  // This component doesn't render anything
  return null;
}