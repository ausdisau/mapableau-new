import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bell,
  CheckCircle,
  AlertCircle,
  Clock,
  Car,
  Users,
  DollarSign,
  Calendar,
  MessageSquare,
  Settings as SettingsIcon,
  Trash2,
  Check,
  X,
  Loader2
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const NOTIFICATION_ICONS = {
  booking_confirmed: Calendar,
  booking_cancelled: X,
  driver_assigned: Car,
  driver_en_route: Car,
  trip_starting: Clock,
  trip_completed: CheckCircle,
  payment_processed: DollarSign,
  schedule_published: Calendar,
  conflict_detected: AlertCircle,
  review_request: MessageSquare,
  message: MessageSquare,
  system: Bell,
};

const PRIORITY_COLORS = {
  low: "bg-gray-100 border-gray-200",
  medium: "bg-blue-50 border-blue-200",
  high: "bg-yellow-50 border-yellow-200",
  urgent: "bg-red-50 border-red-200",
};

export default function InAppNotificationCenter({ onClose }) {
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState("all");

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["userNotifications", currentUser?.email],
    queryFn: async () => {
      if (!currentUser) return [];
      return await base44.entities.Notification.filter(
        { user_email: currentUser.email },
        "-created_date"
      );
    },
    enabled: !!currentUser,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId) =>
      base44.entities.Notification.update(notificationId, { read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userNotifications"] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.read);
      await Promise.all(
        unreadNotifications.map(n =>
          base44.entities.Notification.update(n.id, { read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userNotifications"] });
    },
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: (notificationId) =>
      base44.entities.Notification.delete(notificationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userNotifications"] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.read) {
      markAsReadMutation.mutate(notification.id);
    }
    if (notification.action_url && onClose) {
      onClose();
    }
  };

  // Filter notifications
  const unreadNotifications = notifications.filter(n => !n.read);
  const urgentNotifications = notifications.filter(n => n.priority === "urgent" && !n.read);
  
  const filteredNotifications = {
    all: notifications,
    unread: unreadNotifications,
    urgent: urgentNotifications,
  }[selectedTab] || notifications;

  const NotificationItem = ({ notification }) => {
    const Icon = NOTIFICATION_ICONS[notification.type] || Bell;
    const isUnread = !notification.read;
    const priorityColor = PRIORITY_COLORS[notification.priority] || PRIORITY_COLORS.medium;

    return (
      <div
        className={cn(
          "group relative p-4 border-b hover:bg-gray-50 transition-colors",
          isUnread && "bg-blue-50/50",
          priorityColor
        )}
      >
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
            notification.priority === "urgent" ? "bg-red-100" : "bg-blue-100"
          )}>
            <Icon className={cn(
              "w-5 h-5",
              notification.priority === "urgent" ? "text-red-600" : "text-blue-600"
            )} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h4 className={cn(
                "text-sm font-semibold",
                isUnread && "text-blue-900"
              )}>
                {notification.title}
              </h4>
              {isUnread && (
                <div className="w-2 h-2 rounded-full bg-blue-600 flex-shrink-0 mt-1" />
              )}
            </div>

            <p className="text-sm text-gray-700 mb-2 line-clamp-2">
              {notification.message}
            </p>

            <div className="flex items-center gap-3 text-xs text-gray-500">
              <span>
                {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
              </span>
              {notification.priority === "urgent" && (
                <Badge variant="destructive" className="text-xs">Urgent</Badge>
              )}
            </div>

            {/* Action URL */}
            {notification.action_url && (
              <Link
                to={notification.action_url}
                onClick={() => handleNotificationClick(notification)}
                className="mt-2 inline-block text-sm font-medium text-blue-600 hover:text-blue-700"
              >
                View Details →
              </Link>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            {!notification.read && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => markAsReadMutation.mutate(notification.id)}
                title="Mark as read"
              >
                <Check className="w-4 h-4" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-red-600 hover:text-red-700"
              onClick={() => deleteNotificationMutation.mutate(notification.id)}
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full max-h-[600px]">
      {/* Header */}
      <div className="p-4 border-b bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-white" />
            <h2 className="text-lg font-bold text-white">Notifications</h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Quick Actions */}
        {unreadNotifications.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => markAllAsReadMutation.mutate()}
            disabled={markAllAsReadMutation.isPending}
            className="text-white hover:bg-white/20 text-xs"
          >
            {markAllAsReadMutation.isPending ? (
              <>
                <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                Marking all...
              </>
            ) : (
              <>
                <CheckCircle className="w-3 h-3 mr-1" />
                Mark all as read
              </>
            )}
          </Button>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-3 rounded-none">
          <TabsTrigger value="all" className="gap-2">
            All
            {notifications.length > 0 && (
              <Badge variant="secondary" className="text-xs">{notifications.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="unread" className="gap-2">
            Unread
            {unreadNotifications.length > 0 && (
              <Badge variant="default" className="text-xs bg-blue-600">
                {unreadNotifications.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="urgent" className="gap-2">
            Urgent
            {urgentNotifications.length > 0 && (
              <Badge variant="destructive" className="text-xs">
                {urgentNotifications.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="flex-1 m-0 overflow-hidden">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
            </div>
          ) : filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                <Bell className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No notifications
              </h3>
              <p className="text-sm text-gray-600">
                {selectedTab === "unread" 
                  ? "You're all caught up!" 
                  : selectedTab === "urgent"
                  ? "No urgent notifications"
                  : "You'll see notifications here when you receive them"}
              </p>
            </div>
          ) : (
            <ScrollArea className="h-full">
              <div className="divide-y">
                {filteredNotifications.map((notification) => (
                  <NotificationItem key={notification.id} notification={notification} />
                ))}
              </div>
            </ScrollArea>
          )}
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <div className="p-3 border-t bg-gray-50">
        <Link to="/account-settings?tab=notifications" onClick={onClose}>
          <Button variant="outline" size="sm" className="w-full gap-2">
            <SettingsIcon className="w-4 h-4" />
            Notification Settings
          </Button>
        </Link>
      </div>
    </div>
  );
}