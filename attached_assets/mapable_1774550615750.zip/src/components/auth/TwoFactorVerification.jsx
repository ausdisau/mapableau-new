import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Shield,
  Smartphone,
  MessageSquare,
  Key,
  AlertTriangle,
  Clock,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";

// Utility functions
function isAccountLocked(twoFactorAuth) {
  if (!twoFactorAuth?.locked_until) return false;
  return new Date(twoFactorAuth.locked_until) > new Date();
}

function getLockTimeRemaining(twoFactorAuth) {
  if (!isAccountLocked(twoFactorAuth)) return 0;
  const remaining = new Date(twoFactorAuth.locked_until) - new Date();
  return Math.ceil(remaining / 60000);
}

function generateDeviceFingerprint() {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.textBaseline = 'top';
  ctx.font = '14px Arial';
  ctx.fillText('fingerprint', 2, 2);
  
  const fingerprint = canvas.toDataURL();
  const hash = fingerprint.split('').reduce((acc, char) => {
    return ((acc << 5) - acc) + char.charCodeAt(0);
  }, 0);
  
  return `${navigator.userAgent}_${hash}_${screen.width}x${screen.height}`;
}

function getDeviceName() {
  const ua = navigator.userAgent;
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Mac/.test(ua)) return 'Mac';
  if (/iPhone/.test(ua)) return 'iPhone';
  if (/iPad/.test(ua)) return 'iPad';
  if (/Android/.test(ua)) return 'Android Device';
  if (/Linux/.test(ua)) return 'Linux PC';
  return 'Unknown Device';
}

function maskPhoneNumber(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length < 4) return phone;
  return `***-***-${cleaned.slice(-4)}`;
}

export default function TwoFactorVerification({ 
  userEmail, 
  twoFactorAuth, 
  onVerified, 
  onCancel 
}) {
  const [code, setCode] = useState("");
  const [useBackupCode, setUseBackupCode] = useState(false);
  const [trustDevice, setTrustDevice] = useState(false);
  const [resendCountdown, setResendCountdown] = useState(0);
  const [generatedCode, setGeneratedCode] = useState("");

  useEffect(() => {
    if (resendCountdown > 0) {
      const timer = setTimeout(() => setResendCountdown(resendCountdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCountdown]);

  const sendSMSCodeMutation = useMutation({
    mutationFn: async () => {
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedCode(code);
      
      await base44.integrations.Core.SendEmail({
        to: userEmail,
        subject: "MapAble 2FA Verification Code",
        body: `Your verification code is: ${code}\n\nThis code will expire in 10 minutes.`
      });
      
      setResendCountdown(60);
      return code;
    },
    onSuccess: () => {
      toast.success("Verification code sent!");
    },
  });

  const verifyCodeMutation = useMutation({
    mutationFn: async ({ code, isBackupCode }) => {
      if (isAccountLocked(twoFactorAuth)) {
        const minutes = getLockTimeRemaining(twoFactorAuth);
        throw new Error(`Account locked. Try again in ${minutes} minutes.`);
      }

      let verified = false;

      if (isBackupCode) {
        const validCode = twoFactorAuth.backup_codes?.find(
          c => c.code === code && !c.used
        );
        
        if (validated) {
          verified = true;
          const updatedCodes = twoFactorAuth.backup_codes.map(c =>
            c.code === code ? { ...c, used: true, used_date: new Date().toISOString() } : c
          );
          
          await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, {
            backup_codes: updatedCodes,
            last_verified: new Date().toISOString(),
            failed_attempts: 0,
          });
        }
      } else {
        if (twoFactorAuth.method === "sms" && code === generatedCode) {
          verified = true;
        } else if (twoFactorAuth.method === "totp" && /^\d{6}$/.test(code)) {
          verified = true;
        }

        if (verified) {
          const updates = {
            last_verified: new Date().toISOString(),
            failed_attempts: 0,
          };

          if (trustDevice) {
            const deviceId = generateDeviceFingerprint();
            const deviceName = getDeviceName();
            const trustedDevices = twoFactorAuth.trusted_devices || [];
            
            updates.trusted_devices = [
              ...trustedDevices,
              {
                device_id: deviceId,
                device_name: deviceName,
                last_used: new Date().toISOString(),
                ip_address: 'unknown',
              }
            ];
          }

          await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, updates);
        } else {
          const newFailedAttempts = (twoFactorAuth.failed_attempts || 0) + 1;
          const updates = { failed_attempts: newFailedAttempts };

          if (newFailedAttempts >= 5) {
            const lockUntil = new Date();
            lockUntil.setMinutes(lockUntil.getMinutes() + 30);
            updates.locked_until = lockUntil.toISOString();
          }

          await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, updates);
          
          if (newFailedAttempts >= 5) {
            throw new Error("Too many failed attempts. Account locked for 30 minutes.");
          }
          
          throw new Error("Invalid verification code");
        }
      }

      return verified;
    },
    onSuccess: () => {
      toast.success("Verification successful!");
      if (onVerified) onVerified();
    },
    onError: (error) => {
      toast.error(error.message || "Verification failed");
    },
  });

  const handleVerify = () => {
    if (!code || code.length < 6) {
      toast.error("Please enter a valid code");
      return;
    }

    verifyCodeMutation.mutate({
      code,
      isBackupCode: useBackupCode,
    });
  };

  const handleResend = () => {
    if (twoFactorAuth.method === "sms") {
      sendSMSCodeMutation.mutate();
    }
  };

  useEffect(() => {
    if (twoFactorAuth.method === "sms" && !generatedCode) {
      sendSMSCodeMutation.mutate();
    }
  }, []);

  const isLocked = isAccountLocked(twoFactorAuth);
  const lockTimeRemaining = getLockTimeRemaining(twoFactorAuth);

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          <CardTitle className="text-center text-2xl">
            Two-Factor Authentication
          </CardTitle>
          <p className="text-center text-gray-600 mt-2">
            {useBackupCode
              ? "Enter your backup recovery code"
              : twoFactorAuth.method === "totp"
              ? "Enter the code from your authenticator app"
              : `Enter the code sent to ${maskPhoneNumber(twoFactorAuth.sms_phone)}`}
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLocked ? (
            <Alert className="bg-red-50 border-red-200 border-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <AlertDescription className="text-red-900">
                <p className="font-semibold mb-1">Account Temporarily Locked</p>
                <p className="text-sm">
                  Too many failed attempts. Try again in {lockTimeRemaining} minutes.
                </p>
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <div className="flex justify-center">
                {useBackupCode ? (
                  <Key className="w-12 h-12 text-gray-600" />
                ) : twoFactorAuth.method === "totp" ? (
                  <Smartphone className="w-12 h-12 text-blue-600" />
                ) : (
                  <MessageSquare className="w-12 h-12 text-purple-600" />
                )}
              </div>

              <div className="space-y-2">
                <Input
                  type="text"
                  placeholder={useBackupCode ? "XXXX-XXXX" : "000000"}
                  maxLength={useBackupCode ? 9 : 6}
                  value={code}
                  onChange={(e) => {
                    const value = e.target.value.replace(/[^0-9-]/g, '');
                    setCode(value);
                  }}
                  className="text-center text-2xl tracking-widest font-mono"
                  autoFocus
                />
              </div>

              {!useBackupCode && (
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="trust-device"
                    checked={trustDevice}
                    onCheckedChange={setTrustDevice}
                  />
                  <label htmlFor="trust-device" className="text-sm text-gray-700 cursor-pointer">
                    Trust this device for 30 days
                  </label>
                </div>
              )}

              <Button
                onClick={handleVerify}
                disabled={verifyCodeMutation.isPending || code.length < 6}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {verifyCodeMutation.isPending ? "Verifying..." : "Verify"}
              </Button>

              {twoFactorAuth.method === "sms" && !useBackupCode && (
                <Button
                  variant="outline"
                  onClick={handleResend}
                  disabled={resendCountdown > 0 || sendSMSCodeMutation.isPending}
                  className="w-full gap-2"
                >
                  {resendCountdown > 0 ? (
                    <>
                      <Clock className="w-4 h-4" />
                      Resend in {resendCountdown}s
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4" />
                      Resend Code
                    </>
                  )}
                </Button>
              )}

              <Button
                variant="ghost"
                onClick={() => {
                  setUseBackupCode(!useBackupCode);
                  setCode("");
                }}
                className="w-full"
              >
                {useBackupCode ? "Use verification code instead" : "Use backup recovery code"}
              </Button>

              {twoFactorAuth.failed_attempts > 0 && (
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-900 text-sm">
                    {twoFactorAuth.failed_attempts} failed attempt(s). 
                    Account will be locked after 5 failed attempts.
                  </AlertDescription>
                </Alert>
              )}
            </>
          )}

          {onCancel && (
            <Button
              variant="ghost"
              onClick={onCancel}
              className="w-full"
            >
              Cancel
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}