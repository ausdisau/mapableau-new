import React from "react";
import { Button } from "@/components/ui/button";

export default function SocialLoginButtons() {
  const handleGoogleLogin = () => {
    // Get config from localStorage (in production, fetch from backend)
    const config = JSON.parse(localStorage.getItem('oauth_config') || '{}');
    
    if (config.provider === 'google' && config.enabled) {
      const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
        `client_id=${encodeURIComponent(config.clientId)}` +
        `&redirect_uri=${encodeURIComponent(config.redirectUri)}` +
        `&response_type=code` +
        `&scope=${encodeURIComponent('openid email profile')}` +
        `&access_type=offline` +
        `&prompt=consent`;
      
      window.location.href = googleAuthUrl;
    }
  };

  const handleFacebookLogin = () => {
    const config = JSON.parse(localStorage.getItem('oauth_config') || '{}');
    
    if (config.provider === 'facebook' && config.enabled) {
      const facebookAuthUrl = `https://www.facebook.com/v18.0/dialog/oauth?` +
        `client_id=${encodeURIComponent(config.appId)}` +
        `&redirect_uri=${encodeURIComponent(config.redirectUri)}` +
        `&scope=${encodeURIComponent('email,public_profile')}` +
        `&response_type=code`;
      
      window.location.href = facebookAuthUrl;
    }
  };

  const handleMicrosoftLogin = () => {
    const config = JSON.parse(localStorage.getItem('oauth_config') || '{}');
    
    if (config.provider === 'microsoft' && config.enabled) {
      const tenantId = config.tenantId || 'common';
      const microsoftAuthUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize?` +
        `client_id=${encodeURIComponent(config.clientId)}` +
        `&redirect_uri=${encodeURIComponent(config.redirectUri)}` +
        `&response_type=code` +
        `&scope=${encodeURIComponent('openid email profile User.Read')}` +
        `&response_mode=query`;
      
      window.location.href = microsoftAuthUrl;
    }
  };

  // Check which providers are enabled
  const oauthConfig = JSON.parse(localStorage.getItem('oauth_config') || '{}');
  const googleEnabled = oauthConfig.provider === 'google' && oauthConfig.enabled;
  const facebookEnabled = oauthConfig.provider === 'facebook' && oauthConfig.enabled;
  const microsoftEnabled = oauthConfig.provider === 'microsoft' && oauthConfig.enabled;

  // Don't render if no providers are enabled
  if (!googleEnabled && !facebookEnabled && !microsoftEnabled) {
    return null;
  }

  return (
    <div className="space-y-3">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-white px-2 text-gray-500">Or continue with</span>
        </div>
      </div>

      <div className="grid gap-3">
        {googleEnabled && (
          <Button
            variant="outline"
            onClick={handleGoogleLogin}
            className="w-full gap-2 h-11"
          >
            <img 
              src="https://www.google.com/favicon.ico" 
              alt="Google" 
              className="w-5 h-5" 
            />
            Continue with Google
          </Button>
        )}

        {facebookEnabled && (
          <Button
            variant="outline"
            onClick={handleFacebookLogin}
            className="w-full gap-2 h-11"
          >
            <img 
              src="https://www.facebook.com/favicon.ico" 
              alt="Facebook" 
              className="w-5 h-5" 
            />
            Continue with Facebook
          </Button>
        )}

        {microsoftEnabled && (
          <Button
            variant="outline"
            onClick={handleMicrosoftLogin}
            className="w-full gap-2 h-11"
          >
            <img 
              src="https://www.microsoft.com/favicon.ico" 
              alt="Microsoft" 
              className="w-5 h-5" 
            />
            Continue with Microsoft
          </Button>
        )}
      </div>
    </div>
  );
}