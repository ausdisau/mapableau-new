import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Shield,
  CheckCircle,
  XCircle,
  Smartphone,
  MessageSquare,
  Key,
  Trash2,
  Plus,
  Download,
  AlertTriangle,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import TwoFactorSetup from "./TwoFactorSetup";

// Utility functions
function downloadBackupCodes(codes, userEmail) {
  const codeList = Array.isArray(codes) 
    ? codes.map(c => typeof c === 'string' ? c : c.code).join('\n')
    : codes;
    
  const content = `MapAble 2FA Recovery Codes
Account: ${userEmail}
Generated: ${new Date().toLocaleString()}

${codeList}`;

  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `recovery-codes-${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function maskPhoneNumber(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length < 4) return phone;
  return `***-***-${cleaned.slice(-4)}`;
}

function generateBackupCodes(count = 10) {
  const codes = [];
  for (let i = 0; i < count; i++) {
    const code = Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
    codes.push({ code, used: false, used_date: null });
  }
  return codes;
}

export default function TwoFactorSettings({ userEmail }) {
  const queryClient = useQueryClient();
  const [showSetup, setShowSetup] = useState(false);
  const [showDisableConfirm, setShowDisableConfirm] = useState(false);
  const [showRegenerateCodes, setShowRegenerateCodes] = useState(false);

  const { data: twoFactorAuth, isLoading } = useQuery({
    queryKey: ["twoFactorAuth", userEmail],
    queryFn: async () => {
      const results = await base44.entities.TwoFactorAuth.filter({ user_email: userEmail });
      return results[0] || null;
    },
  });

  const disable2FAMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, {
        enabled: false,
        totp_enabled: false,
        sms_enabled: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["twoFactorAuth"] });
      setShowDisableConfirm(false);
      toast.success("Two-factor authentication disabled");
    },
  });

  const regenerateCodesMutation = useMutation({
    mutationFn: async () => {
      const newCodes = generateBackupCodes();
      
      await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, {
        backup_codes: newCodes,
      });
      
      return newCodes;
    },
    onSuccess: (newCodes) => {
      queryClient.invalidateQueries({ queryKey: ["twoFactorAuth"] });
      downloadBackupCodes(newCodes, userEmail);
      setShowRegenerateCodes(false);
      toast.success("New recovery codes generated and downloaded");
    },
  });

  const removeTrustedDeviceMutation = useMutation({
    mutationFn: async (deviceId) => {
      const updatedDevices = twoFactorAuth.trusted_devices.filter(
        d => d.device_id !== deviceId
      );
      
      await base44.entities.TwoFactorAuth.update(twoFactorAuth.id, {
        trusted_devices: updatedDevices,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["twoFactorAuth"] });
      toast.success("Device removed");
    },
  });

  const usedCodesCount = twoFactorAuth?.backup_codes?.filter(c => c.used).length || 0;
  const totalCodesCount = twoFactorAuth?.backup_codes?.length || 0;
  const remainingCodes = totalCodesCount - usedCodesCount;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-blue-600" />
              <CardTitle>Two-Factor Authentication</CardTitle>
            </div>
            {twoFactorAuth?.enabled ? (
              <Badge className="bg-green-100 text-green-700 gap-1">
                <CheckCircle className="w-3 h-3" />
                Enabled
              </Badge>
            ) : (
              <Badge className="bg-gray-100 text-gray-700 gap-1">
                <XCircle className="w-3 h-3" />
                Disabled
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {!twoFactorAuth?.enabled ? (
            <>
              <p className="text-gray-600">
                Add an extra layer of security to your account by requiring a verification code in addition to your password.
              </p>
              <Button
                onClick={() => setShowSetup(true)}
                className="bg-blue-600 hover:bg-blue-700 gap-2"
              >
                <Plus className="w-4 h-4" />
                Enable Two-Factor Authentication
              </Button>
            </>
          ) : (
            <>
              <p className="text-gray-600">
                Your account is protected with two-factor authentication.
              </p>

              <div className="grid md:grid-cols-2 gap-4">
                {twoFactorAuth.totp_enabled && (
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Smartphone className="w-5 h-5 text-blue-600" />
                      <span className="font-semibold">Authenticator App</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Active and verified
                    </p>
                  </div>
                )}

                {twoFactorAuth.sms_enabled && (
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageSquare className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold">SMS</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      {maskPhoneNumber(twoFactorAuth.sms_phone)}
                    </p>
                  </div>
                )}
              </div>

              {twoFactorAuth.last_verified && (
                <p className="text-sm text-gray-600">
                  Last verified: {format(new Date(twoFactorAuth.last_verified), "PPpp")}
                </p>
              )}

              <Button
                variant="destructive"
                onClick={() => setShowDisableConfirm(true)}
                className="gap-2"
              >
                <XCircle className="w-4 h-4" />
                Disable 2FA
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {twoFactorAuth?.enabled && (
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Key className="w-6 h-6 text-yellow-600" />
              <CardTitle>Recovery Codes</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">
              Recovery codes can be used to access your account if you lose your device.
            </p>

            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold">Available Codes</span>
                <Badge variant="outline">
                  {remainingCodes} of {totalCodesCount} remaining
                </Badge>
              </div>
              {remainingCodes < 3 && (
                <Alert className="mt-2">
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription className="text-sm">
                    You're running low on recovery codes. Generate new ones to ensure account access.
                  </AlertDescription>
                </Alert>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  if (twoFactorAuth.backup_codes) {
                    downloadBackupCodes(twoFactorAuth.backup_codes, userEmail);
                    toast.success("Recovery codes downloaded");
                  }
                }}
                className="flex-1 gap-2"
              >
                <Download className="w-4 h-4" />
                Download Codes
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowRegenerateCodes(true)}
                className="flex-1 gap-2"
              >
                <Plus className="w-4 h-4" />
                Generate New Codes
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {twoFactorAuth?.enabled && twoFactorAuth.trusted_devices?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Trusted Devices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {twoFactorAuth.trusted_devices.map((device, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{device.device_name}</p>
                    <p className="text-sm text-gray-600">
                      Last used: {format(new Date(device.last_used), "PPp")}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => removeTrustedDeviceMutation.mutate(device.device_id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={showSetup} onOpenChange={setShowSetup}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Enable Two-Factor Authentication</DialogTitle>
          </DialogHeader>
          <TwoFactorSetup
            userEmail={userEmail}
            onComplete={() => setShowSetup(false)}
            onCancel={() => setShowSetup(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showDisableConfirm} onOpenChange={setShowDisableConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Disable Two-Factor Authentication?</DialogTitle>
          </DialogHeader>
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-900">
              Disabling 2FA will make your account less secure. You'll only need your password to log in.
            </AlertDescription>
          </Alert>
          <div className="flex justify-end gap-3 mt-4">
            <Button variant="outline" onClick={() => setShowDisableConfirm(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => disable2FAMutation.mutate()}
              disabled={disable2FAMutation.isPending}
            >
              {disable2FAMutation.isPending ? "Disabling..." : "Yes, Disable 2FA"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showRegenerateCodes} onOpenChange={setShowRegenerateCodes}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Generate New Recovery Codes?</DialogTitle>
          </DialogHeader>
          <Alert className="bg-yellow-50 border-yellow-200">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-yellow-900">
              This will invalidate all existing recovery codes. Make sure to save the new codes securely.
            </AlertDescription>
          </Alert>
          <div className="flex justify-end gap-3 mt-4">
            <Button variant="outline" onClick={() => setShowRegenerateCodes(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => regenerateCodesMutation.mutate()}
              disabled={regenerateCodesMutation.isPending}
              className="bg-yellow-600 hover:bg-yellow-700"
            >
              {regenerateCodesMutation.isPending ? "Generating..." : "Generate New Codes"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}