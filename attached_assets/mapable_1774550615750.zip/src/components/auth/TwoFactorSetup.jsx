import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Sparkles, Copy, CheckCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";

// AI Generation Functions
async function generateContent(contentType, context, additionalInstructions, tone) {
  try {
    let prompt = "";
    
    switch (contentType) {
      case "job_description":
        prompt = `Generate a professional job description:
Title: ${context.title || "Not specified"}
Company: ${context.company || "Not specified"}
Include role overview, responsibilities, qualifications, and support available.`;
        break;
      case "location_notes":
        prompt = `Generate accessibility notes for a location with scores: Entrance: ${context.entrance_score}/10, Interior: ${context.interior_score}/10, Bathroom: ${context.bathroom_score}/10, Parking: ${context.parking_score}/10`;
        break;
      case "provider_bio":
        prompt = `Create a professional bio for: ${context.name}, Type: ${context.type}, Specialties: ${context.specialties?.join(", ")}, Experience: ${context.experience_years} years`;
        break;
      case "message_reply":
        prompt = `Generate a ${tone} reply to this message thread: ${JSON.stringify(context.thread || [])}`;
        break;
      case "ticket_response":
        prompt = `Generate a support response for: Subject: ${context.subject}, Issue: ${context.description}`;
        break;
      default:
        prompt = additionalInstructions || "Generate helpful content";
    }

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          content: { type: "string" }
        }
      }
    });

    return { success: true, content: result.content };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export default function AIContentGenerator({ 
  isOpen, 
  onClose, 
  onApply,
  contentType = "general",
  context = {},
  title = "AI Content Generator"
}) {
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState("");
  const [additionalInstructions, setAdditionalInstructions] = useState("");
  const [tone, setTone] = useState("professional");

  const handleGenerate = async () => {
    setGenerating(true);
    
    try {
      const result = await generateContent(contentType, context, additionalInstructions, tone);

      if (result.success) {
        setGeneratedContent(result.content);
      } else {
        toast.error("Failed to generate content");
      }
    } catch (error) {
      toast.error("An error occurred");
    }
    
    setGenerating(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedContent);
    toast.success("Copied to clipboard!");
  };

  const handleApply = () => {
    onApply(generatedContent);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Alert className="bg-purple-50 border-purple-200">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <AlertDescription className="text-purple-900 text-sm">
              AI will generate content based on your input. You can refine and edit the result before applying it.
            </AlertDescription>
          </Alert>

          {(contentType === "message_reply" || contentType === "ticket_response") && (
            <div className="space-y-2">
              <Label>Tone</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="empathetic">Empathetic</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label>Additional Instructions (optional)</Label>
            <Textarea
              placeholder="Add any specific requirements or guidelines..."
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              rows={3}
            />
          </div>

          {!generatedContent && (
            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full bg-purple-600 hover:bg-purple-700 gap-2"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate Content
                </>
              )}
            </Button>
          )}

          {generatedContent && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Generated Content</Label>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopy}
                    className="gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleGenerate}
                    disabled={generating}
                    className="gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Regenerate
                  </Button>
                </div>
              </div>
              
              <Textarea
                value={generatedContent}
                onChange={(e) => setGeneratedContent(e.target.value)}
                rows={12}
                className="font-mono text-sm"
              />

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={handleApply}
                  className="bg-green-600 hover:bg-green-700 gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Apply Content
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}