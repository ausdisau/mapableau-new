import React from "react";
import { Progress } from "@/components/ui/progress";
import { Sparkles, TrendingUp } from "lucide-react";

export default function MatchScore({ score, size = "md", showLabel = true, animated = true }) {
  const getScoreColor = (score) => {
    if (score >= 80) return {
      gradient: "from-green-400 to-emerald-600",
      bg: "bg-green-100",
      text: "text-green-700",
      label: "Excellent"
    };
    if (score >= 60) return {
      gradient: "from-blue-400 to-blue-600",
      bg: "bg-blue-100",
      text: "text-blue-700",
      label: "Good"
    };
    if (score >= 40) return {
      gradient: "from-yellow-400 to-orange-500",
      bg: "bg-yellow-100",
      text: "text-yellow-700",
      label: "Fair"
    };
    return {
      gradient: "from-gray-400 to-gray-600",
      bg: "bg-gray-100",
      text: "text-gray-700",
      label: "Limited"
    };
  };

  const sizes = {
    sm: { container: "w-14 h-14", text: "text-base", icon: "w-3 h-3" },
    md: { container: "w-20 h-20", text: "text-2xl", icon: "w-4 h-4" },
    lg: { container: "w-28 h-28", text: "text-3xl", icon: "w-5 h-5" }
  };

  const colors = getScoreColor(score);
  const sizeClasses = sizes[size];

  return (
    <div className="flex flex-col items-center">
      <div className="relative group">
        {/* Animated Background Pulse */}
        {animated && (
          <div className={`absolute inset-0 ${colors.bg} rounded-full animate-pulse opacity-50`}></div>
        )}
        
        {/* Main Circle */}
        <div className={`
          ${sizeClasses.container} 
          rounded-full 
          bg-gradient-to-br ${colors.gradient}
          flex items-center justify-center 
          relative
          shadow-lg
          transition-transform
          group-hover:scale-110
        `}>
          <div className={`
            ${sizeClasses.container} 
            rounded-full 
            bg-white 
            flex items-center justify-center
            m-1
          `}>
            <div className="text-center">
              <div className={`${sizeClasses.text} font-bold ${colors.text}`}>
                {score}
              </div>
              {size !== 'sm' && (
                <div className="text-xs text-gray-600">Match</div>
              )}
            </div>
          </div>
        </div>

        {/* Sparkle Icon */}
        {animated && (
          <Sparkles className={`
            ${sizeClasses.icon} 
            ${colors.text} 
            absolute -top-1 -right-1
            animate-pulse
          `} />
        )}
      </div>

      {/* Label */}
      {showLabel && (
        <div className="mt-2 flex items-center gap-1">
          <TrendingUp className={`w-3 h-3 ${colors.text}`} />
          <span className={`text-xs font-semibold ${colors.text}`}>
            {colors.label} Match
          </span>
        </div>
      )}
    </div>
  );
}