import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Filter, X } from "lucide-react";

export default function MatchFilters({ filters, onChange }) {
  const handleFilterChange = (key, value) => {
    onChange({ ...filters, [key]: value });
  };

  const handleServiceToggle = (service) => {
    const current = filters.preferred_services || [];
    const updated = current.includes(service)
      ? current.filter(s => s !== service)
      : [...current, service];
    handleFilterChange('preferred_services', updated);
  };

  const serviceTypes = [
    "personal_care",
    "community_access",
    "therapy",
    "employment_support",
    "transport",
    "household_support",
    "meal_preparation",
    "mobility_assistance"
  ];

  const states = ["NSW", "VIC", "QLD", "SA", "WA", "TAS", "NT", "ACT"];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Matching Preferences
          </CardTitle>
          {Object.keys(filters).length > 0 && (
            <button
              onClick={() => onChange({})}
              className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              Clear All
            </button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Location */}
        <div className="space-y-3">
          <Label>Location</Label>
          <div className="grid grid-cols-2 gap-3">
            <Input
              placeholder="Suburb"
              value={filters.location_suburb || ""}
              onChange={(e) => handleFilterChange('location_suburb', e.target.value)}
            />
            <Select
              value={filters.location_state || ""}
              onValueChange={(v) => handleFilterChange('location_state', v)}
            >
              <SelectTrigger>
                <SelectValue placeholder="State" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Any State</SelectItem>
                {states.map(state => (
                  <SelectItem key={state} value={state}>{state}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Service Types */}
        <div className="space-y-3">
          <Label>Services Needed</Label>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {serviceTypes.map(service => (
              <div key={service} className="flex items-center gap-2">
                <Checkbox
                  id={service}
                  checked={(filters.preferred_services || []).includes(service)}
                  onCheckedChange={() => handleServiceToggle(service)}
                />
                <label
                  htmlFor={service}
                  className="text-sm cursor-pointer"
                >
                  {service.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </label>
              </div>
            ))}
          </div>
          
          {filters.preferred_services && filters.preferred_services.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-2">
              {filters.preferred_services.map(service => (
                <Badge key={service} variant="secondary" className="gap-1">
                  {service.replace(/_/g, ' ')}
                  <button onClick={() => handleServiceToggle(service)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Minimum Match Score */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label>Minimum Match Score</Label>
            <span className="text-sm font-semibold text-gray-700">
              {filters.min_score || 40}%
            </span>
          </div>
          <Slider
            value={[filters.min_score || 40]}
            onValueChange={(v) => handleFilterChange('min_score', v[0])}
            min={0}
            max={100}
            step={5}
          />
          <p className="text-xs text-gray-600">
            Only show providers with at least this compatibility score
          </p>
        </div>

        {/* Experience Level */}
        <div className="space-y-3">
          <Label>Minimum Experience</Label>
          <Select
            value={filters.min_experience || ""}
            onValueChange={(v) => handleFilterChange('min_experience', v)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Any experience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Any experience</SelectItem>
              <SelectItem value="2">2+ years</SelectItem>
              <SelectItem value="5">5+ years</SelectItem>
              <SelectItem value="10">10+ years</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Additional Filters */}
        <div className="space-y-3">
          <Label>Additional Requirements</Label>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Checkbox
                id="ndis_only"
                checked={filters.ndis_registered_only || false}
                onCheckedChange={(checked) => handleFilterChange('ndis_registered_only', checked)}
              />
              <label htmlFor="ndis_only" className="text-sm cursor-pointer">
                NDIS Registered only
              </label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="mobile_service"
                checked={filters.mobile_service || false}
                onCheckedChange={(checked) => handleFilterChange('mobile_service', checked)}
              />
              <label htmlFor="mobile_service" className="text-sm cursor-pointer">
                Provides mobile/home visits
              </label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="high_rated"
                checked={filters.high_rated_only || false}
                onCheckedChange={(checked) => handleFilterChange('high_rated_only', checked)}
              />
              <label htmlFor="high_rated" className="text-sm cursor-pointer">
                4+ star rating only
              </label>
            </div>
          </div>
        </div>

        {/* Languages */}
        <div className="space-y-3">
          <Label>Languages</Label>
          <Input
            placeholder="e.g., English, Mandarin, Arabic"
            value={filters.languages?.join(', ') || ""}
            onChange={(e) => handleFilterChange('languages', e.target.value.split(',').map(l => l.trim()))}
          />
          <p className="text-xs text-gray-600">
            Separate multiple languages with commas
          </p>
        </div>
      </CardContent>
    </Card>
  );
}