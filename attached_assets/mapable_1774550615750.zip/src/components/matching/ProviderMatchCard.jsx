import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Star,
  MapPin,
  Phone,
  Mail,
  CheckCircle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Calendar,
  Award,
  Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProviderMatchCard({ match, onContact, onViewProfile }) {
  const { provider, match_score, compatibility_factors, concerns, recommendation } = match;
  const [expanded, setExpanded] = useState(false);

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-blue-600";
    if (score >= 40) return "text-yellow-600";
    return "text-gray-600";
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return "Excellent Match";
    if (score >= 60) return "Good Match";
    if (score >= 40) return "Moderate Match";
    return "Limited Match";
  };

  return (
    <Card className="hover-lift">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <CardTitle className="text-xl">{provider.name}</CardTitle>
              {provider.verified && (
                <CheckCircle className="w-5 h-5 text-blue-600" title="Verified Provider" />
              )}
              {provider.ndis_registered && (
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  NDIS Registered
                </Badge>
              )}
            </div>
            
            <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600">
              <span className="flex items-center gap-1">
                <Award className="w-4 h-4" />
                {provider.type?.replace(/_/g, ' ')}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {provider.location_suburb}, {provider.location_state}
              </span>
              {provider.rating && (
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  {provider.rating.toFixed(1)} ({provider.review_count || 0} reviews)
                </span>
              )}
            </div>
          </div>

          {/* Match Score Badge */}
          <div className="text-center ml-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center">
                <div className="text-center">
                  <div className={`text-2xl font-bold ${getScoreColor(match_score)}`}>
                    {match_score}
                  </div>
                  <div className="text-xs text-gray-600">Match</div>
                </div>
              </div>
              <Sparkles className="w-4 h-4 text-purple-600 absolute -top-1 -right-1" />
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Match Quality Indicator */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-gray-700">
              {getScoreLabel(match_score)}
            </span>
            <span className="text-xs text-gray-500">{match_score}% compatible</span>
          </div>
          <Progress value={match_score} className="h-2" />
        </div>

        {/* AI Recommendation */}
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-900">
            <strong className="flex items-center gap-1 mb-1">
              <Sparkles className="w-4 h-4" />
              AI Insight:
            </strong>
            {recommendation}
          </p>
        </div>

        {/* Specialties */}
        {provider.specialties && provider.specialties.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-gray-700 mb-2">Specialties:</p>
            <div className="flex flex-wrap gap-2">
              {provider.specialties.slice(0, expanded ? undefined : 3).map((specialty, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {specialty.replace(/_/g, ' ')}
                </Badge>
              ))}
              {!expanded && provider.specialties.length > 3 && (
                <Badge variant="outline" className="text-xs text-gray-500">
                  +{provider.specialties.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Compatibility Factors */}
        {compatibility_factors && compatibility_factors.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Why This Match Works:
            </p>
            <ul className="space-y-1">
              {compatibility_factors.slice(0, expanded ? undefined : 2).map((factor, idx) => (
                <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                  <CheckCircle className="w-3 h-3 text-green-600 mt-1 flex-shrink-0" />
                  {factor}
                </li>
              ))}
            </ul>
            {!expanded && compatibility_factors.length > 2 && (
              <p className="text-xs text-gray-500 mt-1">
                +{compatibility_factors.length - 2} more factors
              </p>
            )}
          </div>
        )}

        {/* Concerns */}
        {expanded && concerns && concerns.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              Things to Consider:
            </p>
            <ul className="space-y-1">
              {concerns.map((concern, idx) => (
                <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                  <AlertCircle className="w-3 h-3 text-yellow-600 mt-1 flex-shrink-0" />
                  {concern}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Expanded Details */}
        {expanded && (
          <div className="pt-3 border-t space-y-3">
            {provider.bio && (
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-1">About:</p>
                <p className="text-sm text-gray-600">{provider.bio}</p>
              </div>
            )}

            {provider.experience_years && (
              <p className="text-sm text-gray-600">
                <strong>Experience:</strong> {provider.experience_years} years
              </p>
            )}

            {provider.languages && provider.languages.length > 0 && (
              <p className="text-sm text-gray-600">
                <strong>Languages:</strong> {provider.languages.join(', ')}
              </p>
            )}

            {provider.availability && (
              <p className="text-sm text-gray-600">
                <strong>Availability:</strong> {provider.availability}
              </p>
            )}

            <div className="flex flex-wrap gap-2">
              {provider.phone && (
                <a href={`tel:${provider.phone}`} className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  {provider.phone}
                </a>
              )}
              {provider.email && (
                <a href={`mailto:${provider.email}`} className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  Contact
                </a>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-3 border-t">
          <Button
            onClick={() => setExpanded(!expanded)}
            variant="outline"
            className="flex-1 gap-2"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-4 h-4" />
                Show Less
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4" />
                Show More
              </>
            )}
          </Button>
          
          <Link to={`${createPageUrl("ProviderProfile")}?id=${provider.id}`} className="flex-1">
            <Button variant="outline" className="w-full gap-2">
              <Award className="w-4 h-4" />
              View Profile
            </Button>
          </Link>

          <Button
            onClick={() => onContact && onContact(provider)}
            className="flex-1 bg-secondary hover:bg-secondary/90 gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Contact
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}