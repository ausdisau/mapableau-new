import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Minus } from "lucide-react";
import {
  MODULES,
  getModuleLabel,
  getModulePermissions,
  getAllRoles,
} from "@/components/utils/permissions";

export default function PermissionMatrix() {
  const roles = getAllRoles();
  const modules = Object.values(MODULES);

  const getRolePermissions = (role) => {
    return role.permissions || [];
  };

  const hasModulePermission = (rolePermissions, module, action) => {
    const permission = `${module}:${action}`;
    return rolePermissions.includes(permission);
  };

  const getModuleAccessLevel = (rolePermissions, module) => {
    const modulePerms = getModulePermissions(module);
    const hasAll = modulePerms.every(p => rolePermissions.includes(p.permission));
    const hasSome = modulePerms.some(p => rolePermissions.includes(p.permission));
    const count = modulePerms.filter(p => rolePermissions.includes(p.permission)).length;
    
    return { hasAll, hasSome, count, total: modulePerms.length };
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Role Permissions Overview</CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Visual matrix showing which permissions each role has across all modules
          </p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className="text-left p-3 font-semibold sticky left-0 bg-white z-10">
                    Module
                  </th>
                  {roles.map(role => (
                    <th key={role.value} className="p-3 text-center min-w-[120px]">
                      <div className="flex flex-col items-center gap-2">
                        <Badge className={`bg-${role.color}-100 text-${role.color}-700 border-${role.color}-200`}>
                          {role.name}
                        </Badge>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {modules.map(module => (
                  <tr key={module} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="p-3 font-medium sticky left-0 bg-white">
                      {getModuleLabel(module)}
                    </td>
                    {roles.map(role => {
                      const rolePerms = getRolePermissions(role);
                      const access = getModuleAccessLevel(rolePerms, module);
                      
                      return (
                        <td key={`${module}-${role.value}`} className="p-3 text-center">
                          <div className="flex flex-col items-center gap-1">
                            {access.hasAll ? (
                              <>
                                <CheckCircle className="w-5 h-5 text-green-600" />
                                <span className="text-xs text-green-700 font-semibold">
                                  Full Access
                                </span>
                              </>
                            ) : access.hasSome ? (
                              <>
                                <Minus className="w-5 h-5 text-yellow-600" />
                                <span className="text-xs text-yellow-700">
                                  {access.count}/{access.total}
                                </span>
                              </>
                            ) : (
                              <>
                                <XCircle className="w-5 h-5 text-gray-300" />
                                <span className="text-xs text-gray-400">
                                  No Access
                                </span>
                              </>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Legend */}
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm font-semibold mb-2">Legend:</p>
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span>Full Access - All permissions granted</span>
              </div>
              <div className="flex items-center gap-2">
                <Minus className="w-4 h-4 text-yellow-600" />
                <span>Partial Access - Some permissions granted</span>
              </div>
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-gray-300" />
                <span>No Access - No permissions granted</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Permission Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {modules.map(module => {
              const modulePerms = getModulePermissions(module);
              
              return (
                <div key={module} className="border rounded-lg p-4">
                  <h3 className="font-semibold text-lg mb-3">{getModuleLabel(module)}</h3>
                  <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {modulePerms.map(perm => (
                      <div key={perm.permission} className="text-sm p-2 bg-gray-50 rounded">
                        <p className="font-medium">{perm.label}</p>
                        <p className="text-xs text-gray-500 font-mono">{perm.action}</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}