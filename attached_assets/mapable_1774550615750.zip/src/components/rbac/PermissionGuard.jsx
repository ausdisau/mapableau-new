import React from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Lock } from "lucide-react";
import { hasPermission, hasAnyPermission, hasAllPermissions, hasRole, hasAnyRole } from "@/utils/permissions";

/**
 * Guard component that only renders children if user has required permission(s)
 */
export function PermissionGuard({ 
  user, 
  permission, 
  permissions, 
  requireAll = false,
  fallback = null,
  showMessage = false,
  children 
}) {
  let hasAccess = false;

  if (permission) {
    hasAccess = hasPermission(user, permission);
  } else if (permissions && Array.isArray(permissions)) {
    hasAccess = requireAll 
      ? hasAllPermissions(user, permissions)
      : hasAnyPermission(user, permissions);
  }

  if (!hasAccess) {
    if (showMessage) {
      return (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Lock className="w-4 h-4 text-yellow-600" />
          <AlertDescription className="text-yellow-900">
            You don't have permission to access this feature.
          </AlertDescription>
        </Alert>
      );
    }
    return fallback;
  }

  return <>{children}</>;
}

/**
 * Guard component that only renders children if user has required role(s)
 */
export function RoleGuard({ 
  user, 
  role, 
  roles, 
  fallback = null,
  showMessage = false,
  children 
}) {
  let hasAccess = false;

  if (role) {
    hasAccess = hasRole(user, role);
  } else if (roles && Array.isArray(roles)) {
    hasAccess = hasAnyRole(user, roles);
  }

  if (!hasAccess) {
    if (showMessage) {
      return (
        <Alert className="bg-yellow-50 border-yellow-200">
          <Shield className="w-4 h-4 text-yellow-600" />
          <AlertDescription className="text-yellow-900">
            You don't have the required role to access this feature.
          </AlertDescription>
        </Alert>
      );
    }
    return fallback;
  }

  return <>{children}</>;
}

/**
 * Higher-order function that returns component only if user has permission
 */
export function withPermission(permission) {
  return function (Component) {
    return function PermissionWrappedComponent({ user, ...props }) {
      if (!hasPermission(user, permission)) {
        return null;
      }
      return <Component user={user} {...props} />;
    };
  };
}

/**
 * Higher-order function that returns component only if user has role
 */
export function withRole(role) {
  return function (Component) {
    return function RoleWrappedComponent({ user, ...props }) {
      if (!hasRole(user, role)) {
        return null;
      }
      return <Component user={user} {...props} />;
    };
  };
}

/**
 * Button that's only enabled if user has permission
 */
export function PermissionButton({ 
  user, 
  permission, 
  permissions,
  requireAll = false,
  children,
  disabled,
  ...props 
}) {
  let hasAccess = false;

  if (permission) {
    hasAccess = hasPermission(user, permission);
  } else if (permissions && Array.isArray(permissions)) {
    hasAccess = requireAll 
      ? hasAllPermissions(user, permissions)
      : hasAnyPermission(user, permissions);
  }

  return (
    <button {...props} disabled={disabled || !hasAccess}>
      {children}
    </button>
  );
}

export default {
  PermissionGuard,
  RoleGuard,
  withPermission,
  withRole,
  PermissionButton,
};