import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Save, 
  X, 
  Info,
  CheckCircle
} from "lucide-react";
import {
  MODULES,
  getModulePermissions,
  getModuleLabel,
  createPermission,
} from "@/components/utils/permissions";

export default function CustomRoleEditor({ role = null, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    name: role?.name || "",
    description: role?.description || "",
    permissions: role?.permissions || [],
    color: role?.color || "blue",
  });

  const [selectedModule, setSelectedModule] = useState(null);

  const availableColors = [
    { value: "blue", label: "Blue" },
    { value: "green", label: "Green" },
    { value: "purple", label: "Purple" },
    { value: "red", label: "Red" },
    { value: "yellow", label: "Yellow" },
    { value: "indigo", label: "Indigo" },
    { value: "pink", label: "Pink" },
    { value: "teal", label: "Teal" },
    { value: "orange", label: "Orange" },
  ];

  const togglePermission = (permission) => {
    const newPermissions = formData.permissions.includes(permission)
      ? formData.permissions.filter(p => p !== permission)
      : [...formData.permissions, permission];
    
    setFormData({ ...formData, permissions: newPermissions });
  };

  const toggleAllModulePermissions = (module, allPerms) => {
    const modulePermissions = allPerms.map(p => p.permission);
    const hasAll = modulePermissions.every(p => formData.permissions.includes(p));
    
    if (hasAll) {
      // Remove all module permissions
      const newPermissions = formData.permissions.filter(
        p => !modulePermissions.includes(p)
      );
      setFormData({ ...formData, permissions: newPermissions });
    } else {
      // Add all module permissions
      const newPermissions = [...new Set([...formData.permissions, ...modulePermissions])];
      setFormData({ ...formData, permissions: newPermissions });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      return;
    }
    
    onSave({
      ...formData,
      name: formData.name.trim(),
      description: formData.description.trim(),
    });
  };

  const getModulePermissionCount = (module) => {
    const modulePerms = getModulePermissions(module);
    const selected = modulePerms.filter(p => formData.permissions.includes(p.permission));
    return `${selected.length}/${modulePerms.length}`;
  };

  const isModuleFullySelected = (module) => {
    const modulePerms = getModulePermissions(module);
    return modulePerms.every(p => formData.permissions.includes(p.permission));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Alert className="bg-blue-50 border-blue-200">
        <Info className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          Create a custom role by selecting specific permissions from each module. 
          Users with this role will only be able to access the features you enable.
        </AlertDescription>
      </Alert>

      {/* Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle>Role Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Role Name *</Label>
            <Input
              placeholder="e.g., Customer Support Manager"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              placeholder="Describe what this role is responsible for..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Badge Color</Label>
            <div className="flex flex-wrap gap-2">
              {availableColors.map(color => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, color: color.value })}
                  className={`px-4 py-2 rounded-lg border-2 transition-all ${
                    formData.color === color.value
                      ? `bg-${color.value}-100 border-${color.value}-400 text-${color.value}-700`
                      : `bg-${color.value}-50 border-${color.value}-200 text-${color.value}-600 hover:border-${color.value}-300`
                  }`}
                >
                  {color.label}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Permissions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Permissions ({formData.permissions.length} selected)</span>
            <Badge variant="outline">
              {formData.permissions.length} total permissions
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Module List */}
            <div className="grid md:grid-cols-2 gap-3">
              {Object.values(MODULES).map(module => {
                const perms = getModulePermissions(module);
                const isFullySelected = isModuleFullySelected(module);
                
                return (
                  <button
                    key={module}
                    type="button"
                    onClick={() => setSelectedModule(selectedModule === module ? null : module)}
                    className={`p-4 rounded-lg border-2 text-left transition-all hover:shadow-md ${
                      selectedModule === module
                        ? "border-blue-400 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-primary">
                        {getModuleLabel(module)}
                      </h4>
                      {isFullySelected && (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      )}
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">
                        {getModulePermissionCount(module)} permissions
                      </span>
                      <span className={`font-medium ${
                        formData.permissions.some(p => p.startsWith(module + ":"))
                          ? "text-blue-600"
                          : "text-gray-400"
                      }`}>
                        {selectedModule === module ? "Hide" : "Configure"}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Module Permissions Detail */}
            {selectedModule && (
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">
                      {getModuleLabel(selectedModule)} Permissions
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const perms = getModulePermissions(selectedModule);
                          toggleAllModulePermissions(selectedModule, perms);
                        }}
                      >
                        {isModuleFullySelected(selectedModule) ? "Deselect All" : "Select All"}
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedModule(null)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {getModulePermissions(selectedModule).map(perm => (
                      <div key={perm.permission} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50">
                        <Checkbox
                          id={perm.permission}
                          checked={formData.permissions.includes(perm.permission)}
                          onCheckedChange={() => togglePermission(perm.permission)}
                        />
                        <label htmlFor={perm.permission} className="flex-1 cursor-pointer">
                          <p className="font-medium text-sm">{perm.label}</p>
                          <p className="text-xs text-gray-500 font-mono">{perm.permission}</p>
                        </label>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Summary */}
      {formData.permissions.length > 0 && (
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-blue-600 flex-shrink-0" />
              <div>
                <h4 className="font-semibold mb-2">Selected Permissions Summary</h4>
                <div className="flex flex-wrap gap-2">
                  {Object.values(MODULES).map(module => {
                    const modulePerms = getModulePermissions(module);
                    const selected = modulePerms.filter(p => 
                      formData.permissions.includes(p.permission)
                    );
                    
                    if (selected.length === 0) return null;
                    
                    return (
                      <Badge key={module} variant="outline" className="bg-white">
                        {getModuleLabel(module)}: {selected.length}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button 
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 gap-2"
          disabled={!formData.name.trim() || formData.permissions.length === 0}
        >
          <Save className="w-4 h-4" />
          {role ? "Update Role" : "Create Role"}
        </Button>
      </div>
    </form>
  );
}