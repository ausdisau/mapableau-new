import { base44 } from './base44Client';


export const Location = base44.entities.Location;

export const Review = base44.entities.Review;

export const ServiceProvider = base44.entities.ServiceProvider;

export const ServiceRequest = base44.entities.ServiceRequest;

export const Job = base44.entities.Job;

export const JobApplication = base44.entities.JobApplication;

export const Payment = base44.entities.Payment;

export const Invoice = base44.entities.Invoice;

export const Notification = base44.entities.Notification;

export const Message = base44.entities.Message;

export const SupportTicket = base44.entities.SupportTicket;

export const KnowledgeBaseArticle = base44.entities.KnowledgeBaseArticle;

export const ProviderReview = base44.entities.ProviderReview;

export const Vehicle = base44.entities.Vehicle;

export const Driver = base44.entities.Driver;

export const TransportBooking = base44.entities.TransportBooking;

export const NDISPlanBudget = base44.entities.NDISPlanBudget;

export const TransportReview = base44.entities.TransportReview;

export const DailySchedule = base44.entities.DailySchedule;

export const NotificationPreference = base44.entities.NotificationPreference;

export const ProviderCredential = base44.entities.ProviderCredential;

export const AuditLog = base44.entities.AuditLog;

export const TwoFactorAuth = base44.entities.TwoFactorAuth;

export const WorkflowDefinition = base44.entities.WorkflowDefinition;

export const WorkflowExecution = base44.entities.WorkflowExecution;

export const ApprovalRequest = base44.entities.ApprovalRequest;

export const ForumPost = base44.entities.ForumPost;

export const ForumComment = base44.entities.ForumComment;

export const ProviderAvailability = base44.entities.ProviderAvailability;



// auth sdk:
export const User = base44.auth;