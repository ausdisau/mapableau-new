# MapAble — NDIS Policy & Procedure Suite v2.1 (Certification-grade)

This suite is engineered to pass a **Certification** audit for the following registration groups in MapAble’s scope:

- **0107 Assistance with daily personal activities** — *Certification*
- **0108 Assistance with travel/transport arrangements** — *Verification* (but included here to certification depth)
- **0102 Assistance to access and maintain employment or higher education** — *Certification*
- **0106 Assistance in coordinating or managing life stages, transitions and supports (Support Coordination)** — *Certification*
- **0127 Management of funding for supports in participant plans (Plan Management)** — *Verification* (depth elevated)

> The NDIS Commission confirms these audit pathways in its official table of **Registration groups or classes of support** (“If a provider's application includes registration groups associated with both verification and certification audits, they will need to complete a certification audit”).

**Core design**  
- Every policy has: scope, detailed controls, responsibilities (RACI), evidence for auditors, and implementation tasks.
- Procedures include **RACI**, **inputs/outputs**, **risk controls**, and **records**.
- Registers and forms are provided as CSV/Markdown for direct use.

**Authoritative references used throughout:**  
- Practice Standards (online): https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards
- Practice Standards & Quality Indicators (PDF): https://www.ndiscommission.gov.au/sites/default/files/2024-05/ndis-practice-standards-and-quality-indicatorsfinal1_1.pdf
- Registration groups & audit types: https://www.ndiscommission.gov.au/provider-registration/apply-registration/registration-groups-or-classes-support
- Audit process (certification/verification): https://www.ndiscommission.gov.au/provider-registration/apply-registration/types-audits
- Verification Required Documentation: https://www.ndiscommission.gov.au/sites/default/files/2025-05/ndis-verification-module-required-documentation.pdf
- Reportable incidents: https://www.ndiscommission.gov.au/rules-and-standards/reportable-incidents-and-incident-management/reportable-incidents
- Incident management: https://www.ndiscommission.gov.au/rules-and-standards/reportable-incidents-and-incident-management/incident-management
- Worker screening (registered providers): https://www.ndiscommission.gov.au/workforce/worker-screening/worker-screening-registered-providers
- Worker training: Orientation: https://www.ndiscommission.gov.au/workforce/online-training-modules
- Safe Transportation Practice Guide: https://www.ndiscommission.gov.au/sites/default/files/2023-02/Safe%20Transportation%20Practice%20Guide.pdf
- High Intensity skills descriptors: https://www.ndiscommission.gov.au/sites/default/files/2024-09/High%20Intensity%20support%20skills%20descriptors.pdf
- NDIA Pricing (PAPL) 2025-26: https://www.ndis.gov.au/media/7739/download?attachment=
- Travel claiming/gap fees explainer: https://www.ndis.gov.au/news/10827-travel-claiming-rules-gap-fees-and-other-costs
- Service agreements guidance: https://www.ndis.gov.au/providers/working-provider/connecting-participants/service-agreements
- Support coordination & plan management (quality practice): https://www.ndiscommission.gov.au/rules-and-standards/quality-practice/support-coordination-and-plan-management
- my NDIS provider portal & myID/RAM: https://www.ndis.gov.au/providers/working-provider/my-ndis-provider-portal-and-resources
- 0107 additional registration condition: https://www.ndiscommission.gov.au/provider-registration/about-registration/registration-conditions-personal-support-providers
- Core: Provider governance and operational management: https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards/core-module-provider-governance-and-operational
