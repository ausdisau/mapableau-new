# MapAble — SOP — 0127 Plan Management
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Verification module; PAPL

---

1) Onboard: service agreement; Authority to Act; identity verification.  
2) **Invoice validation checklist**: item code, date/service description, price ≤ PAPL, travel rules, duplication check, service agreement match.  
3) Claim via NDIA portal; pay provider; send participant statement.  
4) Reconciliations: weekly bank rec; monthly participant statements.  
5) Fraud red‑flags: split billing, unusual volumes, non‑NDIS items; escalate to CEO.

**Records**: invoices, claims, statements, reconciliations, exceptions log.
