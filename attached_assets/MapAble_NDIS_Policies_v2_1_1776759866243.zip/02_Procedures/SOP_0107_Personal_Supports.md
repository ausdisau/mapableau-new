# MapAble — SOP — 0107 Personal Supports
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** 0107; 0107 additional condition; HISSD where relevant

---

## Pre‑service
- Intake, consent, risk screen; mealtime/medication needs; cultural and communication preferences.
- **Living‑alone sole‑worker?** complete checklist & monitoring plan; add to 0107 register.

## Delivery
- Respect dignity and routines; implement support plan; use least‑restrictive strategies.
- High‑intensity tasks only by trained/assessed competent workers.

## Post‑service
- Progress notes; variance alerts; incident escalation where indicated; monthly review with participant.
