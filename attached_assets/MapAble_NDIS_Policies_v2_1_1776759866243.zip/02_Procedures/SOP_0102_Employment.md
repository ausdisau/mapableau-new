# MapAble — SOP — 0102 Finding & Keeping a Job
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** 0102

---

- Vocational profile → employment plan (milestones).  
- Host agreement; OHS induction checklist.  
- On‑the‑job coaching notes; outcome measures.  
- Employer & participant satisfaction checks; retention plan.
