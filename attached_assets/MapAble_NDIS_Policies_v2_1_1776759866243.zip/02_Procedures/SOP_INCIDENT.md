# MapAble — SOP — Incident Management & Reportable Incidents
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Incident management; Reportable incidents

---

## Inputs
Incident observed/reported; participant support plan; risk register.

## Steps
```
1. Make safe; call 000 if required
2. On‑call/Manager notified immediately for critical incidents
3. Complete Incident Report within 24 hours
4. Determine reportable status using decision tree (appendix)
5. Lodge Immediate Notification (<24h) where required via Commission portal
6. Open investigation (proportionate); preserve evidence
7. Lodge 5‑Day form with actions
8. Implement/verify corrective actions; update CI and risk registers
9. Close incident and conduct debrief
``` 

## RACI
- **A:** CEO  **R:** Service Manager  **C:** Quality Lead  **I:** Participant/nominee

## Records
Incident forms (24h; 5‑day), investigation notes, corrective actions, debrief minutes.
