# MapAble — SOP — 0106 Support Coordination
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Support coordination quality practice

---

- **Engage & consent**; explain role/boundaries and COI.  
- **Map supports & risks**; crisis plan.  
- **Genuine choice**: provide multiple provider options; document decisions.  
- **Implement & monitor**: budgets, service bookings (NDIA), escalation of barriers.  
- **Review & report**.

**Records**: options lists, case notes, budget trackers, reports.
