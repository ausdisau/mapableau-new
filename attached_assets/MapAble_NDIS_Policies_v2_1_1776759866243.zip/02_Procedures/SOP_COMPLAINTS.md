# MapAble — SOP — Complaints Management
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Feedback & complaints

---

**Targets:** Acknowledge in 2 working days; resolve in 20 working days unless complex.

```
1. Receive via any channel (incl. anonymous)
2. Record in Complaints Register; confirm preferred communication method
3. Acknowledge and outline process/timeframes
4. Assess complexity; early resolution where possible
5. Investigate (collect statements/records) where needed
6. Response letter incl. reasons, remedies, review options
7. Close and log CI actions; trend analysis monthly
``` 
