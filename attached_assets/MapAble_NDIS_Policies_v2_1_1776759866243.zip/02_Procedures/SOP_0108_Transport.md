# MapAble — SOP — 0108 Transport
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** 0108; Safe Transportation Practice Guide; PAPL travel rules

---

**Pre‑trip**: vehicle pre‑start checks; confirm route/time; consider fatigue.  
**Loading**: secure mobility aids; seatbelts/child restraints.  
**During trip**: safe driving; follow behaviour support plans; avoid restrictive practices unless authorised.  
**Post‑trip**: time/km logged; billing record prepared compliant with PAPL.

**Records**: vehicle checklist, transport log, incident/near‑miss log.
