# Audit Day Runbook
- Welcome & opening meeting (agenda + scope)
- Org overview, service scope & registration groups
- Evidence index + crosswalk handover
- Document sampling packs (incidents, complaints, HR files, transport logs, PM files)
- Participant/worker interview schedule
- Daily wash‑up & corrective action log
- Closing meeting & non‑conformity response plan
