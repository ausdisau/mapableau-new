# Internal Audit Program (Annual)
Quarterly Core Module audits; mid‑term mock audit; sampling strategy; reporting and follow‑up.
