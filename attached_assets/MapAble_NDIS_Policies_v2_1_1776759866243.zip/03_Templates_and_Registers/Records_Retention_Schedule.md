# Records Retention Schedule (Base)
Participant records, incidents, complaints, finance and HR — retain **≥7 years** unless law/contract requires longer; add state specifics.
