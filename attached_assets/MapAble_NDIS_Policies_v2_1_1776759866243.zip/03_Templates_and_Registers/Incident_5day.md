# 5‑Business‑Day Report — Internal Capture
Fields: root cause, corrective actions, verification, support provided, dates, portal reference.
