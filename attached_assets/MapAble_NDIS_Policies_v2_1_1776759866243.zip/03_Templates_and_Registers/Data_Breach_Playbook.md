# Data Breach Response
Contain → Assess serious‑harm → Notify (OAIC & individuals if required) → Remediate → Record.
