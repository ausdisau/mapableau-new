# Mealtime/Dysphagia Plan (IDDSI)
Sections: texture/fluids, positioning, equipment, supervision, choking response, training required.
