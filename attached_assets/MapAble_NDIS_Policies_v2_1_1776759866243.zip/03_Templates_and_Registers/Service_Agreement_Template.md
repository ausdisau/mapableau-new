# Service Agreement Template — MapAble
- Parties; scope; schedules; prices aligned to **PAPL 2025‑26**; cancellations per PAPL.
- Travel charging disclosure; no gap fees/surcharges; consent to any non‑labour costs where permitted.
- Rights & responsibilities; privacy; complaints and Commission contact.
- Ending the agreement & safe transition.
