# Plan Management — Invoice Validation Checklist
Price ≤ PAPL, correct item code/date/description, travel rules, duplicates, agreement match, approvals.
