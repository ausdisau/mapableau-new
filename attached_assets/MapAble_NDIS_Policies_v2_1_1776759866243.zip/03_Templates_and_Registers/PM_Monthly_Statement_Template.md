# Plan Management — Monthly Statement
Opening balance by category; claims itemised; payments; remaining funds; forecast; alerts.
