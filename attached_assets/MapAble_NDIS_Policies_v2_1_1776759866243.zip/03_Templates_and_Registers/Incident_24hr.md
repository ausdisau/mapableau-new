# Immediate Notification (24h) — Internal Capture
Fields: participant, category, what happened, immediate actions, external authorities, portal lodgement time, reference.
