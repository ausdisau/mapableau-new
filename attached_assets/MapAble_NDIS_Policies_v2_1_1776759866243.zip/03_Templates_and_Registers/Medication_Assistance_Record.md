# Medication Assistance Record
Fields: meds, dose/time/route, assistance level, variances/errors, signatures.
