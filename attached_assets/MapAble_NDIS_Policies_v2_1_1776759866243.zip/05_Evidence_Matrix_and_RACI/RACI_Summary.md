# RACI Summary (selected processes)
- Incident management — A: CEO; R: Service Manager; C: Quality Lead; I: Participant
- Complaints — A: Quality Lead; R: Service Manager; C: CEO; I: Participant
- 0107 living‑alone monitoring — A: Service Manager; R: Team Leader; C: Quality Lead; I: Participant
- Plan Management invoice approval — A: Finance Lead; R: Plan Manager; C: CEO; I: Participant
