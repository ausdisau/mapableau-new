# MapAble — Document Control & Quality Management System (QMS) Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Governance & operational management; Quality management

---

## Purpose
Establish a controlled document system and QMS that meets the **NDIS Practice Standards** and produces objective evidence for audit.

## Policy
- All documents have unique IDs, version control, approver, and next review.
- Obsolete documents are removed from points of use.
- **Quarterly internal audits**; **biannual management reviews** with actions, owners, due dates.
- **Continuous Improvement (CI) Register** captures Incidents, Complaints, Audits, Feedback and Risks as inputs.

## RACI
- **Accountable:** CEO  
- **Responsible:** Quality & Safeguarding Lead  
- **Consulted:** Service Managers, Finance Lead  
- **Informed:** All workers

## Evidence
- CI Register, internal audit schedule & reports, management review minutes, superseded doc archive index.
