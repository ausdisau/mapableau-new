# MapAble — Risk Management Framework
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Governance & operational management; Risk management

---

## Framework
- Risk appetite statement (safety = zero appetite for preventable harm).
- **5x5 matrix** with qualitative descriptors and risk rating bands.
- **Key risk domains:** safeguarding, clinical/practice, finance/fraud (incl. plan management), information security, transport safety, employment supports, support coordination COI, business continuity.

## Process
1) Identify (service intake, environment, change).  
2) Assess (likelihood x consequence).  
3) Treat (controls & owners).  
4) Monitor (monthly review; escalate red risks to Board).  
5) Learn (link to incidents/complaints and audits).

## Special controls
- **0107 personal supports**: living-alone sole-worker checklist; unannounced spot checks; escalation tree.  
- **Restrictive practices**: authorisation & monthly reporting where relevant; emergency use triggers reportable incident.  
- **Plan Management**: 3‑way match (agreement–invoice–claim), dual approvals over \$X, bank rec weekly, fraud red-flags.  
- **Transport**: pre‑start vehicle checks, fatigue limits, wheelchair restraint competency, crash response plan.

## Evidence
- Risk register (CSV), risk treatment plans, escalation records.
