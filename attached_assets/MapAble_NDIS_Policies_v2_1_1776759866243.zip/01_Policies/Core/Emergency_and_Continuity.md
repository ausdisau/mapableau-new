# MapAble — Emergency & Disaster Management and Continuity of Supports Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Continuity of supports; Emergency & disaster management

---

- Participant‑level contingency plans for critical supports; organisation continuity plan for staffing, premises and ICT.  
- Annual drills; after‑action reviews; update risk register.

**Evidence:** drill records, call‑tree test logs, alternate site arrangements.
