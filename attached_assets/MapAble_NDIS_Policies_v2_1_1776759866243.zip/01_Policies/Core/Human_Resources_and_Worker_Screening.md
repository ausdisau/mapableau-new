# MapAble — Human Resources, Worker Screening & Competency Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Human resource management; Worker screening

---

- Identify **risk‑assessed roles**; **NDIS Worker Screening** required with verification in the Commission portal.  
- Worker screening generally valid **5 years**; track expiries and re‑checks.  
- Induction includes **NDIS Worker Orientation**; role‑specific training; supervised practice until competency is signed off.  
- Document supervision at least quarterly.

**Evidence:** Worker Screening Register, Training Matrix, supervision records, competency checklists.
