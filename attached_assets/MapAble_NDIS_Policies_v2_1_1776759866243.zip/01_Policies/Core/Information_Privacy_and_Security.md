# MapAble — Information Privacy & Security Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Information management; OAIC Notifiable Data Breaches (NDB) scheme

---

- Australian Privacy Principles; least‑privilege access; MFA on critical systems.  
- **Data Breach Response**: contain → assess serious‑harm risk → notify affected people & OAIC if notifiable → remediate → record.
- Records retention: **7 years minimum** unless law/contract requires longer.

**Evidence:** access reviews, backup logs, breach decision records, retention schedule.
