# MapAble — Feedback & Complaints Management Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Feedback & complaints management

---

- Accessible pathways; *no‑detriment* principle.  
- Acknowledge within **2 business days**; aim to resolve within **20 business days** unless complex.  
- Participants can complain to the NDIS Commission at any time.  
- Track trends; feed into CI register.

**Evidence:** complaints register, outcomes letters, trend analysis to management review.
