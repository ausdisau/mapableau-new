# MapAble — Incident Management & Reportable Incidents Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core: Incident management; Reportable incidents

---

## Timeframes (per Commission)
- **Immediate Notification**: within **24 hours** for death, serious injury, abuse/neglect, unlawful sexual/physical contact, sexual misconduct.  
- **5‑Business‑Day** report: further detail and actions.  
- **Unauthorised Restrictive Practices** causing no immediate harm: **5‑day form only**.

## Process (SOP linked)
1) Make safe and support the person; call emergency services where indicated.  
2) Escalate to On‑call/CEO for critical incidents.  
3) Record in Incident Register within 24 hours.  
4) Notify NDIS Commission via portal within required timeframes.  
5) Investigate proportionately; implement and verify corrective actions.  
6) Debrief, update risk register; CI entry.

## RACI
A: CEO; R: Service Managers; C: Quality Lead; I: Participant/nominee.

## Evidence
- Incident files (initial/5‑day/final), RCA notes, corrective actions with verification.
