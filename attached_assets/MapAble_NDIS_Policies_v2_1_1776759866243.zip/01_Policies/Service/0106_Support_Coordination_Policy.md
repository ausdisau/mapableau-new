# MapAble — 0106 — Support Coordination Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core modules; Quality practice — support coordination

---

- Role clarity and boundaries; participant consent; **genuine choice** of providers; **COI** identified and mitigated.  
- Mapping of informal/mainstream/funded supports; risk plan and escalation/crisis pathway.  
- Budget and implementation monitoring; provider interface and review preparation.  

**Evidence:** options presented, COI disclosures, case notes, budgets and reports.
