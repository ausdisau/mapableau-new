# MapAble — 0102 — Finding & Keeping a Job (Employment Supports) Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core modules

---

- Vocational profiling and employment plan with milestones.  
- Host workplace safety checks; reasonable adjustments; agreements with hosts clarifying roles and insurances.  
- On‑the‑job coaching with progress data; retention follow‑ups.  
- Interfaces with DES or mainstream services documented where relevant.

**Evidence:** employment plans, workplace risk assessments, progress/outcome tracking.
