# MapAble — 0108 — Transport Safety & Charging Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** 0108 Verification controls; Safe Transportation Guide; PAPL travel charging

---

## Safety controls
- Licensed/insured drivers; vehicle pre‑start checks and maintenance schedule.  
- Seatbelts; child restraints as required by road laws; safe wheelchair tie‑down/occupant restraints per manufacturer guidance.  
- Where behaviour presents risk, use positive strategies; **any restrictive practice in vehicles** must follow authorisation rules and reporting.  
- Fatigue management: schedule limits and breaks.

## Charging controls
- Apply **PAPL 2025‑26** rules; no **gap fees** or surcharges; record **time/distance/purpose**.  
- Keep logs to support claims and plan manager verification.

**Evidence:** vehicle logs/checks; transport log CSV; sample invoices with travel records.
