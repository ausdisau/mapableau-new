# MapAble — 0127 — Plan Management Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Verification module; NDIA pricing & claiming

---

- **Controls**: 3‑way match (service agreement ↔ invoice ↔ PAPL rules); segregation of duties; timely claims and payments.  
- Statements to participants at least monthly/on request; exceptions management (over‑claim, duplicate, incorrect item codes).  
- COI management (no steering to related providers; disclose related parties).  
- Data security and retention aligned to records policy.

**Evidence:** invoice validation checklist, reconciliations, statements, COI register entries.
