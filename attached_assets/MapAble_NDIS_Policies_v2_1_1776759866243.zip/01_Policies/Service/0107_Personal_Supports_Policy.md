# MapAble — 0107 — Assistance with Daily Personal Activities (Personal Supports) Policy
**Version:** v2.1 (Certification-grade)  
**Effective:** 2025-11-07  **Next review:** 2026-11-07  
**Owner:** Quality & Safeguarding Lead  
**Applies to:** All staff, contractors and volunteers  
**Related NDIS Practice Standards:** Core modules; 0107 additional registration condition; HISSD where relevant

---

## Scope
Personal care in home/community settings. High‑intensity tasks only where explicitly in scope and competent.

## Mandatory controls
- **0107 additional registration condition** (participants living alone with a sole worker): complete risk assessment, monitor quality/satisfaction, maintain an up‑to‑date register and conduct periodic spot checks.  
- Participant consent, dignity, cultural safety, trauma‑informed practice.  
- For mealtime dysphagia risks: documented mealtime plans; IDDSI where applicable.  
- Medication assistance within competence and documented plan; medication incidents are reportable where thresholds met.

## Workforce
- Competency‑based allocation; manual handling & IPC training; supervision with field observations.

## Evidence to auditor
- Living‑alone register and risk assessments; sample support plans and daily notes; training & competency records.
