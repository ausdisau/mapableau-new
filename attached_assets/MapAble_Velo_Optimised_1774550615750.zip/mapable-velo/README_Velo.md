# MapAble Velo Integration Guide

This guide shows how to implement the MapAble concept using **Velo by Wix** instead of relying on an HTML iframe embed. It follows performance and accessibility best‑practices from Wix, such as keeping heavy third‑party code off the homepage, using static elements above the fold, and minimizing fonts and animations【718735534299092†L139-L151】. See the sample code in `velo_code_example.js` for wiring search filters, maps and datasets.

## 1. Structure your Wix site

1. **Create Collections** in **Content Manager (Wix Data)**:
   - **Places**: fields like `name` (text), `category` (text: “Care”, “Transport”, “Jobs”), `latitude` (number), `longitude` (number), `verified` (boolean), `NDIS_registered` (boolean), `access_tags` (text list), `rating` (number), `address` (text).  
   - **Jobs**: `title`, `employer`, `accommodations` (text list), `location`, `remote` (boolean), `salary_range`, `apply_url`.  
   - **Events**: `title`, `dateTime` (datetime), `location`, `description`, `signupUrl`.  
   - (Optional) **Stories**, **Volunteers** and **Products** collections for future modules.

2. **Design pages** using the Wix Editor:
   - **Home**: Add static hero text and CTA buttons. Keep the hero free of heavy widgets to improve above‑the‑fold loading time【718735534299092†L144-L151】. Add a light background graphic (e.g., radial gradients) and small animated dots via CSS or Velo animations if needed.
   - **Directory page**: Place a **Repeater** or **Repeating List** connected to the *Places* dataset. Add filter dropdowns/checkboxes (wheelchair access, NDIS, etc.) and a **Map** widget or custom Google Maps element. Place heavy elements (map) below the fold if possible to meet performance guidelines【718735534299092†L183-L191】.
   - **Care**, **Transport**, **Jobs**, **Marketplace**, **Community** pages: Either use **Dynamic Pages** (one template per dataset) or standard pages with repeaters bound to filtered datasets.

3. **Create Dynamic Pages** if you want individual detail pages for each place, job or event. Use a dataset and set the dynamic page URL pattern (e.g., `/places/{title}`) from the collection.

## 2. Implement interactivity with Velo

1. **Data filtering and search**: Use `wix-data` in page code to build filters based on user input. For example, on the Directory page, listen to changes in checkboxes and search boxes and apply filters to the dataset. See `velo_code_example.js` for a complete pattern.

2. **Map integration**: Use Wix’s built‑in **Google Maps** element or embed a third‑party map (e.g., Leaflet) only on pages where it’s truly needed. Avoid embedding heavy maps on the homepage since third‑party iFrames increase page load time【718735534299092†L183-L191】. For external maps, place them on secondary pages and link from the main page.

3. **Accessibility toolbar**: Implement a global toolbar component (e.g., a lightbox or strip) that toggles CSS classes on the `<body>` via `$w` and stores preferences in `localStorage`. You can adapt the logic from the original HTML starter (`main.js`) to Velo by writing functions on site or page code. Remember to add focus styles using Velo’s theme options.

4. **Community features**: Leverage **Wix Forum**, **Wix Events**, and **Wix Groups** apps for built‑in moderation, user profiles, and membership. Use the Content Manager to assign badges/roles to users.

5. **Performance tips**:
   - **Minimize third‑party scripts**: Limit external apps to secondary pages; third‑party content slows down page loads and can’t be optimized by Wix【718735534299092†L183-L191】.
   - **Keep above‑the‑fold content light**: Use text, shapes, and buttons; move maps, carousels, and videos further down the page【718735534299092†L144-L151】.
   - **Use modern image formats**: Upload AVIF images when possible; they load faster and Wix will automatically compress images【718735534299092†L160-L171】.
   - **Limit fonts**: Use no more than 3–4 fonts across the site to reduce loading time【718735534299092†L196-L200】.
   - **Reduce animations**: Use simple transitions only where necessary; heavy animations should be below the fold【718735534299092†L207-L213】.

## 3. Sample Velo Page Code (Directory)

The `velo_code_example.js` file contains an example of how to wire up a directory page with filters, search, and a map. Here’s the gist:

```js
// velo_code_example.js
import wixData from 'wix-data';
import { debounce } from 'lodash'; // Add lodash in package manager or implement your own debounce

// Called when the page is ready
$w.onReady(async function () {
  // Ensure dataset is ready
  await $w('#placesDataset').onReady();

  // Initialize map with markers from dataset (pseudo-code)
  loadMarkersFromDataset();

  // Search input handler
  $w('#searchBox').onInput(debounce((event) => {
    const query = $w('#searchBox').value;
    applyFilters(query);
  }, 300));

  // Checkbox filters (example for wheelchair and NDIS)
  $w('#wheelchairCheck').onChange(updateFilters);
  $w('#ndisCheck').onChange(updateFilters);

  function updateFilters() {
    const wheelchair = $w('#wheelchairCheck').checked;
    const ndis = $w('#ndisCheck').checked;
    const query = $w('#searchBox').value;
    applyFilters(query, { wheelchair, ndis });
  }

  function applyFilters(searchText, flags = {}) {
    let filter = wixData.filter();

    if (searchText) {
      filter = filter.contains('name', searchText);
    }
    if (flags.wheelchair) {
      filter = filter.contains('access_tags', 'Wheelchair access');
    }
    if (flags.ndis) {
      filter = filter.eq('NDIS_registered', true);
    }

    // Set filter on dataset and update the map
    $w('#placesDataset').setFilter(filter).then(() => {
      loadMarkersFromDataset();
    });
  }

  function loadMarkersFromDataset() {
    const items = $w('#placesDataset').getItems();
    const mapWidget = $w('#map');
    mapWidget.clearMarkers();
    items.items.forEach((item) => {
      mapWidget.addMarker({
        location: {
          latitude: item.latitude,
          longitude: item.longitude,
          description: item.name,
        },
        tooltip: `${item.name}\n${item.access_tags.join(', ')}`,
      });
    });
  }
});
```

## 4. Next Steps

1. **Build dynamic pages** for each place/job: Add detail fields and dynamic page routes. Use dataset connected elements to display provider profiles, journey plans, job descriptions, etc.
2. **Replace demo data** with live feeds (NDIS provider registry, GTFS‑real time, job boards) via serverless functions or scheduled tasks with `wix-fetch` or external APIs.
3. **Test accessibility** using Wix’s **Accessibility Wizard** and run audits via external tools like Lighthouse. Ensure all interactive elements are keyboard reachable and provide proper ARIA labels.
4. **Monitor performance** under *Site Speed* in Wix’s dashboard and adjust images, third‑party apps, and code accordingly. Remember that third‑party iFrames and heavy animations increase load times【718735534299092†L183-L191】.

---

For further reading on Velo and performance, consult the Wix developer docs and the *Site Performance: Best Practices* article【718735534299092†L93-L151】.
