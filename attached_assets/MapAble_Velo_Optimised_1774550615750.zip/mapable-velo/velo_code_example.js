// Example code for the MapAble directory page using Velo by Wix
// Connect elements in the editor: #placesDataset (dataset), #searchBox (input),
// #wheelchairCheck, #ndisCheck (checkboxes), #map (Google Maps element or custom embed)

import wixData from 'wix-data';
import { debounce } from 'lodash-es';

$w.onReady(async function () {
  await $w('#placesDataset').onReady();
  // Initial marker load
  loadMarkers();

  // Search input filter
  $w('#searchBox').onInput(debounce(() => {
    updateFilters();
  }, 300));

  // Checkbox listeners
  $w('#wheelchairCheck').onChange(updateFilters);
  $w('#ndisCheck').onChange(updateFilters);

  function updateFilters() {
    let filter = wixData.filter();
    const query = $w('#searchBox').value;
    if (query) {
      filter = filter.contains('name', query);
    }
    if ($w('#wheelchairCheck').checked) {
      filter = filter.contains('access_tags', 'Wheelchair access');
    }
    if ($w('#ndisCheck').checked) {
      filter = filter.eq('NDIS_registered', true);
    }
    $w('#placesDataset').setFilter(filter).then(() => {
      loadMarkers();
    });
  }

  function loadMarkers() {
    const dataItems = $w('#placesDataset').getItems();
    const mapWidget = $w('#map');
    if (!mapWidget.addMarker) return;
    mapWidget.clearMarkers();
    dataItems.items.forEach((item) => {
      mapWidget.addMarker({
        location: {
          latitude: item.latitude,
          longitude: item.longitude,
          description: item.name,
        },
        title: item.name,
        tooltip: `${item.name}\n${item.access_tags.join(', ')}`,
      });
    });
  }
});
