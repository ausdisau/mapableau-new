
import { useState } from 'react';

export default function QuoteToClaim() {
  const [quote, setQuote] = useState({ description: '', amount: '' });
  const [message, setMessage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(quote),
    });
    const data = await res.json();
    setMessage(data.message);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md p-6 mx-auto bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4">Submit Quote as Claim</h2>
      <input className="w-full p-2 mb-2 border" placeholder="Description" onChange={e => setQuote({ ...quote, description: e.target.value })} />
      <input className="w-full p-2 mb-2 border" placeholder="Amount" type="number" onChange={e => setQuote({ ...quote, amount: e.target.value })} />
      <button className="w-full p-2 bg-blue-600 text-white rounded">Submit Claim</button>
      {message && <p className="mt-3 text-green-700">{message}</p>}
    </form>
  );
}
