
import { useState } from 'react';

export default function NDISPaymentForm() {
  const [status, setStatus] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const body = Object.fromEntries(form.entries());

    const res = await fetch('/api/lodge-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const result = await res.json();
    setStatus(result.message);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md p-6 mx-auto bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4 text-gray-700">Lodge NDIS Payment Request</h2>
      <label className="block mb-2">
        Participant ID:
        <input name="participantId" required className="w-full mt-1 p-2 border rounded" />
      </label>
      <label className="block mb-2">
        Service Description:
        <input name="serviceDescription" required className="w-full mt-1 p-2 border rounded" />
      </label>
      <label className="block mb-2">
        Amount ($):
        <input name="amount" type="number" step="0.01" required className="w-full mt-1 p-2 border rounded" />
      </label>
      <button type="submit" className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        Lodge Request
      </button>
      {status && <p className="mt-3 text-green-600">{status}</p>}
    </form>
  );
}
