
export default function handler(req, res) {
  if (req.method === 'POST') {
    const { participantId, serviceDescription, amount } = req.body;
    if (participantId && serviceDescription && amount) {
      return res.status(200).json({
        success: true,
        message: `Payment request of $${amount} for "${serviceDescription}" has been lodged.`,
      });
    } else {
      return res.status(400).json({ success: false, message: "Missing fields" });
    }
  } else {
    res.status(405).json({ message: "Method Not Allowed" });
  }
}
