
export default function handler(req, res) {
  const invoices = [
    { description: 'Community Access', amount: 145.00, status: 'Paid' },
    { description: 'Transport', amount: 87.50, status: 'Pending' },
  ];
  res.status(200).json(invoices);
}
