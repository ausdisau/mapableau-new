
import { useEffect, useState } from 'react';

export default function InvoiceDashboard() {
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    fetch('/api/invoice')
      .then(res => res.json())
      .then(setInvoices);
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Issued Invoices</h2>
      <ul className="space-y-2">
        {invoices.map((inv, idx) => (
          <li key={idx} className="p-4 bg-white rounded shadow">
            <div className="flex justify-between">
              <div><strong>{inv.description}</strong> • ${inv.amount}</div>
              <div>{inv.status}</div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
