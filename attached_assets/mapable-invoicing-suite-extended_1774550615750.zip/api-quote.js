
export default function handler(req, res) {
  if (req.method === 'POST') {
    const { description, amount } = req.body;
    if (description && amount) {
      return res.status(200).json({
        success: true,
        message: `Quote for "${description}" ($${amount}) submitted as claim.`,
      });
    } else {
      return res.status(400).json({ success: false, message: "Missing fields" });
    }
  } else {
    res.status(405).json({ message: "Method Not Allowed" });
  }
}
