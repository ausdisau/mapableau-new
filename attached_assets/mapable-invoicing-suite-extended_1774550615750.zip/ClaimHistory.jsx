
import { useEffect, useState } from 'react';

export default function ClaimHistory() {
  const [claims, setClaims] = useState([]);

  useEffect(() => {
    setClaims([
      { date: '2024-01-10', service: 'Transport', amount: 88.50, status: 'Approved' },
      { date: '2024-01-08', service: 'Support Worker', amount: 150.00, status: 'Pending' },
    ]);
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Claim History</h2>
      <ul className="space-y-2">
        {claims.map((claim, idx) => (
          <li key={idx} className="p-3 bg-gray-100 rounded">
            {claim.date} • {claim.service} • ${claim.amount} • <strong>{claim.status}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}
