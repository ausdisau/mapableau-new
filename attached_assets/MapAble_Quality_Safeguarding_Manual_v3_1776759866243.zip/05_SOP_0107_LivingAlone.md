# SOP — Safeguard for 0107 Personal Supports (participant lives alone & sole worker)

**Condition:** If a participant **lives alone** and receives **personal support from a sole worker**, we must:  
- **assess risks**, and  
- **monitor** the **quality** of, and **participant satisfaction** with, the supports.

## Steps
1. **Identify**: at intake and whenever circumstances change.  
2. **Risk assessment**: environment, frequency/duration, worker rotation, escalation plan.  
3. **Controls**: spot checks/unannounced visits, check‑in schedule, escalation triggers.  
4. **Monitor**: monthly check‑ins on quality/satisfaction; log outcomes.  
5. **Review**: management review each quarter; adjust roster/controls if needed.

## RACI
- **A:** Service Manager  
- **R:** Team Leader  
- **C:** Quality & Safeguarding Lead  
- **I:** Participant/nominee

## Records / Evidence
0107 Living‑Alone Register, risk assessments, monitoring notes, spot‑check records.

