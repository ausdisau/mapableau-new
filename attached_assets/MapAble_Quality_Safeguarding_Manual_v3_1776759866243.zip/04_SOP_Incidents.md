# SOP — Incident Management & Reportable Incidents

**Purpose:** Respond to incidents quickly and report **reportable incidents** to the NDIS Commission in required timeframes.

## Timeframes (per Commission)
- **Immediate Notification**: submit within **24 hours** for death, serious injury, abuse/neglect, unlawful sexual/physical contact, sexual misconduct.  
- **5‑Business‑Day** report: submit follow‑up with actions taken.  
- **Unauthorised restrictive practice (no immediate harm)**: **5‑day** form only.

## Steps
1. **Make safe first**: first aid, call **000** if needed; support the person.  
2. **Escalate**: inform on‑call/manager immediately for serious incidents.  
3. **Record**: complete incident report within **24 hours**.  
4. **Notify**: decide if reportable → lodge in NDIS Commission portal in timeframe.  
5. **Investigate**: proportionate to risk; preserve evidence; consult affected person.  
6. **Act & verify**: corrective actions; check they worked.  
7. **Close & learn**: update risk register; debrief; report trends to management.

## RACI
- **A:** CEO  
- **R:** Service Manager  
- **C:** Quality & Safeguarding Lead  
- **I:** Participant/nominee

## Records / Evidence
Incident reports (24h, 5‑day), investigation notes, actions, debrief, communications.

