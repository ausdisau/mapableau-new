# Workforce: Screening, Training & Supervision

- Workers in **risk‑assessed roles** must hold **NDIS Worker Screening** clearance (valid **5 years**).  
- We link workers in the NDIS portal/NWSD and track expiries.  
- Mandatory **NDIS Worker Orientation**; role‑specific training (e.g., mealtime/dysphagia, transport safety); supervision at least quarterly; competency sign‑off before high‑risk tasks.

**Evidence:** Worker Screening Register; Training Matrix; supervision notes.

