# SOP — Plan Management (0127) — Invoice validation & controls

## Controls
- **3‑way match**: service agreement ↔ invoice ↔ price limits (PAPL).  
- **Segregation of duties** for approvals & payments.  
- **Statements** to participants monthly or on request.  
- **Exceptions log** for rejections/queries; fraud red‑flags monitored.

## Steps
1. Onboard: authority to act; budgets confirmed.  
2. Validate invoices: correct item codes, dates, descriptions; price ≤ limits; travel rules; check duplicates.  
3. Claim via portal; pay provider; send participant statement.  
4. Reconcile weekly; escalate anomalies; report trends.

## RACI
- **A:** Finance Lead  
- **R:** Plan Manager  
- **C:** CEO (major exceptions)  
- **I:** Participant/nominee

## Records / Evidence
Invoices, service agreements, statements, reconciliations, exceptions log.

