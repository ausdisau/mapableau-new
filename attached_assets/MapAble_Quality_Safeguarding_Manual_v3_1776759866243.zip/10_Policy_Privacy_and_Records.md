# Privacy, Information & Records

- We follow the Australian Privacy Principles and keep records secure.  
- We keep **audit‑ready records** of supports and **evidence for payment assurance** (invoices, service agreements, delivery evidence).  
- We have a Data Breach Response (contain → assess serious‑harm → notify OAIC/people if required → fix → record).  
- Minimum retention: **7 years** unless law/contract requires longer.

**Evidence:** retention schedule, access controls, breach log, backups, audit files.

