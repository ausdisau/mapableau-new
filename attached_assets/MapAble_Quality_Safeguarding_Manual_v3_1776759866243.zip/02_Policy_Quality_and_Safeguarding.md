# 1. Quality & Safeguarding Policy (human‑centred)

## Purpose
To set out how MapAble ensures **quality supports** and **safeguards people’s rights** in line with the NDIS Practice Standards and Code of Conduct (see references). We use feedback, complaints and incidents to improve.

## Principles (how we behave)
1. **Rights first** — dignity, privacy, choice and control.  
2. **Safety** — zero tolerance for abuse, neglect, exploitation or discrimination; act immediately to make people safe.  
3. **Openness** — we welcome feedback and complaints; we respond promptly and fairly.  
4. **Accessibility** — multiple ways to contact us; Easy Read and interpreters on request.  
5. **Accountability** — clear roles, timeframes, records, and independent oversight.  
6. **Learning** — we analyse trends and fix root causes; we share improvements.

## Scope
All services we deliver (e.g., 0107 Personal Supports, 0108 Transport, 0102 Employment Supports, 0106 Support Coordination, 0127 Plan Management). Everyone working with or for MapAble follows this policy.

## What participants can expect (our commitments)
- Safe, respectful supports that uphold your rights.  
- Clear information about services, prices and cancellations.  
- Real **choice of providers** and help to decide.  
- Easy ways to give feedback or **make a complaint**; we keep you informed.  
- If an **incident** happens, we support you first, then report and learn.  
- Your information is kept private and secure.  
- Staff who are checked (**NDIS Worker Screening**), trained and supervised.

## How to contact us (and others)
- **MapAble**: phone, email, online form, in person.  
- **NDIS Quality & Safeguards Commission** (complaints about providers): **1800 035 544**; online form available.  
- In an emergency: **000**.
