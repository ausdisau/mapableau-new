# SOP — Feedback & Complaints (welcoming and fair)

**Why:** Complaints help us improve. We make it safe and easy to speak up.

## Principles
- **Openness & no detriment:** it’s always OK to complain; it won’t affect your supports.  
- **Confidentiality & respect:** we keep information private.  
- **Responsiveness:** acknowledge within **2 business days**; regular updates; fair outcome.  
- **Choice:** you can bring a support person or advocate; you can complain to the **NDIS Commission** at any time.

## How to make a complaint
- Tell any staff member, or  
- Use our online form / email / phone / in person, or  
- Ask us to help you write it down, or  
- Contact the **NDIS Commission** directly (1800 035 544).

## Steps (what we do)
1. **Receive & record** the complaint; confirm preferred contact & accessibility needs.  
2. **Acknowledge** within **2 business days** (sooner for safety concerns).  
3. **Assess & plan**: low‑complexity → early resolution; complex → proportionate investigation.  
4. **Investigate**: gather information, speak with you respectfully; offer supports.  
5. **Respond**: outcome letter in plain English (what we found, reasons, actions, your options).  
6. **Close & learn**: log actions in our Continuous Improvement register; check satisfaction.  
7. **Appeal**: if unhappy, ask for a review by a senior manager. You can still contact the NDIS Commission.

## RACI
- **Accountable:** Quality & Safeguarding Lead  
- **Responsible:** Service Manager handling the complaint  
- **Consulted:** CEO (for serious/ systemic matters)  
- **Informed:** Participant/nominee; Board via trend reports

## Records / Evidence
Complaints register, correspondence, investigation notes, outcome letters, CI actions.

