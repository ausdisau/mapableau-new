# MapAble Quality & Safeguarding Policy and Procedures Manual
**Version:** v3.0 (quality & safeguarding)  |  **Effective:** 07 Nov 2025  |  **Next review:** 07 Nov 2026  
**Owner:** Quality & Safeguarding Lead  |  **Applies to:** All workers, contractors and volunteers

> **Why this exists**  
> We want every person we support to be safe, respected and in control. This manual explains our commitments and how we act — in everyday practice and when something goes wrong.


**House style (how this is written and how to keep it human):**
- We use *plain English* and talk directly: **we** (MapAble) and **you** (participants, families).
- We lead with **values and principles** (rights, safety, respect, choice) and then set out **what we do**.
- Every procedure is step‑by‑step, with **RACI** so people know who is doing what.
- We give **timeframes** where they matter (e.g., complaints acknowledgement; reportable incidents in 24h/5 business days).
- We include **easy‑read summaries** at the front.
- We finish with **evidence** (what records we keep) and **how we learn** (continuous improvement).


**References we follow** (selected):  
- NDIS Practice Standards & Quality Indicators — https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards  
- Core: Provider governance & operational management — https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards/core-module-provider-governance-and-operational  
- NDIS Code of Conduct — https://www.ndiscommission.gov.au/rules-and-standards/ndis-code-conduct  
- Reportable incidents (24h / 5 business days) — https://www.ndiscommission.gov.au/rules-and-standards/reportable-incidents-and-incident-management/reportable-incidents  
- Worker screening (valid 5 years & NWSD link) — https://www.ndiscommission.gov.au/workforce/worker-screening/worker-screening-registered-providers  
- Safe Transportation Practice Guide (restrictive practices) — https://www.ndiscommission.gov.au/sites/default/files/2024-09/Safe%20Transportation%20Practice%20Guide.pdf  
- Additional condition for 0107 personal supports (participants living alone / sole worker) — https://www.ndiscommission.gov.au/provider-registration/about-registration  
- NDIA travel claiming rules / gap fees update — https://www.ndis.gov.au/news/10827-travel-claiming-rules-gap-fees-and-other-costs  
- Quality practice: Support coordination & Plan management — https://www.ndiscommission.gov.au/rules-and-standards/quality-practice/support-coordination-and-plan-management  
- Privacy & record‑keeping (invoice/claim evidence) — https://www.ndis.gov.au/providers/working-provider/getting-paid/invoicing-and-record-keeping

**Writing approach inspired by**: Style reference: Cerebral Palsy Alliance — Upholding Human Rights Policy (includes Easy Read); Style reference: The Housing Connection — Management of Abuse, Neglect & Injury policy; Style reference: Hireup — Statement on Complaints (principles, openness); Style reference: Mable — Incidents & Complaints Management Policy (guiding principles, timeframes, appeals).
