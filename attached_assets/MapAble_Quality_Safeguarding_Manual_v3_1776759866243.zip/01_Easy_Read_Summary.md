# Easy Read: Your Rights and Safety at MapAble

- **You matter.** You have the right to be safe, respected and to make choices.  
- **It is OK to speak up.** You can tell us what is good or not good. We will listen.  
- **Complaints are welcome.** We say thank you for feedback and fix problems quickly.  
- **Incidents:** If something bad happens, we make you safe first. We will tell the NDIS Commission when we must.  
- **Transport:** We keep you safe in cars and buses. We use seatbelts. We do not use restraints unless the law says it is OK.  
- **Workers:** Our workers have the right checks (NDIS Worker Screening). We train and supervise them.  
- **Your information:** We keep your information private and safe.  
- **Your choices:** We give you real choices of services and help you decide.  
- **Need help to complain?** You can call the NDIS Commission on **1800 035 544** or ask us to help you.

If you need an interpreter or Easy Read versions of other policies, ask us.
