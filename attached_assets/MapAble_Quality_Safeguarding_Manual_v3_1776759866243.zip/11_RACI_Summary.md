# RACI Summary (who does what at a glance)

- **Complaints:** A=Quality Lead; R=Service Manager; C=CEO; I=Participant  
- **Incidents:** A=CEO; R=Service Manager; C=Quality Lead; I=Participant  
- **0107 Living‑Alone safeguard:** A=Service Manager; R=Team Leader; C=Quality Lead; I=Participant  
- **Transport safety & charging:** A=Service Manager (Transport); R=Drivers/Support Workers; C=Quality Lead; I=Participant  
- **Support Coordination:** A=SC Lead; R=Support Coordinator; C=Participant; I=CEO  
- **Plan Management:** A=Finance Lead; R=Plan Manager; C=CEO; I=Participant

