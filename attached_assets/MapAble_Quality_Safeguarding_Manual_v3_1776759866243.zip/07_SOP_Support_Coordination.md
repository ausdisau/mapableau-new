# SOP — Support Coordination (choice, impartiality & risk)

## Principles
- **Genuine choice**: present multiple provider options; document preferences.  
- **Impartiality / COI**: declare and manage conflicts; never steer decisions.  
- **Safety & risk**: have escalation and crisis pathways.

## Steps
1. Engage & consent; explain role & COI approach.  
2. Map supports (informal, mainstream, funded); identify risks & mitigations.  
3. Provide options (≥3 where possible) with pros/cons; record participant choice.  
4. Implement & monitor; keep budgets on track; escalate barriers.  
5. Prepare for plan reviews; provide progress reports when requested.

## RACI
- **A:** Support Coordination Lead  
- **R:** Support Coordinator  
- **C:** Participant/nominee  
- **I:** CEO (for systemic risks)

## Records / Evidence
Options & Choice record, case notes, budgets, reports.

