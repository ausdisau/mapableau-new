# References (key external sources)

- PracticeStandards: NDIS Practice Standards & Quality Indicators — https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards
- CoreGovOps: Core: Provider governance & operational management — https://www.ndiscommission.gov.au/rules-and-standards/ndis-practice-standards/core-module-provider-governance-and-operational
- Reportable: Reportable incidents (24h / 5 business days) — https://www.ndiscommission.gov.au/rules-and-standards/reportable-incidents-and-incident-management/reportable-incidents
- WorkerScreening: Worker screening (valid 5 years & NWSD link) — https://www.ndiscommission.gov.au/workforce/worker-screening/worker-screening-registered-providers
- SafeTransport: Safe Transportation Practice Guide (restrictive practices) — https://www.ndiscommission.gov.au/sites/default/files/2024-09/Safe%20Transportation%20Practice%20Guide.pdf
- 0107Condition: Additional condition for 0107 personal supports (participants living alone / sole worker) — https://www.ndiscommission.gov.au/provider-registration/about-registration
- PAPLTravel: NDIA travel claiming rules / gap fees update — https://www.ndis.gov.au/news/10827-travel-claiming-rules-gap-fees-and-other-costs
- SC_PM_Quality: Quality practice: Support coordination & Plan management — https://www.ndiscommission.gov.au/rules-and-standards/quality-practice/support-coordination-and-plan-management
- Privacy: Privacy & record‑keeping (invoice/claim evidence) — https://www.ndis.gov.au/providers/working-provider/getting-paid/invoicing-and-record-keeping
- CodeOfConduct: NDIS Code of Conduct — https://www.ndiscommission.gov.au/rules-and-standards/ndis-code-conduct
- CPA_HR_Policy: Style reference: Cerebral Palsy Alliance — Upholding Human Rights Policy (includes Easy Read)
- THC_Abuse: Style reference: The Housing Connection — Management of Abuse, Neglect & Injury policy
- Hireup_Complaints: Style reference: Hireup — Statement on Complaints (principles, openness)
- Mable_Incidents: Style reference: Mable — Incidents & Complaints Management Policy (guiding principles, timeframes, appeals)