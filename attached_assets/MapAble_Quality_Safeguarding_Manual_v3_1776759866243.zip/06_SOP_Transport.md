# SOP — Transport Safety & Travel Charging (0108)

## Safety
- Pre‑start vehicle check; licensed & insured drivers.  
- Seatbelts and approved restraints; wheelchair tie‑downs as per manufacturer.  
- If behaviour risks are present, use **positive supports**; any restrictive practice in a vehicle must follow authorisation rules and reporting.

## Charging (PAPL)
- Follow current NDIA travel rules; keep **time, distance, purpose** records.  
- No **gap fees** or surcharges outside the rules; be transparent in service agreements.

## Steps
1. Pre‑trip: check vehicle; confirm route/access needs.  
2. Loading: safe entry/exit; secure aids; fit restraints.  
3. During: safe driving; follow behaviour support plans.  
4. Post‑trip: log time/km; note any incidents; bill per rules.

## RACI
- **A:** Service Manager (Transport)  
- **R:** Driver/Support Worker  
- **C:** Quality & Safeguarding Lead  
- **I:** Participant/nominee

## Records / Evidence
Vehicle pre‑start checklist, transport log, service agreement clauses, invoice/claim support.

