import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertLocationSchema } from "@shared/schema";

const addLocationFormSchema = insertLocationSchema.extend({
  images: z.array(z.string()).optional(),
  accessibilityFeatures: z.array(z.string()).min(1, "Please select at least one accessibility feature"),
});

type AddLocationForm = z.infer<typeof addLocationFormSchema>;

const accessibilityOptions = [
  { id: "ramps", label: "Wheelchair Ramps", icon: "fas fa-wheelchair" },
  { id: "sensory", label: "Sensory Equipment", icon: "fas fa-brain" },
  { id: "fencing", label: "Secure Fencing", icon: "fas fa-shield-alt" },
  { id: "quiet", label: "Quiet Spaces", icon: "fas fa-volume-mute" },
  { id: "autism", label: "Autism Friendly", icon: "fas fa-puzzle-piece" },
  { id: "visual", label: "Visual Support", icon: "fas fa-eye" },
];

const locationTypes = [
  { value: "playground", label: "Playground" },
  { value: "school", label: "School" },
  { value: "therapy", label: "Therapy Centre" },
  { value: "other", label: "Other" },
];

const ageRanges = [
  { value: "0-5", label: "0-5 years" },
  { value: "6-12", label: "6-12 years" },
  { value: "13-18", label: "13-18 years" },
  { value: "all", label: "All ages" },
];

export default function AddLocation() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);

  const form = useForm<AddLocationForm>({
    resolver: zodResolver(addLocationFormSchema),
    defaultValues: {
      accessibilityFeatures: [],
      images: [],
    },
  });

  const createLocationMutation = useMutation({
    mutationFn: async (data: AddLocationForm) => {
      const response = await apiRequest('POST', '/api/locations', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Location has been added successfully. Thank you for helping our community!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/locations'] });
      form.reset();
      setSelectedFeatures([]);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add location. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AddLocationForm) => {
    createLocationMutation.mutate({
      ...data,
      accessibilityFeatures: selectedFeatures,
    });
  };

  const toggleFeature = (featureId: string) => {
    setSelectedFeatures(prev => 
      prev.includes(featureId)
        ? prev.filter(id => id !== featureId)
        : [...prev, featureId]
    );
    form.setValue('accessibilityFeatures', selectedFeatures);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Add an Accessible Location
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Help other families by sharing accessible places in your community. 
              Your contribution makes a real difference.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <i className="fas fa-map-marker-alt text-primary"></i>
                Location Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Basic Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Location Name *</Label>
                    <Input
                      id="name"
                      data-testid="input-location-name"
                      {...form.register('name')}
                      placeholder="e.g., Sunshine Playground"
                    />
                    {form.formState.errors.name && (
                      <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">Location Type *</Label>
                    <Select onValueChange={(value) => form.setValue('type', value)}>
                      <SelectTrigger data-testid="select-location-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {locationTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {form.formState.errors.type && (
                      <p className="text-sm text-destructive">{form.formState.errors.type.message}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Full Address *</Label>
                  <Input
                    id="address"
                    data-testid="input-location-address"
                    {...form.register('address')}
                    placeholder="123 Main Street, Suburb, State, Postcode"
                  />
                  {form.formState.errors.address && (
                    <p className="text-sm text-destructive">{form.formState.errors.address.message}</p>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="latitude">Latitude *</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="any"
                      data-testid="input-latitude"
                      {...form.register('latitude', { valueAsNumber: true })}
                      placeholder="-37.7749"
                    />
                    {form.formState.errors.latitude && (
                      <p className="text-sm text-destructive">{form.formState.errors.latitude.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="longitude">Longitude *</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="any"
                      data-testid="input-longitude"
                      {...form.register('longitude', { valueAsNumber: true })}
                      placeholder="144.8441"
                    />
                    {form.formState.errors.longitude && (
                      <p className="text-sm text-destructive">{form.formState.errors.longitude.message}</p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    data-testid="textarea-description"
                    {...form.register('description')}
                    placeholder="Describe the location and its accessibility features in detail..."
                    rows={4}
                  />
                  {form.formState.errors.description && (
                    <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
                  )}
                </div>

                {/* Accessibility Features */}
                <div className="space-y-4">
                  <Label>Accessibility Features *</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {accessibilityOptions.map((option) => (
                      <div
                        key={option.id}
                        className={`flex items-center space-x-3 p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedFeatures.includes(option.id)
                            ? 'border-primary bg-primary/10'
                            : 'border-border hover:bg-muted'
                        }`}
                        onClick={() => toggleFeature(option.id)}
                        data-testid={`checkbox-feature-${option.id}`}
                      >
                        <Checkbox
                          checked={selectedFeatures.includes(option.id)}
                          onChange={() => {}}
                        />
                        <i className={`${option.icon} text-lg text-primary`}></i>
                        <span className="text-sm font-medium">{option.label}</span>
                      </div>
                    ))}
                  </div>
                  {form.formState.errors.accessibilityFeatures && (
                    <p className="text-sm text-destructive">{form.formState.errors.accessibilityFeatures.message}</p>
                  )}
                </div>

                {/* Optional Information */}
                <div className="space-y-6 pt-6 border-t border-border">
                  <h3 className="text-lg font-semibold">Optional Information</h3>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="ageRange">Suitable Age Range</Label>
                      <Select onValueChange={(value) => form.setValue('ageRange', value)}>
                        <SelectTrigger data-testid="select-age-range">
                          <SelectValue placeholder="Select age range" />
                        </SelectTrigger>
                        <SelectContent>
                          {ageRanges.map((range) => (
                            <SelectItem key={range.value} value={range.value}>
                              {range.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        data-testid="input-phone"
                        {...form.register('phone')}
                        placeholder="(03) 9876 5432"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="website">Website</Label>
                      <Input
                        id="website"
                        data-testid="input-website"
                        {...form.register('website')}
                        placeholder="https://example.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        data-testid="input-email"
                        {...form.register('email')}
                        placeholder="info@example.com"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => window.history.back()}
                    data-testid="button-cancel"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createLocationMutation.isPending}
                    data-testid="button-submit-location"
                    className="flex-1"
                  >
                    {createLocationMutation.isPending ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Adding Location...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-plus mr-2"></i>
                        Add Location
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
