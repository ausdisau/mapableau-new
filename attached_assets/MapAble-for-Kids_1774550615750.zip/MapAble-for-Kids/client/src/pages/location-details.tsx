import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Footer from "@/components/footer";
import StarRating from "@/components/star-rating";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { MapPin, Phone, Globe, Mail, Clock, Users, Star } from "lucide-react";

export default function LocationDetails() {
  const { id } = useParams();
  
  const { data: location, isLoading, error } = useQuery({
    queryKey: ['/api/locations', id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-muted rounded w-1/3"></div>
              <div className="h-64 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded w-2/3"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !location) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-destructive mb-4">Location Not Found</h1>
              <p className="text-muted-foreground mb-4">
                The location you're looking for doesn't exist or has been removed.
              </p>
              <Button onClick={() => window.location.href = '/'}>
                Return Home
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  const getAccessibilityIcon = (feature: string) => {
    const icons: Record<string, string> = {
      ramps: "fas fa-wheelchair",
      sensory: "fas fa-brain",
      fencing: "fas fa-shield-alt",
      quiet: "fas fa-volume-mute",
      autism: "fas fa-puzzle-piece",
      visual: "fas fa-eye"
    };
    return icons[feature] || "fas fa-check";
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex items-center gap-2 text-muted-foreground mb-4">
              <button 
                data-testid="button-back"
                onClick={() => window.history.back()}
                className="hover:text-primary transition-colors"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Back to search
              </button>
            </div>
            
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2" data-testid="text-location-name">
                  {location.name}
                </h1>
                <div className="flex items-center gap-4 text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span data-testid="text-location-address">{location.address}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-accent text-accent" />
                    <span data-testid="text-location-rating">{location.rating || 0}</span>
                    <span>({location.reviewCount || 0} reviews)</span>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button data-testid="button-write-review" className="bg-accent text-accent-foreground hover:bg-accent/90">
                  <i className="fas fa-edit mr-2"></i>
                  Write Review
                </Button>
                <Button data-testid="button-share-location" variant="outline">
                  <i className="fas fa-share-alt mr-2"></i>
                  Share
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Main Info */}
            <div className="lg:col-span-2 space-y-8">
              {/* Images */}
              {location.images && location.images.length > 0 && (
                <div className="grid md:grid-cols-2 gap-4">
                  {location.images.map((image: string, index: number) => (
                    <img
                      key={index}
                      src={image}
                      alt={`${location.name} - Image ${index + 1}`}
                      className="w-full h-64 object-cover rounded-2xl shadow-lg"
                      data-testid={`img-location-${index}`}
                    />
                  ))}
                </div>
              )}

              {/* Description */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-2xl font-semibold mb-4">About This Location</h2>
                  <p className="text-foreground leading-relaxed" data-testid="text-location-description">
                    {location.description}
                  </p>
                </CardContent>
              </Card>

              {/* Accessibility Features */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-2xl font-semibold mb-4">Accessibility Features</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {location.accessibilityFeatures.map((feature: string, index: number) => (
                      <div 
                        key={index}
                        className="flex items-center gap-3 p-3 bg-muted rounded-lg"
                        data-testid={`feature-${feature}`}
                      >
                        <i className={`${getAccessibilityIcon(feature)} text-primary text-lg`}></i>
                        <span className="font-medium capitalize">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Reviews */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-2xl font-semibold mb-6">Reviews</h2>
                  {location.reviews && location.reviews.length > 0 ? (
                    <div className="space-y-6">
                      {location.reviews.map((review: any, index: number) => (
                        <div key={review.id} className="border-b border-border pb-6 last:border-b-0">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                                <span className="text-primary-foreground font-semibold text-sm">
                                  {review.authorName.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <p className="font-medium" data-testid={`text-review-author-${index}`}>
                                  {review.authorName}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {review.childAge && `Parent of child, age ${review.childAge}`}
                                </p>
                              </div>
                            </div>
                            <StarRating rating={review.rating} readonly />
                          </div>
                          <h4 className="font-semibold mb-2" data-testid={`text-review-title-${index}`}>
                            {review.title}
                          </h4>
                          <p className="text-foreground leading-relaxed" data-testid={`text-review-content-${index}`}>
                            {review.content}
                          </p>
                          {review.childNeeds && (
                            <p className="text-sm text-muted-foreground mt-2">
                              Child's needs: {review.childNeeds}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Star className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No reviews yet. Be the first to share your experience!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Contact Info */}
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    {location.phone && (
                      <div className="flex items-center gap-3">
                        <Phone className="w-5 h-5 text-primary" />
                        <span data-testid="text-location-phone">{location.phone}</span>
                      </div>
                    )}
                    {location.email && (
                      <div className="flex items-center gap-3">
                        <Mail className="w-5 h-5 text-primary" />
                        <span data-testid="text-location-email">{location.email}</span>
                      </div>
                    )}
                    {location.website && (
                      <div className="flex items-center gap-3">
                        <Globe className="w-5 h-5 text-primary" />
                        <a 
                          href={location.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                          data-testid="link-location-website"
                        >
                          Visit Website
                        </a>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Quick Info</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Type</span>
                      <Badge variant="secondary" className="capitalize" data-testid="badge-location-type">
                        {location.type}
                      </Badge>
                    </div>
                    {location.ageRange && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Age Range</span>
                        <Badge variant="outline" data-testid="badge-age-range">
                          {location.ageRange}
                        </Badge>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Rating</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-accent text-accent" />
                        <span data-testid="text-rating-summary">{location.rating || 0}/5</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button 
                data-testid="button-get-directions"
                className="w-full" 
                size="lg"
                onClick={() => window.open(`https://maps.google.com/?q=${encodeURIComponent(location.address)}`, '_blank')}
              >
                <MapPin className="w-5 h-5 mr-2" />
                Get Directions
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
