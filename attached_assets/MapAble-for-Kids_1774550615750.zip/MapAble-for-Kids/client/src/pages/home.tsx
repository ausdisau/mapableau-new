import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import SearchSection from "@/components/search-section";
import HolidayPrograms from "@/components/holiday-programs";
import CommunityReviews from "@/components/community-reviews";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      
      {/* Quick Stats */}
      <section className="py-12 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">247</div>
              <div className="text-muted-foreground font-medium">Accessible Locations</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-secondary mb-2">1,324</div>
              <div className="text-muted-foreground font-medium">Parent Reviews</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-accent mb-2">89</div>
              <div className="text-muted-foreground font-medium">Holiday Programs</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-destructive mb-2">15</div>
              <div className="text-muted-foreground font-medium">Cities Covered</div>
            </div>
          </div>
        </div>
      </section>

      <SearchSection />
      <HolidayPrograms />
      <CommunityReviews />
      
      {/* Add Location CTA */}
      <section className="py-16 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-6">
              Know an Accessible Place?
            </h3>
            <p className="text-xl text-primary-foreground/90 mb-8 leading-relaxed">
              Help other families by sharing accessible locations in your community. 
              Together, we can build a comprehensive directory of inclusive spaces.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                data-testid="button-add-location"
                className="bg-white text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white/95 transition-colors flex items-center justify-center space-x-2"
                onClick={() => window.location.href = '/add-location'}
              >
                <i className="fas fa-plus"></i>
                <span>Add a Location</span>
              </button>
              <button 
                data-testid="button-submit-review"
                className="bg-accent text-accent-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-colors flex items-center justify-center space-x-2"
              >
                <i className="fas fa-edit"></i>
                <span>Submit a Review</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
