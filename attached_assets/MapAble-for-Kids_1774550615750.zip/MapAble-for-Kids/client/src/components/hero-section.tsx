import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToMap = () => {
    const mapSection = document.getElementById('map');
    if (mapSection) {
      mapSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="gradient-bg py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-8 h-8 bg-yellow-300 rounded-full opacity-70 animate-bounce"></div>
        <div className="absolute top-20 right-20 w-6 h-6 bg-white rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute bottom-20 left-1/4 w-4 h-4 bg-green-300 rounded-full opacity-80 animate-ping"></div>
        <div className="absolute bottom-10 right-1/3 w-5 h-5 bg-orange-300 rounded-full opacity-70 animate-bounce delay-300"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Every Child Deserves Amazing 
              <span className="text-yellow-300"> Adventures!</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              Find the perfect accessible playgrounds, schools, therapy centres, and fun events near you! 
              Made with ❤️ by families like yours.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                onClick={scrollToMap}
                className="bg-white text-primary px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/95 transition-all hover:scale-105 playful-shadow"
                data-testid="button-find-places-hero"
              >
                <i className="fas fa-map-marker-alt mr-2 text-primary"></i>
                🗺️ Find Places Near Me
              </Button>
              <Button
                onClick={() => window.location.href = '/add-location'}
                className="bg-accent text-accent-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-accent/90 transition-all hover:scale-105 playful-shadow"
                data-testid="button-add-location-hero"
              >
                <i className="fas fa-plus mr-2"></i>
                ⭐ Add a Location
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img 
              src="https://pixabay.com/get/g74bb5f5450cfb6b153c4512e1a61009f79a7f4f4850df793cfd52ad1e993f85a25a203b36abdf205d9f5cf64edd6312486cc6ec49a7daa93193d81ef1b3f92a5_1280.jpg" 
              alt="Children with disabilities playing outdoors" 
              className="rounded-2xl playful-shadow w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
              data-testid="img-hero-1"
            />
            <img 
              src="https://pixabay.com/get/ga3a5352b3f4be91451c0d15e07035e85902a56fe9751fdee11a5f07a5c35d744cb8c89ab86622c1f4df4fc02770a203bf3eaa64cdd1d6332ce3b3ff201371eb7_1280.jpg" 
              alt="Accessible playground equipment" 
              className="rounded-2xl playful-shadow w-full h-48 object-cover hover:scale-105 transition-transform duration-300 delay-100"
              data-testid="img-hero-2"
            />
            <img 
              src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
              alt="Inclusive classroom activities" 
              className="rounded-2xl playful-shadow w-full h-48 object-cover hover:scale-105 transition-transform duration-300 delay-200"
              data-testid="img-hero-3"
            />
            <img 
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
              alt="Modern therapy center" 
              className="rounded-2xl playful-shadow w-full h-48 object-cover hover:scale-105 transition-transform duration-300 delay-300"
              data-testid="img-hero-4"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
