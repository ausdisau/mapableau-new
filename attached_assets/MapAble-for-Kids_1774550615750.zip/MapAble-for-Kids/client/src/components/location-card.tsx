import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import StarRating from "@/components/star-rating";
import { MapPin } from "lucide-react";

interface LocationCardProps {
  location: {
    id: string;
    name: string;
    address: string;
    description: string;
    accessibilityFeatures: string[];
    images: string[];
    rating?: number;
    reviewCount?: number;
    type: string;
  };
}

const getAccessibilityIcon = (feature: string) => {
  const icons: Record<string, string> = {
    ramps: "fas fa-wheelchair",
    sensory: "fas fa-brain",
    fencing: "fas fa-shield-alt",
    quiet: "fas fa-volume-mute",
    autism: "fas fa-puzzle-piece",
    visual: "fas fa-eye"
  };
  return icons[feature] || "fas fa-check";
};

const getFeatureLabel = (feature: string) => {
  const labels: Record<string, string> = {
    ramps: "Ramps",
    sensory: "Sensory",
    fencing: "Fenced",
    quiet: "Quiet",
    autism: "Autism Friendly",
    visual: "Visual Support"
  };
  return labels[feature] || feature;
};

export default function LocationCard({ location }: LocationCardProps) {
  return (
    <Card className="bg-card rounded-2xl playful-shadow overflow-hidden hover:shadow-xl transition-all hover:scale-102 duration-300">
      <div className="grid md:grid-cols-3">
        {location.images && location.images.length > 0 && (
          <img 
            src={location.images[0]} 
            alt={location.name}
            className="w-full h-48 md:h-full object-cover"
            data-testid={`img-location-${location.id}`}
          />
        )}
        <div className={`${location.images && location.images.length > 0 ? 'md:col-span-2' : 'md:col-span-3'} p-6`}>
          <div className="flex items-start justify-between mb-3">
            <div>
              <h5 className="text-xl font-semibold text-foreground" data-testid={`text-location-name-${location.id}`}>
                {location.name}
              </h5>
              <p className="text-muted-foreground" data-testid={`text-location-address-${location.id}`}>
                {location.address}
              </p>
            </div>
            <div className="flex items-center space-x-1">
              <StarRating rating={location.rating || 0} readonly />
              <span className="text-sm text-muted-foreground ml-2" data-testid={`text-location-rating-${location.id}`}>
                {location.rating || 0}
              </span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {location.accessibilityFeatures.slice(0, 3).map((feature, index) => (
              <Badge 
                key={index}
                className="accessibility-badge px-3 py-1 rounded-full text-sm font-medium text-accent-foreground"
                data-testid={`badge-feature-${feature}-${location.id}`}
              >
                <i className={`${getAccessibilityIcon(feature)} mr-1`}></i>
                {getFeatureLabel(feature)}
              </Badge>
            ))}
            {location.accessibilityFeatures.length > 3 && (
              <Badge variant="outline" className="px-3 py-1 rounded-full text-sm">
                +{location.accessibilityFeatures.length - 3} more
              </Badge>
            )}
          </div>
          
          <p className="text-muted-foreground text-sm mb-4 line-clamp-3" data-testid={`text-location-description-${location.id}`}>
            {location.description}
          </p>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center">
              <MapPin className="w-4 h-4 mr-1" />
              <span>2.3 km away</span>
            </span>
            <Button 
              onClick={() => window.location.href = `/location/${location.id}`}
              data-testid={`button-view-details-${location.id}`}
            >
              View Details
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
