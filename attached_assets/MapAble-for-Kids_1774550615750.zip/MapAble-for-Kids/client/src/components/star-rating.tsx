import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number;
  readonly?: boolean;
  onRatingChange?: (rating: number) => void;
  size?: "sm" | "md" | "lg";
}

export default function StarRating({ 
  rating, 
  readonly = false, 
  onRatingChange, 
  size = "md" 
}: StarRatingProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6"
  };

  const stars = Array.from({ length: 5 }, (_, index) => {
    const starValue = index + 1;
    const isFilled = starValue <= rating;
    
    return (
      <button
        key={index}
        type="button"
        disabled={readonly}
        onClick={() => !readonly && onRatingChange?.(starValue)}
        className={`${readonly ? 'cursor-default' : 'cursor-pointer hover:scale-110'} transition-transform`}
        data-testid={`star-${index + 1}`}
      >
        <Star 
          className={`${sizeClasses[size]} ${
            isFilled 
              ? 'star-filled fill-accent text-accent' 
              : 'star-empty text-muted-foreground'
          }`}
        />
      </button>
    );
  });

  return (
    <div className="flex items-center space-x-1" data-testid="star-rating">
      {stars}
    </div>
  );
}
