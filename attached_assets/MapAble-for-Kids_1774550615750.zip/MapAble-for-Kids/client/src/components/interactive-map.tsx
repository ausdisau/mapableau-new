import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Maximize, Layers } from "lucide-react";

interface InteractiveMapProps {
  locations: any[];
}

export default function InteractiveMap({ locations }: InteractiveMapProps) {
  return (
    <Card className="bg-card rounded-2xl shadow-lg overflow-hidden">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h4 className="text-lg font-semibold">Map View</h4>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="sm"
              data-testid="button-expand-map"
            >
              <Maximize className="w-4 h-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              data-testid="button-map-layers"
            >
              <Layers className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      <div className="map-container relative flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground text-lg mb-2">Interactive Map</p>
          <p className="text-sm text-muted-foreground">
            Showing accessible locations near you
          </p>
        </div>
        
        {/* Results count overlay */}
        <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
          <span data-testid="text-results-count">{locations.length}</span> locations found
        </div>
      </div>
    </Card>
  );
}
