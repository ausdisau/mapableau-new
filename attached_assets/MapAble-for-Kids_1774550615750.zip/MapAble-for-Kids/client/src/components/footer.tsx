import logoImage from "@assets/MapAble for Kids_1757211986188.png";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <img 
                src={logoImage} 
                alt="MapAble for KIDS logo" 
                className="w-12 h-12 object-contain"
              />
              <div>
                <h4 className="text-2xl font-bold">MapAble for KIDS</h4>
                <p className="text-sm text-background/70">Accessible places for every child</p>
              </div>
            </div>
            <p className="text-background/80 leading-relaxed">
              Making it easier for families with disabled children to find accessible 
              playgrounds, schools, therapy centres, and inclusive events. 🌟
            </p>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Quick Links</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-find-places">Find Places</a></li>
              <li><a href="#programs" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-programs">Holiday Programs</a></li>
              <li><a href="/add-location" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-add-location">Add Location</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-submit-review">Submit Review</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Resources</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-guide">Accessibility Guide</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-support">Parent Support</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-forum">Community Forum</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-help">Help Center</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="text-lg font-semibold mb-4">Contact</h5>
            <ul className="space-y-2">
              <li className="text-background/80 flex items-center">
                <i className="fas fa-envelope mr-2"></i>
                hello@accessiplay.com
              </li>
              <li className="text-background/80 flex items-center">
                <i className="fas fa-phone mr-2"></i>
                1800 ACCESS
              </li>
              <li className="text-background/80 flex items-center">
                <i className="fas fa-map-marker-alt mr-2"></i>
                Australia-wide
              </li>
            </ul>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-facebook">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-instagram">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-background/80 hover:text-background transition-colors" data-testid="link-footer-twitter">
                <i className="fab fa-twitter text-xl"></i>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-background/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-background/60 text-sm">
            © 2024 MapAble for KIDS. Made with ❤️ by parents, for parents.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-background/60 hover:text-background transition-colors text-sm" data-testid="link-footer-privacy">Privacy Policy</a>
            <a href="#" className="text-background/60 hover:text-background transition-colors text-sm" data-testid="link-footer-terms">Terms of Service</a>
            <a href="#" className="text-background/60 hover:text-background transition-colors text-sm" data-testid="link-footer-accessibility">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
