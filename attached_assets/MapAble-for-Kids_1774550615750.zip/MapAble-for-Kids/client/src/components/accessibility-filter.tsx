import { Card, CardContent } from "@/components/ui/card";

interface AccessibilityFilterProps {
  selectedFilters: string[];
  onFiltersChange: (filters: string[]) => void;
}

const filterOptions = [
  { id: "ramps", label: "Ramps", icon: "fas fa-wheelchair" },
  { id: "sensory", label: "Sensory", icon: "fas fa-brain" },
  { id: "fencing", label: "Fencing", icon: "fas fa-shield-alt" },
  { id: "quiet", label: "Quiet", icon: "fas fa-volume-mute" },
  { id: "autism", label: "Autism", icon: "fas fa-puzzle-piece" },
  { id: "visual", label: "Visual", icon: "fas fa-eye" },
];

export default function AccessibilityFilter({ selectedFilters, onFiltersChange }: AccessibilityFilterProps) {
  const toggleFilter = (filterId: string) => {
    const newFilters = selectedFilters.includes(filterId)
      ? selectedFilters.filter(id => id !== filterId)
      : [...selectedFilters, filterId];
    onFiltersChange(newFilters);
  };

  return (
    <Card className="bg-card rounded-2xl shadow-lg">
      <CardContent className="p-6">
        <h4 className="text-lg font-semibold text-foreground mb-4">Filter by Accessibility Features</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {filterOptions.map((option) => (
            <button
              key={option.id}
              onClick={() => toggleFilter(option.id)}
              className={`flex flex-col items-center space-y-2 p-4 border rounded-lg transition-colors ${
                selectedFilters.includes(option.id)
                  ? 'filter-active border-primary'
                  : 'border-border hover:bg-muted'
              }`}
              data-testid={`filter-${option.id}`}
            >
              <i className={`${option.icon} text-2xl ${
                selectedFilters.includes(option.id) ? 'text-primary-foreground' : 'text-primary'
              }`}></i>
              <span className={`text-sm font-medium ${
                selectedFilters.includes(option.id) ? 'text-primary-foreground' : 'text-foreground'
              }`}>
                {option.label}
              </span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
