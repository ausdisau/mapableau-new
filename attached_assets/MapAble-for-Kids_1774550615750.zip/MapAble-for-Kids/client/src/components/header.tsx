import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import logoImage from "@assets/MapAble for Kids_1757211801014.png";

export default function Header() {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-card shadow-sm border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3" data-testid="link-home">
            <img 
              src={logoImage} 
              alt="MapAble for KIDS logo" 
              className="w-12 h-12 object-contain"
            />
            <div>
              <h1 className="text-2xl font-bold text-primary">MapAble for KIDS</h1>
              <p className="text-sm text-muted-foreground hidden md:block">Accessible places for every child</p>
            </div>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/#map" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-find-places">
              Find Places
            </Link>
            <Link href="/#programs" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-programs">
              Programs
            </Link>
            <Link href="/#reviews" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-resources">
              Resources
            </Link>
            <Link href="/add-location">
              <Button data-testid="button-add-location-header">
                Add Location
              </Button>
            </Link>
          </nav>
          
          <button 
            className="md:hidden bg-primary text-primary-foreground p-2 rounded-lg"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            data-testid="button-mobile-menu"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-border pt-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/#map" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-find-places-mobile">
                Find Places
              </Link>
              <Link href="/#programs" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-programs-mobile">
                Programs
              </Link>
              <Link href="/#reviews" className="text-foreground hover:text-primary font-medium transition-colors" data-testid="link-resources-mobile">
                Resources
              </Link>
              <Link href="/add-location">
                <Button className="w-full" data-testid="button-add-location-mobile">
                  Add Location
                </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
