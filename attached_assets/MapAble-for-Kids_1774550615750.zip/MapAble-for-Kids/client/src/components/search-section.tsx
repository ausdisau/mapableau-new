import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AccessibilityFilter from "@/components/accessibility-filter";
import LocationCard from "@/components/location-card";
import InteractiveMap from "@/components/interactive-map";
import { MapPin, Search } from "lucide-react";

export default function SearchSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [distance, setDistance] = useState("10");

  const { data: locations = [], isLoading } = useQuery({
    queryKey: ['/api/locations', searchQuery, selectedFilters.join(',')],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (selectedFilters.length > 0) params.set('filters', selectedFilters.join(','));
      
      const response = await fetch(`/api/locations?${params}`);
      if (!response.ok) throw new Error('Failed to fetch locations');
      return response.json();
    },
  });

  const handleSearch = () => {
    // The query will automatically refetch due to dependency on searchQuery
  };

  return (
    <section id="map" className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Find Accessible Places</h3>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Search by location and filter by accessibility features to find the perfect place for your child
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="bg-card rounded-2xl shadow-lg p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-foreground mb-2">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                  <Input
                    type="text"
                    placeholder="Enter suburb, postcode, or address"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 pr-4 py-3 text-lg"
                    data-testid="input-search-location"
                  />
                </div>
              </div>
              <div className="md:w-48">
                <label className="block text-sm font-medium text-foreground mb-2">Distance</label>
                <Select value={distance} onValueChange={setDistance}>
                  <SelectTrigger data-testid="select-distance">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 km</SelectItem>
                    <SelectItem value="10">10 km</SelectItem>
                    <SelectItem value="25">25 km</SelectItem>
                    <SelectItem value="50">50 km</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:w-32 flex items-end">
                <Button 
                  onClick={handleSearch} 
                  className="w-full py-3 px-6 text-lg"
                  data-testid="button-search"
                >
                  <Search className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="max-w-4xl mx-auto mb-8">
          <AccessibilityFilter 
            selectedFilters={selectedFilters}
            onFiltersChange={setSelectedFilters}
          />
        </div>

        {/* Map and Results Layout */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Interactive Map */}
          <InteractiveMap locations={locations} />

          {/* Location Results */}
          <div className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-card rounded-2xl p-6 shadow-lg animate-pulse">
                    <div className="flex gap-4">
                      <div className="w-24 h-24 bg-muted rounded-lg"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-muted rounded w-3/4"></div>
                        <div className="h-3 bg-muted rounded w-1/2"></div>
                        <div className="h-3 bg-muted rounded w-2/3"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : locations.length > 0 ? (
              <>
                {locations.map((location: any) => (
                  <LocationCard key={location.id} location={location} />
                ))}
                
                {locations.length > 0 && (
                  <div className="text-center pt-6">
                    <Button 
                      variant="secondary"
                      className="px-8 py-3"
                      data-testid="button-load-more"
                    >
                      Load More Results
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <div className="bg-card rounded-2xl p-12 text-center shadow-lg">
                <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">No locations found</h3>
                <p className="text-muted-foreground mb-6">
                  Try adjusting your search criteria or expanding your search area.
                </p>
                <Button 
                  onClick={() => window.location.href = '/add-location'}
                  data-testid="button-add-first-location"
                >
                  <i className="fas fa-plus mr-2"></i>
                  Add the first location
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
