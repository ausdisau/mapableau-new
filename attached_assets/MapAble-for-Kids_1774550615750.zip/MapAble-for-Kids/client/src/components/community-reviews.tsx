import { Card, CardContent } from "@/components/ui/card";
import StarRating from "@/components/star-rating";

const sampleReviews = [
  {
    id: "1",
    rating: 5,
    content: "Sunshine Playground has been a game-changer for our family. The accessible equipment means my daughter can play alongside her siblings without barriers. The sensory garden is particularly wonderful for children with autism.",
    author: "Sarah H.",
    childInfo: "Parent of Emma, 7"
  },
  {
    id: "2",
    rating: 4,
    content: "The therapy centre staff are incredibly knowledgeable and compassionate. They've helped our son make amazing progress with his motor skills. The quiet spaces are perfect for children who need sensory breaks.",
    author: "Michael R.",
    childInfo: "Parent of Lucas, 5"
  },
  {
    id: "3",
    rating: 5,
    content: "Finding inclusive holiday programs used to be so stressful. This platform made it easy to find programs that truly understand and cater to children with disabilities. The detailed descriptions give me confidence.",
    author: "Jennifer L.",
    childInfo: "Parent of twin boys, 9"
  }
];

export default function CommunityReviews() {
  return (
    <section id="reviews" className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Parents Say</h3>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real reviews from families who have found their perfect accessible places
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sampleReviews.map((review, index) => (
            <Card key={review.id} className="bg-card rounded-2xl p-6 shadow-lg">
              <CardContent className="p-0">
                <div className="mb-4">
                  <StarRating rating={review.rating} readonly />
                </div>
                <p className="text-foreground mb-4 leading-relaxed" data-testid={`text-review-content-${index}`}>
                  "{review.content}"
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground font-semibold text-sm">
                      {review.author.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground" data-testid={`text-review-author-${index}`}>
                      {review.author}
                    </p>
                    <p className="text-sm text-muted-foreground" data-testid={`text-review-child-info-${index}`}>
                      {review.childInfo}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
