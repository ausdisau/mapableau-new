import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, DollarSign } from "lucide-react";

export default function HolidayPrograms() {
  const { data: programs = [], isLoading } = useQuery({
    queryKey: ['/api/programs'],
    queryFn: async () => {
      const response = await fetch('/api/programs?type=holiday');
      if (!response.ok) throw new Error('Failed to fetch programs');
      return response.json();
    },
  });

  const getAccessibilityIcon = (feature: string) => {
    const icons: Record<string, string> = {
      ramps: "fas fa-wheelchair",
      sensory: "fas fa-brain",
      fencing: "fas fa-shield-alt",
      quiet: "fas fa-volume-mute",
      autism: "fas fa-puzzle-piece",
      visual: "fas fa-eye"
    };
    return icons[feature] || "fas fa-check";
  };

  const formatDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
    return `${start.toLocaleDateString('en-US', options)} - ${end.toLocaleDateString('en-US', options)}`;
  };

  const formatTimeRange = (startTime: string, endTime: string) => {
    return `${startTime} - ${endTime}`;
  };

  if (isLoading) {
    return (
      <section id="programs" className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">School Holiday Programs</h3>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Inclusive activities and programs designed for children with disabilities during school breaks
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-muted rounded-2xl overflow-hidden shadow-lg animate-pulse">
                <div className="w-full h-48 bg-muted-foreground/20"></div>
                <div className="p-6 space-y-4">
                  <div className="h-4 bg-muted-foreground/20 rounded w-3/4"></div>
                  <div className="h-3 bg-muted-foreground/20 rounded w-1/2"></div>
                  <div className="h-3 bg-muted-foreground/20 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="programs" className="py-16 bg-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">School Holiday Programs</h3>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Inclusive activities and programs designed for children with disabilities during school breaks
          </p>
        </div>

        {programs.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {programs.map((program: any) => (
              <Card key={program.id} className="bg-muted rounded-2xl overflow-hidden playful-shadow hover:shadow-xl transition-all hover:scale-105 duration-300">
                <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <div className="text-center">
                    <i className="fas fa-calendar text-4xl text-primary mb-2"></i>
                    <p className="text-sm font-medium text-foreground">Holiday Program</p>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-primary text-primary-foreground">
                      {formatDateRange(program.startDate, program.endDate)}
                    </Badge>
                    <span className="text-sm text-muted-foreground" data-testid={`text-program-age-${program.id}`}>
                      Ages {program.ageRange}
                    </span>
                  </div>
                  
                  <h4 className="text-xl font-semibold text-foreground mb-2" data-testid={`text-program-name-${program.id}`}>
                    {program.name}
                  </h4>
                  
                  <p className="text-muted-foreground mb-4 line-clamp-3" data-testid={`text-program-description-${program.id}`}>
                    {program.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {program.accessibilityFeatures.slice(0, 2).map((feature: string, index: number) => (
                      <Badge 
                        key={index}
                        variant="secondary"
                        className="text-sm"
                        data-testid={`badge-program-feature-${feature}-${program.id}`}
                      >
                        <i className={`${getAccessibilityIcon(feature)} mr-1`}></i>
                        {feature}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {formatDateRange(program.startDate, program.endDate)}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {formatTimeRange(program.startTime, program.endTime)}
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      ${program.price}/day
                    </span>
                  </div>
                  
                  <Button 
                    className="w-full"
                    data-testid={`button-learn-more-${program.id}`}
                  >
                    Learn More & Book
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">No Programs Available</h3>
            <p className="text-muted-foreground">
              Check back soon for new holiday programs and activities.
            </p>
          </div>
        )}

        {programs.length > 0 && (
          <div className="text-center mt-12">
            <Button 
              variant="secondary"
              className="px-8 py-3"
              data-testid="button-view-all-programs"
            >
              View All Programs
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
