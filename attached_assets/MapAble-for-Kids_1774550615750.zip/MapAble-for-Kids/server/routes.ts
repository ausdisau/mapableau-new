import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLocationSchema, insertReviewSchema, insertProgramSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Locations
  app.get("/api/locations", async (req, res) => {
    try {
      const { q, filters } = req.query;
      const query = typeof q === 'string' ? q : '';
      const filterArray = typeof filters === 'string' ? filters.split(',').filter(Boolean) : [];
      
      const locations = await storage.searchLocations(query, filterArray);
      
      // Add ratings to locations
      const locationsWithRatings = await Promise.all(
        locations.map(async (location) => {
          const rating = await storage.getLocationRating(location.id);
          const reviews = await storage.getReviewsByLocationId(location.id);
          return { 
            ...location, 
            rating,
            reviewCount: reviews.length
          };
        })
      );
      
      res.json(locationsWithRatings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  app.get("/api/locations/:id", async (req, res) => {
    try {
      const location = await storage.getLocation(req.params.id);
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      const rating = await storage.getLocationRating(location.id);
      const reviews = await storage.getReviewsByLocationId(location.id);
      
      res.json({ 
        ...location, 
        rating,
        reviews: reviews.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch location" });
    }
  });

  app.post("/api/locations", async (req, res) => {
    try {
      const validatedData = insertLocationSchema.parse(req.body);
      const location = await storage.createLocation(validatedData);
      res.status(201).json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid location data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create location" });
    }
  });

  // Reviews
  app.post("/api/reviews", async (req, res) => {
    try {
      const validatedData = insertReviewSchema.parse(req.body);
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Programs
  app.get("/api/programs", async (req, res) => {
    try {
      const { type } = req.query;
      const programs = type 
        ? await storage.getProgramsByType(type as string)
        : await storage.getAllPrograms();
      
      res.json(programs.sort((a, b) => a.startDate.getTime() - b.startDate.getTime()));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch programs" });
    }
  });

  app.post("/api/programs", async (req, res) => {
    try {
      const validatedData = insertProgramSchema.parse(req.body);
      const program = await storage.createProgram(validatedData);
      res.status(201).json(program);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid program data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create program" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
