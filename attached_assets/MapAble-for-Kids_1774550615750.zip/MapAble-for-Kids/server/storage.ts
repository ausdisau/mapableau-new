import { type User, type InsertUser, type Location, type InsertLocation, type Review, type InsertReview, type Program, type InsertProgram } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Locations
  getLocation(id: string): Promise<Location | undefined>;
  getAllLocations(): Promise<Location[]>;
  searchLocations(query: string, filters: string[]): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  updateLocation(id: string, location: Partial<InsertLocation>): Promise<Location | undefined>;

  // Reviews
  getReviewsByLocationId(locationId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  getLocationRating(locationId: string): Promise<number>;

  // Programs
  getAllPrograms(): Promise<Program[]>;
  getProgramsByType(type: string): Promise<Program[]>;
  createProgram(program: InsertProgram): Promise<Program>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private locations: Map<string, Location>;
  private reviews: Map<string, Review>;
  private programs: Map<string, Program>;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.reviews = new Map();
    this.programs = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private async initializeSampleData() {
    // Sample locations
    const sampleLocations: InsertLocation[] = [
      {
        name: "Sunshine Playground",
        type: "playground",
        address: "123 Happy Street, Sunshine, VIC 3020",
        latitude: -37.7749,
        longitude: 144.8441,
        description: "Beautiful playground with wheelchair accessible equipment, sensory play areas, and secure fencing. Perfect for children with mobility and developmental needs.",
        accessibilityFeatures: ["ramps", "sensory", "fencing", "quiet"],
        images: ["https://pixabay.com/get/ge21eb96496cf3eb98688ccae717b63b9053b75a5f9f33fd130ba8ec15f9e7ca851f87f577522413dc10c599fa85fbeae_1280.jpg"],
        phone: "(03) 9876 5432",
        website: "https://sunshineplayground.com.au",
        ageRange: "all"
      },
      {
        name: "Rainbow Therapy Centre",
        type: "therapy",
        address: "456 Wellness Way, Hope Valley, SA 5090",
        latitude: -34.8617,
        longitude: 138.7104,
        description: "Comprehensive therapy services with specialized equipment for children with disabilities. Offering occupational, speech, and physical therapy in a calm environment.",
        accessibilityFeatures: ["ramps", "autism", "quiet", "visual"],
        images: ["https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"],
        phone: "(08) 8234 5678",
        email: "info@rainbowtherapy.com.au",
        ageRange: "0-18"
      },
      {
        name: "Harmony Primary School",
        type: "school",
        address: "789 Education Drive, Learning Hills, NSW 2153",
        latitude: -33.7461,
        longitude: 150.9072,
        description: "Award-winning inclusive primary school with dedicated special education support, accessible facilities, and holiday programs for children with diverse needs.",
        accessibilityFeatures: ["ramps", "sensory", "autism"],
        images: ["https://images.unsplash.com/photo-1544717302-de2939b7ef71?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"],
        phone: "(02) 9876 5432",
        website: "https://harmonyprimary.nsw.edu.au",
        email: "office@harmonyprimary.nsw.edu.au",
        ageRange: "6-12"
      }
    ];

    for (const location of sampleLocations) {
      await this.createLocation(location);
    }

    // Sample programs
    const samplePrograms: InsertProgram[] = [
      {
        name: "Sensory Adventure Camp",
        description: "Fun-filled camp with sensory activities, adaptive sports, and creative arts. Specialized support for children with autism and sensory processing needs.",
        type: "holiday",
        startDate: new Date('2024-07-08'),
        endDate: new Date('2024-07-19'),
        startTime: "09:00",
        endTime: "15:00",
        ageRange: "5-12",
        price: 180,
        accessibilityFeatures: ["autism", "sensory"],
        maxParticipants: 20,
        contactEmail: "camps@sensoryplay.com.au",
        contactPhone: "(03) 9876 1234"
      },
      {
        name: "Adaptive Sports Club",
        description: "Wheelchair basketball, swimming, and other adaptive sports. Professional coaches trained in inclusive sports programs.",
        type: "holiday",
        startDate: new Date('2024-10-01'),
        endDate: new Date('2024-10-12'),
        startTime: "10:00",
        endTime: "16:00",
        ageRange: "6-16",
        price: 150,
        accessibilityFeatures: ["ramps", "visual"],
        maxParticipants: 15,
        contactEmail: "sports@adaptiveclub.com.au",
        contactPhone: "(03) 9876 5678"
      },
      {
        name: "Creative Arts Studio",
        description: "Music therapy, art workshops, and drama activities. Designed for children with intellectual and developmental disabilities.",
        type: "holiday",
        startDate: new Date('2024-12-16'),
        endDate: new Date('2024-12-20'),
        startTime: "09:00",
        endTime: "14:00",
        ageRange: "4-14",
        price: 120,
        accessibilityFeatures: ["autism", "sensory", "quiet"],
        maxParticipants: 12,
        contactEmail: "arts@creativestudio.com.au",
        contactPhone: "(03) 9876 9012"
      }
    ];

    for (const program of samplePrograms) {
      await this.createProgram(program);
    }
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Locations
  async getLocation(id: string): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async getAllLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async searchLocations(query: string, filters: string[]): Promise<Location[]> {
    const allLocations = Array.from(this.locations.values());
    
    let filtered = allLocations;

    // Apply text search
    if (query.trim()) {
      const searchTerm = query.toLowerCase();
      filtered = filtered.filter(location => 
        location.name.toLowerCase().includes(searchTerm) ||
        location.address.toLowerCase().includes(searchTerm) ||
        location.description.toLowerCase().includes(searchTerm)
      );
    }

    // Apply accessibility filters
    if (filters.length > 0) {
      filtered = filtered.filter(location =>
        filters.every(filter => location.accessibilityFeatures.includes(filter))
      );
    }

    return filtered;
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = randomUUID();
    const location: Location = { 
      ...insertLocation, 
      id,
      createdAt: new Date()
    };
    this.locations.set(id, location);
    return location;
  }

  async updateLocation(id: string, locationUpdate: Partial<InsertLocation>): Promise<Location | undefined> {
    const location = this.locations.get(id);
    if (!location) return undefined;

    const updatedLocation = { ...location, ...locationUpdate };
    this.locations.set(id, updatedLocation);
    return updatedLocation;
  }

  // Reviews
  async getReviewsByLocationId(locationId: string): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      review => review.locationId === locationId
    );
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = randomUUID();
    const review: Review = { 
      ...insertReview, 
      id,
      createdAt: new Date()
    };
    this.reviews.set(id, review);
    return review;
  }

  async getLocationRating(locationId: string): Promise<number> {
    const locationReviews = await this.getReviewsByLocationId(locationId);
    if (locationReviews.length === 0) return 0;
    
    const totalRating = locationReviews.reduce((sum, review) => sum + review.rating, 0);
    return Math.round((totalRating / locationReviews.length) * 10) / 10;
  }

  // Programs
  async getAllPrograms(): Promise<Program[]> {
    return Array.from(this.programs.values());
  }

  async getProgramsByType(type: string): Promise<Program[]> {
    return Array.from(this.programs.values()).filter(
      program => program.type === type
    );
  }

  async createProgram(insertProgram: InsertProgram): Promise<Program> {
    const id = randomUUID();
    const program: Program = { 
      ...insertProgram, 
      id,
      createdAt: new Date()
    };
    this.programs.set(id, program);
    return program;
  }
}

export const storage = new MemStorage();
