# AccessiPlay - Accessible Places Platform

## Overview

AccessiPlay is a web platform designed to help families with disabled children find accessible playgrounds, schools, therapy centres, and inclusive events. The application allows users to search for locations by accessibility features, view detailed location information with community reviews, and add new accessible locations to help other families.

The platform features a comprehensive search system with filtering capabilities, community-driven reviews and ratings, holiday programs listing, and a user-friendly interface built with modern React components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Radix UI primitives with custom Tailwind CSS styling (shadcn/ui design system)
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Forms**: React Hook Form with Zod validation
- **Component Structure**: Modular component architecture with reusable UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful API with JSON responses
- **Request Handling**: Express middleware for logging, JSON parsing, and error handling
- **Development**: Vite middleware integration for hot reloading in development
- **Build Process**: ESBuild for server bundling, separate client and server build outputs

### Data Storage Solutions
- **ORM**: Drizzle ORM for database operations and schema management
- **Database**: PostgreSQL (configured for Neon Database serverless)
- **Session Storage**: PostgreSQL session store with connect-pg-simple
- **Development Storage**: In-memory storage implementation for development/testing
- **Schema**: Strongly typed database schema with Zod validation integration

### Authentication and Authorization
- **Session Management**: Express sessions stored in PostgreSQL
- **User Model**: Basic user authentication with username/password
- **Security**: Session-based authentication with secure session configuration

### Data Models
- **Locations**: Name, type, address, coordinates, accessibility features, contact information
- **Reviews**: User ratings, detailed feedback, child-specific information
- **Programs**: Holiday and educational programs with dates, times, and location associations
- **Users**: Basic user accounts for review submission and location management

### External Dependencies
- **Database**: Neon Database (PostgreSQL serverless)
- **Fonts**: Google Fonts (Inter, various display fonts)
- **Icons**: Font Awesome icons
- **Maps**: Placeholder map interface (ready for integration)
- **Images**: External image hosting via URLs
- **Development**: Replit-specific development tooling and error handling

The application uses a monorepo structure with shared TypeScript schemas between client and server, ensuring type safety across the full stack. The build process creates separate bundles for client and server with appropriate optimization for each environment.