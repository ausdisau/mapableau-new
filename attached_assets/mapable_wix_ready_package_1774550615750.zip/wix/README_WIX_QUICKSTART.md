# Wix Quickstart (MapAble)
1) Upload assets:
   - Banners (wix/assets/banners/*) and icons (wix/assets/icons/*) to Wix Media.
   - Give each image alt text (see wix/accessibility/alt_text_templates.txt).
2) Create pages: Home, Care, Transport, Employment, Explore Map, About, Contact.
3) Add your hero banner to each page.
4) Add 2–3 sentences above the embed (copy from wix/copy/*.txt).
5) Insert HTML iframe embed:
   - Care: open wix/embeds/embed_care.html and paste into a Custom Embed (HTML).
   - Transport: embed_transport.html
   - Employment: embed_jobs.html
   - Explore Map: embed_map.html
6) Head code (Wix → Settings → Custom Code → Head):
   - Paste preconnect_snippets.html to speed up embeds.
   - Paste csp.txt as your Content Security Policy (adjust later if needed).
7) Structured data (per page → SEO → Advanced):
   - Employment: paste head/structured_data/jobposting.json
   - Home or About: paste head/structured_data/organization.json
8) SEO (per page → SEO Basics):
   - Copy titles and meta descriptions from wix/seo_meta.txt
9) Accessibility:
   - Run Wix Accessibility Wizard; fix all findings.
   - Use wix/accessibility/wix_checklist.txt before publish.
10) Test:
   - Keyboard only (Tab/Shift+Tab) and on a mid‑range phone.
