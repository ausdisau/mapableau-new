import React from 'react';
import './Dashboard.css';

function Dashboard() {
  return (
    <main className="dashboard">
      <div className="tiles">
        <div className="tile">Book a Carer</div>
        <div className="tile">Find a Job</div>
        <div className="tile">Get Transport</div>
      </div>
      <div className="cards">
        <div className="card">
          <img src="https://via.placeholder.com/150" alt="Worker" />
          <div>Support Worker A</div>
          <div className="tags">Manual handling, Auslan</div>
          <button>View Profile</button>
        </div>
        <div className="card">
          <img src="https://via.placeholder.com/150" alt="Worker" />
          <div>Support Worker B</div>
          <div className="tags">Cultural Safety, Community Access</div>
          <button>Book</button>
        </div>
        <div className="card">
          <img src="https://via.placeholder.com/150" alt="Worker" />
          <div>Support Worker C</div>
          <div className="tags">Transport, Meal Prep</div>
          <button>View Profile</button>
        </div>
      </div>
    </main>
  );
}

export default Dashboard;
