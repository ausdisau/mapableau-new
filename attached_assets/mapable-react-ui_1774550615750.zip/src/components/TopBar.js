import React from 'react';
import './TopBar.css';

function TopBar() {
  return (
    <header className="topbar">
      <div className="logo">MapAble</div>
      <input type="text" className="search-bar" placeholder="Search services..." />
      <div className="user-controls">Accessibility | Login</div>
    </header>
  );
}

export default TopBar;
