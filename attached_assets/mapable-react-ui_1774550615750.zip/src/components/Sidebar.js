import React from 'react';
import './Sidebar.css';

function Sidebar() {
  return (
    <nav className="sidebar">
      <h2>MapAble</h2>
      <ul>
        <li>Dashboard</li>
        <li>Book a Carer</li>
        <li>Find a Job</li>
        <li>Get Transport</li>
        <li>Community</li>
        <li>Marketplace</li>
        <li>Settings</li>
      </ul>
    </nav>
  );
}

export default Sidebar;
