# MapAble NDIS Verification Audit Pack – Upload Pack Template

This pack provides a folder structure + naming conventions + register templates for an **NDIS verification (desktop) audit**.

## Naming convention
`{Area}_{DocType}_{ShortDescription}_{VersionOrDate}.{ext}`
