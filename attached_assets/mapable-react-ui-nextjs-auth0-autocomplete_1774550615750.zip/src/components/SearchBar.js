
import { useRef, useEffect } from 'react';

export default function SearchBar() {
  const inputRef = useRef(null);

  useEffect(() => {
    const loadAutocomplete = () => {
      if (!window.google || !window.google.maps) return;
      new window.google.maps.places.Autocomplete(inputRef.current, {
        types: ['geocode'],
        componentRestrictions: { country: 'au' },
      });
    };

    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places`;
      script.async = true;
      script.onload = loadAutocomplete;
      document.head.appendChild(script);
    } else {
      loadAutocomplete();
    }
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto mt-8">
      <input
        ref={inputRef}
        type="text"
        placeholder="Search by suburb / postcode"
        className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring focus:border-blue-300"
      />
    </div>
  );
}
