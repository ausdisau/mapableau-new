
import Image from 'next/image';
import Link from 'next/link';

export default function TopBar() {
  return (
    <header className="bg-white shadow-md flex items-center justify-between px-6 py-4">
      <Link href="/">
        <div className="flex items-center space-x-3">
          <Image src="/logo.png" alt="MapAble Logo" width=50 height=50 />
          <span className="text-2xl font-bold text-blue-900">MapAble</span>
        </div>
      </Link>
      <nav className="flex space-x-6">
        <Link href="/" className="text-blue-700 hover:underline">Home</Link>
        <Link href="/services" className="text-blue-700 hover:underline">Services</Link>
        <Link href="/about" className="text-blue-700 hover:underline">About</Link>
        <Link href="/api/auth/login" className="bg-blue-700 text-white px-4 py-2 rounded-md hover:bg-blue-800">Login</Link>
      </nav>
    </header>
  );
}
